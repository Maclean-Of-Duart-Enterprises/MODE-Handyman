# MODE Handyman 2.2.2

Open **People and materials → Employee and Subcontractor**, select the person, then choose **Employee setup / export for Time**. The JSON includes the pay rate from their current payroll profile. Time 1.0.4 displays it under **Pay rate** on the worker profile. The file also carries the exact amount in cents, pay basis, and increment for software that reads structured pay information.

To authorize the import, enter the receiving Time device’s current 6–12 digit admin PIN in **Time admin PIN for this JSON**, then export and send the JSON. Leading zeroes are preserved. Time verifies the included PIN when the employee taps **Apply**. Leaving the field empty uses Time’s usual import authorization.

Anyone who receives a JSON containing a PIN can read and reuse it. The PIN is entered for the export and is excluded from employee settings, profile CSVs and MODE’s backup of generated files.
