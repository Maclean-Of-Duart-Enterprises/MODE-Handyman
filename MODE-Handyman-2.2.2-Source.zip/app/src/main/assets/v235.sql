CREATE TABLE mode_followup_settings (
 profile_id INTEGER PRIMARY KEY,
 enabled INTEGER NOT NULL DEFAULT 0,
 invoice_paid INTEGER NOT NULL DEFAULT 1,
 job_finished INTEGER NOT NULL DEFAULT 1,
 facebook_enabled INTEGER NOT NULL DEFAULT 1,
 maps_enabled INTEGER NOT NULL DEFAULT 1,
 facebook_url TEXT NOT NULL DEFAULT '',
 maps_url TEXT NOT NULL DEFAULT '',
 message_template TEXT NOT NULL DEFAULT '',
 once_per_job INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE mode_followup_outbox (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER NOT NULL,
 job_id INTEGER NOT NULL,
 customer_id INTEGER,
 invoice_id INTEGER,
 trigger_kind TEXT NOT NULL,
 event_key TEXT NOT NULL,
 job_created TEXT NOT NULL DEFAULT '',
 invoice_number TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'pending',
 recipient TEXT NOT NULL DEFAULT '',
 body TEXT NOT NULL DEFAULT '',
 attempt_token TEXT NOT NULL DEFAULT '',
 parts_total INTEGER NOT NULL DEFAULT 0,
 error TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
 UNIQUE(profile_id,event_key)
);
CREATE INDEX mode_followup_pending ON mode_followup_outbox(status,id);
CREATE TABLE mode_followup_parts (
 message_id INTEGER NOT NULL,
 attempt_token TEXT NOT NULL,
 part_index INTEGER NOT NULL,
 result_code INTEGER NOT NULL,
 PRIMARY KEY(message_id,attempt_token,part_index)
);
