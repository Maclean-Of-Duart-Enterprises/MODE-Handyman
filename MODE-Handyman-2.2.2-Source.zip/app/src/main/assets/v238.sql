ALTER TABLE mode_payroll_timecard ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0 CHECK(deleted IN (0,1));
ALTER TABLE mode_payroll_worker ADD COLUMN time_setup_json TEXT NOT NULL DEFAULT '{}';
