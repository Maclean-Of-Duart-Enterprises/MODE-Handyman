CREATE TABLE mode_payroll_worker (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER NOT NULL REFERENCES business_profile(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('Employee','Subcontractor')),
 phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '',
 pay_json TEXT NOT NULL, cadence TEXT NOT NULL, anchor_date TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT '', archived INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0,1)),
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(profile_id,id)
);
CREATE INDEX mode_payroll_worker_profile ON mode_payroll_worker(profile_id,archived,name);
CREATE TABLE mode_payroll_timecard (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER NOT NULL,
 worker_id INTEGER NOT NULL,
 period_start TEXT NOT NULL, period_end TEXT NOT NULL, pay_date TEXT NOT NULL,
 cadence TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','rejected','approved')),
 entries_json TEXT NOT NULL, pay_json TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT '', rejection_reason TEXT NOT NULL DEFAULT '',
 revision INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 FOREIGN KEY(profile_id,worker_id) REFERENCES mode_payroll_worker(profile_id,id) ON DELETE RESTRICT,
 UNIQUE(profile_id,id)
);
CREATE INDEX mode_payroll_timecard_worker ON mode_payroll_timecard(profile_id,worker_id,period_end);
CREATE TABLE mode_payroll_stub (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 profile_id INTEGER NOT NULL, worker_id INTEGER NOT NULL, card_id INTEGER NOT NULL,
 revision INTEGER NOT NULL, number TEXT NOT NULL,
 pay_date TEXT NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, cadence TEXT NOT NULL,
 gross_cents INTEGER NOT NULL CHECK(gross_cents>=0), deduction_cents INTEGER NOT NULL CHECK(deduction_cents>=0),
 net_cents INTEGER NOT NULL CHECK(net_cents>=0), employer_cents INTEGER NOT NULL CHECK(employer_cents>=0),
 worked_seconds INTEGER NOT NULL CHECK(worked_seconds>0),
 snapshot_json TEXT NOT NULL, approved_at TEXT NOT NULL, voided_at TEXT NOT NULL DEFAULT '',
 FOREIGN KEY(profile_id,worker_id) REFERENCES mode_payroll_worker(profile_id,id) ON DELETE RESTRICT,
 FOREIGN KEY(profile_id,card_id) REFERENCES mode_payroll_timecard(profile_id,id) ON DELETE RESTRICT,
 UNIQUE(card_id,revision), UNIQUE(profile_id,number), CHECK(gross_cents-deduction_cents=net_cents)
);
CREATE UNIQUE INDEX mode_payroll_one_current_stub ON mode_payroll_stub(card_id) WHERE voided_at='';
CREATE INDEX mode_payroll_stub_worker ON mode_payroll_stub(profile_id,worker_id,pay_date);
