ALTER TABLE mode_followup_outbox ADD COLUMN email TEXT NOT NULL DEFAULT '';
ALTER TABLE mode_followup_outbox ADD COLUMN customer_name TEXT NOT NULL DEFAULT '';
ALTER TABLE mode_followup_outbox ADD COLUMN last_shared_at TEXT NOT NULL DEFAULT '';
UPDATE mode_followup_outbox SET status='pending',error=CASE WHEN status='failed' THEN 'Previous SMS attempt failed; some segments may have been sent. Check your messaging app before sharing. ' || error ELSE '' END WHERE status IN ('blocked','failed');
UPDATE mode_followup_outbox SET status='uncertain',error='Previous automatic SMS attempt; check your messaging app before sharing again.' WHERE status='sending';
UPDATE mode_followup_outbox SET status='shared',error='Previously opened in messaging app; sending is not confirmed.' WHERE status='manual';
