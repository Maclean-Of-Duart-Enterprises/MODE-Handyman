package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode

enum class DiscountType(val stored:String) { AMOUNT("amount"), PERCENT("percent");
    companion object { fun read(value:String)=entries.firstOrNull{it.stored==value}?:throw IllegalArgumentException("Unknown discount type") }
}

/** value is cents for an amount, or hundredths of one percent (1000 = 10%). */
data class DocumentDiscount(val type:DiscountType=DiscountType.AMOUNT,val value:Long=0,val label:String="Discount",val description:String="") {
    init { require(value>=0){"Discount cannot be negative"};require(type!=DiscountType.PERCENT || value<=10000){"Discount percentage must be between 0 and 100"} }
    fun cents(subtotal:Long):Long {
        val base=subtotal.coerceAtLeast(0)
        return (if(type==DiscountType.PERCENT)MoneyMath.percentage(base,value.toInt()) else value).coerceAtMost(base)
    }
    fun inputText():String=BigDecimal.valueOf(value,2).stripTrailingZeros().toPlainString()
    fun displayLabel():String=label.trim().ifBlank{"Discount"}+(if(type==DiscountType.PERCENT)" (${inputText()}%)" else "")
    companion object {
        fun parse(type:DiscountType,text:String,label:String,description:String):DocumentDiscount {
            val clean=text.trim().removePrefix("$").removeSuffix("%").replace(",","")
            val numeric=if(clean.isBlank())BigDecimal.ZERO else BigDecimal(clean)
            require(numeric.signum()>=0){"Discount cannot be negative"}
            require(type!=DiscountType.PERCENT || numeric<=BigDecimal(100)){"Discount percentage must be between 0 and 100"}
            val value=numeric.movePointRight(2).setScale(0,RoundingMode.HALF_UP).longValueExact()
            return DocumentDiscount(type,value,label.trim().ifBlank{"Discount"},description.trim())
        }
        fun taxHundredths(text:String):Int {
            val clean=text.trim().removeSuffix("%").ifBlank{"0"}
            val numeric=BigDecimal(clean);require(numeric.signum()>=0){"Tax cannot be negative"}
            return numeric.movePointRight(2).setScale(0,RoundingMode.HALF_UP).intValueExact()
        }
    }
}
