package com.macleanofduartenterprises.modehandyman

import android.app.Application
import com.macleanofduartenterprises.modehandyman.data.DatabaseManager
import com.macleanofduartenterprises.modehandyman.diagnostics.LocalCrashReporter

class ModeApplication : Application() {
    lateinit var databaseManager: DatabaseManager
        private set

    override fun onCreate() {
        super.onCreate()
        com.macleanofduartenterprises.modehandyman.ui.Ui.configure(this)
        LocalCrashReporter.install(this)
        com.macleanofduartenterprises.modehandyman.ui.Ui.configure(this)
        databaseManager = DatabaseManager(this)
    }
}
