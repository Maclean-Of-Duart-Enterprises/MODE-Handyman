package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

data class PayrollTax(val name:String, val description:String="", val type:String="percent", val value:String="0", val employer:Boolean=false, val enabled:Boolean=true) {
    fun validate() {
        require(name.isNotBlank() && name.length<=120) { "Enter a tax or deduction name (up to 120 characters)" }
        require(description.length<=2000) { "Tax description is too long" }
        require(type in listOf("percent","fixed")) { "Choose percentage or fixed dollars" }
        val amount=Payroll.decimal(value,"Tax value")
        require(amount>=BigDecimal.ZERO && amount<=if(type=="percent") BigDecimal(100) else BigDecimal("10000000")) { "Tax value is out of range" }
        require(amount.scale()<=if(type=="percent") 6 else 2) { "Use at most 6 percentage decimals or 2 dollar decimals" }
    }
}

data class PayrollPay(val rateCents:Long=0, val basis:String="time", val incrementMinutes:Long=60, val incrementLabel:String="hour", val taxes:List<PayrollTax> = emptyList()) {
    fun validate() {
        require(rateCents in 0..1_000_000_000L) { "Pay rate must be between $0 and $10,000,000" }
        require(basis in listOf("time","period")) { "Invalid pay basis" }
        require(incrementMinutes in 1..525600) { "Time increment must be 1–525600 working minutes" }
        require(incrementLabel.isNotBlank() && incrementLabel.length<=100) { "Enter a pay increment label, such as hour" }
        require(taxes.size<=100) { "A maximum of 100 tax/deduction boxes is supported" }
        taxes.forEach { it.validate() }
    }
}

data class PayrollEntry(val date:String, val start:String="", val end:String="", val breakSeconds:Long=0,
                        val durationSeconds:Long=0, val multiplier:String="1", val notes:String="") {
    fun workedSeconds():Long {
        LocalDate.parse(date)
        require(notes.length<=4000) { "Time entry notes are too long" }
        val factor=Payroll.decimal(multiplier,"Pay multiplier")
        require(factor>=BigDecimal("0.01") && factor<=BigDecimal.TEN && factor.scale()<=4) { "Multiplier must be 0.01–10, with at most 4 decimals" }
        require(start.isBlank()==end.isBlank()) { "Enter both clock-in and clock-out, or leave both blank for hours only" }
        require(breakSeconds>=0) { "Unpaid break cannot be negative" }
        val seconds=if(start.isNotBlank()) {
            val a=LocalTime.parse(start);val b=LocalTime.parse(end)
            require(a.nano==0 && b.nano==0) { "Use clock times to whole seconds" }
            var elapsed=ChronoUnit.SECONDS.between(a,b)
            if(elapsed<0) elapsed+=86400
            require(elapsed>0) { "Clock-in and clock-out must differ; split 24-hour shifts into separate entries" }
            elapsed
        } else durationSeconds
        require(seconds in 1..86400 && breakSeconds<seconds) { "Each entry must have positive paid time within 24 hours, with a smaller unpaid break" }
        return seconds-breakSeconds
    }
}

data class PayrollTaxAmount(val tax:PayrollTax, val cents:Long)
data class PayrollCalculation(val workedSeconds:Long, val earnings:List<Long>, val gross:Long, val taxes:List<PayrollTaxAmount>, val deductions:Long, val employerContributions:Long, val net:Long)

object Payroll {
    val cadences=listOf("Weekly","Biweekly","Monthly","Custom")
    fun decimal(text:String,label:String):BigDecimal {
        require(text.trim().matches(Regex("[+-]?\\d+(?:\\.\\d+)?")) && text.trim().length<=24) { "$label must be a plain number" }
        return text.trim().toBigDecimal()
    }
    fun cents(text:String):Long {
        val amount=decimal(text.removePrefix("$"),"Dollar amount")
        require(amount>=BigDecimal.ZERO && amount<=BigDecimal("10000000") && amount.scale()<=2) { "Enter dollars with at most two decimals" }
        return amount.movePointRight(2).longValueExact()
    }
    fun secondsFromHours(text:String):Long {
        val clean=text.trim()
        if(clean.contains(':')) {
            require(clean.matches(Regex("\\d{1,3}:[0-5]\\d(?::[0-5]\\d)?"))) { "Duration must be decimal hours or H:MM[:SS]" }
            val parts=clean.split(':').map(String::toLong)
            return parts[0]*3600+parts[1]*60+parts.getOrElse(2){0}
        }
        val hours=decimal(clean,"Hours")
        require(hours>=BigDecimal.ZERO && hours<=BigDecimal(24)) { "Hours must be 0–24 per entry" }
        return hours.multiply(BigDecimal(3600)).setScale(0,RoundingMode.HALF_UP).longValueExact()
    }
    fun secondsFromMinutes(text:String):Long {
        val value=decimal(text.ifBlank{"0"},"Minutes")
        require(value>=BigDecimal.ZERO && value<=BigDecimal(1440)) { "Minutes must be 0–1440" }
        return value.multiply(BigDecimal(60)).setScale(0,RoundingMode.HALF_UP).longValueExact()
    }
    fun hours(seconds:Long)=BigDecimal(seconds).divide(BigDecimal(3600),6,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    fun minutes(seconds:Long)=BigDecimal(seconds).divide(BigDecimal(60),6,RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    fun duration(seconds:Long):String="${seconds/3600}h ${(seconds%3600)/60}m"+if(seconds%60!=0L) " ${seconds%60}s" else ""
    fun rateLabel(pay:PayrollPay)=MoneyMath.format(pay.rateCents)+if(pay.basis=="period") " / pay period" else " / ${pay.incrementLabel} (${pay.incrementMinutes} working min)"
    fun validatePeriod(start:String,end:String,payDate:String,entries:List<PayrollEntry>) {
        val a=LocalDate.parse(start);val b=LocalDate.parse(end);LocalDate.parse(payDate)
        require(!b.isBefore(a) && ChronoUnit.DAYS.between(a,b)<=366) { "Pay period must be ordered and no longer than 367 days" }
        require(entries.isNotEmpty() && entries.size<=5000) { "A timecard needs 1–5000 time entries" }
        entries.forEachIndexed { i,e ->
            require(LocalDate.parse(e.date) in a..b) { "Entry ${i+1} falls outside the pay period" }
            try { e.workedSeconds() } catch(t:Exception) { throw IllegalArgumentException("Entry ${i+1}: ${t.message}",t) }
        }
        val shifts=entries.filter {it.start.isNotBlank()}.map { e->
            val startSeconds=LocalDate.parse(e.date).atTime(LocalTime.parse(e.start)).toEpochSecond(ZoneOffset.UTC)
            startSeconds to startSeconds+e.workedSeconds()+e.breakSeconds
        }.sortedBy {it.first}
        shifts.zipWithNext().forEach { (previous,next)->require(previous.second<=next.first){"Clock entries overlap, including an overnight shift. Edit the time entries before saving."} }
    }
    fun calculate(pay:PayrollPay,entries:List<PayrollEntry>):PayrollCalculation {
        pay.validate();require(entries.isNotEmpty() && entries.size<=5000) { "Add at least one time entry" }
        val seconds=entries.map { it.workedSeconds() }
        val earnings=entries.mapIndexed { i,e ->
            if(pay.basis=="period") 0L else BigDecimal(pay.rateCents).multiply(BigDecimal(seconds[i])).multiply(decimal(e.multiplier,"Multiplier"))
                .divide(BigDecimal(pay.incrementMinutes*60),0,RoundingMode.HALF_UP).longValueExact()
        }
        val gross=if(pay.basis=="period")pay.rateCents else earnings.fold(0L,Math::addExact)
        require(gross<=10_000_000_000L) { "Gross pay exceeds the supported $100,000,000 per paystub" }
        val taxes=pay.taxes.filter { it.enabled }.map { tax ->
            val amount=decimal(tax.value,"Tax value")
            PayrollTaxAmount(tax,if(tax.type=="fixed")amount.movePointRight(2).longValueExact() else BigDecimal(gross).multiply(amount).divide(BigDecimal(100),0,RoundingMode.HALF_UP).longValueExact())
        }
        val deductions=taxes.filter { !it.tax.employer }.fold(0L){sum,t->Math.addExact(sum,t.cents)}
        val employer=taxes.filter { it.tax.employer }.fold(0L){sum,t->Math.addExact(sum,t.cents)}
        require(deductions<=gross) { "Deductions exceed gross pay. Edit the timecard pay/tax settings before approval." }
        return PayrollCalculation(seconds.sum(),earnings,gross,taxes,deductions,employer,gross-deductions)
    }
}
