package com.macleanofduartenterprises.modehandyman.data

import com.macleanofduartenterprises.modehandyman.core.Payroll
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal

data class TimeJob(val id:Long, val profile:Long, val name:String, val number:String, val address:String) {
    val code get() = "MODE-$profile-$id"
    val caption get() = "$code · $name"
    val label get() = listOf(number,name).filter { it.isNotBlank() }.joinToString(" · ")
}

data class JobOptions(val route:String="", val multiplier:String="1", val hours:String="") {
    fun json() = JSONObject().put("route",route).put("multiplier",multiplier).put("hours",hours)
    fun validate() {
        val n = Payroll.decimal(multiplier,"Job multiplier")
        require(n >= BigDecimal("0.01") && n <= BigDecimal.TEN && n.scale() <= 4 && multiplier.matches(Regex("\\d+(\\.\\d{1,4})?"))) { "Use a job multiplier from 0.01 to 10." }
        TimeSetupExport.limit(hours, null)
        require(route.length<=10000) { "Shorten the routing destination." }
    }
    companion object {
        fun from(json:JSONObject) = JobOptions(json.optString("route"),json.optString("multiplier","1"),json.optString("hours"))
    }
}

object TimeSetupExport {
    fun limit(text:String, max:Int?) {
        if (text.isEmpty()) return
        val n = Payroll.decimal(text,"Hour limit")
        require(n.signum()>0 && (max==null || n <= BigDecimal(max)) && n.scale()<=2) {
            "Enter positive hours with up to two decimals"+(max?.let { ", up to $it." } ?: ".")
        }
    }
    private fun destination(job:TimeJob, options:JobOptions) = options.route.ifBlank { job.address }
    private fun validate(job:TimeJob, options:JobOptions) {
        options.validate()
        require(job.name.isNotBlank() && job.name.length<=250 && job.name.none { it=='\r' || it=='\n' }) { "Give the job a single-line name of up to 250 characters before exporting." }
        require(job.number.length<=10000 && destination(job,options).length<=10000) { "Shorten the job number or site address before exporting." }
    }
    private fun workerFields(w:PayrollWorker,daily:String,weekly:String) = linkedMapOf(
        "Phone" to w.phone, "Email" to w.email, "Address" to w.address, "Kind" to w.kind,
        "Daily hour limit" to daily, "Weekly hour limit" to weekly
    )
    fun setup(w:PayrollWorker, jobs:List<Pair<TimeJob,JobOptions>>, daily:String, weekly:String, adminPin:String=""):String {
        limit(daily,24); limit(weekly,168)
        require(adminPin.isEmpty() || adminPin.matches(Regex("[0-9]{6,12}"))) { "Enter the existing 6–12 digit admin PIN from the receiving Time device." }
        require(jobs.size<=1000) { "Time accepts up to 1,000 jobs per setup file." }
        val worker=JSONObject().put("name",w.name).put("employee_id",w.id.toString())
            .put("business_profile_id",w.profile.toString()).put("phone",w.phone).put("email",w.email)
            .put("address",w.address).put("kind",w.kind)
            .put("pay",PayrollCodec.rate(w.pay))
            .put("fields",JSONObject().put("Pay rate",Payroll.rateLabel(w.pay)).put("Daily hour limit",daily).put("Weekly hour limit",weekly))
        val records = JSONArray()
        jobs.forEach { (job, options) ->
            require(job.profile==w.profile)
            validate(job,options)
            records.put(JSONObject().put("job_code",job.code).put("job_name",job.name)
                .put("job_site_address",destination(job,options)).put("multiplier",options.multiplier)
                .put("fields",JSONObject().put("MODE job number",job.number).put("Job hour limit",options.hours)))
        }
        val result=JSONObject().put("format","time.setup.v1").put("employees",JSONArray().put(worker)).put("jobs",records)
            .apply { if(adminPin.isNotEmpty())put("admin_password",adminPin) }.toString(2)
        require(result.toByteArray(Charsets.UTF_8).size<=16*1024*1024) { "Choose fewer jobs to fit Time's 16 MiB file limit." }
        return result
    }
    private fun csv(rows:List<List<String>>):String {
        val result=rows.joinToString("\r\n",postfix="\r\n") { row ->
            row.joinToString(",") { "\"" + it.replace("\"","\"\"") + "\"" }
        }
        require(result.length<=2_000_000 && rows.size<=5001) { "Select fewer jobs to fit Time's CSV limit." }
        return result
    }
    fun workerCsv(w:PayrollWorker,daily:String,weekly:String):String {
        limit(daily,24); limit(weekly,168)
        val fields=workerFields(w,daily,weekly)
        return csv(listOf(listOf("employee_name","employee_id","business_profile_id")+fields.keys,
            listOf(w.name,w.id.toString(),w.profile.toString())+fields.values))
    }
    fun jobsCsv(jobs:List<Pair<TimeJob,JobOptions>>):String {
        require(jobs.isNotEmpty()) { "Select at least one job." }
        return csv(listOf(listOf("job_name","job_code","multiplier","Site address","MODE job number","Job hour limit"))+
            jobs.map { (j,o) -> validate(j,o); listOf(j.name,j.code,o.multiplier,destination(j,o),j.number,o.hours) })
    }
    // Time 1.0.4 puts this caption on the first line of shift notes in its payroll CSV.
    fun jobCaption(notes:String) = notes.lineSequence().first().takeIf { it.startsWith("Job: ") }?.removePrefix("Job: ")?.trim().orEmpty()
}
