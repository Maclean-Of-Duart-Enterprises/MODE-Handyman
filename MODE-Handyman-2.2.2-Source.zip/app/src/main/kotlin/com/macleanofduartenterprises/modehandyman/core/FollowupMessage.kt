package com.macleanofduartenterprises.modehandyman.core

import java.net.URI

data class FollowupSettings(
    val enabled:Boolean=false,val invoicePaid:Boolean=true,val jobFinished:Boolean=true,
    val facebook:Boolean=true,val maps:Boolean=true,val facebookUrl:String="",val mapsUrl:String="",
    val template:String=DEFAULT_TEMPLATE,val oncePerJob:Boolean=true
) {
    fun validate() {
        if(!enabled)return
        require(invoicePaid||jobFinished){"Choose at least one draft trigger"}
        require(facebook||maps){"Choose Facebook, Google Maps, or both"}
        require(template.isNotBlank()){"Enter a customer message"}
        require(template.length<=2000){"Keep the message template under 2,000 characters"}
        if(facebook)FollowupMessage.requireLink(facebookUrl,"Facebook")
        if(maps)FollowupMessage.requireLink(mapsUrl,"Google Maps")
    }
    fun allows(kind:String)=enabled && when(kind){"invoice_paid"->invoicePaid;"job_finished"->jobFinished;else->false}
    companion object {const val DEFAULT_TEMPLATE="Thank you for choosing {business}, {customer}! We appreciate your business. Please share your feedback or follow our page using the links below."}
}

object FollowupMessage {
    fun requireLink(link:String,label:String) {
        require(link.length<=2048){"$label link is too long; use a shorter share/review link"}
        val uri=runCatching{URI(link.trim())}.getOrNull()
        require(uri!=null && uri.scheme?.lowercase() in listOf("https","http") && !uri.host.isNullOrBlank() && uri.userInfo==null && link.none{it.isWhitespace()||it.isISOControl()}){"Enter a complete http(s) $label link"}
    }
    fun phone(value:String):String {
        val clean=value.trim()
        require(clean.matches(Regex("\\+?[0-9 ().-]+"))){"Customer phone must contain a phone number without extensions"}
        val digits=clean.filter{it in '0'..'9'}
        require(digits.length in 7..15){"Customer phone must contain 7 to 15 digits"}
        return (if(clean.startsWith("+"))"+" else "")+digits
    }
    fun render(settings:FollowupSettings,values:Map<String,String>):String {
        settings.validate()
        val body=Regex("\\{(customer|business|job|invoice|event)\\}").replace(settings.template){values[it.groupValues[1]].orEmpty()}.trim()
        val lines=mutableListOf(body)
        if(settings.facebook && settings.facebookUrl.isNotBlank() && !body.contains(settings.facebookUrl.trim()))lines+="Facebook: ${settings.facebookUrl.trim()}"
        if(settings.maps && settings.mapsUrl.isNotBlank() && !lines.joinToString("\n").contains(settings.mapsUrl.trim()))lines+="Google Maps: ${settings.mapsUrl.trim()}"
        return lines.joinToString("\n\n")
    }
}
