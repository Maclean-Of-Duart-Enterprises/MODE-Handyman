package com.macleanofduartenterprises.modehandyman.core

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

data class PayrollImport(val entries:List<PayrollEntry>,val employeeId:String="",val employeeName:String="",val profileId:String="",val periodStart:String="",val periodEnd:String="",val payDate:String="",val cadence:String="")

/** RFC 4180 quoting, UTF-8 BOM, comma/semicolon/tab headers, and explicit validation. */
object PayrollCsv {
    const val MAX_CHARS=2_000_000
    private fun key(value:String)=value.trim().lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"),"_").trim('_')
    private val aliases=mapOf("work_date" to "date","start_time" to "start","clock_in" to "start","time_in" to "start",
        "end_time" to "end","clock_out" to "end","time_out" to "end","total_hours" to "hours","duration" to "hours",
        "unpaid_break_minutes" to "break_minutes","break" to "break_minutes","breaks" to "break_minutes",
        "pay_multiplier" to "multiplier","note" to "notes","worker_id" to "employee_id","worker_name" to "employee_name")
    fun parse(text:String):PayrollImport {
        require(text.length<=MAX_CHARS) { "CSV must be smaller than 2 MB" }
        val clean=text.removePrefix("\uFEFF")
        val header=clean.lineSequence().firstOrNull().orEmpty()
        val delimiter=listOf(',', ';', '\t').maxBy { d->header.count { it==d } }
        val records=records(clean,delimiter).filter { row->row.any { it.isNotBlank() } }
        require(records.size>=2) { "CSV needs column headings and at least one time entry" }
        require(records.size<=5001) { "CSV supports a maximum of 5000 time entries" }
        val columns=records.first().map { aliases[key(it)]?:key(it) }
        require(columns.distinct().size==columns.size) { "CSV contains duplicate column headings" }
        require("date" in columns) { "CSV needs a date or work_date column (YYYY-MM-DD)" }
        require("hours" in columns || "worked_seconds" in columns || ("start" in columns && "end" in columns)) { "CSV needs hours, worked_seconds, or start and end columns" }
        val ids=mutableSetOf<String>();val names=mutableSetOf<String>();val profiles=mutableSetOf<String>()
        val periodStarts=mutableSetOf<String>();val periodEnds=mutableSetOf<String>();val payDates=mutableSetOf<String>();val cadences=mutableSetOf<String>()
        val entries=records.drop(1).mapIndexed { rowIndex,row ->
            try {
                require(row.size<=columns.size) { "Too many cells for the header; quote commas inside text" }
                val values=columns.mapIndexed { i,k->k to row.getOrElse(i){""}.let {if(k=="notes")it else it.trim()} }.toMap()
                fun value(name:String)=values[name].orEmpty()
                value("employee_id").takeIf(String::isNotBlank)?.let(ids::add)
                value("employee_name").takeIf(String::isNotBlank)?.let(names::add)
                value("business_profile_id").takeIf(String::isNotBlank)?.let(profiles::add)
                value("period_start").takeIf(String::isNotBlank)?.let{periodStarts.add(date(it))}
                value("period_end").takeIf(String::isNotBlank)?.let{periodEnds.add(date(it))}
                value("pay_date").takeIf(String::isNotBlank)?.let{payDates.add(date(it))}
                value("pay_schedule").takeIf(String::isNotBlank)?.let{schedule->require(schedule in Payroll.cadences){"Unknown pay_schedule"};cadences.add(schedule)}
                val date=date(value("date"));val start=clock(value("start"));val end=clock(value("end"))
                val breakSeconds=Payroll.secondsFromMinutes(value("break_minutes"))
                val suppliedSeconds=value("worked_seconds").takeIf(String::isNotBlank)?.let {
                    require(it.matches(Regex("\\d{1,6}"))) { "worked_seconds must be whole nonnegative seconds" };it.toLong()
                }
                val suppliedHours=value("hours").takeIf(String::isNotBlank)?.let(Payroll::secondsFromHours)
                if(suppliedHours!=null && suppliedSeconds!=null)require(abs(suppliedHours-suppliedSeconds)<=1) { "hours and worked_seconds disagree" }
                val net=suppliedSeconds?:suppliedHours
                require(start.isNotBlank() || net!=null) { "Enter hours or worked_seconds for a duration-only entry" }
                val entry=PayrollEntry(date,start,end,breakSeconds,if(start.isBlank()) Math.addExact(net?:0,breakSeconds) else 0,
                    value("multiplier").ifBlank{"1"},value("notes"))
                val actual=entry.workedSeconds()
                if(net!=null)require(abs(actual-net)<=1) { "Clock times minus break disagree with hours/worked_seconds" }
                entry
            } catch(t:Exception) {throw IllegalArgumentException("CSV row ${rowIndex+2}: ${t.message}",t)}
        }
        require(ids.size<=1 && profiles.size<=1 && (ids.isNotEmpty() || names.map { it.lowercase(Locale.ROOT) }.distinct().size<=1)) { "Import one employee and one business per CSV" }
        require(listOf(periodStarts,periodEnds,payDates,cadences).all{it.size<=1}) { "Import one pay period and pay date per CSV" }
        val first=periodStarts.firstOrNull().orEmpty();val last=periodEnds.firstOrNull().orEmpty();val paid=payDates.firstOrNull().orEmpty()
        if(first.isNotBlank() && last.isNotBlank())Payroll.validatePeriod(first,last,paid.ifBlank{last},entries)
        return PayrollImport(entries,ids.firstOrNull().orEmpty(),names.firstOrNull().orEmpty(),profiles.firstOrNull().orEmpty(),first,last,paid,cadences.firstOrNull().orEmpty())
    }
    private fun date(value:String):String {
        if(value.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))return LocalDate.parse(value).toString()
        require(value.matches(Regex("\\d{1,2}/\\d{1,2}/\\d{4}"))) { "Dates must be YYYY-MM-DD or M/D/YYYY" }
        return LocalDate.parse(value,DateTimeFormatter.ofPattern("M/d/uuuu").withResolverStyle(java.time.format.ResolverStyle.STRICT)).toString()
    }
    private fun clock(value:String):String {
        if(value.isBlank())return ""
        val format=when {
            value.matches(Regex("\\d{1,2}:\\d{2}:\\d{2}"))->"H:mm:ss"
            value.matches(Regex("\\d{1,2}:\\d{2}"))->"H:mm"
            value.matches(Regex("\\d{1,2}:\\d{2} ?[APap][Mm]"))->"h:mm a"
            else->error("Clock times must be HH:MM[:SS] or h:mm AM/PM")
        }
        val normal=if(format=="h:mm a")value.uppercase(Locale.ROOT).replace(Regex(" ?([AP]M)$")," $1") else value
        return LocalTime.parse(normal,DateTimeFormatter.ofPattern(format,Locale.US).withResolverStyle(java.time.format.ResolverStyle.STRICT)).toString()
    }
    fun export(entries:List<PayrollEntry>,employeeId:Long,employeeName:String,profileId:Long,periodStart:String="",periodEnd:String="",payDate:String="",cadence:String=""):String {
        val rows=mutableListOf(listOf("employee_id","employee_name","business_profile_id","date","start","end","break_minutes","hours","worked_seconds","multiplier","notes","period_start","period_end","pay_date","pay_schedule"))
        entries.forEach { e->val seconds=e.workedSeconds();rows+=listOf(employeeId.toString(),employeeName,profileId.toString(),e.date,e.start,e.end,Payroll.minutes(e.breakSeconds),Payroll.hours(seconds),seconds.toString(),e.multiplier,e.notes,periodStart,periodEnd,payDate,cadence) }
        return rows.joinToString("\r\n",postfix="\r\n") { row->row.joinToString(",") { quote(it) } }
    }
    fun template()="date,start,end,break_minutes,hours,multiplier,notes\r\n2026-11-16,08:00,16:30,30,,1,Example shift\r\n"
    private fun quote(value:String)="\""+value.replace("\"","\"\"")+"\""
    private fun records(text:String,delimiter:Char):List<List<String>> {
        val rows=mutableListOf<List<String>>();var row=mutableListOf<String>();val cell=StringBuilder()
        var quoted=false;var closed=false;var i=0
        fun field(){row+=cell.toString();cell.setLength(0);closed=false}
        fun record(){field();rows+=row;row=mutableListOf();require(rows.size<=5002){"CSV has too many rows"}}
        while(i<text.length) {
            val c=text[i]
            if(quoted) {
                if(c=='"') {if(i+1<text.length && text[i+1]=='"'){cell.append('"');i++}else{quoted=false;closed=true}}
                else cell.append(c)
            } else when(c) {
                '"'->{require(cell.isEmpty() && !closed){"Unexpected quote in CSV; quote the entire cell"};quoted=true}
                delimiter->field()
                '\r','\n'->{record();if(c=='\r' && i+1<text.length && text[i+1]=='\n')i++}
                else->{require(!closed || c==' '){"Unexpected text after closing CSV quote"};if(!closed)cell.append(c)}
            }
            require(cell.length<=10000 && row.size<=100) { "CSV cell or column count exceeds the supported limit" }
            i++
        }
        require(!quoted) { "CSV has an unclosed quoted field" }
        if(cell.isNotEmpty() || row.isNotEmpty() || closed)record()
        return rows
    }
}
