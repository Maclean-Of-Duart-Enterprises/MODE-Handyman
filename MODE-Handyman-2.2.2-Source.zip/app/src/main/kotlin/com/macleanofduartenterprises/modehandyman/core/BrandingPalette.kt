package com.macleanofduartenterprises.modehandyman.core

import kotlin.math.pow

/** Accessible interface colors derived from a profile's document colors. */
data class BrandingPalette(val background:Int,val surface:Int,val accent:Int,val accentText:Int,val highlight:Int) {
    companion object {
        fun blend(first:Int,second:Int,fraction:Double):Int {
            fun channel(shift:Int)=((((first ushr shift) and 255)*(1-fraction)+((second ushr shift) and 255)*fraction).toInt().coerceIn(0,255)) shl shift
            return 0xff000000.toInt() or channel(16) or channel(8) or channel(0)
        }
        fun contrast(first:Int,second:Int):Double {
            fun luminance(color:Int):Double {
                fun channel(shift:Int):Double {val s=((color ushr shift) and 255)/255.0;return if(s<=0.04045)s/12.92 else ((s+0.055)/1.055).pow(2.4)}
                return 0.2126*channel(16)+0.7152*channel(8)+0.0722*channel(0)
            }
            val a=luminance(first);val b=luminance(second)
            return (maxOf(a,b)+0.05)/(minOf(a,b)+0.05)
        }
        fun from(ink:Int,accent:Int):BrandingPalette {
            val black=0xff000000.toInt();val white=0xffffffff.toInt()
            val background=blend(ink,black,0.65)
            val opaqueAccent=accent or black
            val accentText=if(contrast(opaqueAccent,black)>=contrast(opaqueAccent,white))black else white
            val surface=blend(background,white,0.06)
            val highlight=if(minOf(contrast(opaqueAccent,background),contrast(opaqueAccent,surface))>=4.5)opaqueAccent else white
            return BrandingPalette(background,surface,opaqueAccent,accentText,highlight)
        }
    }
}
