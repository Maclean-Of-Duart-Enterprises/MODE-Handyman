package com.macleanofduartenterprises.modehandyman.export

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.macleanofduartenterprises.modehandyman.core.DocumentLine
import com.macleanofduartenterprises.modehandyman.core.MoneyMath
import java.io.File

object PdfGenerator {
    /** A profile-branded, paginated PDF export for financial report rows. */
    fun createReport(context: Context, title: String, business: String, dateLabel: String,
                     rows: List<com.macleanofduartenterprises.modehandyman.core.ListRow>,
                     details: Map<String,String>, logo: File?): File {
        val directory=File(context.filesDir,"exports").apply { mkdirs() }
        val filename="report-"+title.lowercase().replace(Regex("[^a-z0-9-]"),"-")+"-"+System.currentTimeMillis()+".pdf"
        val target=File(directory,filename)
        val pdf=PdfDocument()
        val ink=0xff233243.toInt(); val accent=0xffaa8930.toInt()
        val normal=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=ink;textSize=10f }
        val small=Paint(normal).apply { textSize=8f;color=0xff667381.toInt() }
        val heading=Paint(normal).apply { textSize=18f;typeface=Typeface.DEFAULT_BOLD;color=accent }
        var number=0
        var page:PdfDocument.Page?=null
        var canvas:Canvas?=null
        var y=0f
        fun start() {
            if(page!=null) pdf.finishPage(page!!)
            number++
            page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,number).create())
            canvas=page!!.canvas
            y=50f
            if(number==1) {
                if(logo!=null && logo.isFile && logo.length() in 1..8_000_000) {
                    val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
                    BitmapFactory.decodeFile(logo.absolutePath,bounds)
                    if(bounds.outWidth in 1..12000 && bounds.outHeight in 1..12000) {
                        var sample=1
                        while(maxOf(bounds.outWidth/sample,bounds.outHeight/sample)>800) sample*=2
                        val bitmap=BitmapFactory.decodeFile(logo.absolutePath,BitmapFactory.Options().apply { inSampleSize=sample })
                        if(bitmap!=null) try {
                            val scale=minOf(160f/bitmap.width,70f/bitmap.height)
                            canvas!!.drawBitmap(bitmap,null,RectF(550f-bitmap.width*scale,35f,550f,35f+bitmap.height*scale),null)
                        } finally { bitmap.recycle() }
                    }
                }
                canvas!!.drawText(business,44f,y,heading);y+=21f
                canvas!!.drawText("A division of Maclean Of Duart Enterprises Corp",44f,y,small);y+=14f
                listOf("address_line_1","address_line_2","suburb","state","postcode","mobile_number","email_address")
                    .mapNotNull { details[it]?.takeIf(String::isNotBlank) }.forEach {
                        canvas!!.drawText(it.take(75),44f,y,small);y+=12f
                    }
                y=maxOf(y,130f)
                y+=22f
            }
            canvas!!.drawText(title+if(number>1)" (continued)" else "",44f,y,heading);y+=22f
            canvas!!.drawText(dateLabel,44f,y,small);y+=25f
            canvas!!.drawLine(44f,y,550f,y,normal);y+=18f
        }
        fun finishPage() {
            canvas!!.drawLine(44f,790f,550f,790f,small)
            canvas!!.drawText("$business  •  Page $number",44f,805f,small)
        }
        try {
            start()
            if(rows.isEmpty()) { canvas!!.drawText("No records for this business profile.",44f,y,normal) }
            rows.forEach { row ->
                val subtitle=row.subtitle.take(105)
                val height=if(subtitle.isBlank())35f else 49f
                if(y+height>775f) { finishPage();start() }
                canvas!!.drawText(row.title.take(65),44f,y,normal)
                val amount=row.trailing.take(35)
                canvas!!.drawText(amount,550f-normal.measureText(amount),y,normal)
                if(subtitle.isNotBlank()) canvas!!.drawText(subtitle,44f,y+15f,small)
                y+=height
                canvas!!.drawLine(44f,y-12f,550f,y-12f,small)
            }
            finishPage();pdf.finishPage(page!!)
            target.outputStream().use { pdf.writeTo(it) }
            return target
        } finally { pdf.close() }
    }

    data class ApprovalBlock(
        val signer: String,
        val consent: String,
        val approvedAt: String,
        val signature: File
    )

    data class Document(
        val kind: String,
        val number: String,
        val business: String,
        val customer: String,
        val customerDetails: List<String> = emptyList(),
        val job: String,
        val jobSiteAddress: String = "",
        val dateLabel: String,
        val lines: List<DocumentLine>,
        val subtotal: Long,
        val discount: Long = 0,
        val discountLabel:String="Discount",
        val discountDescription:String="",
        val tax: Long = 0,
        val total: Long,
        val paidAmount: Long? = null,
        val balanceDue: Long? = null,
        val terms: String = "",
        val businessDetails: Map<String, String> = emptyMap(),
        val parentCompany: String = "",
        val attachments: List<File> = emptyList(),
        val approval: ApprovalBlock? = null,
        val logo: File? = null
    )

    fun create(context: Context, document: Document): File {
        val directory = File(context.filesDir, "exports").apply { mkdirs() }
        val safeKind = document.kind.lowercase().replace(Regex("[^a-z0-9._-]"), "-")
        val safeNumber = document.number.replace(Regex("[^A-Za-z0-9._-]"), "-")
        val target = File(directory, "$safeKind-$safeNumber.pdf")
        val pdf = PdfDocument()
        val width = 595; val height = 842; val left = 44f; val right = 551f
        val branding = BrandingStore.load(context, document.businessDetails["_profile_id"].orEmpty())
        val layout=if(document.kind.equals("Invoice",true)||document.kind.equals("Quote",true))branding.documentLayout else FULL_BACKGROUND
        val headerOnly=layout==HEADER_ONLY
        val ink = branding.ink; val gold = branding.accent; val muted = 0xff667381.toInt()
        fun textPaint(size: Float, color: Int = ink, heavy: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = if (heavy) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        val body = textPaint(10f); val small = textPaint(8.5f, muted); val bold = textPaint(10f, ink, true)
        val rule = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xffd7dce0.toInt(); strokeWidth = 1f }
        var pageNumber = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(width,height,pageNumber).create())
        var canvas: Canvas = page.canvas
        var y = 45f

        fun write(text: String, x: Float, baseline: Float, paint: Paint = body) = canvas.drawText(text,x,baseline,paint)
        fun wrap(value: String, paint: Paint, available: Float): List<String> {
            val result = mutableListOf<String>()
            value.replace("\r","").split("\n").forEach { paragraph ->
                if(paragraph.isBlank()) { result += ""; return@forEach }
                var line = ""
                paragraph.split(Regex("\\s+")).filter(String::isNotBlank).forEach { word ->
                    if(paint.measureText(word)>available) {
                        if(line.isNotBlank()) { result += line; line = "" }
                        var part=""
                        word.forEach { character ->
                            if(part.isNotEmpty() && paint.measureText(part+character)>available) { result += part; part="" }
                            part += character
                        }
                        line=part
                    } else {
                        val candidate=if(line.isBlank()) word else "$line $word"
                        if(line.isNotBlank() && paint.measureText(candidate)>available) { result += line; line=word } else line=candidate
                    }
                }
                result += line
            }
            return result
        }
        fun footer() {
            canvas.drawLine(left,793f,right,793f,rule)
            write(document.business,left,808f,small)
            val issued = "Created ${java.time.LocalDate.now()}"
            write(issued,right-small.measureText(issued),808f,small)
            val label="Page $pageNumber";write(label,right-small.measureText(label),823f,small)
        }
        fun nextPage() {
            footer();pdf.finishPage(page)
            pageNumber++
            page=pdf.startPage(PdfDocument.PageInfo.Builder(width,height,pageNumber).create())
            canvas=page.canvas
            BrandingStore.drawDocumentBackground(canvas,width.toFloat(),height.toFloat(),branding,context,layout)
            val offset=if(headerOnly)22f else 0f
            y=55f+offset
            write("${document.kind.uppercase()} ${document.number} — continued",left,37f+offset,bold)
            canvas.drawLine(left,45f+offset,right,45f+offset,rule)
        }
        fun ensure(space: Float) { if(y+space>777f) nextPage() }
        fun paragraph(value: String, x: Float=left, available: Float=505f, paint: Paint=body, step: Float=14f) {
            wrap(value,paint,available).forEach { line -> ensure(step);write(line,x,y,paint);y+=step }
        }
        fun drawImage(file: File, heading: String) {
            if(!file.isFile || file.length() !in 1..15_000_000) return
            val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
            BitmapFactory.decodeFile(file.absolutePath,bounds)
            if(bounds.outWidth<=0 || bounds.outHeight<=0) return
            val sample=(maxOf(bounds.outWidth,bounds.outHeight)/1400).coerceAtLeast(1)
            val bitmap=BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply { inSampleSize=sample }) ?: return
            try {
                ensure(260f);paragraph(heading,paint=textPaint(10f,gold,true),step=19f)
                val scale=minOf(490f/bitmap.width,215f/bitmap.height)
                val rectangle=RectF(left,y,left+bitmap.width*scale,y+bitmap.height*scale)
                canvas.drawBitmap(bitmap,null,rectangle,null);y=rectangle.bottom+20f
            } finally { bitmap.recycle() }
        }
        fun drawSignature(file:File) {
            if(!file.isFile || file.length() !in 1..8_000_000) return
            val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
            BitmapFactory.decodeFile(file.absolutePath,bounds)
            if(bounds.outWidth<=0 || bounds.outHeight<=0) return
            val sample=(maxOf(bounds.outWidth,bounds.outHeight)/800).coerceAtLeast(1)
            val bitmap=BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply { inSampleSize=sample }) ?: return
            try {
                ensure(58f)
                val scale=minOf(140f/bitmap.width,50f/bitmap.height)
                val rectangle=RectF(left,y,left+bitmap.width*scale,y+bitmap.height*scale)
                canvas.drawBitmap(bitmap,null,rectangle,null)
                y=rectangle.bottom+8f
            } finally { bitmap.recycle() }
        }

        BrandingStore.drawDocumentBackground(canvas,width.toFloat(),height.toFloat(),branding,context,layout)
        val details=document.businessDetails
        val address=listOf("address_line_1","address_line_2","suburb","state","postcode")
            .mapNotNull { details[it]?.takeIf(String::isNotBlank) }.joinToString(", ")
        val contacts=buildList {
            if(address.isNotBlank())add(address)
            listOf("mobile_number","email_address","web_url").mapNotNull { details[it]?.takeIf(String::isNotBlank) }.forEach(::add)
            details["business_number"]?.takeIf(String::isNotBlank)?.let{add("Business number: $it")}
        }
        fun drawLogo(bounds:RectF) {
            val file=document.logo?:return
            if(!file.isFile || file.length() !in 1..8_000_000)return
            val dimensions=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeFile(file.absolutePath,dimensions)
            if(dimensions.outWidth !in 1..12000 || dimensions.outHeight !in 1..12000)return
            var sample=1
            while(maxOf(dimensions.outWidth/sample,dimensions.outHeight/sample)>800)sample*=2
            val bitmap=BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply{inSampleSize=sample})?:return
            try {
                val scale=minOf(bounds.width()/bitmap.width,bounds.height()/bitmap.height)
                val w=bitmap.width*scale;val h=bitmap.height*scale
                canvas.drawBitmap(bitmap,null,RectF(bounds.centerX()-w/2,bounds.centerY()-h/2,bounds.centerX()+w/2,bounds.centerY()+h/2),Paint(Paint.FILTER_BITMAP_FLAG))
            } finally {bitmap.recycle()}
        }
        if(headerOnly) {
            val headingPaint=textPaint(18f,ink,true)
            val headingLines=wrap(document.business,headingPaint,333f)
            val contactLines=contacts.flatMap{wrap(it,small,333f)}
            val bottom=maxOf(142f,52f+headingLines.size*22f+contactLines.size*12f+12f)
            val panel=Paint().apply{color=0xffedf3f8.toInt()}
            val shape=Path().apply{moveTo(0f,22f);lineTo(198f,22f);lineTo(184f,bottom);lineTo(0f,bottom);close()}
            canvas.drawPath(shape,panel)
            canvas.drawLine(198f,22f,184f,bottom,Paint().apply{color=gold;strokeWidth=2f})
            drawLogo(RectF(26f,36f,164f,minOf(bottom-14f,128f)))
            y=52f
            headingLines.forEach{write(it,218f,y,headingPaint);y+=22f}
            contactLines.forEach{write(it,218f,y,small);y+=12f}
            canvas.drawLine(0f,bottom,width.toFloat(),bottom,Paint().apply{color=gold;strokeWidth=1.5f})
            y=bottom+29f
        } else {
            if(document.logo?.isFile==true) {drawLogo(RectF(right-180f,y-18f,right,y+60f));y+=60f}
            paragraph(document.business,paint=textPaint(23f,gold,true),step=28f)
            contacts.forEach{paragraph(it,paint=small,step=12f)}
            y+=12f;canvas.drawLine(left,y,right,y,rule);y+=29f
        }
        write(document.kind.uppercase(),left,y,textPaint(20f,ink,true));write(document.number,330f,y,textPaint(12f,gold,true));y+=25f
        paragraph(document.dateLabel,paint=small);y+=11f
        write("PREPARED FOR",left,y,textPaint(9f,gold,true));write("JOB / PROJECT",312f,y,textPaint(9f,gold,true));y+=19f
        val customers = listOf(document.customer.ifBlank { "Not specified" }) + document.customerDetails
        val customerLines = customers.flatMap { wrap(it,body,235f) }
        val jobs=wrap(document.job.ifBlank{"Not specified"},body,235f).toMutableList().apply {
            if(document.jobSiteAddress.isNotBlank()) addAll(wrap("Job site address: ${document.jobSiteAddress.trim()}",body,235f))
        }
        repeat(maxOf(customerLines.size,jobs.size)) { index ->
            ensure(15f)
            customerLines.getOrNull(index)?.let { write(it,left,y) }
            jobs.getOrNull(index)?.let { write(it,312f,y) }
            y+=15f
        }
        y+=24f;ensure(50f)
        canvas.drawRect(left,y-15f,right,y+11f,Paint().apply { color=ink })
        write("DESCRIPTION",left+9f,y+2f,textPaint(9f,Color.WHITE,true));write("QTY",362f,y+2f,textPaint(9f,Color.WHITE,true))
        write("RATE",415f,y+2f,textPaint(9f,Color.WHITE,true));write("AMOUNT",492f,y+2f,textPaint(9f,Color.WHITE,true));y+=31f
        document.lines.forEachIndexed { index,item ->
            val descriptions=wrap(item.description.ifBlank{"Item"},body,302f);val rowHeight=maxOf(26f,descriptions.size*14f+12f);ensure(rowHeight)
            if(index%2==1) canvas.drawRect(left,y-12f,right,y+rowHeight-12f,Paint().apply { color=0xfff5f6f7.toInt() })
            descriptions.forEachIndexed { lineIndex,line -> write(line,left+8f,y+lineIndex*14f) }
            write(MoneyMath.quantityText(item.quantityThousandths),362f,y,small);write(MoneyMath.format(item.unitCents),415f,y,small)
            val amount=MoneyMath.format(item.totalCents);write(amount,right-8f-bold.measureText(amount),y,bold);y+=rowHeight
        }
        y+=13f;ensure(115f)
        fun totalRow(label:String,cents:Long,prominent:Boolean=false) {
            val paint=if(prominent)textPaint(14f,gold,true) else bold
            val amount=MoneyMath.format(cents)
            val labelWidth=(right-345f-paint.measureText(amount)-12f).coerceAtLeast(35f)
            val labels=wrap(label,paint,labelWidth)
            val step=if(prominent)17f else 14f
            labels.forEachIndexed { index,line ->
                ensure(step+7f);write(line,345f,y,paint)
                if(index==0)write(amount,right-paint.measureText(amount),y,paint)
                y+=step
            }
            y+=if(prominent)10f else 6f
        }
        totalRow("Subtotal",document.subtotal)
        if(document.discount!=0L) {
            totalRow(document.discountLabel.ifBlank{"Discount"},-document.discount)
            if(document.discountDescription.isNotBlank()){paragraph(document.discountDescription,x=345f,available=right-345f,paint=small,step=12f);y+=5f}
        }
        if(document.tax!=0L)totalRow("Tax",document.tax)
        canvas.drawLine(345f,y-10f,right,y-10f,rule);y+=13f;totalRow("TOTAL",document.total,true)
        document.paidAmount?.let { totalRow("PAID",it) }
        document.balanceDue?.let { totalRow("BALANCE DUE",it,true) }
        if(document.terms.isNotBlank()) { y+=16f;ensure(35f);paragraph("TERMS & CONDITIONS",paint=textPaint(10f,gold,true),step=19f);paragraph(document.terms,paint=small,step=13f) }
        document.approval?.let { approval ->
            y+=12f;ensure(125f);paragraph("CUSTOMER APPROVAL",paint=textPaint(10f,gold,true),step=19f)
            paragraph("Signed by: ${approval.signer}",paint=bold)
            drawSignature(approval.signature)
            paragraph("Approved: ${approval.approvedAt}",paint=small)
            paragraph(approval.consent,paint=small,step=13f)
        }
        document.attachments.distinctBy(File::getAbsolutePath).take(20).forEach { drawImage(it,"PROJECT ATTACHMENT") }
        footer();pdf.finishPage(page)
        try { target.outputStream().use(pdf::writeTo) } finally { pdf.close() }
        return target
    }
}
