package com.macleanofduartenterprises.modehandyman.export

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

/** Render the actual PDF so JPG pages preserve the same layout, totals and branding. */
object DocumentImages {
    fun fromPdf(pdf:File):List<File> {
        val files=mutableListOf<File>()
        try {
            ParcelFileDescriptor.open(pdf,ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    val stamp=System.currentTimeMillis()
                    for(index in 0 until renderer.pageCount)renderer.openPage(index).use { page ->
                        val bitmap=Bitmap.createBitmap(page.width*2,page.height*2,Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                            val file=File(pdf.parentFile,"${pdf.nameWithoutExtension}-$stamp-page-${index+1}.jpg")
                            files+=file
                            file.outputStream().use{check(bitmap.compress(Bitmap.CompressFormat.JPEG,95,it)){"Could not encode JPG page"}}
                        }finally{bitmap.recycle()}
                    }
                }
            }
            check(files.isNotEmpty()){"No document pages to share"}
            return files
        }catch(error:Exception){files.forEach{it.delete()};throw error}
    }
}
