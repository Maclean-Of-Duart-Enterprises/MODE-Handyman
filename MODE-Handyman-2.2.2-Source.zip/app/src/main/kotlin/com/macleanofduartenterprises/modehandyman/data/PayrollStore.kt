package com.macleanofduartenterprises.modehandyman.data

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.macleanofduartenterprises.modehandyman.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate

data class PayrollWorker(val id:Long=0,val profile:Long,val name:String,val kind:String="Employee",val phone:String="",val email:String="",val address:String="",
                         val pay:PayrollPay=PayrollPay(),val cadence:String="Weekly",val anchor:String=LocalDate.now().toString(),val notes:String="",val archived:Boolean=false)
data class PayrollCard(val id:Long=0,val profile:Long,val workerId:Long,val start:String,val end:String,val payDate:String,val cadence:String="Weekly",
                       val status:String="draft",val entries:List<PayrollEntry>,val pay:PayrollPay,val notes:String="",val rejection:String="",val revision:Int=0)
data class PayrollStub(val id:Long,val profile:Long,val workerId:Long,val cardId:Long,val revision:Int,val number:String,val payDate:String,
                       val start:String,val end:String,val cadence:String,val gross:Long,val deductions:Long,val net:Long,val employer:Long,val seconds:Long,
                       val approvedAt:String,val voidedAt:String,val snapshot:JSONObject)

object PayrollCodec {
    fun rate(value:PayrollPay)=JSONObject().put("rate_cents",value.rateCents).put("basis",value.basis).put("increment_minutes",value.incrementMinutes)
        .put("increment_label",value.incrementLabel)
    fun pay(value:PayrollPay)=rate(value).put("taxes",JSONArray().apply { value.taxes.forEach { t->put(JSONObject().put("name",t.name).put("description",t.description).put("type",t.type).put("value",t.value).put("employer",t.employer).put("enabled",t.enabled)) } })
    fun pay(value:JSONObject)=PayrollPay(value.getLong("rate_cents"),value.getString("basis"),value.getLong("increment_minutes"),value.getString("increment_label"),
        value.getJSONArray("taxes").let { a->(0 until a.length()).map { i->a.getJSONObject(i).let { PayrollTax(it.getString("name"),it.getString("description"),it.getString("type"),it.getString("value"),it.getBoolean("employer"),it.getBoolean("enabled")) } } })
    fun entries(values:List<PayrollEntry>)=JSONArray().apply { values.forEach { e->put(JSONObject().put("date",e.date).put("start",e.start).put("end",e.end).put("break_seconds",e.breakSeconds).put("duration_seconds",e.durationSeconds).put("multiplier",e.multiplier).put("notes",e.notes)) } }
    fun entries(values:JSONArray):List<PayrollEntry> = (0 until values.length()).map { i->values.getJSONObject(i).let { PayrollEntry(it.getString("date"),it.getString("start"),it.getString("end"),it.getLong("break_seconds"),it.getLong("duration_seconds"),it.getString("multiplier"),it.getString("notes")) } }
    fun worker(value:PayrollWorker)=JSONObject().put("id",value.id).put("profile",value.profile).put("name",value.name).put("kind",value.kind).put("phone",value.phone).put("email",value.email).put("address",value.address)
        .put("pay",pay(value.pay)).put("cadence",value.cadence).put("anchor",value.anchor).put("notes",value.notes).put("archived",value.archived)
    fun worker(value:JSONObject)=PayrollWorker(value.getLong("id"),value.getLong("profile"),value.getString("name"),value.getString("kind"),value.getString("phone"),value.getString("email"),value.getString("address"),pay(value.getJSONObject("pay")),value.getString("cadence"),value.getString("anchor"),value.getString("notes"),value.getBoolean("archived"))
    fun calculation(value:PayrollCalculation)=JSONObject().put("seconds",value.workedSeconds).put("earnings",JSONArray(value.earnings)).put("gross",value.gross).put("deductions",value.deductions).put("employer",value.employerContributions).put("net",value.net)
        .put("tax_amounts",JSONArray().apply { value.taxes.forEach { t->put(JSONObject().put("name",t.tax.name).put("description",t.tax.description).put("type",t.tax.type).put("value",t.tax.value).put("employer",t.tax.employer).put("cents",t.cents)) } })
    fun calculation(value:JSONObject)=PayrollCalculation(value.getLong("seconds"),value.getJSONArray("earnings").let { a->(0 until a.length()).map(a::getLong) },value.getLong("gross"),
        value.getJSONArray("tax_amounts").let { a->(0 until a.length()).map { i->a.getJSONObject(i).let { PayrollTaxAmount(PayrollTax(it.getString("name"),it.getString("description"),it.getString("type"),it.getString("value"),it.getBoolean("employer")),it.getLong("cents")) } } },value.getLong("deductions"),value.getLong("employer"),value.getLong("net"))
}

/** All queries bind both business profile and record identity. Approved snapshots never mutate. */
class PayrollStore(private val db:SQLiteDatabase,val profile:Long) {
    companion object {
        val IMMUTABLE_TRIGGER = """CREATE TRIGGER IF NOT EXISTS mode_payroll_stub_immutable BEFORE UPDATE OF profile_id,worker_id,card_id,revision,number,pay_date,period_start,period_end,cadence,gross_cents,deduction_cents,net_cents,employer_cents,worked_seconds,snapshot_json,approved_at ON mode_payroll_stub
            BEGIN SELECT RAISE(ABORT,'Approved paystub snapshots are immutable'); END"""
    }
    // Leave room for the other columns in Android's SQLite cursor window.
    private fun checkPayloadSize(vararg fields: String) {
        val bytes = fields.sumOf { it.toByteArray(Charsets.UTF_8).size.toLong() }
        require(bytes <= 1_400_000) {
            "This payroll record is too large to store safely. Shorten the notes and descriptions, or split the time entries across smaller timecards."
        }
    }
    private fun now()=Instant.now().toString()
    fun workers(includeArchived:Boolean=true):List<PayrollWorker> = db.rawQuery("SELECT * FROM mode_payroll_worker WHERE profile_id=?"+if(includeArchived)" ORDER BY archived,name COLLATE NOCASE" else " AND archived=0 ORDER BY name COLLATE NOCASE",arrayOf(profile.toString())).use { c->buildList { while(c.moveToNext())add(c.worker()) } }
    fun worker(id:Long):PayrollWorker=db.rawQuery("SELECT * FROM mode_payroll_worker WHERE profile_id=? AND id=?",arrayOf(profile.toString(),id.toString())).use { check(it.moveToFirst()){ "Employee or subcontractor not found in this business" };it.worker() }
    fun saveWorker(value:PayrollWorker):Long {
        require(value.profile==profile);require(value.name.trim().isNotEmpty() && value.name.length<=200){"Enter a name of up to 200 characters"}
        require(value.kind in listOf("Employee","Subcontractor"));value.pay.validate();require(value.cadence in Payroll.cadences);LocalDate.parse(value.anchor)
        require(value.phone.length<=200 && value.email.length<=320 && value.address.length<=2000 && value.notes.length<=4000){"Contact details are too long"}
        checkPayloadSize(PayrollCodec.worker(value).toString())
        if(value.id!=0L)worker(value.id)
        val values=ContentValues().apply {
            put("profile_id",profile);put("name",value.name.trim());put("kind",value.kind);put("phone",value.phone.trim());put("email",value.email.trim());put("address",value.address.trim())
            put("pay_json",PayrollCodec.pay(value.pay).toString());put("cadence",value.cadence);put("anchor_date",value.anchor);put("notes",value.notes);put("archived",value.archived);put("updated_at",now())
        }
        return if(value.id==0L) {values.put("created_at",now());db.insertOrThrow("mode_payroll_worker",null,values)} else {check(db.update("mode_payroll_worker",values,"profile_id=? AND id=?",arrayOf(profile.toString(),value.id.toString()))==1);value.id}
    }
    fun deleteWorker(id:Long) {worker(id);require(cards(id).isEmpty() && stubs(id,true).isEmpty()){ "This person has timecard history. Archive their profile instead." };check(db.delete("mode_payroll_worker","profile_id=? AND id=?",arrayOf(profile.toString(),id.toString()))==1)}
    fun cards(workerId:Long):List<PayrollCard> {worker(workerId);return db.rawQuery("SELECT * FROM mode_payroll_timecard WHERE deleted=0 AND profile_id=? AND worker_id=? ORDER BY period_end DESC,id DESC",arrayOf(profile.toString(),workerId.toString())).use { c->buildList{while(c.moveToNext())add(c.card())} }}
    fun card(id:Long):PayrollCard=db.rawQuery("SELECT * FROM mode_payroll_timecard WHERE deleted=0 AND profile_id=? AND id=?",arrayOf(profile.toString(),id.toString())).use { check(it.moveToFirst()){ "Timecard not found in this business" };it.card() }
    fun saveCard(value:PayrollCard):Long = transaction {
        require(value.profile==profile);val person=worker(value.workerId);require(!person.archived){"Unarchive this person before changing timecards"}
        Payroll.validatePeriod(value.start,value.end,value.payDate,value.entries);value.pay.validate();require(value.cadence in Payroll.cadences)
        require(value.notes.length<=4000){"Timecard notes are too long"}
        if(value.id!=0L) {val old=card(value.id);require(old.workerId==value.workerId);require(old.status!="approved"){"Reopen the approved timecard before editing"}}
        val entriesJson = PayrollCodec.entries(value.entries).toString()
        val payJson = PayrollCodec.pay(value.pay).toString()
        checkPayloadSize(entriesJson, payJson, value.notes)
        val values=ContentValues().apply {
            put("profile_id",profile);put("worker_id",value.workerId);put("period_start",value.start);put("period_end",value.end);put("pay_date",value.payDate);put("cadence",value.cadence)
            put("status","draft");put("entries_json",entriesJson);put("pay_json",payJson);put("notes",value.notes);put("rejection_reason","");put("updated_at",now())
        }
        if(value.id==0L) {values.put("created_at",now());db.insertOrThrow("mode_payroll_timecard",null,values)} else {check(db.update("mode_payroll_timecard",values,"profile_id=? AND id=? AND status!='approved'",arrayOf(profile.toString(),value.id.toString()))==1);value.id}
    }
    fun reject(id:Long,reason:String)=transaction {
        val old=card(id);require(old.status!="approved"){"Reopen this timecard before rejecting it"};require(reason.length<=4000)
        check(db.update("mode_payroll_timecard",ContentValues().apply {put("status","rejected");put("rejection_reason",reason);put("updated_at",now())},"profile_id=? AND id=?",arrayOf(profile.toString(),id.toString()))==1)
    }
    fun reopen(id:Long)=transaction {
        val old=card(id);require(old.status=="approved"){"This timecard is already editable"}
        val stamp=now()
        db.update("mode_payroll_stub",ContentValues().apply { put("voided_at",stamp) },"profile_id=? AND card_id=? AND voided_at=''",arrayOf(profile.toString(),id.toString()))
        check(db.update("mode_payroll_timecard",ContentValues().apply {put("status","draft");put("updated_at",stamp)},"profile_id=? AND id=?",arrayOf(profile.toString(),id.toString()))==1)
    }
    fun hasCard(id:Long):Boolean = db.rawQuery(
        "SELECT 1 FROM mode_payroll_timecard WHERE deleted=0 AND profile_id=? AND id=?",
        arrayOf(profile.toString(),id.toString())
    ).use { it.moveToFirst() }

    /** A whole-card deletion leaves issued paystubs intact. A partial correction requires fresh approval. */
    fun removeTime(expected:PayrollCard, positions:Set<Int>) = transaction {
        val current = card(expected.id)
        require(current == expected) { "This timecard changed. Reopen it before deleting time." }
        require(positions.isNotEmpty() && positions.all { it in current.entries.indices })
        val remaining = current.entries.filterIndexed { index, _ -> index !in positions }
        val args = arrayOf(profile.toString(),current.id.toString())
        if (remaining.isEmpty() && current.revision == 0) {
            check(db.delete("mode_payroll_timecard","profile_id=? AND id=?",args)==1)
        } else {
            val values = ContentValues().apply {
                put("entries_json", PayrollCodec.entries(remaining).toString())
                put("rejection_reason", "")
                put("updated_at", now())
                if (remaining.isEmpty()) {
                    put("deleted", 1)
                    put("notes", "")
                } else put("status", "draft")
            }
            if (remaining.isNotEmpty() && current.status == "approved") {
                check(db.update("mode_payroll_stub",ContentValues().apply { put("voided_at",now()) },
                    "profile_id=? AND card_id=? AND voided_at=''", args)==1)
            }
            check(db.update("mode_payroll_timecard",values,"profile_id=? AND id=? AND deleted=0",args)==1)
        }
    }

    fun timeSetup(workerId:Long):JSONObject = db.rawQuery(
        "SELECT time_setup_json FROM mode_payroll_worker WHERE profile_id=? AND id=?",
        arrayOf(profile.toString(),workerId.toString())
    ).use { check(it.moveToFirst()); JSONObject(it.getString(0)) }

    fun saveTimeSetup(workerId:Long,settings:JSONObject) {
        val json = settings.toString()
        checkPayloadSize(json)
        check(db.update("mode_payroll_worker",ContentValues().apply { put("time_setup_json",json) },
            "profile_id=? AND id=?",arrayOf(profile.toString(),workerId.toString()))==1)
    }

    fun approve(id:Long,business:Map<String,String>):PayrollStub = transaction {
        val card=card(id);require(card.status!="approved"){"Timecard is already approved"};val person=worker(card.workerId);require(!person.archived){"Unarchive this person before approval"}
        Payroll.validatePeriod(card.start,card.end,card.payDate,card.entries)
        val calculation=Payroll.calculate(card.pay,card.entries);val stamp=now();val revision=card.revision+1;val number="PS-$profile-$id-R$revision"
        val previousTotals = db.rawQuery(
            """SELECT COALESCE(SUM(gross_cents),0), COALESCE(SUM(deduction_cents),0), COALESCE(SUM(net_cents),0)
                 FROM mode_payroll_stub WHERE profile_id=? AND worker_id=? AND voided_at='' AND pay_date BETWEEN ? AND ?""",
            arrayOf(profile.toString(), card.workerId.toString(), card.payDate.take(4) + "-01-01", card.payDate)
        ).use { cursor ->
            check(cursor.moveToFirst())
            JSONObject()
                .put("gross", Math.addExact(cursor.getLong(0), calculation.gross))
                .put("deductions", Math.addExact(cursor.getLong(1), calculation.deductions))
                .put("net", Math.addExact(cursor.getLong(2), calculation.net))
        }
        val snapshot=JSONObject().put("version",1).put("year_to_date",previousTotals).put("worker",PayrollCodec.worker(person.copy(pay=card.pay))).put("pay",PayrollCodec.pay(card.pay))
            .put("entries",PayrollCodec.entries(card.entries)).put("business",JSONObject(business)).put("calculation",PayrollCodec.calculation(calculation)).put("notes",card.notes)
        val snapshotText = snapshot.toString()
        checkPayloadSize(snapshotText)
        val values=ContentValues().apply {
            put("profile_id",profile);put("worker_id",card.workerId);put("card_id",id);put("revision",revision);put("number",number);put("pay_date",card.payDate);put("period_start",card.start);put("period_end",card.end);put("cadence",card.cadence)
            put("gross_cents",calculation.gross);put("deduction_cents",calculation.deductions);put("net_cents",calculation.net);put("employer_cents",calculation.employerContributions);put("worked_seconds",calculation.workedSeconds)
            put("snapshot_json",snapshotText);put("approved_at",stamp)
        }
        val stubId=db.insertOrThrow("mode_payroll_stub",null,values)
        check(db.update("mode_payroll_timecard",ContentValues().apply {put("status","approved");put("revision",revision);put("rejection_reason","");put("updated_at",stamp)},"profile_id=? AND id=? AND status!='approved'",arrayOf(profile.toString(),id.toString()))==1)
        stub(stubId)
    }
    fun stubs(workerId:Long,includeVoided:Boolean=false):List<PayrollStub> {worker(workerId);return db.rawQuery("SELECT * FROM mode_payroll_stub WHERE profile_id=? AND worker_id=?"+(if(includeVoided)"" else " AND voided_at=''")+" ORDER BY pay_date DESC,id DESC",arrayOf(profile.toString(),workerId.toString())).use { c->buildList{while(c.moveToNext())add(c.stub())} }}
    fun stub(id:Long):PayrollStub=db.rawQuery("SELECT * FROM mode_payroll_stub WHERE profile_id=? AND id=?",arrayOf(profile.toString(),id.toString())).use { check(it.moveToFirst()){ "Paystub not found in this business" };it.stub() }
    fun activeStub(cardId:Long):PayrollStub? {val c=card(cardId);return stubs(c.workerId).firstOrNull { it.cardId==cardId }}
    private fun <T> transaction(action:()->T):T {db.beginTransaction();try {val result=action();db.setTransactionSuccessful();return result}finally {db.endTransaction()}}
    private fun Cursor.s(key:String)=getString(getColumnIndexOrThrow(key)).orEmpty()
    private fun Cursor.l(key:String)=getLong(getColumnIndexOrThrow(key))
    private fun Cursor.worker()=PayrollWorker(l("id"),l("profile_id"),s("name"),s("kind"),s("phone"),s("email"),s("address"),PayrollCodec.pay(JSONObject(s("pay_json"))),s("cadence"),s("anchor_date"),s("notes"),l("archived")!=0L)
    private fun Cursor.card()=PayrollCard(l("id"),l("profile_id"),l("worker_id"),s("period_start"),s("period_end"),s("pay_date"),s("cadence"),s("status"),PayrollCodec.entries(JSONArray(s("entries_json"))),PayrollCodec.pay(JSONObject(s("pay_json"))),s("notes"),s("rejection_reason"),l("revision").toInt())
    private fun Cursor.stub()=PayrollStub(l("id"),l("profile_id"),l("worker_id"),l("card_id"),l("revision").toInt(),s("number"),s("pay_date"),s("period_start"),s("period_end"),s("cadence"),l("gross_cents"),l("deduction_cents"),l("net_cents"),l("employer_cents"),l("worked_seconds"),s("approved_at"),s("voided_at"),JSONObject(s("snapshot_json")))
}
