package com.macleanofduartenterprises.modehandyman.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.macleanofduartenterprises.modehandyman.R
import com.macleanofduartenterprises.modehandyman.export.Branding
import com.macleanofduartenterprises.modehandyman.export.BrandingStore
import com.macleanofduartenterprises.modehandyman.core.BrandingPalette
import android.app.Activity
import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import java.io.File

object Ui {
    var BG = 0xff0d1e2e.toInt(); private set
    var SURFACE = 0xff172d40.toInt(); private set
    var GOLD = 0xffd9bd63.toInt(); private set
    const val TEXT = 0xfff1eff4.toInt()
    var MUTED = 0xffb9b7be.toInt(); private set
    const val ERROR = 0xffda6379.toInt()
    private var brand:Branding?=null
    private var palette=BrandingPalette.from(0xff233243.toInt(),0xffaa8930.toInt())
    var businessName="MODE Handyman";private set
    private var profile=""

    fun configure(context:Context,profileId:String?=null,name:String?=null) {
        val prefs=context.getSharedPreferences("mode_native_preferences",Context.MODE_PRIVATE)
        profile=profileId?:prefs.getString("branding_active_profile","").orEmpty()
        businessName=name?.takeIf{it.isNotBlank()}?:prefs.getString("branding_business_name","MODE Handyman").orEmpty()
        brand=BrandingStore.load(context,profile)
        palette=BrandingPalette.from(brand!!.ink,brand!!.accent)
        BG=palette.background;SURFACE=palette.surface;GOLD=palette.highlight
        val patternBase=BrandingPalette.blend(BG,Color.WHITE,38/255.0)
        MUTED=if(BrandingPalette.contrast(0xffb9b7be.toInt(),patternBase)>=4.5)0xffb9b7be.toInt() else TEXT
        if(profileId!=null)prefs.edit().putString("branding_active_profile",profile).putString("branding_business_name",businessName).apply()
    }
    fun background(context:Context)=brand?.let{BrandingStore.appBackground(context,it,BG)}?:ColorDrawable(BG)
    fun logoFile(context:Context)=File(context.filesDir,"business-logos/profile-$profile.png")
    fun applyWindow(activity:Activity) {
        activity.window.decorView.setBackgroundColor(BG)
        activity.window.statusBarColor=BG;activity.window.navigationBarColor=BG
    }
    fun styleDialog(dialog:AlertDialog) {
        dialog.window?.setBackgroundDrawable(rounded(dialog.context,SURFACE))
        dialog.window?.decorView?.let(::tintControls)
    }
    fun dialog(context:Context):AlertDialog.Builder=object:AlertDialog.Builder(context) {
        override fun create():AlertDialog=super.create().apply{setOnShowListener{styleDialog(this)}}
    }
    private fun rounded(context:Context,color:Int,outline:Int=GOLD)=GradientDrawable().apply{setColor(color);cornerRadius=context.dp(7).toFloat();setStroke(context.dp(1),outline)}
    fun styleButton(button:Button) {
        button.background=rounded(button.context,palette.accent,palette.accent)
        button.setTextColor(palette.accentText)
        button.backgroundTintList=null
    }
    fun tintControls(view:View) {
        when(view) {
            is CompoundButton -> {view.buttonTintList=ColorStateList.valueOf(palette.accent);view.setTextColor(TEXT)}
            is Button -> styleButton(view)
            is SeekBar -> {view.progressTintList=ColorStateList.valueOf(palette.accent);view.thumbTintList=ColorStateList.valueOf(palette.accent)}
            is EditText -> visibleCursor(view)
            is Spinner -> view.backgroundTintList=ColorStateList.valueOf(GOLD)
        }
        if(view is ViewGroup)for(i in 0 until view.childCount)tintControls(view.getChildAt(i))
    }
    fun visibleCursor(field:EditText) {
        field.isCursorVisible=true
        field.textCursorDrawable=GradientDrawable().apply{setColor(GOLD);setSize(field.context.dp(2),field.context.dp(24))}
        field.highlightColor=Color.argb(100,Color.red(GOLD),Color.green(GOLD),Color.blue(GOLD))
    }
    fun brandHeader(context:Context)=LinearLayout(context).apply {
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
        setPadding(context.dp(10),context.dp(10),context.dp(10),context.dp(12))
        val logo=logoFile(context)
        if(logo.isFile)addView(ImageView(context).apply{setImageURI(Uri.fromFile(logo));scaleType=ImageView.ScaleType.FIT_CENTER;contentDescription="Business logo"},LinearLayout.LayoutParams(context.dp(90),context.dp(64)))
        addView(title(context,businessName,21f).apply{setTextColor(GOLD)},LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
    }

    fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    fun column(context: Context, pad: Int = 16) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(context.dp(pad), context.dp(pad), context.dp(pad), context.dp(32))
    }

    fun scroll(context: Context, child: View): ScrollView = ScrollView(context).apply {
        isFillViewport = true
        clipToPadding = false
        setPadding(0, 0, 0, context.dp(96))
        background=Ui.background(context)
        addView(child, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun title(context: Context, text: String, size: Float = 26f) = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(TEXT)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, context.dp(8), 0, context.dp(12))
    }

    fun label(context: Context, text: String, color: Int = MUTED, size: Float = 15f) = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setPadding(0, context.dp(3), 0, context.dp(3))
    }

    fun button(context: Context, text: String, onClick: () -> Unit) = Button(context).apply {
        this.text = text
        isAllCaps = false
        setTextColor(palette.accentText)
        setTypeface(typeface, Typeface.BOLD)
        styleButton(this)
        setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(50)).apply {
            setMargins(0, context.dp(5), 0, context.dp(5))
        }
    }

    fun field(context: Context, hint: String, value: String = "", multiline: Boolean = false): EditText = EditText(context).apply {
        this.hint = hint
        setHintTextColor(0xff85858b.toInt())
        setTextColor(TEXT)
        setText(value)
        textSize = 16f
        background=rounded(context,SURFACE)
        setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        inputType = if (multiline) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
        visibleCursor(this)
        minLines = if (multiline) 3 else 1
        gravity = if (multiline) Gravity.TOP else Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, context.dp(5), 0, context.dp(5))
        }
        setOnFocusChangeListener { view, focused ->
            if (focused) view.post {
                var parent = view.parent
                while (parent is View && parent !is ScrollView) parent = parent.parent
                (parent as? ScrollView)?.requestChildFocus(view, view)
            }
        }
    }

    fun moneyField(context: Context, hint: String, cents: Long = 0) = field(context, hint, if (cents == 0L) "" else "%.2f".format(cents / 100.0)).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    fun card(context: Context, title: String, subtitle: String = "", trailing: String = "", status: String = "", onClick: (() -> Unit)? = null): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background=rounded(context,SURFACE,BrandingPalette.blend(SURFACE,GOLD,0.35))
            setPadding(context.dp(14), context.dp(12), context.dp(14), context.dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, context.dp(4), 0, context.dp(4))
            }
        }
        val words = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        words.addView(label(context, title, TEXT, 18f))
        if (subtitle.isNotBlank()) words.addView(label(context, subtitle))
        if (status.isNotBlank()) words.addView(label(context, status, GOLD, 13f))
        row.addView(words, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing.isNotBlank()) row.addView(label(context, trailing, GOLD, 16f))
        if (onClick != null) {
            row.isClickable = true
            row.isFocusable = true
            row.setOnClickListener { onClick() }
        }
        return row
    }

    fun section(context: Context, text: String) = label(context, text.uppercase(), GOLD, 13f).apply {
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, context.dp(18), 0, context.dp(5))
    }
}
