package com.macleanofduartenterprises.modehandyman.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.macleanofduartenterprises.modehandyman.core.*
import com.macleanofduartenterprises.modehandyman.data.*
import com.macleanofduartenterprises.modehandyman.export.*
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.UUID
import kotlin.concurrent.thread

class PayrollScreens(private val activity:Activity,private val repository:()->ModeRepository,
                     private val open:(String,()->View)->Unit,private val refresh:()->Unit,
                     private val shareDocument:(File,String)->Unit,private val shareFile:(File,String)->Unit,
                     private val clearCardPages:()->Unit,private val pickCsv:(Long,Long)->Unit,private val saveFile:(File)->Unit) {
    private fun active()=repository().profiles.activeId()
    private fun store(profile:Long):PayrollStore {require(active()==profile){"Business changed; open this record from the active business"};return PayrollStore(repository().db,profile)}
    private fun toast(text:String)=Toast.makeText(activity,text,Toast.LENGTH_LONG).show()
    private fun attempt(action:()->Unit){runCatching(action).onFailure { toast(it.message?:"Unable to complete payroll operation") }}
    private fun column()=Ui.column(activity)
    private fun LinearLayout.text(value:String,heading:Boolean=false){addView(if(heading)Ui.title(activity,value,20f) else Ui.label(activity,value))}
    private fun LinearLayout.button(label:String,action:()->Unit){addView(Ui.button(activity,label){attempt(action)})}
    private fun LinearLayout.field(label:String,value:String="",multiline:Boolean=false):EditText {addView(Ui.label(activity,label));return Ui.field(activity,label,value,multiline).also(::addView)}
    private fun LinearLayout.choice(label:String,values:List<String>,selected:Int=0):Spinner {
        addView(Ui.label(activity,label));return Spinner(activity).apply {adapter=ArrayAdapter(activity,android.R.layout.simple_spinner_dropdown_item,values);setSelection(selected.coerceIn(0,values.lastIndex))}.also(::addView)
    }
    private fun LinearLayout.date(label:String,value:String):EditText=field(label,value).apply {
        inputType=InputType.TYPE_NULL;isFocusable=false
        setOnClickListener {val d=runCatching{LocalDate.parse(text.toString())}.getOrElse{LocalDate.now()};DatePickerDialog(activity,{_,y,m,day->setText(LocalDate.of(y,m+1,day).toString())},d.year,d.monthValue-1,d.dayOfMonth).show()}
    }
    private fun confirm(title:String,message:String,action:()->Unit){Ui.dialog(activity).setTitle(title).setMessage(message).setPositiveButton("Continue"){_,_->attempt(action)}.setNegativeButton("Cancel",null).show()}
    private fun form(title:String,body:LinearLayout,saveLabel:String="Save",save:()->Unit) {
        val dialog=Ui.dialog(activity).setTitle(title).setView(Ui.scroll(activity,body)).setPositiveButton(saveLabel,null).setNegativeButton("Cancel",null).create()
        dialog.show();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {runCatching(save).onSuccess {dialog.dismiss()}.onFailure {toast(it.message?:"Check the entered details")}}
    }
    fun workersScreen() {
        val profile=active()
        open("Employee and Subcontractor") {
            val s=store(profile);Ui.scroll(activity,column().apply {
                text("Employee and Subcontractor",true)
                button("+ Add employee or subcontractor"){workerForm(profile,null)}
                button("CSV format / template"){csvHelp(profile)}
                val workers=s.workers()
                if(workers.isEmpty())text("Add a person, set their pay rate and taxes, then import a CSV or create a timecard.")
                workers.forEach { w->addView(Ui.card(activity,w.name,"${w.kind}${if(w.archived)" · Archived" else ""}",Payroll.rateLabel(w.pay)){attempt{workerScreen(profile,w.id)}}) }
            })
        }
    }
    private fun workerScreen(profile:Long,id:Long) {
        open("Employee / subcontractor") {
            val s=store(profile);val w=s.worker(id)
            Ui.scroll(activity,column().apply {
                text(w.name,true);text(w.kind+if(w.archived)" · Archived" else "")
                if(w.phone.isNotBlank()){text("Phone: ${w.phone}");button("Call phone"){activity.startActivity(Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",w.phone,null)))}}
                if(w.email.isNotBlank()){text("Email: ${w.email}");button("Email"){activity.startActivity(Intent(Intent.ACTION_SENDTO,Uri.fromParts("mailto",w.email,null)))}}
                if(w.address.isNotBlank())text(w.address)
                text(Payroll.rateLabel(w.pay));text("Pay schedule: ${w.cadence} · Biweekly anchor: ${w.anchor}")
                w.pay.taxes.forEach { t->text("${t.name}: ${if(t.type=="percent")t.value+"%" else "$"+t.value}${if(t.employer)" employer contribution" else " deduction"}${if(!t.enabled)" (off)" else ""}${if(t.description.isNotBlank())"\n${t.description}" else ""}") }
                if(w.notes.isNotBlank())text(w.notes)
                button("Edit contact, pay and tax settings"){workerForm(profile,w)}
                button("Employee setup / export for Time"){employeeSetup(profile,id)}
                if(!w.archived){
                    button("Import timecard CSV"){pickCsv(profile,id)}
                    button("+ Create timecard manually"){cardForm(profile,w,null,emptyList())}
                }
                button("Timecards / time reports"){records(profile,id,false)}
                button("Paystubs / pay reports"){records(profile,id,true)}
                button(if(w.archived)"Unarchive person" else "Archive person"){confirm("Change archive status?","Archiving keeps all timecard and paystub history."){s.saveWorker(w.copy(archived=!w.archived));refresh()}}
                if(s.cards(id).isEmpty() && s.stubs(id,true).isEmpty())button("Delete person"){confirm("Delete person?",w.name){s.deleteWorker(id);workersScreen()}}
            })
        }
    }
    private fun employeeSetup(profile:Long,id:Long) {
        val s=store(profile)
        val w=s.worker(id)
        val prefs=s.timeSetup(id)
        val jobs=repository().timeSetupJobs()
        val selected=linkedMapOf<Long,JobOptions>()
        jobs.forEach { j -> prefs.optJSONObject("jobs")?.optJSONObject(j.id.toString())?.let { selected[j.id]=JobOptions.from(it) } }
        val body=column()
        body.text(w.name,true)
        body.text(listOf(w.phone,w.email,w.address).filter(String::isNotBlank).joinToString("\n").ifBlank { "No contact details on this profile." })
        body.text("Pay rate included in JSON: ${Payroll.rateLabel(w.pay)}")
        val daily=body.field("Daily hour limit (optional)",prefs.optString("daily"))
        val weekly=body.field("Weekly hour limit (optional)",prefs.optString("weekly"))
        body.text("Time displays hour limits as instructions. Imported jobs become choices on its Timecard tab alongside existing jobs.")
        val summary=Ui.label(activity,"")
        body.addView(summary)
        fun updateSummary() { summary.text="${selected.size} of ${jobs.size} jobs selected" }
        updateSummary()
        body.button("Choose jobs") {
            require(jobs.isNotEmpty()) { "Add a job under Jobs first." }
            val checked=jobs.map { it.id in selected }.toBooleanArray()
            Ui.dialog(activity).setTitle("Jobs for ${w.name}").setMultiChoiceItems(jobs.map { it.label }.toTypedArray(),checked) { _,i,on -> checked[i]=on }
                .setNegativeButton("Cancel",null).setPositiveButton("Use selected jobs") { _,_ ->
                    jobs.forEachIndexed { i,j -> if(checked[i]) selected.putIfAbsent(j.id,JobOptions()) else selected.remove(j.id) }
                    updateSummary()
                }.show()
        }
        body.button("Edit selected job settings") {
            val choices=jobs.filter { it.id in selected }
            require(choices.isNotEmpty()) { "Choose a job first." }
            Ui.dialog(activity).setTitle("Job settings").setItems(choices.map { it.label }.toTypedArray()) { _,i ->
                val j=choices[i]
                val old=selected.getValue(j.id)
                val editor=column()
                editor.text(j.label,true)
                editor.text("Saved job site: "+j.address.ifBlank { "No destination saved" })
                val route=editor.field("Alternate routing address or latitude, longitude (optional)",old.route)
                val factor=editor.field("Timecard pay multiplier",old.multiplier)
                val budget=editor.field("Assigned hours for this job (optional)",old.hours)
                form("Job settings",editor,"Apply") {
                    val options=JobOptions(route.text.toString().trim(),factor.text.toString().trim(),budget.text.toString().trim())
                    options.validate()
                    selected[j.id]=options
                }
            }.show()
        }
        fun chosen() = jobs.mapNotNull { j -> selected[j.id]?.let { j to it } }
        fun remember() {
            TimeSetupExport.limit(daily.text.toString().trim(),24)
            TimeSetupExport.limit(weekly.text.toString().trim(),168)
            val items=JSONObject()
            selected.forEach { (id,o) -> items.put(id.toString(),o.json()) }
            store(profile).saveTimeSetup(id,JSONObject().put("daily",daily.text.toString().trim()).put("weekly",weekly.text.toString().trim()).put("jobs",items))
        }
        val pin=body.field("Time admin PIN for this JSON (optional)").apply {
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            isSaveEnabled=false
            importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO
        }
        body.text("Use the receiving device’s existing 6–12 digit PIN to skip typing it during import. Anyone with the exported JSON can read the PIN.")
        body.button("Export employee setup JSON") {
            val json=TimeSetupExport.setup(store(profile).worker(id),chosen(),daily.text.toString().trim(),weekly.text.toString().trim(),pin.text.toString())
            remember()
            exportText("Employee setup","Time-setup-${w.name}-$profile-$id","json",json)
        }
        body.button("Export employee profile CSV") {
            val csv=TimeSetupExport.workerCsv(store(profile).worker(id),daily.text.toString().trim(),weekly.text.toString().trim())
            remember()
            exportText("Worker profile","Time-worker-${w.name}-$profile-$id","csv",csv)
        }
        body.button("Export selected job profiles CSV") {
            val csv=TimeSetupExport.jobsCsv(chosen())
            remember()
            exportText("Job profiles","Time-jobs-${w.name}-$profile-$id","csv",csv)
        }
        form("Employee setup for Time",body,"Save settings",::remember)
    }

    fun jobCsv(id:Long) = attempt {
        val r=repository()
        val j=r.job(id)
        val job=TimeJob(id,active(),j.summary,j.jobNumber,j.jobSiteAddress)
        exportText("Job profile","Time-job-${job.label}-${job.code}","csv",TimeSetupExport.jobsCsv(listOf(job to JobOptions())))
    }

    private fun exportText(title:String,base:String,extension:String,contents:String) {
        val type=if(extension=="json")"application/json" else "text/csv"
        val label=extension.uppercase()
        Ui.dialog(activity).setTitle(title).setItems(arrayOf("Save $label","Share $label")) { _,index ->
            attempt {
                val dir=if(extension=="json")SecureExportProvider.setupDirectory(activity) else File(activity.filesDir,"exports")
                dir.mkdirs()
                if(extension=="json") {
                    val cutoff=System.currentTimeMillis()-86_400_000L
                    dir.listFiles()?.filter { it.isFile && it.lastModified()<cutoff }?.forEach { it.delete() }
                }
                val safe=base.replace(Regex("[^\\p{L}\\p{N}._-]+"),"-").take(70)
                val file=File(dir,"$safe-${UUID.randomUUID().toString().take(12)}.$extension")
                file.writeText(contents,Charsets.UTF_8)
                if(index==0)saveFile(file) else shareFile(file,type)
            }
        }.show()
    }

    private fun deleteEntries(c:PayrollCard) {
        val selected=mutableSetOf<Int>()
        val labels=c.entries.mapIndexed { i,e -> "${i+1}. ${e.date} · ${e.start.ifBlank{"Hours only"}}${e.end.takeIf(String::isNotBlank)?.let{"–$it"}.orEmpty()} · ${Payroll.duration(e.workedSeconds())}"+e.notes.takeIf(String::isNotBlank)?.let{"\n"+it.take(110)}.orEmpty() }
        val dialog=Ui.dialog(activity).setTitle("Delete time entries").setMultiChoiceItems(labels.toTypedArray(),null) { _,i,on ->
            if(on)selected.add(i) else selected.remove(i)
        }.setNegativeButton("Cancel",null).setPositiveButton("Review",null).create()
        dialog.show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if(selected.isEmpty())toast("Select at least one time entry.")
            else { dialog.dismiss(); confirmRemoval(c,selected.toSet()) }
        }
    }

    private fun confirmRemoval(c:PayrollCard,indices:Set<Int>) {
        val whole=indices.size==c.entries.size
        val detail=when {
            whole && c.status=="approved" -> "The issued paystub stays in Paystubs and pay reports."
            whole -> "The timecard will be removed from this person's time reports."
            c.status=="approved" -> "The current paystub will be superseded. Review and approve the remaining time again."
            else -> "The remaining entries will be saved as a draft."
        }
        val label=if(whole)"Delete entire timecard" else "Delete ${indices.size} time entr${if(indices.size==1)"y" else "ies"}"
        val duration=Payroll.duration(indices.sumOf { c.entries[it].workedSeconds() })
        Ui.dialog(activity).setTitle("$label?").setMessage("${c.start} to ${c.end}\n${indices.size} entries · $duration\n\n$detail")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete") { _,_ -> attempt {
                store(c.profile).removeTime(c,indices)
                if(whole) { clearCardPages(); records(c.profile,c.workerId,false) } else refresh()
                toast(if(whole)"Timecard deleted" else "Selected entries deleted")
            } }.show()
    }

    private fun workerForm(profile:Long,existing:PayrollWorker?) {
        val initial=existing?:PayrollWorker(profile=profile,name="",anchor=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString())
        val body=column();val name=body.field("Name",initial.name)
        val kind=body.choice("Type",listOf("Employee","Subcontractor"),if(initial.kind=="Employee")0 else 1)
        val phone=body.field("Phone number",initial.phone).apply {inputType=InputType.TYPE_CLASS_PHONE}
        val email=body.field("Email",initial.email).apply {inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS}
        val address=body.field("Physical / mailing address",initial.address,true)
        var pay=initial.pay
        val paySummary=Ui.label(activity,Payroll.rateLabel(pay));body.addView(paySummary)
        body.button("Set pay rate and tax boxes"){payForm(pay){pay=it;paySummary.text="${Payroll.rateLabel(pay)} · ${pay.taxes.count { t->t.enabled }} tax/deduction boxes"}}
        val cadence=body.choice("Default pay schedule",Payroll.cadences,Payroll.cadences.indexOf(initial.cadence))
        val anchor=body.date("Biweekly period anchor date",initial.anchor)
        val notes=body.field("Notes",initial.notes,true)
        form(if(existing==null)"Add employee / subcontractor" else "Edit person",body) {
            val id=store(profile).saveWorker(initial.copy(name=name.text.toString(),kind=listOf("Employee","Subcontractor")[kind.selectedItemPosition],phone=phone.text.toString(),email=email.text.toString(),address=address.text.toString(),pay=pay,cadence=Payroll.cadences[cadence.selectedItemPosition],anchor=anchor.text.toString(),notes=notes.text.toString()))
            if(existing==null)workerScreen(profile,id)else refresh()
        }
    }
    private fun payForm(initial:PayrollPay,save:(PayrollPay)->Unit) {
        val body=column()
        val rate=body.field("Pay rate in dollars",java.math.BigDecimal(initial.rateCents).movePointLeft(2).toPlainString())
        val basis=body.choice("Pay basis",listOf("Per working-time increment","Fixed amount per pay period"),if(initial.basis=="time")0 else 1)
        body.text("For time-based pay, set the working minutes covered by the rate. Examples: hour = 60, quarter hour = 15, 8-hour day = 480. Fixed-period pay is paid once per approved timecard.")
        val increment=body.field("Working minutes per rate increment",initial.incrementMinutes.toString())
        val label=body.field("Increment label (hour, day, custom)",initial.incrementLabel)
        body.text("Tax and deduction boxes",true)
        body.text("Percentages apply independently to gross pay. Fixed dollar amounts apply once per paystub. Employer contributions are shown separately and do not reduce net pay. Enter the values applicable to this person.")
        val taxes=initial.taxes.toMutableList();val list=column();body.addView(list)
        fun render() {
            list.removeAllViews()
            taxes.forEachIndexed { index,t->
                list.addView(Ui.card(activity,t.name,"${if(t.type=="percent")t.value+"%" else "$"+t.value} · ${if(t.employer)"Employer" else "Deduction"} · ${if(t.enabled)"On" else "Off"}","Edit"){taxForm(t,{taxes[index]=it;render()},{taxes.removeAt(index);render()})})
            }
        }
        render();body.button("+ Add tax / deduction box"){taxForm(PayrollTax(""),{taxes+=it;render()},null)}
        form("Pay and tax settings",body) {
            val value=PayrollPay(Payroll.cents(rate.text.toString()),if(basis.selectedItemPosition==0)"time" else "period",increment.text.toString().toLongOrNull()?:error("Enter whole working minutes"),label.text.toString(),taxes.toList())
            value.validate();save(value)
        }
    }
    private fun taxForm(initial:PayrollTax,save:(PayrollTax)->Unit,delete:(()->Unit)?) {
        val body=column();val name=body.field("Tax / deduction name",initial.name)
        val description=body.field("Description",initial.description,true)
        val type=body.choice("Value type",listOf("Percentage of gross","Fixed dollars per paystub"),if(initial.type=="percent")0 else 1)
        val value=body.field("Percentage or dollar amount",initial.value)
        val side=body.choice("Treatment",listOf("Employee deduction","Employer contribution"),if(initial.employer)1 else 0)
        val enabled=CheckBox(activity).apply {text="Enabled";isChecked=initial.enabled;setTextColor(Ui.TEXT)};body.addView(enabled)
        val dialog=Ui.dialog(activity).setTitle("Tax / deduction box").setView(Ui.scroll(activity,body)).setPositiveButton("Save",null).setNegativeButton("Cancel",null)
        if(delete!=null)dialog.setNeutralButton("Delete"){_,_->delete()}
        val shown=dialog.create();shown.show();shown.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            runCatching {val t=PayrollTax(name.text.toString(),description.text.toString(),if(type.selectedItemPosition==0)"percent" else "fixed",value.text.toString(),side.selectedItemPosition==1,enabled.isChecked);t.validate();save(t)}.onSuccess{shown.dismiss()}.onFailure{toast(it.message?:"Check the tax value")}
        }
    }
    private fun entryForm(initial:PayrollEntry?,defaultDate:String,save:(PayrollEntry)->Unit,delete:(()->Unit)?=null) {
        val e=initial?:PayrollEntry(defaultDate,"08:00","17:00")
        val body=column();val date=body.date("Work date",e.date)
        val mode=body.choice("Entry mode",listOf("Clock in / clock out","Hours only"),if(e.start.isBlank())1 else 0)
        val start=body.field("Clock in (24-hour H:MM[:SS])",e.start)
        val end=body.field("Clock out (earlier time means next day)",e.end)
        val hours=body.field("Hours before unpaid break (hours-only mode)",Payroll.hours(if(e.start.isBlank())e.durationSeconds else e.workedSeconds()+e.breakSeconds))
        val breaks=body.field("Unpaid break in minutes",Payroll.minutes(e.breakSeconds))
        val multiplier=body.field("Pay multiplier (1 regular; e.g. 1.5 premium)",e.multiplier)
        body.text("Premium hours are marked manually. Fixed-period pay ignores time multipliers.")
        val originalJob=TimeSetupExport.jobCaption(e.notes)
        val jobOptions=(listOf("")+listOf(originalJob).filter(String::isNotBlank)+repository().timeSetupJobs().map { it.caption }).distinct()
        val job=body.choice("Timecard job",jobOptions.map { it.ifBlank { "Unassigned" } },jobOptions.indexOf(originalJob))
        val notes=body.field("Job / task / notes",if(originalJob.isEmpty())e.notes else e.notes.substringAfter('\n',""),true)
        val builder=Ui.dialog(activity).setTitle(if(initial==null)"Add time entry" else "Edit time entry").setView(Ui.scroll(activity,body)).setPositiveButton("Save",null).setNegativeButton("Cancel",null)
        if(delete!=null)builder.setNeutralButton("Delete"){_,_->delete()}
        val dialog=builder.create();dialog.show();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            runCatching {
                fun clock(value:String)=LocalTime.parse(value.trim(),DateTimeFormatter.ofPattern("H:mm[:ss]")).toString()
                val entry=PayrollEntry(date.text.toString(),if(mode.selectedItemPosition==0)clock(start.text.toString())else "",if(mode.selectedItemPosition==0)clock(end.text.toString())else "",Payroll.secondsFromMinutes(breaks.text.toString()),if(mode.selectedItemPosition==1)Payroll.secondsFromHours(hours.text.toString())else 0,multiplier.text.toString(),listOf(jobOptions[job.selectedItemPosition].takeIf(String::isNotEmpty)?.let{"Job: $it"}.orEmpty(),notes.text.toString()).filter(String::isNotEmpty).joinToString("\n"))
                entry.workedSeconds();save(entry)
            }.onSuccess{dialog.dismiss()}.onFailure{toast(it.message?:"Check the time entry")}
        }
    }
    private fun cardForm(profile:Long,worker:PayrollWorker,existing:PayrollCard?,imported:List<PayrollEntry>,metadata:PayrollImport?=null) {
        require(existing?.status!="approved"){"Reopen this timecard before editing"}
        val initial=existing?:PayrollCard(profile=profile,workerId=worker.id,start=metadata?.periodStart?.takeIf(String::isNotBlank)?:imported.minOfOrNull{it.date}?:LocalDate.now().toString(),end=metadata?.periodEnd?.takeIf(String::isNotBlank)?:imported.maxOfOrNull{it.date}?:LocalDate.now().toString(),payDate=metadata?.payDate?.takeIf(String::isNotBlank)?:imported.maxOfOrNull{it.date}?:LocalDate.now().toString(),cadence=metadata?.cadence?.takeIf(String::isNotBlank)?:worker.cadence,entries=imported,pay=worker.pay)
        val body=column();body.text(worker.name,true)
        if(imported.isNotEmpty() && existing==null)body.text("Parsed ${imported.size} CSV entries. Review the dates and settings, then save to review and approve the timecard.")
        val from=body.date("Pay period start",initial.start);val to=body.date("Pay period end",initial.end);val paid=body.date("Pay date",initial.payDate)
        val cadence=body.choice("Pay schedule",Payroll.cadences,Payroll.cadences.indexOf(initial.cadence))
        var pay=initial.pay;val summary=Ui.label(activity,Payroll.rateLabel(pay));body.addView(summary)
        body.button("Edit this timecard's pay / taxes"){payForm(pay){pay=it;summary.text=Payroll.rateLabel(pay)}}
        body.button("Use current person pay / tax settings"){pay=store(profile).worker(worker.id).pay;summary.text=Payroll.rateLabel(pay)}
        val notes=body.field("Timecard notes",initial.notes,true)
        val entries=initial.entries.toMutableList();var offset=0;val entryList=column();body.addView(entryList)
        fun renderEntries() {
            offset=offset.coerceAtMost(((entries.size-1).coerceAtLeast(0)/30)*30)
            entryList.removeAllViews();entryList.text("${entries.size} entries · ${Payroll.duration(entries.sumOf{it.workedSeconds()})}",true)
            entries.drop(offset).take(30).forEachIndexed { local,e->val index=offset+local
                entryList.addView(Ui.card(activity,"${index+1}. ${e.date}",if(e.start.isBlank())"Hours only" else "${e.start}–${e.end}",Payroll.duration(e.workedSeconds())){entryForm(e,e.date,{entries[index]=it;renderEntries()},{entries.removeAt(index);renderEntries()})})
            }
            if(offset>0)entryList.button("Previous 30 entries"){offset-=30;renderEntries()}
            if(offset+30<entries.size)entryList.button("Next 30 entries"){offset+=30;renderEntries()}
        }
        renderEntries();body.button("+ Add time entry"){entryForm(null,from.text.toString(),{require(entries.size<5000){"Maximum 5000 entries"};entries+=it;renderEntries()})}
        form(if(existing==null)"Create timecard" else "Edit timecard",body,"Save draft") {
            if(existing!=null && entries.isEmpty()) { confirmRemoval(existing,existing.entries.indices.toSet()); return@form }
            val id=store(profile).saveCard(initial.copy(start=from.text.toString(),end=to.text.toString(),payDate=paid.text.toString(),cadence=Payroll.cadences[cadence.selectedItemPosition],entries=entries.toList(),pay=pay,notes=notes.text.toString()))
            if(existing==null)cardScreen(profile,id)else refresh()
        }
    }
    private fun business(profile:Long):Map<String,String> {
        store(profile)
        return repository().system().mapValues {it.value?.toString().orEmpty()}+mapOf("_profile_id" to profile.toString(),"business_name" to repository().system()["business_name"]?.toString().orEmpty().ifBlank {repository().profiles.all().first {it.id==profile}.name})
    }
    private fun cardScreen(profile:Long,id:Long) {
        open("Timecard") {
            val s=store(profile);val c=s.card(id);val w=s.worker(c.workerId);val result=runCatching {Payroll.calculate(c.pay,c.entries)}
            Ui.scroll(activity,column().apply {
                text("${w.name} · TC-$profile-$id",true)
                text("${c.start} to ${c.end} · ${c.cadence}\nPay date: ${c.payDate}\nStatus: ${c.status.uppercase()}")
                if(c.rejection.isNotBlank())text("Rejection reason: ${c.rejection}")
                text("${c.entries.size} time entries · ${Payroll.duration(c.entries.sumOf {it.workedSeconds()})}",true)
                c.entries.take(8).forEach { e->text("${e.date} · ${if(e.start.isBlank())"Hours only" else e.start+"–"+e.end} · ${Payroll.duration(e.workedSeconds())} · ${e.multiplier}×${if(e.notes.isBlank())"" else "\n"+e.notes}") }
                if(c.entries.size>8)text("${c.entries.size-8} more entries; open the timecard PDF or edit the timecard to see all entries.")
                text(Payroll.rateLabel(c.pay))
                result.onSuccess { r->text("Gross ${MoneyMath.format(r.gross)} · Deductions ${MoneyMath.format(r.deductions)} · Net ${MoneyMath.format(r.net)}",true) }
                    .onFailure {text("Pay calculation needs attention: ${it.message}")}
                if(c.notes.isNotBlank())text(c.notes)
                if(c.status=="approved") {
                    val stub=s.activeStub(id)?:error("Approved paystub not found")
                    button("View paystub"){stubScreen(profile,stub.id)}
                    button("Export / share paystub"){exportStub(profile,stub.id)}
                    button("Export approved timecard CSV"){exportCsv(profile,id)}
                    button("Export approved timecard CSV by job"){
                        val person=PayrollCodec.worker(stub.snapshot.getJSONObject("worker"))
                        selectTimeJob(c.entries,false) { label,entries ->
                            exportText("Timecard · $label","TC-$profile-$id-R${c.revision}-$label","csv",PayrollCsv.export(entries,person.id,person.name,profile,c.start,c.end,c.payDate,c.cadence))
                        }
                    }
                    button("Reopen timecard for editing"){reopen(profile,id)}
                } else {
                    button("View calculated paystub preview"){previewScreen(profile,id)}
                    if(!w.archived){
                        button("Edit timecard / time entries"){cardForm(profile,w,c,emptyList())}
                        button("Approve timecard and paystub"){approve(profile,id)}
                        button("Reject timecard"){reject(profile,id)}
                    }
                }
                button("Delete time entries…"){deleteEntries(c)}
                button("Delete entire pay-period timecard…"){confirmRemoval(c,c.entries.indices.toSet())}
                button("Export / share timecard PDF or JPG"){
                    val person=if(c.status=="approved")PayrollCodec.worker(s.activeStub(id)!!.snapshot.getJSONObject("worker")) else w
                    exportDocument(profile,"Timecard","TC-$profile-$id",business(profile),PayrollDocuments.timecardRows(c,person))
                }
                val history=s.stubs(w.id,true).filter {it.cardId==id && it.voidedAt.isNotBlank()}
                if(history.isNotEmpty()) {text("Earlier paystub revisions",true);history.forEach { stub->button("${stub.number} · Superseded"){stubScreen(profile,stub.id)} }}
            })
        }
    }
    private fun previewScreen(profile:Long,id:Long) {
        open("Paystub preview") {
            val s=store(profile);val c=s.card(id);val w=s.worker(c.workerId)
            Ui.scroll(activity,column().apply {
                text("${w.name} · Paystub preview",true);text("${c.start} to ${c.end} · Pay date ${c.payDate}")
                runCatching {Payroll.calculate(c.pay,c.entries)}.onSuccess {r->calculationView(this,r,c.pay)}.onFailure {text("Cannot calculate paystub: ${it.message}")}
                text("Preview uses this timecard's saved pay and tax settings. Approval creates a separate saved paystub.")
                if(c.status=="approved")button("View approved paystub"){stubScreen(profile,s.activeStub(id)!!.id)}
                else if(!w.archived){button("Approve"){approve(profile,id)};button("Reject"){reject(profile,id)};button("Edit timecard / pay settings"){cardForm(profile,w,c,emptyList())}}
            })
        }
    }
    private fun calculationView(body:LinearLayout,result:PayrollCalculation,pay:PayrollPay) {
        body.text(Payroll.rateLabel(pay));body.text("Worked time: ${Payroll.duration(result.workedSeconds)}")
        body.text("Gross pay: ${MoneyMath.format(result.gross)}",true)
        result.taxes.forEach { t->body.text("${t.tax.name} (${if(t.tax.type=="percent")t.tax.value+"%" else "fixed"}): ${MoneyMath.format(t.cents)}${if(t.tax.employer)" · Employer contribution" else " · Deduction"}");if(t.tax.description.isNotBlank())body.text(t.tax.description) }
        body.text("Deductions: ${MoneyMath.format(result.deductions)}")
        if(result.employerContributions>0)body.text("Employer contributions: ${MoneyMath.format(result.employerContributions)} (not deducted)")
        body.text("Net pay: ${MoneyMath.format(result.net)}",true)
    }
    private fun approve(profile:Long,id:Long) {
        val s=store(profile);val c=s.card(id);val result=Payroll.calculate(c.pay,c.entries)
        val overlap=s.stubs(c.workerId).any {it.cardId!=id && it.start<=c.end && it.end>=c.start}
        val message="Approve ${c.start} to ${c.end}, pay date ${c.payDate}?\nGross ${MoneyMath.format(result.gross)}\nDeductions ${MoneyMath.format(result.deductions)}\nNet ${MoneyMath.format(result.net)}"+
            if(overlap)"\n\nAn approved paystub overlaps this work period. Verify that these hours have not already been included in another paystub." else ""
        confirm("Approve timecard and paystub",message) {val stub=store(profile).approve(id,business(profile));toast("Approved ${stub.number}");stubScreen(profile,stub.id)}
    }
    private fun reject(profile:Long,id:Long) {
        val body=column();val reason=body.field("Reason for rejection",multiline=true)
        form("Reject timecard",body,"Reject") {require(reason.text.isNotBlank()){ "Enter a rejection reason" };store(profile).reject(id,reason.text.toString());cardScreen(profile,id)}
    }
    private fun reopen(profile:Long,id:Long) {
        confirm("Reopen approved timecard?","Its current paystub will be marked superseded and excluded from current pay reports. The earlier revision remains in history. Edit the timecard and approve it again to create a new paystub.") {
            store(profile).reopen(id);cardScreen(profile,id)
        }
    }
    private fun stubScreen(profile:Long,id:Long) {
        open("Paystub") {
            val s=store(profile);val stub=s.stub(id);val w=PayrollCodec.worker(stub.snapshot.getJSONObject("worker"));val result=PayrollCodec.calculation(stub.snapshot.getJSONObject("calculation"))
            Ui.scroll(activity,column().apply {
                text("${w.name} · ${stub.number}",true);text("${stub.start} to ${stub.end}\nPay date: ${stub.payDate}\n${if(stub.voidedAt.isBlank())"APPROVED" else "SUPERSEDED — revision retained for history"}")
                calculationView(this,result,PayrollCodec.pay(stub.snapshot.getJSONObject("pay")))
                text("Approved: ${stub.approvedAt}")
                if(stub.voidedAt.isBlank()) {
                    button("Export / share paystub"){exportStub(profile,id)}
                    if(s.hasCard(stub.cardId))button("View timecard"){cardScreen(profile,stub.cardId)} else text("The timecard was deleted. This issued paystub is retained.")
                } else text("Superseded at: ${stub.voidedAt}")
            })
        }
    }
    private fun exportStub(profile:Long,id:Long) {
        val s=store(profile);val stub=s.stub(id);require(stub.voidedAt.isBlank()){"Only current approved paystubs can be exported"}
        val json=stub.snapshot.getJSONObject("business");val details=json.keys().asSequence().associateWith { json.getString(it) }
        exportDocument(profile,"Paystub",stub.number,details,PayrollDocuments.paystubRows(stub,s.stubs(stub.workerId))) {
            val current=store(profile).stub(id)
            require(current.voidedAt.isBlank()) {"This paystub has been superseded; approve and export the current revision"}
        }
    }
    private fun exportDocument(profile:Long,title:String,number:String,details:Map<String,String>,rows:List<PayrollDocumentRow>,guard:()->Unit={}) {
        Ui.dialog(activity).setTitle("$title export").setItems(arrayOf("View PDF","Share PDF","Save PDF","Share JPG page(s)")){_,index->
            toast("Preparing $title…")
            thread(name="mode-payroll-export") {
                runCatching {PayrollDocuments.create(activity,profile,title,number,details,rows)}.onSuccess {file->activity.runOnUiThread {
                    if(activity.isFinishing || activity.isDestroyed)return@runOnUiThread
                    attempt {store(profile);guard();when(index){
                        0->{val uri=SecureExportProvider.uriFor(activity,file);activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}
                        1->shareDocument(file,"pdf")
                        2->saveFile(file)
                        else->shareDocument(file,"jpg")
                    }}
                }}.onFailure {e->activity.runOnUiThread {toast(e.message?:"Document export failed")}}
            }
        }.show()
    }
    private fun csvFile(text:String,name:String):File=File(activity.filesDir,"exports").apply{mkdirs()}.let { File(it,"$name-${UUID.randomUUID()}.csv").apply{writeText(text,Charsets.UTF_8)} }
    private fun chooseCsv(file:File) {Ui.dialog(activity).setTitle("Timecard CSV").setItems(arrayOf("Share CSV","Save CSV")){_,i->attempt{if(i==0)shareFile(file,"text/csv")else saveFile(file)}}.show()}
    private fun exportCsv(profile:Long,id:Long) {
        val s=store(profile);val c=s.card(id);require(c.status=="approved"){"Approve the timecard before CSV export"}
        val stub=s.activeStub(id)?:error("Approved paystub not found");val worker=PayrollCodec.worker(stub.snapshot.getJSONObject("worker"))
        chooseCsv(csvFile(PayrollCsv.export(c.entries,worker.id,worker.name,profile,c.start,c.end,c.payDate,c.cadence),"timecard-TC-$profile-$id-R${c.revision}"))
    }
    private fun selectTimeJob(entries:List<PayrollEntry>,all:Boolean,onSelect:(String,List<PayrollEntry>)->Unit) {
        require(entries.isNotEmpty()) { "No approved time entries match these dates and filters." }
        // MODE job codes survive renames. Keep jobs from other sources grouped by their original caption.
        val groups=entries.groupBy { entry ->
            val caption=TimeSetupExport.jobCaption(entry.notes)
            val code=caption.substringBefore(" · ")
            if(code.matches(Regex("MODE-[0-9]+-[0-9]+")))code else caption
        }.values.sortedBy { TimeSetupExport.jobCaption(it.first().notes) }
        val options=groups.map { group -> TimeSetupExport.jobCaption(group.last().notes).ifBlank { "Unassigned" } to group }
        val choices=if(all)listOf("All jobs" to entries)+options else options
        Ui.dialog(activity).setTitle("Choose time entries to export").setItems(choices.map { (label,rows) -> "$label · ${Payroll.duration(rows.sumOf { it.workedSeconds() })}" }.toTypedArray()) { _,i ->
            attempt { val (label,rows)=choices[i]; onSelect(label,rows) }
        }.show()
    }

    private fun csvHelp(profile:Long) {
        open("Timecard CSV format") {store(profile);Ui.scroll(activity,column().apply {
            text("Timecard CSV format",true)
            text("Select the person first, then Import timecard CSV. Use UTF-8 text with a header row. Comma, semicolon and tab delimiters are accepted.")
            text("Required: date (YYYY-MM-DD or M/D/YYYY), plus start and end clock times OR hours / worked_seconds. Clock times use H:MM[:SS] or h:mm AM/PM.")
            text("Optional: break_minutes, multiplier (default 1), notes, employee_id, employee_name, business_profile_id. The optional identity columns must match the selected person and business.")
            text("Hours and worked_seconds are NET time after unpaid breaks. With hours-only rows, break_minutes is added back to reconstruct the full duration. With clock times, it is subtracted from elapsed time. Conflicting durations are rejected.")
            text("Earlier clock-out times mean the next day. The work date is the shift's start date. Premium multipliers are entered manually. Each row supports up to 24 hours; split longer shifts.")
            text("Example:\ndate,start,end,break_minutes,hours,multiplier,notes\n2026-11-16,08:00,16:30,30,,1,Example shift")
            text("Imports are drafts. Edit the displayed entries, review the paystub, and approve. Approved timecards can be saved or shared as CSV for your future time management app. Original CSV files are not changed.")
            button("Download / share CSV template"){chooseCsv(csvFile(PayrollCsv.template(),"timecard-template"))}
        }) }
    }
    fun importCsv(profile:Long,workerId:Long,uri:Uri) {
        store(profile).worker(workerId);toast("Reading timecard CSV…")
        thread(name="mode-payroll-csv") {
            runCatching {
                val decoder=Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                val text=activity.contentResolver.openInputStream(uri)?.let {java.io.InputStreamReader(it,decoder).buffered()}?.use {reader->
                    val result=StringBuilder();val buffer=CharArray(8192)
                    while(true){val count=reader.read(buffer);if(count<0)break;require(result.length+count<=PayrollCsv.MAX_CHARS){"CSV must be smaller than 2 MB"};result.append(buffer,0,count)}
                    result.toString()
                }?:error("Unable to read the selected file")
                PayrollCsv.parse(text)
            }.onSuccess {parsed->activity.runOnUiThread {
                if(activity.isFinishing || activity.isDestroyed)return@runOnUiThread
                attempt {
                    val w=store(profile).worker(workerId)
                    require(parsed.profileId.isBlank() || parsed.profileId==profile.toString()){ "CSV belongs to another business profile" }
                    require(parsed.employeeId.isBlank() || parsed.employeeId==workerId.toString()){ "CSV belongs to another employee ID" }
                    require(parsed.employeeId.isNotBlank() || parsed.employeeName.isBlank() || parsed.employeeName.equals(w.name,true)){ "CSV names ${parsed.employeeName}; select that person before importing" }
                    cardForm(profile,w,null,parsed.entries,parsed)
                }
            }}.onFailure {e->activity.runOnUiThread {toast(e.message?:"CSV import failed")}}
        }
    }
    private data class RecordFilter(val from:String="",val to:String="",val cadence:String="All schedules",val status:String="All statuses",val ascending:Boolean=false) {
        fun includes(date:String)=(from.isBlank() || date>=from) && (to.isBlank() || date<=to)
        fun description(paystubs:Boolean)="${if(paystubs)"Pay dates" else "Work dates"}: ${from.ifBlank{"beginning"}} to ${to.ifBlank{"latest"}} · $cadence · ${if(paystubs)"Current approved paystubs" else status} · ${if(ascending)"Oldest first" else "Newest first"}"
    }
    private val filters=mutableMapOf<String,RecordFilter>()
    private fun records(profile:Long,workerId:Long,paystubs:Boolean) {
        val key="$profile/$workerId/$paystubs"
        open(if(paystubs)"Paystubs and reports" else "Timecards and reports") {
            val s=store(profile);val w=s.worker(workerId);val filter=filters[key]?:RecordFilter()
            val cards=s.cards(workerId).filter {c->c.entries.any {filter.includes(it.date)} && (filter.cadence=="All schedules" || c.cadence==filter.cadence) && (filter.status=="All statuses" || c.status.equals(filter.status,true))}
                .sortedWith(compareBy<PayrollCard> {it.end}.thenBy {it.id}).let {if(filter.ascending)it else it.reversed()}
            val stubs=s.stubs(workerId).filter {filter.includes(it.payDate) && (filter.cadence=="All schedules" || it.cadence==filter.cadence)}
                .sortedWith(compareBy<PayrollStub>{it.payDate}.thenBy {it.id}).let {if(filter.ascending)it else it.reversed()}
            Ui.scroll(activity,column().apply {
                text(w.name,true);text(filter.description(paystubs))
                button("Filter / sort: week, biweekly, dates, year"){filterForm(w,filter,paystubs){filters[key]=it;refresh()}}
                if(paystubs) {
                    text("${stubs.size} paystubs · Gross ${MoneyMath.format(stubs.sumOf {it.gross})}\nDeductions ${MoneyMath.format(stubs.sumOf {it.deductions})} · Net ${MoneyMath.format(stubs.sumOf {it.net})}",true)
                    stubs.forEach {stub->addView(Ui.card(activity,"${stub.number} · ${stub.payDate}","${stub.start} to ${stub.end} · ${stub.cadence}",MoneyMath.format(stub.net)){attempt{stubScreen(profile,stub.id)}})}
                    val superseded=s.stubs(workerId,true).filter { it.voidedAt.isNotEmpty() && filter.includes(it.payDate) && (filter.cadence=="All schedules" || it.cadence==filter.cadence) }
                    if(superseded.isNotEmpty()) button("View superseded paystubs") {
                        Ui.dialog(activity).setTitle("Superseded paystubs").setItems(superseded.map { "${it.number} · ${it.payDate}" }.toTypedArray()) { _,i -> attempt { stubScreen(profile,superseded[i].id) } }.show()
                    }
                    if(stubs.isEmpty())text("No current approved paystubs match these filters.")
                    button("Export / share paystub report"){
                        val rows=buildList {
                            add(PayrollDocumentRow(w.name,w.kind,true));add(PayrollDocumentRow(filter.description(true)))
                            stubs.forEach {stub->add(PayrollDocumentRow("${stub.number} · Pay date ${stub.payDate}",MoneyMath.format(stub.net),true));add(PayrollDocumentRow("${stub.start} to ${stub.end} · ${stub.cadence}"));add(PayrollDocumentRow("Gross ${MoneyMath.format(stub.gross)} · Deductions ${MoneyMath.format(stub.deductions)} · Employer ${MoneyMath.format(stub.employer)}"))}
                            add(PayrollDocumentRow("TOTAL GROSS",MoneyMath.format(stubs.sumOf {it.gross}),true));add(PayrollDocumentRow("TOTAL DEDUCTIONS",MoneyMath.format(stubs.sumOf {it.deductions})));add(PayrollDocumentRow("TOTAL NET",MoneyMath.format(stubs.sumOf {it.net}),true));add(PayrollDocumentRow("Employer contributions",MoneyMath.format(stubs.sumOf {it.employer})))
                        }
                        exportDocument(profile,"Paystub report","WORKER-$workerId",business(profile),rows)
                    }
                } else {
                    val selectedSeconds=cards.sumOf {c->c.entries.filter {filter.includes(it.date)}.sumOf{it.workedSeconds()}}
                    text("${cards.size} timecards · ${Payroll.duration(selectedSeconds)} in selected work dates",true)
                    text("Each card opens its full pay period. Report totals include only entries within the selected work dates. Filter by Approved to exclude drafts and rejected cards.")
                    cards.forEach {c->val seconds=c.entries.filter{filter.includes(it.date)}.sumOf{it.workedSeconds()};addView(Ui.card(activity,"TC-$profile-${c.id} · ${c.status.uppercase()}","${c.start} to ${c.end} · ${c.cadence}",Payroll.duration(seconds)){attempt{cardScreen(profile,c.id)}})}
                    if(cards.isEmpty())text("No timecards match these filters.")
                    button("Export approved hours CSV · all jobs or one job"){
                        val entries=cards.filter { it.status=="approved" }.flatMap { c -> c.entries.filter { filter.includes(it.date) } }.sortedBy { it.date }
                        selectTimeJob(entries,true) { label,rows ->
                            exportText("Approved hours · $label","Time-report-${w.name}-$label-$profile-$workerId","csv",PayrollCsv.export(rows,w.id,w.name,profile))
                        }
                    }
                    button("Export / share timecard report"){
                        val rows=buildList {
                            add(PayrollDocumentRow(w.name,w.kind,true));add(PayrollDocumentRow(filter.description(false)))
                            cards.forEach {c->
                                add(PayrollDocumentRow("TC-$profile-${c.id} · ${c.status.uppercase()}","${c.start} to ${c.end}",true))
                                c.entries.filter {filter.includes(it.date)}.forEach {e->add(PayrollDocumentRow("${e.date} · ${if(e.start.isBlank())"Hours only" else e.start+"–"+e.end} · Break ${Payroll.minutes(e.breakSeconds)} min · ${e.multiplier}×",Payroll.duration(e.workedSeconds())));if(e.notes.isNotBlank())add(PayrollDocumentRow(e.notes))}
                            }
                            add(PayrollDocumentRow("SELECTED WORKED TIME",Payroll.duration(selectedSeconds),true))
                        }
                        exportDocument(profile,"Timecard report","WORKER-$workerId",business(profile),rows)
                    }
                }
            })
        }
    }
    private fun filterForm(worker:PayrollWorker,initial:RecordFilter,paystubs:Boolean,save:(RecordFilter)->Unit) {
        val body=column();val options=listOf("All dates","This week","Previous week","This biweekly period","Previous biweekly period","Full year","Custom date range")
        val preset=body.choice("Date filter",options,if(initial.from.isBlank() && initial.to.isBlank())0 else 6)
        val year=body.field("Year (for Full year)",LocalDate.now().year.toString())
        val from=body.date(if(paystubs)"Pay date from" else "Work date from",initial.from.ifBlank{LocalDate.now().toString()})
        val to=body.date(if(paystubs)"Pay date through" else "Work date through",initial.to.ifBlank{LocalDate.now().toString()})
        body.text("Weekly filters use Monday–Sunday. Biweekly filters use the person's saved anchor date. Paystubs use pay dates; time reports use individual work dates.")
        val schedules=listOf("All schedules")+Payroll.cadences;val cadence=body.choice("Pay schedule",schedules,schedules.indexOf(initial.cadence))
        val statuses=listOf("All statuses","Approved","Draft","Rejected");val status=if(paystubs)null else body.choice("Timecard status",statuses,statuses.indexOf(initial.status))
        val sort=body.choice("Sort order",listOf("Newest first","Oldest first"),if(initial.ascending)1 else 0)
        form("Filter and sort",body,"Apply") {
            val now=LocalDate.now();val monday=now.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            val anchor=LocalDate.parse(worker.anchor);val biweekly=anchor.plusDays(Math.floorDiv(ChronoUnit.DAYS.between(anchor,now),14)*14)
            val range=when(preset.selectedItemPosition) {
                0->"" to ""
                1->monday.toString() to monday.plusDays(6).toString()
                2->monday.minusDays(7).toString() to monday.minusDays(1).toString()
                3->biweekly.toString() to biweekly.plusDays(13).toString()
                4->biweekly.minusDays(14).toString() to biweekly.minusDays(1).toString()
                5->{val y=year.text.toString().toIntOrNull()?:error("Enter a year");require(y in 1900..9999){"Year must be 1900–9999"};LocalDate.of(y,1,1).toString() to LocalDate.of(y,12,31).toString()}
                else->{val a=LocalDate.parse(from.text);val b=LocalDate.parse(to.text);require(!b.isBefore(a)){"End date must follow start date"};a.toString() to b.toString()}
            }
            save(RecordFilter(range.first,range.second,schedules[cadence.selectedItemPosition],if(status==null)"All statuses" else statuses[status.selectedItemPosition],sort.selectedItemPosition==1))
        }
    }
}
