package com.macleanofduartenterprises.modehandyman.data

/** Queue inside the source transaction; network/SIM work happens only after commit. */
object FollowupTriggers {
    val statements=listOf(
        """CREATE TRIGGER IF NOT EXISTS mode_followup_invoice_paid_v235
        AFTER UPDATE OF paid ON invoice
        WHEN NEW.paid=1 AND COALESCE(OLD.paid,0)=0
        BEGIN
          INSERT OR IGNORE INTO mode_followup_outbox(profile_id,job_id,customer_id,invoice_id,trigger_kind,event_key,job_created,invoice_number)
          SELECT NEW.profile_id,j.id,COALESCE(NEW.billing_customer_id,j.customer_id),NEW.id,'invoice_paid',
            CASE WHEN s.once_per_job=1 THEN 'job:'||j.id||':created:'||COALESCE(j.created_date,'')||':customer:'||COALESCE(NEW.billing_customer_id,j.customer_id,0)
                 ELSE 'invoice_paid:'||NEW.id||':created:'||COALESCE(NEW.created_date,'') END,
            COALESCE(j.created_date,''),COALESCE(NEW.invoice_num,'')
          FROM job j JOIN mode_followup_settings s ON s.profile_id=NEW.profile_id
          WHERE j.id=NEW.job_id AND j.profile_id=NEW.profile_id AND s.enabled=1 AND s.invoice_paid=1;
        END""",
        """CREATE TRIGGER IF NOT EXISTS mode_followup_job_finished_v235
        AFTER UPDATE OF status_id ON job
        WHEN lower(trim(COALESCE(NEW.status_id,''))) IN ('finished','completed')
         AND lower(trim(COALESCE(OLD.status_id,''))) NOT IN ('finished','completed')
        BEGIN
          INSERT OR IGNORE INTO mode_followup_outbox(profile_id,job_id,customer_id,invoice_id,trigger_kind,event_key,job_created,invoice_number)
          SELECT NEW.profile_id,NEW.id,NEW.customer_id,NULL,'job_finished',
            CASE WHEN s.once_per_job=1 THEN 'job:'||NEW.id||':created:'||COALESCE(NEW.created_date,'')||':customer:'||COALESCE(NEW.customer_id,0)
                 ELSE 'job_finished:'||NEW.id||':created:'||COALESCE(NEW.created_date,'') END,
            COALESCE(NEW.created_date,''),''
          FROM mode_followup_settings s
          WHERE s.profile_id=NEW.profile_id AND s.enabled=1 AND s.job_finished=1;
        END"""
    )
}
