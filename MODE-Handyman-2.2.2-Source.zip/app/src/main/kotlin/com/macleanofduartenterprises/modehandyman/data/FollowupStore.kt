package com.macleanofduartenterprises.modehandyman.data

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.macleanofduartenterprises.modehandyman.core.FollowupSettings
import com.macleanofduartenterprises.modehandyman.core.FollowupMessage
import org.json.JSONObject
import java.time.Instant

data class FollowupRecord(val id:Long,val profile:Long,val job:Long,val customer:Long?,val invoice:Long?,val kind:String,val status:String,val recipient:String,val email:String,val customerName:String,val body:String,val error:String,val created:String,val jobCreated:String,val invoiceNumber:String,val sharedAt:String)
data class FollowupDraft(val phone:String,val email:String,val customerName:String,val body:String,val optedOut:Boolean)

/** Local draft storage only. No network or SMS sending code. */
class FollowupStore(private val db:SQLiteDatabase) {
    fun settings(profile:Long):FollowupSettings=db.rawQuery("SELECT * FROM mode_followup_settings WHERE profile_id=?",arrayOf(profile.toString())).use { c ->
        if(!c.moveToFirst())FollowupSettings() else FollowupSettings(c.flag("enabled"),c.flag("invoice_paid"),c.flag("job_finished"),c.flag("facebook_enabled"),c.flag("maps_enabled"),c.text("facebook_url"),c.text("maps_url"),c.text("message_template"),c.flag("once_per_job"))
    }
    fun save(profile:Long,value:FollowupSettings) {
        value.validate()
        db.insertWithOnConflict("mode_followup_settings",null,ContentValues().apply {
            put("profile_id",profile);put("enabled",value.enabled);put("invoice_paid",value.invoicePaid);put("job_finished",value.jobFinished)
            put("facebook_enabled",value.facebook);put("maps_enabled",value.maps);put("facebook_url",value.facebookUrl.trim());put("maps_url",value.mapsUrl.trim())
            put("message_template",value.template);put("once_per_job",value.oncePerJob)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun history(profile:Long):List<FollowupRecord> = db.rawQuery("SELECT * FROM mode_followup_outbox WHERE profile_id=? ORDER BY CASE WHEN status='ready' THEN 0 ELSE 1 END,id DESC",arrayOf(profile.toString())).use { c ->buildList{while(c.moveToNext())add(c.record())} }
    fun readyCount(profile:Long):Int=db.rawQuery("SELECT COUNT(*) FROM mode_followup_outbox WHERE profile_id=? AND status='ready'",arrayOf(profile.toString())).use{it.moveToFirst();it.getInt(0)}
    fun get(id:Long,profile:Long):FollowupRecord=db.rawQuery("SELECT * FROM mode_followup_outbox WHERE id=? AND profile_id=?",arrayOf(id.toString(),profile.toString())).use{check(it.moveToFirst()){ "Message not found in this business" };it.record()}
    private fun draft(row:FollowupRecord):FollowupDraft {
        val values=db.rawQuery("""SELECT j.summary,j.job_number,c.id,c.name,c.exclude_from_mailings,COALESCE(x.customer_phone,''),COALESCE(x.customer_email,'')
            FROM job j LEFT JOIN customer c ON c.id=? AND c.profile_id=j.profile_id
            LEFT JOIN mode_customer_contact_extra x ON x.customer_id=c.id
            WHERE j.id=? AND j.profile_id=? AND COALESCE(j.created_date,'')=?""",arrayOf(row.customer?.toString().orEmpty(),row.job.toString(),row.profile.toString(),row.jobCreated)).use { c ->
            check(c.moveToFirst()&&!c.isNull(2)){"Customer or job is no longer available in this business"}
            listOf(c.getString(0).orEmpty(),c.getString(1).orEmpty(),c.getString(3).orEmpty(),c.getString(5).orEmpty(),c.getInt(4).toString(),c.getString(6).orEmpty())
        }
        val business=db.rawQuery("SELECT display_name,configuration_json,active FROM business_profile WHERE id=?",arrayOf(row.profile.toString())).use { c ->
            check(c.moveToFirst()){"Business profile no longer exists"}
            if(c.getInt(2)==1)db.rawQuery("SELECT business_name FROM system LIMIT 1",null).use{if(it.moveToFirst())it.getString(0).orEmpty().ifBlank{c.getString(0)} else c.getString(0)}
            else runCatching{JSONObject(c.getString(1)).optString("business_name")}.getOrDefault("").ifBlank{c.getString(0)}
        }
        val body=row.body.ifBlank{FollowupMessage.render(settings(row.profile).copy(enabled=true),mapOf("customer" to values[2],"business" to business,"job" to (values[1]+" · "+values[0]),"invoice" to row.invoiceNumber,"event" to if(row.kind=="invoice_paid")"invoice paid" else "job finished"))}
        return FollowupDraft(values[3],values[5],values[2],body,values[4]!="0")
    }
    /** Runs after local edits, before rendering. Only persists message snapshots. */
    fun preparePending(profile:Long) {
        val rows=db.rawQuery("SELECT * FROM mode_followup_outbox WHERE profile_id=? AND status='pending' ORDER BY id",arrayOf(profile.toString())).use{c->buildList{while(c.moveToNext())add(c.record())}}
        rows.forEach { row ->
            try {
                val text=draft(row)
                db.update("mode_followup_outbox",ContentValues().apply {
                    put("status",if(text.optedOut)"skipped" else "ready");put("recipient",text.phone);put("email",text.email);put("customer_name",text.customerName);put("body",text.body)
                    put("error",if(text.optedOut)"Customer is excluded from follow-up messages" else row.error);put("updated_at",Instant.now().toString())
                },"id=? AND profile_id=? AND status='pending'",arrayOf(row.id.toString(),profile.toString()))
            }catch(error:Exception){updateStatus(row,"blocked",error.message?:"Could not prepare draft")}
        }
    }
    fun saveDraft(id:Long,profile:Long,phone:String,email:String,body:String) {
        require(body.isNotBlank()){"Enter a message"};require(body.length<=10000){"Keep the message under 10,000 characters"}
        require(phone.length<=200 && email.length<=320 && email.none{it=='\r'||it=='\n'}){"Check the recipient details"}
        check(db.update("mode_followup_outbox",ContentValues().apply{put("recipient",phone.trim());put("email",email.trim());put("body",body);put("updated_at",Instant.now().toString())},"id=? AND profile_id=?",arrayOf(id.toString(),profile.toString()))==1)
    }
    fun updateStatus(row:FollowupRecord,status:String,error:String="") {
        require(status in listOf("ready","blocked","skipped","done","shared"))
        db.update("mode_followup_outbox",ContentValues().apply{put("status",status);put("error",error.take(1000));put("updated_at",Instant.now().toString());if(status=="shared")put("last_shared_at",Instant.now().toString())},"id=? AND profile_id=?",arrayOf(row.id.toString(),row.profile.toString()))
    }
    fun customerBlocked(id:Long,profile:Long)=db.rawQuery("SELECT exclude_from_mailings FROM customer WHERE id=? AND profile_id=?",arrayOf(id.toString(),profile.toString())).use{check(it.moveToFirst());it.getInt(0)!=0}
    fun setCustomerBlocked(id:Long,profile:Long,blocked:Boolean) {check(db.update("customer",ContentValues().apply{put("exclude_from_mailings",blocked)},"id=? AND profile_id=?",arrayOf(id.toString(),profile.toString()))==1)}
    private fun Cursor.text(name:String)=getString(getColumnIndexOrThrow(name)).orEmpty()
    private fun Cursor.flag(name:String)=getInt(getColumnIndexOrThrow(name))!=0
    private fun Cursor.number(name:String)=getLong(getColumnIndexOrThrow(name))
    private fun Cursor.optional(name:String):Long? {val i=getColumnIndexOrThrow(name);return if(isNull(i))null else getLong(i)}
    private fun Cursor.record()=FollowupRecord(number("id"),number("profile_id"),number("job_id"),optional("customer_id"),optional("invoice_id"),text("trigger_kind"),text("status"),text("recipient"),text("email"),text("customer_name"),text("body"),text("error"),text("created_at"),text("job_created"),text("invoice_number"),text("last_shared_at"))
}
