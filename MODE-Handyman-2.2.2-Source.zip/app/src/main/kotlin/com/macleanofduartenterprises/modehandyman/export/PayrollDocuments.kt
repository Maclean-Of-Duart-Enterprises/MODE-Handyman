package com.macleanofduartenterprises.modehandyman.export

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.macleanofduartenterprises.modehandyman.core.*
import com.macleanofduartenterprises.modehandyman.data.*
import java.io.File
import java.time.LocalDate
import java.util.UUID

data class PayrollDocumentRow(val label:String,val value:String="",val emphasis:Boolean=false)

/** Branded, paginated payroll documents; money and time come from the stored model. */
object PayrollDocuments {
    fun paystubRows(stub:PayrollStub,ytd:List<PayrollStub>):List<PayrollDocumentRow> {
        val snapshot=stub.snapshot;val worker=PayrollCodec.worker(snapshot.getJSONObject("worker"));val pay=PayrollCodec.pay(snapshot.getJSONObject("pay"))
        val entries=PayrollCodec.entries(snapshot.getJSONArray("entries"));val result=PayrollCodec.calculation(snapshot.getJSONObject("calculation"))
        return buildList {
            add(PayrollDocumentRow(if(stub.voidedAt.isBlank())"APPROVED PAYSTUB" else "SUPERSEDED PAYSTUB",stub.number,true))
            add(PayrollDocumentRow("Worker",worker.name,true));add(PayrollDocumentRow("Type",worker.kind))
            if(worker.address.isNotBlank())add(PayrollDocumentRow("Address",worker.address))
            if(worker.phone.isNotBlank())add(PayrollDocumentRow("Phone",worker.phone))
            if(worker.email.isNotBlank())add(PayrollDocumentRow("Email",worker.email))
            add(PayrollDocumentRow("Pay period","${stub.start} to ${stub.end}"));add(PayrollDocumentRow("Pay date",stub.payDate));add(PayrollDocumentRow("Schedule",stub.cadence))
            add(PayrollDocumentRow("Approved",stub.approvedAt));add(PayrollDocumentRow("Pay rate",Payroll.rateLabel(pay)))
            add(PayrollDocumentRow("EARNINGS",emphasis=true))
            if(pay.basis=="period")add(PayrollDocumentRow("Fixed pay for this pay period",MoneyMath.format(result.gross)))
            entries.forEachIndexed { i,e ->
                val clock=if(e.start.isBlank())"Hours entry" else "${e.start}–${e.end}"+if(e.end<e.start)" (+1 day)" else ""
                add(PayrollDocumentRow("${e.date} · $clock · ${Payroll.hours(e.workedSeconds())} hours · ${e.multiplier}×",if(pay.basis=="period")"Included" else MoneyMath.format(result.earnings[i])))
                if(e.notes.isNotBlank())add(PayrollDocumentRow(e.notes))
            }
            add(PayrollDocumentRow("Total worked time",Payroll.duration(result.workedSeconds)))
            add(PayrollDocumentRow("GROSS PAY",MoneyMath.format(result.gross),true))
            add(PayrollDocumentRow("EMPLOYEE TAXES & DEDUCTIONS",emphasis=true))
            val deductions=result.taxes.filter { !it.tax.employer }
            if(deductions.isEmpty())add(PayrollDocumentRow("No employee deductions configured",MoneyMath.format(0)))
            deductions.forEach { t->
                add(PayrollDocumentRow(t.tax.name+" ("+if(t.tax.type=="percent")"${t.tax.value}%)" else "fixed)",MoneyMath.format(t.cents)))
                if(t.tax.description.isNotBlank())add(PayrollDocumentRow(t.tax.description))
            }
            add(PayrollDocumentRow("Total deductions",MoneyMath.format(result.deductions)))
            add(PayrollDocumentRow("NET PAY",MoneyMath.format(result.net),true))
            val contributions=result.taxes.filter { it.tax.employer }
            if(contributions.isNotEmpty()) {
                add(PayrollDocumentRow("EMPLOYER CONTRIBUTIONS (not deducted from net)",emphasis=true))
                contributions.forEach { t->add(PayrollDocumentRow(t.tax.name,MoneyMath.format(t.cents)));if(t.tax.description.isNotBlank())add(PayrollDocumentRow(t.tax.description)) }
                add(PayrollDocumentRow("Total employer contributions",MoneyMath.format(result.employerContributions)))
            }
            val savedTotals = snapshot.optJSONObject("year_to_date")
            val year=stub.payDate.take(4)
            val current=ytd.filter { it.voidedAt.isBlank() && it.payDate.take(4)==year && it.payDate<=stub.payDate }
            add(PayrollDocumentRow("YEAR TO DATE THROUGH ${stub.payDate}",emphasis=true))
            add(PayrollDocumentRow("Gross pay",MoneyMath.format(savedTotals?.getLong("gross") ?: current.sumOf { it.gross })))
            add(PayrollDocumentRow("Deductions",MoneyMath.format(savedTotals?.getLong("deductions") ?: current.sumOf { it.deductions })))
            add(PayrollDocumentRow("Net pay",MoneyMath.format(savedTotals?.getLong("net") ?: current.sumOf { it.net })))
            snapshot.optString("notes").takeIf(String::isNotBlank)?.let {add(PayrollDocumentRow("Notes: $it"))}
            add(PayrollDocumentRow("Taxes and deductions calculated from configured values. All amounts in USD."))
        }
    }
    fun timecardRows(card:PayrollCard,worker:PayrollWorker):List<PayrollDocumentRow> = buildList {
        add(PayrollDocumentRow(worker.name,worker.kind,true))
        add(PayrollDocumentRow("Timecard","TC-${card.profile}-${card.id}"));add(PayrollDocumentRow("Status",card.status.uppercase()))
        add(PayrollDocumentRow("Work period","${card.start} to ${card.end}"));add(PayrollDocumentRow("Pay date",card.payDate));add(PayrollDocumentRow("Schedule",card.cadence))
        add(PayrollDocumentRow("TIME ENTRIES",emphasis=true))
        card.entries.forEach { e ->
            val clock=if(e.start.isBlank())"Hours only" else "${e.start}–${e.end}"+if(e.end<e.start)" (+1 day)" else ""
            add(PayrollDocumentRow("${e.date} · $clock",Payroll.duration(e.workedSeconds()),true))
            add(PayrollDocumentRow("Unpaid break ${Payroll.minutes(e.breakSeconds)} min · Pay multiplier ${e.multiplier}×"))
            if(e.notes.isNotBlank())add(PayrollDocumentRow(e.notes))
        }
        add(PayrollDocumentRow("TOTAL WORKED TIME",Payroll.duration(card.entries.sumOf {it.workedSeconds()}),true))
        if(card.notes.isNotBlank())add(PayrollDocumentRow("Notes: ${card.notes}"))
        if(card.rejection.isNotBlank())add(PayrollDocumentRow("Rejection reason: ${card.rejection}"))
    }
    fun create(context:Context,profile:Long,title:String,number:String,business:Map<String,String>,rows:List<PayrollDocumentRow>):File {
        val branding=BrandingStore.load(context,profile.toString())
        val name=business["business_name"].orEmpty().ifBlank { "MODE Handyman" }
        val root=File(context.filesDir,"exports").apply { mkdirs() }
        val target=File(root,"${title.lowercase().replace(Regex("[^a-z0-9]+"),"-")}-${number.replace(Regex("[^A-Za-z0-9-]"),"-")}-${UUID.randomUUID()}.pdf")
        val pdf=PdfDocument();val left=44f;val right=551f
        fun paint(size:Float,bold:Boolean=false,color:Int=branding.ink)=Paint(Paint.ANTI_ALIAS_FLAG).apply {textSize=size;this.color=color;typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT}
        val normal=paint(10f);val bold=paint(10f,true);val small=paint(8f,false,0xff586777.toInt());val section=paint(11f,true,branding.accent)
        val rule=Paint().apply {color=0xffd6dce2.toInt();strokeWidth=1f}
        var page:PdfDocument.Page?=null;var canvas:Canvas?=null;var pageNumber=0;var y=0f
        fun wrap(text:String,p:Paint,width:Float):List<String> {
            val result=mutableListOf<String>()
            text.replace("\r","").split('\n').forEach { paragraph ->
                var rest=paragraph.trim()
                if(rest.isEmpty())result+=""
                while(rest.isNotEmpty()) {
                    var count=p.breakText(rest,true,width,null).coerceAtLeast(1)
                    if(count<rest.length){val space=rest.lastIndexOf(' ',count-1);if(space>0)count=space}
                    result+=rest.substring(0,count).trimEnd();rest=rest.substring(count).trimStart()
                }
            }
            return result
        }
        fun footer() {
            val c=canvas?:return
            c.drawLine(left,792f,right,792f,rule)
            c.drawText(wrap(name,small,315f).first(),left,808f,small)
            val created="Created ${LocalDate.now()}";c.drawText(created,right-small.measureText(created),808f,small)
            c.drawText("Page $pageNumber",left,823f,small)
        }
        fun start() {
            if(page!=null) {footer();pdf.finishPage(page!!)}
            pageNumber++;page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNumber).create());canvas=page!!.canvas
            val c=canvas!!;BrandingStore.drawDocumentBackground(c,595f,842f,branding,context)
            y=50f
            val heading=paint(21f,true,branding.accent)
            val titleLines=wrap(name,heading,340f).take(3)
            titleLines.forEach { c.drawText(it,left,y,heading);y+=25f }
            val contacts=listOf("address_line_1","address_line_2","suburb","state","postcode","mobile_number","email_address","web_url","business_number")
                .mapNotNull { key->business[key]?.takeIf(String::isNotBlank) }
            if(pageNumber==1)contacts.flatMap { value->wrap(value,small,340f) }.take(12).forEach { c.drawText(it,left,y,small);y+=11f }
            val logo=File(context.filesDir,"business-logos/profile-$profile.png")
            if(pageNumber==1 && logo.isFile && logo.length() in 1..8_000_000) {
                val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(logo.absolutePath,bounds)
                if(bounds.outWidth in 1..12000 && bounds.outHeight in 1..12000) {
                    var sample=1;while(maxOf(bounds.outWidth/sample,bounds.outHeight/sample)>800)sample*=2
                    BitmapFactory.decodeFile(logo.absolutePath,BitmapFactory.Options().apply{inSampleSize=sample})?.let { image->
                        try {val scale=minOf(130f/image.width,80f/image.height);c.drawBitmap(image,null,RectF(right-image.width*scale,35f,right,35f+image.height*scale),null)}finally{image.recycle()}
                    }
                }
            }
            y=maxOf(y,if(pageNumber==1)128f else 85f);y+=14f;c.drawLine(left,y,right,y,rule);y+=25f
            val titlePaint=paint(17f,true)
            wrap(title+if(pageNumber>1)" (continued)" else "",titlePaint,500f).forEach { c.drawText(it,left,y,titlePaint);y+=22f }
            wrap(number,small,500f).forEach { c.drawText(it,left,y,small);y+=12f };y+=15f
        }
        fun ensure(height:Float){if(y+height>776f)start()}
        try {
            start()
            rows.forEach { row ->
                val p=if(row.emphasis)section else normal
                val label=wrap(row.label,p,if(row.value.isBlank())507f else 325f)
                val values=if(row.value.isBlank())emptyList() else wrap(row.value,if(row.emphasis)bold else normal,165f)
                if(row.emphasis){ensure(25f);y+=7f}
                for(i in 0 until maxOf(label.size,values.size)) {
                    ensure(14f);label.getOrNull(i)?.let { canvas!!.drawText(it,left,y,p) }
                    values.getOrNull(i)?.let { val valuePaint=if(row.emphasis)bold else normal;canvas!!.drawText(it,right-valuePaint.measureText(it),y,valuePaint) }
                    y+=14f
                }
                y+=5f
            }
            footer();pdf.finishPage(page!!);page=null
            target.outputStream().use(pdf::writeTo)
            return target
        } catch(t:Exception){target.delete();throw t}finally{pdf.close()}
    }
}
