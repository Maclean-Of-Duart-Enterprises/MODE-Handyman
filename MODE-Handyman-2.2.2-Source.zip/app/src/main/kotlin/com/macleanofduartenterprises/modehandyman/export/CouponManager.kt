package com.macleanofduartenterprises.modehandyman.export

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

object CouponManager {
    private fun store(context:Context,profile:String)=File(context.filesDir,"coupons-$profile.json")
    fun list(context:Context,profile:String):JSONArray = runCatching {JSONArray(store(context,profile).readText())}.getOrDefault(JSONArray())
    fun save(context:Context,profile:String,coupon:JSONObject) {
        val old=list(context,profile);val result=JSONArray()
        for(i in 0 until old.length()){val item=old.getJSONObject(i);if(item.optString("id")!=coupon.optString("id"))result.put(item)}
        result.put(coupon);store(context,profile).writeText(result.toString())
    }
    fun render(context:Context,profile:String,coupon:JSONObject,logo:File?,format:String):File {
        val branding=BrandingStore.load(context,profile)
        val width=1200
        val customerName=coupon.optString("customer_name").takeIf{coupon.optLong("customer_id",0L)>0L}.orEmpty()
        val customerLayout=customerName.takeIf{it.isNotBlank()}?.let { name ->
            val text="Customer: $name"
            val customerPaint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=branding.ink;textSize=30f;typeface=Typeface.DEFAULT}
            StaticLayout.Builder.obtain(text,0,text.length,customerPaint,width-130).setIncludePad(false).build()
        }
        val customerSpace=customerLayout?.let{it.height+20}?:0
        val height=760+customerSpace
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap);canvas.drawColor(Color.WHITE)
        BrandingStore.drawPattern(canvas,width.toFloat(),height.toFloat(),branding,context)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color=branding.accent;canvas.drawRect(0f,0f,width.toFloat(),22f,paint)
        paint.color=branding.ink;paint.typeface=Typeface.DEFAULT_BOLD;paint.textSize=52f
        val business=coupon.optString("business").take(36);canvas.drawText(business,65f,105f,paint)
        paint.textSize=62f;paint.color=branding.accent;canvas.drawText("COUPON",65f,215f,paint)
        paint.textSize=44f;paint.color=branding.ink;canvas.drawText(coupon.optString("title").take(38),65f,300f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=30f
        fun line(text:String,y:Float){canvas.drawText(text.take(66),65f,y,paint)}
        line("Code: "+coupon.optString("code"),370f)
        line("Value: "+coupon.optString("value"),420f)
        line("Expires: "+coupon.optString("expiry").ifBlank {"No expiry"},470f)
        customerLayout?.let{canvas.save();canvas.translate(65f,500f);it.draw(canvas);canvas.restore()}
        line("Terms: "+coupon.optString("terms"),530f+customerSpace)
        if(coupon.optBoolean("used")){paint.color=Color.RED;paint.textSize=58f;paint.typeface=Typeface.DEFAULT_BOLD;canvas.drawText("USED — NOT REDEEMABLE",65f,625f+customerSpace,paint)}
        paint.color=branding.ink;paint.textSize=23f;paint.typeface=Typeface.DEFAULT
        line("Issued "+LocalDate.now(),700f+customerSpace)
        if(logo?.isFile==true){val image=BitmapFactory.decodeFile(logo.absolutePath,BitmapFactory.Options().apply{inSampleSize=2});if(image!=null)try{canvas.drawBitmap(image,null,RectF(950f,55f,1140f,175f),null)}finally{image.recycle()}}
        val folder=File(context.filesDir,"exports").apply{mkdirs()};val name="coupon-"+coupon.optString("id").replace(Regex("[^A-Za-z0-9-]"),"")+"-"+System.currentTimeMillis()
        val target=File(folder,name+if(format=="pdf")".pdf" else ".jpg")
        try {if(format=="pdf") {val pdf=PdfDocument();try{val page=pdf.startPage(PdfDocument.PageInfo.Builder(width,height,1).create());page.canvas.drawBitmap(bitmap,0f,0f,null);pdf.finishPage(page);target.outputStream().use{pdf.writeTo(it)}}finally{pdf.close()}}else target.outputStream().use{bitmap.compress(Bitmap.CompressFormat.JPEG,94,it)}}finally{bitmap.recycle()}
        return target
    }
}
