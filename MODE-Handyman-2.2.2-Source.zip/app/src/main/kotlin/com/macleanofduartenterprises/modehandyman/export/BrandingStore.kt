package com.macleanofduartenterprises.modehandyman.export

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import java.io.File

data class Branding(val accent:Int, val ink:Int, val pattern:String, val image:File?, val documentLayout:String=FULL_BACKGROUND)

const val FULL_BACKGROUND="Full background"
const val WHITE_BACKGROUND="White background"
const val HEADER_ONLY="Header only"

object BrandingStore {
    fun load(context:Context, profile:String):Branding {
        val prefs=context.getSharedPreferences("mode_branding_"+profile,Context.MODE_PRIVATE)
        val image=File(context.filesDir,"brand-pattern-$profile.jpg")
        return Branding(prefs.getInt("accent",0xffaa8930.toInt()),prefs.getInt("ink",0xff233243.toInt()),prefs.getString("pattern","None")?:"None",image.takeIf { it.isFile },prefs.getString("document_layout",FULL_BACKGROUND)?:FULL_BACKGROUND)
    }
    fun save(context:Context,profile:String,accent:Int,ink:Int,pattern:String,documentLayout:String?=null) {
        val edit=context.getSharedPreferences("mode_branding_"+profile,Context.MODE_PRIVATE).edit().putInt("accent",accent).putInt("ink",ink).putString("pattern",pattern)
        if(documentLayout!=null)edit.putString("document_layout",documentLayout)
        edit.apply()
    }
    fun drawPattern(canvas:Canvas,width:Float,height:Float,branding:Branding,context:Context) {
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=branding.accent;alpha=18;strokeWidth=1f }
        when(branding.pattern) {
            "Stripes" -> { var x=0f;while(x<width+height){canvas.drawLine(x,0f,x-height,height,paint);x+=36f} }
            "Dots" -> { var x=20f;while(x<width){var y=20f;while(y<height){canvas.drawCircle(x,y,2f,paint);y+=34f};x+=34f} }
            "Grid" -> {var x=0f;while(x<width){canvas.drawLine(x,0f,x,height,paint);x+=38f};var y=0f;while(y<height){canvas.drawLine(0f,y,width,y,paint);y+=38f}}
            "Uploaded image" -> branding.image?.let { file ->
                val bitmap=BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply{inSampleSize=4})
                if(bitmap!=null)try { val overlay=Paint().apply{alpha=35};canvas.drawBitmap(bitmap,null,RectF(0f,0f,width,height),overlay) }finally{bitmap.recycle()}
            }
        }
    }

    /** An opaque white page is required even when a viewer uses a tinted canvas. */
    fun drawDocumentBackground(canvas:Canvas,width:Float,height:Float,branding:Branding,context:Context,layout:String=branding.documentLayout) {
        canvas.drawColor(Color.WHITE)
        when(layout) {
            FULL_BACKGROUND -> drawPattern(canvas,width,height,branding,context)
            HEADER_ONLY -> {
                canvas.save();canvas.clipRect(0f,0f,width,20f)
                canvas.drawColor(branding.ink)
                if(branding.pattern=="Uploaded image") {
                    val bitmap=branding.image?.let{BitmapFactory.decodeFile(it.absolutePath,BitmapFactory.Options().apply{inSampleSize=4})}
                    if(bitmap!=null)try{canvas.drawBitmap(bitmap,null,RectF(0f,0f,width,width*bitmap.height/bitmap.width),Paint(Paint.FILTER_BITMAP_FLAG))}finally{bitmap.recycle()}
                } else drawPattern(canvas,width,20f,branding,context)
                canvas.restore()
                canvas.drawRect(0f,20f,width,22f,Paint().apply{color=branding.accent})
            }
        }
    }

    /** Decode an uploaded pattern once per screen, rather than on every redraw. */
    fun appBackground(context:Context,branding:Branding,base:Int):Drawable {
        val bitmap=if(branding.pattern=="Uploaded image")branding.image?.let { file ->
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeFile(file.absolutePath,bounds)
            var sample=1
            while(maxOf(bounds.outWidth/sample,bounds.outHeight/sample)>1024)sample*=2
            BitmapFactory.decodeFile(file.absolutePath,BitmapFactory.Options().apply{inSampleSize=sample})
        } else null
        return object:Drawable() {
            override fun draw(canvas:Canvas) {
                canvas.save();canvas.translate(bounds.left.toFloat(),bounds.top.toFloat())
                canvas.drawColor(base)
                if(bitmap!=null)canvas.drawBitmap(bitmap,null,RectF(0f,0f,bounds.width().toFloat(),bounds.height().toFloat()),Paint(Paint.FILTER_BITMAP_FLAG).apply{alpha=38})
                else drawPattern(canvas,bounds.width().toFloat(),bounds.height().toFloat(),branding,context)
                canvas.restore()
            }
            override fun setAlpha(alpha:Int) {}
            override fun setColorFilter(filter:ColorFilter?) {}
            @Deprecated("Deprecated in Java") override fun getOpacity()=PixelFormat.OPAQUE
        }
    }
}
