package com.macleanofduartenterprises.modehandyman.export

import com.macleanofduartenterprises.modehandyman.core.*
import com.macleanofduartenterprises.modehandyman.data.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PayrollDocumentsTest {
    private fun stub():PayrollStub {
        val pay=PayrollPay(2500,taxes=listOf(PayrollTax("Employee tax","Withheld",value="10"),PayrollTax("Employer share","Contribution",value="5",employer=true)))
        val entries=listOf(PayrollEntry("2026-11-16","08:00","16:00",notes="Job A"))
        val worker=PayrollWorker(7,1,"Original employee name",address="Original address",pay=pay)
        val r=Payroll.calculate(pay,entries)
        val snapshot=JSONObject().put("worker",PayrollCodec.worker(worker)).put("pay",PayrollCodec.pay(pay)).put("entries",PayrollCodec.entries(entries)).put("calculation",PayrollCodec.calculation(r))
        return PayrollStub(1,1,7,1,1,"PS-1-1-R1","2026-11-20","2026-11-16","2026-11-22","Weekly",r.gross,r.deductions,r.net,r.employerContributions,r.workedSeconds,"2026-11-20T12:00:00Z","",snapshot)
    }
    @Test fun paystubUsesStoredNamesNetAndSeparatedEmployerAmounts() {
        val stub=stub();val rows=PayrollDocuments.paystubRows(stub,listOf(stub))
        assertTrue(rows.any {it.label=="Worker" && it.value=="Original employee name"})
        assertTrue(rows.any {it.label=="NET PAY" && it.value=="$180.00"})
        assertTrue(rows.any {it.label=="Employer share" && it.value=="$10.00"})
        assertTrue(rows.any {it.label.contains("EMPLOYER CONTRIBUTIONS")})
        assertTrue(rows.any {it.label=="Withheld"})
    }
    @Test fun ytdExcludesSupersededFutureAndOtherYearStubs() {
        val stub=stub();val rows=PayrollDocuments.paystubRows(stub,listOf(stub,stub.copy(id=2,voidedAt="voided"),stub.copy(id=3,payDate="2026-12-31"),stub.copy(id=4,payDate="2025-11-20")))
        assertEquals("$200.00",rows.first {it.label=="Gross pay"}.value)
        assertEquals("$180.00",rows.first {it.label=="Net pay"}.value)
    }
    @Test fun reprintedStubRetainsYearToDateFromApproval() {
        val original = stub()
        original.snapshot.put("year_to_date", JSONObject().put("gross", 20000).put("deductions", 2000).put("net", 18000))
        val laterApproval = original.copy(id = 2, payDate = original.payDate)
        val rows = PayrollDocuments.paystubRows(original, listOf(original, laterApproval))
        assertEquals("$200.00", rows.single { it.label == "Gross pay" }.value)
        assertEquals("$180.00", rows.single { it.label == "Net pay" }.value)
    }
    @Test fun timecardDocumentKeepsTimeSeparateFromPaystubTotals() {
        val stub=stub();val w=PayrollCodec.worker(stub.snapshot.getJSONObject("worker"));val entries=PayrollCodec.entries(stub.snapshot.getJSONArray("entries"))
        val card=PayrollCard(1,1,7,stub.start,stub.end,stub.payDate,status="approved",entries=entries,pay=w.pay)
        val rows=PayrollDocuments.timecardRows(card,w)
        assertTrue(rows.any {it.label=="TOTAL WORKED TIME" && it.value=="8h 0m"})
        assertFalse(rows.any {it.label=="NET PAY"})
    }
}
