package com.macleanofduartenterprises.modehandyman.export

import android.content.ContextWrapper
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class CouponManagerTest {
    @get:Rule val temporary = TemporaryFolder()

    private fun context() = object : ContextWrapper(null) {
        override fun getFilesDir(): File = temporary.root
    }

    @Test fun attachedCustomerSurvivesReloadAndUsedToggle() {
        val context = context()
        val coupon = JSONObject().put("id", "c1").put("title", "Spring offer")
            .put("customer_id", 42L).put("customer_name", "Example Customer").put("used", false)
        CouponManager.save(context, "1", coupon)
        val reloaded = CouponManager.list(context, "1").getJSONObject(0)
        reloaded.put("used", true)
        CouponManager.save(context, "1", reloaded)
        val saved = CouponManager.list(context, "1")
        assertEquals(1, saved.length())
        assertEquals(42L, saved.getJSONObject(0).getLong("customer_id"))
        assertEquals("Example Customer", saved.getJSONObject(0).getString("customer_name"))
        assertTrue(saved.getJSONObject(0).getBoolean("used"))
    }

    @Test fun detachingCustomerPersistsWithoutDuplicatingCoupon() {
        val context = context()
        CouponManager.save(context, "1", JSONObject().put("id", "c1")
            .put("customer_id", 42L).put("customer_name", "Example Customer"))
        val coupon = CouponManager.list(context, "1").getJSONObject(0)
        coupon.remove("customer_id")
        coupon.remove("customer_name")
        CouponManager.save(context, "1", coupon)
        val saved = CouponManager.list(context, "1")
        assertEquals(1, saved.length())
        assertFalse(saved.getJSONObject(0).has("customer_id"))
        assertFalse(saved.getJSONObject(0).has("customer_name"))
    }

    @Test fun existingGeneralCouponsNeedNoMigrationOrCustomer() {
        val context = context()
        File(temporary.root, "coupons-1.json").writeText("""[{"id":"old","title":"General offer","used":true}]""")
        val coupon = CouponManager.list(context, "1").getJSONObject(0)
        coupon.put("title", "Edited general offer")
        CouponManager.save(context, "1", coupon)
        val saved = CouponManager.list(context, "1").getJSONObject(0)
        assertEquals("Edited general offer", saved.getString("title"))
        assertTrue(saved.getBoolean("used"))
        assertFalse(saved.has("customer_id"))
    }

    @Test fun customerLinksRemainSeparateForEachBusinessProfile() {
        val context = context()
        CouponManager.save(context, "1", JSONObject().put("id", "same-code").put("customer_id", 42L))
        CouponManager.save(context, "2", JSONObject().put("id", "same-code").put("customer_id", 99L))
        assertEquals(42L, CouponManager.list(context, "1").getJSONObject(0).getLong("customer_id"))
        assertEquals(99L, CouponManager.list(context, "2").getJSONObject(0).getLong("customer_id"))
    }
}
