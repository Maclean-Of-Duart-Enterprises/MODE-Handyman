package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.*
import org.junit.Test

class DocumentDiscountTest {
    @Test fun screenshotExampleSupportsBothSixtyDollarsAndTenPercent() {
        val amount=DocumentDiscount.parse(DiscountType.AMOUNT,"60","Trade-in reward","Two accepted devices")
        val percent=DocumentDiscount.parse(DiscountType.PERCENT,"10","Trade-in reward","Two accepted devices")
        assertEquals(6000L,amount.cents(60000))
        assertEquals(6000L,percent.cents(60000))
        assertEquals(54000L,MoneyMath.quoteTotal(60000,percent.cents(60000),0))
    }
    @Test fun percentageRecalculatesAfterAddingOrEditingItems() {
        val d=DocumentDiscount.parse(DiscountType.PERCENT,"10","Discount","")
        assertEquals(6000L,d.cents(60000));assertEquals(7000L,d.cents(70000))
        assertEquals(63000L,MoneyMath.quoteTotal(70000,d.cents(70000),0))
    }
    @Test fun fixedAmountRemainsFixedWhenItemsChange() {
        val d=DocumentDiscount(value=6000)
        assertEquals(6000L,d.cents(60000));assertEquals(6000L,d.cents(70000))
    }
    @Test fun transferPreservesDiscountMetadataAndNetTaxCalculation() {
        val quote=DocumentDiscount.parse(DiscountType.PERCENT,"12.5","Returning customer","Thank you for your repeat business")
        val invoice=quote.copy()
        assertEquals("Returning customer (12.5%)",invoice.displayLabel())
        assertEquals(quote.description,invoice.description)
        val subtotal=60000L
        assertEquals(55650L,MoneyMath.quoteTotal(subtotal,invoice.cents(subtotal),600))
        assertEquals(quote.cents(subtotal),invoice.cents(subtotal))
    }
    @Test fun discountIsCappedAndNeverCreatesANegativeTotal() {
        assertEquals(1000L,DocumentDiscount(value=5000).cents(1000))
        assertEquals(0L,DocumentDiscount(value=5000).cents(0))
        val d=DocumentDiscount(DiscountType.PERCENT,10000)
        assertEquals(0L,MoneyMath.quoteTotal(1000,d.cents(1000),600))
    }
    @Test fun percentageRoundingUsesExactCentsAndHalfUp() {
        val d=DocumentDiscount.parse(DiscountType.PERCENT,"12.50","Discount","")
        assertEquals(1250L,d.value);assertEquals(1L,d.cents(4))
        assertEquals("12.5",d.inputText())
    }
    @Test fun rejectsNegativeOutOfRangeAndNonNumericValues() {
        for(value in listOf("-0.001","100.001","NaN","Infinity","ten")) {
            assertThrows(IllegalArgumentException::class.java){DocumentDiscount.parse(DiscountType.PERCENT,value,"Discount","")}
        }
        assertThrows(IllegalArgumentException::class.java){DocumentDiscount.parse(DiscountType.AMOUNT,"-1","Discount","")}
        assertThrows(IllegalArgumentException::class.java){DocumentDiscount.taxHundredths("-0.001")}
    }
    @Test fun labelsAndDescriptionsKeepCustomUnicodeText() {
        val d=DocumentDiscount.parse(DiscountType.AMOUNT,"$60.00","Скидка за обмен","Два устройства — one-time credit")
        assertEquals("Скидка за обмен",d.displayLabel());assertEquals("Два устройства — one-time credit",d.description)
        assertEquals("Discount",DocumentDiscount.parse(DiscountType.AMOUNT,"0"," ","").label)
    }
    @Test fun paidBalanceUsesTheDiscountedInvoiceTotal() {
        val d=DocumentDiscount(DiscountType.PERCENT,1000)
        val total=MoneyMath.quoteTotal(60000,d.cents(60000),0)
        assertEquals(34000L,MoneyMath.invoiceBalance(total,20000))
        assertTrue(MoneyMath.invoicePaid(total,54000))
    }
}
