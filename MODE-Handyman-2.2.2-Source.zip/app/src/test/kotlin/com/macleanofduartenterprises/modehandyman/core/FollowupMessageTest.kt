package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.*
import org.junit.Test

class FollowupMessageTest {
    private val settings=FollowupSettings(enabled=true,facebookUrl="https://www.facebook.com/example",mapsUrl="https://g.page/r/example/review")
    @Test fun disabledDefaultsDoNotRequireLinksAndNeverAllowTriggers() {
        val s=FollowupSettings();s.validate();assertFalse(s.allows("invoice_paid"));assertFalse(s.allows("job_finished"))
    }
    @Test fun facebookOnlyExcludesMapsLink() {
        val text=FollowupMessage.render(settings.copy(maps=false),mapOf("customer" to "Alex","business" to "Example"))
        assertTrue(text.contains(settings.facebookUrl));assertFalse(text.contains(settings.mapsUrl))
    }
    @Test fun mapsOnlyExcludesFacebookLink() {
        val text=FollowupMessage.render(settings.copy(facebook=false),emptyMap())
        assertFalse(text.contains(settings.facebookUrl));assertTrue(text.contains(settings.mapsUrl))
    }
    @Test fun bothLinksAreIncludedWithoutDuplicatingEmbeddedLinks() {
        val text=FollowupMessage.render(settings.copy(template="Thank you: ${settings.facebookUrl}"),emptyMap())
        assertEquals(1,Regex(Regex.escape(settings.facebookUrl)).findAll(text).count())
        assertEquals(1,Regex(Regex.escape(settings.mapsUrl)).findAll(text).count())
    }
    @Test fun placeholderReplacementIsSinglePassAndKeepsCustomUnicode() {
        val text=FollowupMessage.render(settings.copy(template="Спасибо, {customer}! {business} / {job} / {invoice} / {event}"),mapOf("customer" to "{business}","business" to "Example","job" to "Repair","invoice" to "I-1","event" to "invoice paid"))
        assertTrue(text.startsWith("Спасибо, {business}! Example / Repair / I-1 / invoice paid"))
    }
    @Test fun enabledSettingsRequireADestinationAndATrigger() {
        assertThrows(IllegalArgumentException::class.java){settings.copy(facebook=false,maps=false).validate()}
        assertThrows(IllegalArgumentException::class.java){settings.copy(invoicePaid=false,jobFinished=false).validate()}
        assertThrows(IllegalArgumentException::class.java){settings.copy(template=" ").validate()}
    }
    @Test fun triggersAreIndependent() {
        val s=settings.copy(jobFinished=false)
        assertTrue(s.allows("invoice_paid"));assertFalse(s.allows("job_finished"));assertFalse(s.allows("unknown"))
    }
    @Test fun validatesSelectedHttpLinksWithoutAllowingCredentialsOrControlCharacters() {
        for(link in listOf("", "javascript:alert(1)","https://user:password@example.com","https://example.com\nother","https://")) {
            assertThrows(IllegalArgumentException::class.java){settings.copy(facebookUrl=link).validate()}
        }
        settings.copy(facebook=false,facebookUrl="unused").validate()
    }
    @Test fun phoneNumbersAreNormalizedWithoutChoosingAnArbitraryCountryCode() {
        assertEquals("+17175006020",FollowupMessage.phone("+1 (717) 500-6020"))
        assertEquals("7175006020",FollowupMessage.phone("717.500.6020"))
    }
    @Test fun rejectsShortCodesUssdMultipleRecipientsAndExtensions() {
        for(phone in listOf("911","*123#","+17175006020;+17175551234","7175006020 ext 2","++17175006020","")) {
            assertThrows(IllegalArgumentException::class.java){FollowupMessage.phone(phone)}
        }
    }
}
