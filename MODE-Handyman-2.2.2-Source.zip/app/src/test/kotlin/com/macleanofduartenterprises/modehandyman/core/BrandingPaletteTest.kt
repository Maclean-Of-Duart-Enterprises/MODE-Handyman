package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.*
import org.junit.Test

class BrandingPaletteTest {
    @Test fun controlsRemainReadableAcrossBrightDarkAndSaturatedBrandColors() {
        val colors=listOf(0xff000000.toInt(),0xffffffff.toInt(),0xffffff00.toInt(),0xff0000ff.toInt(),0xff00ff00.toInt(),0xffff0000.toInt(),0xff74a5ce.toInt(),0xffaa8930.toInt())
        for(ink in colors)for(accent in colors) {
            val p=BrandingPalette.from(ink,accent)
            assertTrue(BrandingPalette.contrast(p.accent,p.accentText)>=4.5)
            assertTrue(BrandingPalette.contrast(p.highlight,p.background)>=4.5)
            assertTrue(BrandingPalette.contrast(p.highlight,p.surface)>=4.5)
            assertTrue(BrandingPalette.contrast(0xffffffff.toInt(),p.surface)>=4.5)
        }
    }
    @Test fun brandAccentIsPreservedForButtons() {
        assertEquals(0xff74a5ce.toInt(),BrandingPalette.from(0xff233243.toInt(),0xff74a5ce.toInt()).accent)
    }
    @Test fun changingInkChangesTheAppBackgroundAndSurface() {
        val first=BrandingPalette.from(0xff233243.toInt(),0xffaa8930.toInt())
        val second=BrandingPalette.from(0xff204020.toInt(),0xffaa8930.toInt())
        assertNotEquals(first.background,second.background)
        assertNotEquals(first.surface,second.surface)
    }
}
