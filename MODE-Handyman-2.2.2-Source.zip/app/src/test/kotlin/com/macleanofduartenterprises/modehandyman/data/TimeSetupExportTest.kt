package com.macleanofduartenterprises.modehandyman.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class TimeSetupExportTest {
    private val worker=PayrollWorker(29,2,"Anne, \"Аня\"",phone="+1-555-0100",email="anne@example.org",address="5 Main St",notes="private")
    private val job=TimeJob(31,2,"Repair, trim","J-17","40.35,-76.42")

    @Test fun setupContainsOneWorkerOnlySelectedJobsAndContactDetails() {
        val setup=JSONObject(TimeSetupExport.setup(worker,listOf(job to JobOptions(multiplier="1.5",hours="4")),"8","40"))
        assertEquals("time.setup.v1",setup.getString("format"))
        val person=setup.getJSONArray("employees").getJSONObject(0)
        assertEquals("29",person.getString("employee_id"))
        assertEquals(worker.name,person.getString("name"))
        assertEquals(worker.address,person.getString("address"))
        assertEquals(worker.phone,person.getString("phone"))
        assertEquals(worker.email,person.getString("email"))
        assertFalse(person.getJSONObject("pay").has("taxes")); assertFalse(person.has("notes"))
        assertEquals("40",person.getJSONObject("fields").getString("Weekly hour limit"))
        val item=setup.getJSONArray("jobs").getJSONObject(0)
        assertEquals("MODE-2-31",item.getString("job_code"))
        assertEquals(job.address,item.getString("job_site_address"))
        assertEquals("4",item.getJSONObject("fields").getString("Job hour limit"))
        assertEquals(0,JSONObject(TimeSetupExport.setup(worker,emptyList(),"","")).getJSONArray("jobs").length())
    }
    @Test fun exportPreservesThePinAndExactRate() {
        val pay=worker.pay.copy(rateCents=1845,incrementMinutes=30,incrementLabel="half hour")
        val json=JSONObject(TimeSetupExport.setup(worker.copy(pay=pay),emptyList(),"","","001234"))
        assertEquals("001234",json.getString("admin_password"))
        val person=json.getJSONArray("employees").getJSONObject(0)
        assertEquals(1845L,person.getJSONObject("pay").getLong("rate_cents"))
        assertEquals(30L,person.getJSONObject("pay").getLong("increment_minutes"))
        assertEquals("$18.45 / half hour (30 working min)",person.getJSONObject("fields").getString("Pay rate"))
        val fixed=JSONObject(TimeSetupExport.setup(worker.copy(pay=pay.copy(basis="period")),emptyList(),"",""))
        assertFalse(fixed.has("admin_password"))
        assertEquals("$18.45 / pay period",fixed.getJSONArray("employees").getJSONObject(0).getJSONObject("fields").getString("Pay rate"))
    }
    @Test fun rejectPinsTimeCannotUse() {
        for(pin in listOf("12345","1234567890123","12a456"," 123456","１２３４５６"))
            assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.setup(worker,emptyList(),"","",pin) }
    }
    @Test fun jobAndEmployeeCsvPreserveQuotedFieldsAndRouteOverride() {
        assertTrue(TimeSetupExport.workerCsv(worker,"8","40").contains("\"Anne, \"\"Аня\"\"\""))
        val file=TimeSetupExport.jobsCsv(listOf(job to JobOptions("42 East St, Unit 2","2","6")))
        assertTrue(file.contains("\"Repair, trim\",\"MODE-2-31\",\"2\",\"42 East St, Unit 2\""))
        assertTrue(file.endsWith("\r\n"))
        assertEquals("MODE-2-31 · Repair, trim",TimeSetupExport.jobCaption("Job: MODE-2-31 · Repair, trim\nReplace trim"))
        assertEquals("",TimeSetupExport.jobCaption("Repair, trim"))
    }
    @Test fun rejectInvalidLimitsOrAnotherBusiness() {
        assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.setup(worker,listOf(job.copy(profile=3) to JobOptions()),"","") }
        assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.workerCsv(worker,"24.1","") }
        assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.workerCsv(worker,"","169") }
        assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.jobsCsv(listOf(job to JobOptions(hours="-1"))) }
        assertThrows(IllegalArgumentException::class.java){ TimeSetupExport.jobsCsv(listOf(job to JobOptions(multiplier="12"))) }
    }
}
