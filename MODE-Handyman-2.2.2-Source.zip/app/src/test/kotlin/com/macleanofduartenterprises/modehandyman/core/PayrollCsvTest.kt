package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.*
import org.junit.Test

class PayrollCsvTest {
    private fun fails(csv:String) {try{PayrollCsv.parse(csv);fail("Expected CSV validation failure")}catch(expected:IllegalArgumentException){assertFalse(expected.message.isNullOrBlank())}}
    @Test fun templateParsesEightNetHours() {assertEquals(28800,PayrollCsv.parse(PayrollCsv.template()).entries.single().workedSeconds())}
    @Test fun bomAliasesAndUsDatesAreAccepted() {
        val e=PayrollCsv.parse("\uFEFFwork_date,clock_in,clock_out,unpaid_break_minutes\r\n11/16/2026,8:00,16:30,30\r\n").entries.single()
        assertEquals("2026-11-16",e.date);assertEquals(28800,e.workedSeconds())
    }
    @Test fun twelveHourTimesAreAccepted() {assertEquals(28800,PayrollCsv.parse("date,start,end,break_minutes\n2026-11-16,8:00 AM,4:30PM,30").entries.single().workedSeconds())}
    @Test fun semicolonAndTabDelimitersAreAccepted() {
        for(delimiter in listOf(';','\t'))assertEquals(9000,PayrollCsv.parse("date${delimiter}hours\n2026-11-16${delimiter}2.5").entries.single().workedSeconds())
    }
    @Test fun quotedCommasQuotesAndNewlinesArePreserved() {
        val e=PayrollCsv.parse("date,hours,notes\r\n2026-11-16,1,\"Job, A\nHe said \"\"done\"\"\"\r\n").entries.single()
        assertEquals("Job, A\nHe said \"done\"",e.notes)
    }
    @Test fun hoursOnlyAreNetWithBreakAddedBackForEditing() {
        val e=PayrollCsv.parse("date,hours,break_minutes\n2026-11-16,4.25,30").entries.single()
        assertEquals(17100,e.durationSeconds);assertEquals(1800,e.breakSeconds);assertEquals(15300,e.workedSeconds())
    }
    @Test fun hmsHoursAndWorkedSecondsAreSupported() {
        assertEquals(3661,PayrollCsv.parse("date,hours\n2026-11-16,1:01:01").entries.single().workedSeconds())
        assertEquals(901,PayrollCsv.parse("date,worked_seconds\n2026-11-16,901").entries.single().workedSeconds())
    }
    @Test fun approvedExportRoundTripsSecondsNotesIdentityAndPayPeriod() {
        val entries=listOf(PayrollEntry("2026-11-16","22:00:01","06:00:02",900,multiplier="1.5",notes="Работа, \"готово\"\nNext line"),PayrollEntry("2026-11-17",durationSeconds=3662,breakSeconds=61,notes="Second job"))
        val original=PayrollCsv.export(entries,12,"Иван",3,"2026-11-16","2026-11-22","2026-11-27","Weekly")
        val imported=PayrollCsv.parse(original)
        assertEquals(entries,imported.entries);assertEquals("12",imported.employeeId);assertEquals("3",imported.profileId);assertEquals("Иван",imported.employeeName)
        assertEquals("2026-11-16",imported.periodStart);assertEquals("2026-11-22",imported.periodEnd);assertEquals("2026-11-27",imported.payDate);assertEquals("Weekly",imported.cadence)
    }
    @Test fun clockAndSuppliedDurationMustAgree() {
        fails("date,start,end,hours\n2026-11-16,08:00,09:00,2")
        fails("date,hours,worked_seconds\n2026-11-16,1,7200")
    }
    @Test fun malformedCsvAndDuplicateHeadingsAreRejected() {
        fails("date,hours,notes\n2026-11-16,1,\"unfinished")
        fails("date,hours,notes\n2026-11-16,1,\"a\"junk")
        fails("date,hours,total_hours\n2026-11-16,1,1")
        fails("date,hours\n2026-11-16,1,extra")
    }
    @Test fun invalidDatesMissingTimesAndNegativeHoursAreRejected() {
        fails("date,hours\n2026-02-30,1");fails("date,hours\n2/30/2026,1");fails("date,hours\n2026-11-16,-1")
        fails("date,start,end\n2026-11-16,08:00,");fails("date,hours\n2026-11-16,")
    }
    @Test fun mixedEmployeeOrBusinessOrPayDatesAreRejected() {
        fails("date,hours,employee_id\n2026-11-16,1,1\n2026-11-17,1,2")
        fails("date,hours,business_profile_id\n2026-11-16,1,1\n2026-11-17,1,2")
        fails("date,hours,pay_date\n2026-11-16,1,2026-11-20\n2026-11-17,1,2026-11-27")
    }
    @Test fun overnightCsvComputesNextDayEnd() {assertEquals(28800,PayrollCsv.parse("date,start,end\n2026-11-16,22:00,06:00").entries.single().workedSeconds())}
    @Test fun missingRequiredHeaderAndEmptyFileAreRejected() {fails("");fails("date,hours\n");fails("hours\n1");fails("date,notes\n2026-11-16,work")}
}
