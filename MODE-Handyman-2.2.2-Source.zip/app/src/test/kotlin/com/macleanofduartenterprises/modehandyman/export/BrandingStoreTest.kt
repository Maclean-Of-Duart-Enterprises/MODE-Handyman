package com.macleanofduartenterprises.modehandyman.export

import android.content.ContextWrapper
import android.content.SharedPreferences
import java.io.File
import java.lang.reflect.Proxy
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class BrandingStoreTest {
    @get:Rule val temporary=TemporaryFolder()
    private val stores=mutableMapOf<String,SharedPreferences>()
    private fun preferences():SharedPreferences {
        val values=mutableMapOf<String,Any?>()
        val editor=Proxy.newProxyInstance(javaClass.classLoader,arrayOf(SharedPreferences.Editor::class.java)){proxy,method,args ->
            when {
                method.name.startsWith("put") -> {values[args!![0] as String]=args[1];proxy}
                method.name=="apply" -> null
                method.name=="commit" -> true
                else -> proxy
            }
        } as SharedPreferences.Editor
        return Proxy.newProxyInstance(javaClass.classLoader,arrayOf(SharedPreferences::class.java)){_,method,args ->
            when {
                method.name=="edit" -> editor
                method.name.startsWith("get") -> values[args!![0] as String]?:args[1]
                else -> null
            }
        } as SharedPreferences
    }
    private fun context()=object:ContextWrapper(null) {
        override fun getFilesDir():File=temporary.root
        override fun getSharedPreferences(name:String,mode:Int):SharedPreferences=stores.getOrPut(name,::preferences)
    }
    @Test fun oldProfilesKeepTheirExistingFullBackgroundLayout() {
        assertEquals(FULL_BACKGROUND,BrandingStore.load(context(),"old").documentLayout)
    }
    @Test fun changingPatternDoesNotResetHeaderOnlySelection() {
        val c=context()
        BrandingStore.save(c,"1",7,8,"Grid",HEADER_ONLY)
        BrandingStore.save(c,"1",7,8,"Uploaded image")
        val saved=BrandingStore.load(c,"1")
        assertEquals(HEADER_ONLY,saved.documentLayout)
        assertEquals("Uploaded image",saved.pattern)
    }
    @Test fun whiteDocumentChoiceKeepsPatternAvailableForTheAppAndCoupons() {
        val c=context()
        BrandingStore.save(c,"1",7,8,"Grid",WHITE_BACKGROUND)
        assertEquals("Grid",BrandingStore.load(c,"1").pattern)
        assertEquals(WHITE_BACKGROUND,BrandingStore.load(c,"1").documentLayout)
    }
    @Test fun businessProfilesRetainIndependentBrandingAndLayouts() {
        val c=context()
        BrandingStore.save(c,"1",7,8,"Grid",HEADER_ONLY)
        BrandingStore.save(c,"2",9,10,"Dots",WHITE_BACKGROUND)
        assertEquals(HEADER_ONLY,BrandingStore.load(c,"1").documentLayout)
        assertEquals(WHITE_BACKGROUND,BrandingStore.load(c,"2").documentLayout)
        assertEquals("Grid",BrandingStore.load(c,"1").pattern)
    }
}
