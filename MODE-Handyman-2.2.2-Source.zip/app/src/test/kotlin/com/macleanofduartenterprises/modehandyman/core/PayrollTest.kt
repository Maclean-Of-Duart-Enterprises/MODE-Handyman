package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.*
import org.junit.Test

class PayrollTest {
    private fun hours(value:String,multiplier:String="1")=PayrollEntry("2026-11-16",durationSeconds=Payroll.secondsFromHours(value),multiplier=multiplier)
    private fun fails(action:()->Unit) {try{action();fail("Expected validation failure")}catch(expected:IllegalArgumentException){assertFalse(expected.message.isNullOrBlank())}}
    @Test fun hourlyPayUsesNetWorkedTime() {
        val result=Payroll.calculate(PayrollPay(2500),listOf(PayrollEntry("2026-11-16","08:00","16:30",1800)))
        assertEquals(28800,result.workedSeconds);assertEquals(20000,result.gross);assertEquals(20000,result.net)
    }
    @Test fun percentagesFlatTaxesAndEmployerContributionsAreSeparate() {
        val result=Payroll.calculate(PayrollPay(2500,taxes=listOf(PayrollTax("Tax A",value="6.2"),PayrollTax("Tax B",value="1.45"),PayrollTax("Flat",type="fixed",value="5.00"),PayrollTax("Employer",type="fixed",value="7.00",employer=true))),listOf(hours("8")))
        assertEquals(listOf(1240L,290L,500L,700L),result.taxes.map {it.cents})
        assertEquals(2030,result.deductions);assertEquals(700,result.employerContributions);assertEquals(17970,result.net)
    }
    @Test fun disabledTaxDoesNotAffectPay() {
        val r=Payroll.calculate(PayrollPay(2000,taxes=listOf(PayrollTax("Off",value="99",enabled=false))),listOf(hours("1")))
        assertEquals(2000,r.net);assertTrue(r.taxes.isEmpty())
    }
    @Test fun manuallyMarkedPremiumUsesMultiplier() {
        assertEquals(31250,Payroll.calculate(PayrollPay(2500),listOf(hours("8"),hours("3","1.5"))).gross)
    }
    @Test fun customPayIncrementDoesNotRoundTimeToTheNextIncrement() {
        assertEquals(3750,Payroll.calculate(PayrollPay(7500,incrementMinutes=120,incrementLabel="two hours"),listOf(hours("1"))).gross)
    }
    @Test fun fixedPeriodPaidOnceAndIgnoresPremiumMultiplier() {
        val result=Payroll.calculate(PayrollPay(100000,basis="period"),listOf(hours("8"),hours("8","1.5")))
        assertEquals(100000,result.gross);assertEquals(listOf(0L,0L),result.earnings)
    }
    @Test fun earningsRoundHalfUpPerEntryAndSumThoseAmounts() {
        assertEquals(2,Payroll.calculate(PayrollPay(1),listOf(hours("0.5"),hours("0.5"))).gross)
        assertEquals(626,Payroll.calculate(PayrollPay(2500),listOf(hours("0:15:01"))).gross)
    }
    @Test fun overnightShiftSubtractsBreak() {assertEquals(27000,PayrollEntry("2026-11-16","22:00","06:00",1800).workedSeconds())}
    @Test fun secondsAndHourFormattingRoundTripToOneSecond() {
        for(seconds in listOf(1L,59L,60L,3599L,3601L,86399L,86400L))assertEquals(seconds,Payroll.secondsFromHours(Payroll.hours(seconds)))
    }
    @Test fun excessiveDeductionsPreventApprovalCalculation() {fails{Payroll.calculate(PayrollPay(1000,taxes=listOf(PayrollTax("Flat",type="fixed",value="20"))),listOf(hours("1")))}}
    @Test fun invalidMoneyPercentMultiplierAndTimeAreRejected() {
        fails{Payroll.cents("-1")};fails{Payroll.cents("1.001")};fails{PayrollTax("Tax",value="100.1").validate()}
        fails{hours("1","-1").workedSeconds()};fails{hours("1","11").workedSeconds()};fails{PayrollEntry("2026-11-16","08:00","08:00").workedSeconds()}
        fails{PayrollEntry("2026-11-16","08:00","09:00",3600).workedSeconds()};fails{PayrollEntry("2026-11-16",durationSeconds=0).workedSeconds()}
    }
    @Test fun periodRejectsOutOfRangeEntriesAndReversedDates() {
        fails{Payroll.validatePeriod("2026-11-17","2026-11-20","2026-11-20",listOf(hours("1")))}
        fails{Payroll.validatePeriod("2026-11-20","2026-11-16","2026-11-20",listOf(hours("1")))}
    }
    @Test fun overlappingClockShiftsIncludingNextDayAreRejected() {
        fails{Payroll.validatePeriod("2026-11-16","2026-11-17","2026-11-20",listOf(PayrollEntry("2026-11-16","22:00","06:00"),PayrollEntry("2026-11-17","05:30","08:00")))}
        Payroll.validatePeriod("2026-11-16","2026-11-17","2026-11-20",listOf(PayrollEntry("2026-11-16","22:00","06:00"),PayrollEntry("2026-11-17","06:00","08:00")))
    }
    @Test fun emptyOrTooLongPeriodsCannotBeApproved() {
        fails{Payroll.validatePeriod("2026-11-16","2026-11-16","2026-11-20",emptyList())}
        fails{Payroll.validatePeriod("2026-01-01","2027-12-31","2027-12-31",listOf(PayrollEntry("2026-01-01",durationSeconds=3600)))}
    }
}
