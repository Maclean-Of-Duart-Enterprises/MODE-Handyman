package com.macleanofduartenterprises.modehandyman.data

import com.macleanofduartenterprises.modehandyman.core.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PayrollCodecTest {
    @Test fun employeeSettingsRoundTripWithoutLosingDisabledTaxBoxes() {
        val w=PayrollWorker(7,2,"Иван","Subcontractor","555-0100","ivan@example.test","Address",PayrollPay(4500,taxes=listOf(PayrollTax("Custom tax","Description","fixed","12.50",true,false))),"Biweekly","2026-11-16","Notes",true)
        assertEquals(w,PayrollCodec.worker(JSONObject(PayrollCodec.worker(w).toString())))
    }
    @Test fun calculationSnapshotPreservesIndividualEarningsAndDeductions() {
        val r=Payroll.calculate(PayrollPay(2500,taxes=listOf(PayrollTax("Tax",value="10"))),listOf(PayrollEntry("2026-11-16",durationSeconds=28800)))
        assertEquals(r,PayrollCodec.calculation(JSONObject(PayrollCodec.calculation(r).toString())))
    }
    @Test fun editedEntriesRoundTripSeparatelyFromOriginalCsv() {
        val e=listOf(PayrollEntry("2026-11-16","08:30","17:00",1200,multiplier="1.5",notes="Edited locally"))
        assertEquals(e,PayrollCodec.entries(PayrollCodec.entries(e)))
    }
}
