# MODE Handyman 2.1.22 - automatic customer follow-up texts

## Setup

Open Settings > Automatic customer follow-up texts in the active business profile.

- Choose invoice-paid, job-finished, or both triggers.
- Enter the Facebook page/follow link and Google Maps place/review link. Include either link or both.
- Customize and preview the message. Selected links are appended automatically.
- Optional placeholders: {customer}, {business}, {job}, {invoice}, {event}.
- Save and allow Android's SMS permission. A working SMS-capable SIM and default SMS SIM selection are required.
- Settings are independent for each business profile. The feature starts disabled.

## Trigger behavior

- A new transition from unpaid to paid queues the invoice's billing customer's message, falling back to the job customer if no billing override exists.
- An existing job changing from an unfinished status to Finished or Completed queues its customer's message. The job editor now includes Finished as a status.
- Installing, enabling, opening old paid invoices, re-saving an already finished job, and changing Completed to Finished do not create messages. Creating a historical job already marked complete does not send a message.
- SQLite triggers queue the event inside the original database transaction. A rolled-back payment/status change cannot send a message.
- Pending events are processed after the app refreshes/returns to the foreground. No server, messaging-service account, Internet API or default-SMS-app role is added.

## Duplicate protection and history

- One text per job/customer is the default, preventing invoice-paid and job-finished from texting the same person twice for one job. This can be disabled to permit one message for each trigger type.
- Reopening/re-finishing the same job or toggling payment status does not automatically repeat a message.
- A local submission ledger also protects against automatic repeats after restoring an earlier backup on the same device.
- Sent means Android confirmed all outgoing segments. It does not establish customer delivery or reading.
- Failures, missing permission/phone/SIM, and uncertain outcomes appear in Settings > View follow-up text history. Failed/uncertain messages never automatically retry.
- Retrying one message is explicit, with a duplicate warning. Open in messaging app is available when direct SMS is blocked; the normal messaging app's Send action remains manual.
- Customer edit forms have a Skip automatic follow-up texts checkbox, using the existing customer mailing-exclusion flag.
- Restoring a backup cancels restored pending/sending items so historical texts are not automatically replayed.

## Android and privacy

- SEND_SMS is optional and requested only through follow-up settings. The rest of the app works without it.
- Android/installers may restrict granting SMS permission. The app reports blocked sends and provides the manual messaging-app fallback.
- Messages use the phone's default SMS SIM. Carrier fees may apply; longer or non-English messages may use multiple SMS segments.
- The sent-status receiver is private, and callbacks are matched to message, segment and attempt token.
- No SMS reading, contact reading, phone-state reading, cloud SMS account, tracking SDK or new runtime library is required.

Version 2.1.22, code 44. Database schema 235. Privacy & about reads the installed package version. Discounts, PDF/JPG sharing, branding and coupon rendering are retained.
