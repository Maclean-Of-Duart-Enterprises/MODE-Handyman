# MODE Handyman 2.1.20

## Invoice and quote layouts

In Settings > Business setup > Document branding, choose White background, Full background or Header only.

- White background: a solid white page with existing brand colors and logo.
- Full background: the existing faint pattern across an explicitly white page.
- Header only: a pattern strip, logo panel and business details above a white document body. Continuation pages repeat the strip and document identification.
- Every page receives a solid white base, including continuation pages.
- Created date and page number no longer share the same footer position.
- Existing profiles keep Full background until changed. Uploading a new pattern preserves the selected layout.

## Branding throughout the app

- The active business profile's logo, business name, primary color, accent and pattern are used in the app, including the dashboard, app bar, page backgrounds, cards, buttons, fields, Smart Tools and calculator.
- A dark interface palette is derived from the primary color. Button and highlight foreground colors are selected for readable contrast.
- Branding refreshes after saving or switching business profiles. The last active identity is remembered for the opening screen.
- Saving a layout without changing the color controls preserves the exact stored colors.

## Coupons and version

- Coupon rendering and layout are unchanged. The invoice/quote layout choice does not affect coupon PDF/JPG exports or optional customer attachments.
- Version 2.1.20, code 42. Privacy & about continues to read the installed package version.

Build using JDK 17, Android SDK Platform 36 and Gradle 8.13. Supply signing material through MODE_KEYSTORE, MODE_KEY_ALIAS, MODE_STORE_PASSWORD and MODE_KEY_PASSWORD. Private keys and credentials are not included.
