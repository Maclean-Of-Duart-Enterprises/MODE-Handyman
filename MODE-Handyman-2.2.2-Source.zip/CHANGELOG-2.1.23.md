# 2.1.23 — saved follow-up messages

- Paid-invoice and Finished/Completed job transitions create local follow-up drafts using the configured message and Facebook/Google Maps links. Existing per-business settings, customer exclusion, and duplicate protection remain in effect.
- Home now includes Follow-up messages with a ready count. Select a saved message, edit text/phone/email, save, and choose Messaging / SMS, Email, Google Voice, Other available apps, or Copy message. Customer phone/email are optional; snapshots are retained with the message.
- Sending is completed by the user in the chosen app. Google Voice uses standard text sharing when supported; otherwise Copy & open explicitly copies the message and opens Voice for manual recipient selection, paste and Send. No Google account integration or private API.
- Sharing is recorded as opened, never confirmed sent. Cancelling a chooser retains the draft. Mark as sent is an explicit user confirmation; Keep as draft and Dismiss retain history.
- Removed direct SMS sending, its callback receiver, telephony feature and SEND_SMS permission. Existing uncertain SMS attempts remain labelled uncertain. Previous sent records remain sent; blocked/failed records become reviewable drafts. Turning draft creation off keeps saved messages. Backups retain the message queue.
- Schema 236 migration preserves business data and message contents. APK version name 2.1.23 / code 45; Privacy & about reads the installed version.
- Coupons, branding, discounts, PDF/JPG exports and other business workflows are unchanged.

## Use

1. Settings > Customer follow-up messages: configure links/template and enable draft creation for the desired events.
2. Mark an invoice paid or an existing job Finished / Completed.
3. Home > Follow-up messages: select the draft, review it and choose the sending app. Check recipient and sending account, then press Send in that app.

Available apps and their handling of prefilled recipients/text vary by device. Other apps may require you to choose the customer. Google Voice fallback does not prefill a recipient or send anything. Live third-party sharing requires phone testing.
