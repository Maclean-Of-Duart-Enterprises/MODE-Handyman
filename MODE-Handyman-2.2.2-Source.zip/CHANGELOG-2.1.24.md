# MODE Handyman 2.1.24

- Tap the top-right Home button to open the dashboard as before.
- Touch and hold that button on any page with the shared header to open Business profiles. Select another business to switch to its dashboard.
- Releasing after a long press keeps the profile list open. Repeated holds on the profile list do not add duplicate pages. Back returns to the previous page if no profile was changed.
- Added an accessibility description and tooltip explaining the shortcut.
- Version name/code: 2.1.24 / 46. Privacy & about reads the installed version.

Existing profile selection and data isolation behavior are unchanged. No database migration or additional permissions are needed.
