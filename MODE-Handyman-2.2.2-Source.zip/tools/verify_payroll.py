#!/usr/bin/env python3
"""Validate the shipped payroll migration and SQLite constraints on a real DB."""
import datetime
import json
import pathlib
import re
import shutil
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets'


def main():
    with tempfile.TemporaryDirectory() as directory:
        target = pathlib.Path(directory) / 'handyman.db'
        shutil.copy2(ASSETS / 'handyman-template.db', target)
        db = sqlite3.connect(target)
        stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
        for profile in (1, 2):
            db.execute('INSERT INTO business_profile(id,display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date) VALUES(?,?,?,?,?,?,?,?)',
                       (profile, f'Business {profile}', '{}', '{}', '{}', profile == 1, stamp, stamp))
        db.commit()
        for version in range(228, 237):
            db.executescript((ASSETS / f'v{version}.sql').read_text())
        before = {name: db.execute('SELECT COUNT(*) FROM "' + name + '"').fetchone()[0]
                  for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        db.executescript((ASSETS / 'v237.sql').read_text())
        db.execute('PRAGMA user_version=237')
        source = (ROOT / 'app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/PayrollStore.kt').read_text()
        trigger = re.search(r'IMMUTABLE_TRIGGER = """(.*?)"""', source, re.S).group(1)
        db.execute(trigger)
        db.execute(trigger)  # Initialization must remain idempotent.
        for name, count in before.items():
            assert db.execute('SELECT COUNT(*) FROM "' + name + '"').fetchone()[0] == count
        db.commit()
        db.execute('PRAGMA foreign_keys=ON')

        def insert(table, **values):
            columns = ','.join(values)
            return db.execute(f'INSERT INTO {table}({columns}) VALUES({",".join("?" for _ in values)})', tuple(values.values())).lastrowid

        def blocked(action):
            try:
                action()
            except sqlite3.IntegrityError:
                return
            raise AssertionError('Expected SQLite constraint rejection')

        pay = json.dumps(dict(rate_cents=2500, basis='time', increment_minutes=60, increment_label='hour', taxes=[]))
        worker_ids = []
        for profile in (1, 2):
            worker_ids.append(insert('mode_payroll_worker', profile_id=profile, name=f'Worker {profile}', kind='Employee', pay_json=pay,
                                     cadence='Weekly', anchor_date='2026-11-16', created_at=stamp, updated_at=stamp))
        worker = worker_ids[0]
        card_data = dict(profile_id=1, worker_id=worker, period_start='2026-11-16', period_end='2026-11-22', pay_date='2026-11-27', cadence='Weekly',
                         entries_json='[]', pay_json=pay, created_at=stamp, updated_at=stamp)
        blocked(lambda: insert('mode_payroll_timecard', **dict(card_data, profile_id=2)))
        card = insert('mode_payroll_timecard', **card_data)
        snapshot = json.dumps(dict(worker_name='Worker 1', gross=20000, net=18000))
        stub_data = dict(profile_id=1, worker_id=worker, card_id=card, revision=1, number='PS-1-1-R1', pay_date='2026-11-27',
                         period_start='2026-11-16', period_end='2026-11-22', cadence='Weekly', gross_cents=20000, deduction_cents=2000,
                         net_cents=18000, employer_cents=500, worked_seconds=28800, snapshot_json=snapshot, approved_at=stamp)
        blocked(lambda: insert('mode_payroll_stub', **dict(stub_data, net_cents=20000)))
        blocked(lambda: insert('mode_payroll_stub', **dict(stub_data, profile_id=2)))
        db.commit()
        # Approval insert and state update must roll back as a unit on failure.
        db.execute('BEGIN')
        insert('mode_payroll_stub', **stub_data)
        db.execute("UPDATE mode_payroll_timecard SET status='approved',revision=1 WHERE id=?", (card,))
        db.rollback()
        assert db.execute('SELECT COUNT(*) FROM mode_payroll_stub').fetchone()[0] == 0
        assert db.execute('SELECT status FROM mode_payroll_timecard WHERE id=?', (card,)).fetchone()[0] == 'draft'
        stub = insert('mode_payroll_stub', **stub_data)
        db.execute("UPDATE mode_payroll_timecard SET status='approved',revision=1 WHERE id=?", (card,))
        blocked(lambda: insert('mode_payroll_stub', **dict(stub_data, revision=2, number='PS-1-1-R2')))
        blocked(lambda: db.execute('UPDATE mode_payroll_stub SET net_cents=1 WHERE id=?', (stub,)))
        blocked(lambda: db.execute("UPDATE mode_payroll_stub SET snapshot_json='{}' WHERE id=?", (stub,)))
        db.execute("UPDATE mode_payroll_worker SET pay_json='{}',name='Changed later' WHERE id=?", (worker,))
        assert db.execute('SELECT snapshot_json FROM mode_payroll_stub WHERE id=?', (stub,)).fetchone()[0] == snapshot
        db.execute('UPDATE mode_payroll_stub SET voided_at=? WHERE id=?', (stamp, stub))
        db.execute("UPDATE mode_payroll_timecard SET status='draft' WHERE id=?", (card,))
        insert('mode_payroll_stub', **dict(stub_data, revision=2, number='PS-1-1-R2', gross_cents=25000, deduction_cents=2500, net_cents=22500))
        db.execute("UPDATE mode_payroll_timecard SET status='approved',revision=2 WHERE id=?", (card,))
        current = db.execute("SELECT SUM(gross_cents),SUM(net_cents),COUNT(*) FROM mode_payroll_stub WHERE profile_id=1 AND worker_id=? AND voided_at=''", (worker,)).fetchone()
        assert current == (25000, 22500, 1)
        assert db.execute('SELECT COUNT(*) FROM mode_payroll_stub WHERE profile_id=2').fetchone()[0] == 0
        blocked(lambda: db.execute('DELETE FROM mode_payroll_worker WHERE id=?', (worker,)))
        blocked(lambda: db.execute('DELETE FROM mode_payroll_timecard WHERE id=?', (card,)))
        db.commit()
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        # Upgrade a populated 2.2.0 payroll database. Existing cards and issued stubs stay visible.
        db.executescript((ASSETS / 'v238.sql').read_text())
        db.execute('PRAGMA user_version=238')
        assert db.execute('SELECT id FROM mode_payroll_timecard WHERE deleted=0').fetchall() == [(card,)]
        assert db.execute('SELECT time_setup_json FROM mode_payroll_worker WHERE id=?', (worker,)).fetchone()[0] == '{}'
        db.execute("UPDATE mode_payroll_timecard SET deleted=1,entries_json='[]',notes='' WHERE id=?", (card,))
        assert db.execute('SELECT id FROM mode_payroll_timecard WHERE deleted=0').fetchall() == []
        assert db.execute("SELECT COUNT(*) FROM mode_payroll_stub WHERE voided_at=''").fetchone()[0] == 1
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        db.commit()
        backup = pathlib.Path(directory) / 'backup.db' 
        with sqlite3.connect(backup) as saved:
            db.backup(saved)
            assert saved.execute('SELECT COUNT(*) FROM mode_payroll_stub').fetchone()[0] == 2
            assert saved.execute('PRAGMA user_version').fetchone()[0] == 238
            assert saved.execute('SELECT snapshot_json FROM mode_payroll_stub WHERE id=?', (stub,)).fetchone()[0] == snapshot
        print('PASS: migration preserves existing tables; profile isolation; money constraints; approval rollback; immutable snapshots; revision history; active-report totals; deletion protection; backup retention; integrity checks')


if __name__ == '__main__':
    main()
