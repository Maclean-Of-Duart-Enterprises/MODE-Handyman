#!/usr/bin/env python3
"""Exercise actual migration and SQLite triggers; validates local drafts and migration without sending anything."""
import pathlib,re,sqlite3,tempfile,shutil,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
ASSETS=ROOT/"app/src/main/assets"

def main():
    with tempfile.TemporaryDirectory() as directory:
        target=pathlib.Path(directory)/"test.db";shutil.copy2(ASSETS/"handyman-template.db",target)
        db=sqlite3.connect(target)
        now=datetime.datetime.now(datetime.timezone.utc).isoformat()
        def insert(table,values):
            columns={r[1]:r for r in db.execute("PRAGMA table_info("+table+")")}
            data=dict(values)
            for name,(_,_,kind,required,default,primary) in columns.items():
                if name not in data and required and default is None and not primary:data[name]=0 if "INT" in kind.upper() else ""
            keys=list(data)
            return db.execute("INSERT INTO "+table+"("+",".join('"'+k+'"' for k in keys)+") VALUES("+",".join("?" for _ in keys)+")",tuple(data[k] for k in keys)).lastrowid
        profile=insert("business_profile",dict(display_name="One",configuration_json="{}",preferences_json="{}",trip_settings_json="{}",active=1,created_date=now,modified_date=now))
        for version in range(228,236):db.executescript((ASSETS/f"v{version}.sql").read_text())
        customer=insert("customer",dict(name="Test Customer",profile_id=profile))
        job=insert("job",dict(customer_id=customer,profile_id=profile,summary="Test job",status_id="Completed",created_date=now))
        invoice=insert("invoice",dict(job_id=job,profile_id=profile,invoice_num="I-1",paid=1,created_date=now))
        source=(ROOT/"app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/FollowupTriggers.kt").read_text()
        triggers=re.findall(r'"""(CREATE TRIGGER.*?)"""',source,re.S)
        assert len(triggers)==2
        for trigger in triggers:db.executescript(trigger)
        count=lambda:db.execute("SELECT COUNT(*) FROM mode_followup_outbox").fetchone()[0]
        assert count()==0 # Installing the feature never backfills old work.
        db.execute("UPDATE invoice SET paid=0 WHERE id=?",(invoice,));db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,))
        assert count()==0 # Not configured means no queue entry.
        insert("mode_followup_settings",dict(profile_id=profile,enabled=0))
        db.execute("UPDATE job SET status_id='In Progress' WHERE id=?",(job,));db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(job,))
        assert count()==0
        db.execute("UPDATE mode_followup_settings SET enabled=1 WHERE profile_id=?",(profile,))
        assert count()==0 # Enabling does not retroactively send.
        db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));db.execute("UPDATE job SET status_id='Completed' WHERE id=?",(job,))
        assert count()==0 # Re-saving an already paid/finished record is not a transition.
        db.execute("UPDATE invoice SET paid=0 WHERE id=?",(invoice,));db.commit()
        db.execute("BEGIN");db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));assert count()==1
        db.rollback();assert count()==0 # A rolled back payment cannot send a message.
        db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));assert count()==1
        row=db.execute("SELECT customer_id,job_created,invoice_number FROM mode_followup_outbox").fetchone()
        assert row==(customer,now,"I-1")
        db.execute("UPDATE job SET status_id='In Progress' WHERE id=?",(job,));db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(job,));assert count()==1
        db.execute("UPDATE invoice SET paid=0 WHERE id=?",(invoice,));db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));assert count()==1
        db.execute("UPDATE mode_followup_settings SET once_per_job=0 WHERE profile_id=?",(profile,))
        db.execute("UPDATE invoice SET paid=0 WHERE id=?",(invoice,));db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));assert count()==2
        db.execute("UPDATE job SET status_id='In Progress' WHERE id=?",(job,));db.execute("UPDATE job SET status_id='Completed' WHERE id=?",(job,));assert count()==3
        db.execute("UPDATE job SET status_id='In Progress' WHERE id=?",(job,));db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(job,));assert count()==3
        db.execute("UPDATE mode_followup_settings SET invoice_paid=0 WHERE profile_id=?",(profile,))
        db.execute("UPDATE invoice SET paid=0 WHERE id=?",(invoice,));db.execute("UPDATE invoice SET paid=1 WHERE id=?",(invoice,));assert count()==3
        second=insert("business_profile",dict(display_name="Two",configuration_json="{}",preferences_json="{}",trip_settings_json="{}",active=0,created_date=now,modified_date=now))
        customer2=insert("customer",dict(name="Second customer",profile_id=second))
        job2=insert("job",dict(customer_id=customer2,profile_id=second,summary="Second job",job_number="SECOND",status_id="In Progress",created_date=now))
        insert("mode_followup_settings",dict(profile_id=second,enabled=1))
        db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(job2,));assert count()==4
        assert db.execute("SELECT COUNT(*) FROM mode_followup_outbox WHERE profile_id=?",(second,)).fetchone()[0]==1
        # Upgrade real schema-235 events from every legacy send state.
        states=['pending','blocked','failed','sending','sent','manual','uncertain','cancelled']
        ids=[]
        for state in states:
            ids.append(insert("mode_followup_outbox",dict(profile_id=profile,job_id=job,customer_id=customer,trigger_kind="job_finished",event_key="migration:"+state,status=state,body="Saved text "+state,recipient="7175551234")))
        db.executescript((ASSETS/"v236.sql").read_text())
        expected=['pending','pending','pending','uncertain','sent','shared','uncertain','cancelled']
        for mid,state,status in zip(ids,states,expected):
            row=db.execute("SELECT status,body,recipient,email,customer_name,last_shared_at FROM mode_followup_outbox WHERE id=?",(mid,)).fetchone()
            assert row==(status,"Saved text "+state,"7175551234","","","")
            if state=="failed":assert "some segments may have been sent" in db.execute("SELECT error FROM mode_followup_outbox WHERE id=?",(mid,)).fetchone()[0]
        # New events still queue once, but only for local preparation; no sender exists.
        thirdjob=insert("job",dict(customer_id=customer,profile_id=profile,summary="Email only",job_number="THIRD",status_id="In Progress",created_date=now))
        db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(thirdjob,))
        row=db.execute("SELECT status,body FROM mode_followup_outbox WHERE job_id=?",(thirdjob,)).fetchone()
        assert row==('pending','')
        # Disabled creation retains existing drafts and blocks new events.
        db.execute("UPDATE mode_followup_settings SET enabled=0 WHERE profile_id=?",(profile,))
        assert db.execute("SELECT body FROM mode_followup_outbox WHERE id=?",(ids[0],)).fetchone()[0]=='Saved text pending'
        fourthjob=insert("job",dict(customer_id=customer,profile_id=profile,summary="Disabled",job_number="FOURTH",status_id="In Progress",created_date=now))
        db.execute("UPDATE job SET status_id='Finished' WHERE id=?",(fourthjob,))
        assert db.execute("SELECT COUNT(*) FROM mode_followup_outbox WHERE job_id=?",(fourthjob,)).fetchone()[0]==0
        manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
        assert 'android.permission.SEND_SMS' not in manifest and 'FollowupSentReceiver' not in manifest
        kotlin=ROOT/'app/src/main/kotlin'
        assert not any('SmsManager' in path.read_text() or 'sendMultipartTextMessage' in path.read_text() for path in kotlin.rglob('*.kt'))
        assert db.execute("PRAGMA integrity_check").fetchone()[0]=="ok"
        assert db.execute("PRAGMA foreign_key_check").fetchall()==[]
        print("PASS: actual schema-235/236 migration and paid/finished triggers; disabled/old events ignored; rollback; duplicate protection; profile isolation; all legacy message states and contents preserved; no direct SMS permission or sender")
if __name__=="__main__":main()
