# Release verification - MODE Handyman 2.1.19

- Application ID: com.macleanofduartenterprises.modehandyman
- Version name: 2.1.19
- Version code: 41 (previous release: 40)
- Privacy & about uses the installed package version.
- assembleRelease, testReleaseUnitTest and lintRelease: passed.
- Unit tests: 27 passed, 0 failed, 0 skipped, including coupon persistence, optional removal, used status and business-profile isolation.
- Android lint: 0 errors, 20 warnings; full report retained in the local build output.
- APK signature verified with apksigner and matched the supplied release key / attached 2.1.18 APK.
- ZIP alignment verified.
- Signing certificate SHA-256: 62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136
- APK SHA-256: 93d796e267ddb0a3c83f9c3d092fc1dd2eea303035f8f58affa4c6fe60073992

Device UI and Android PDF/JPG rendering were not exercised on a phone or emulator. Customer text uses Android StaticLayout wrapping and increases coupon height, retaining space for terms, used status and issue date. Existing coupons remain readable without a migration.

The source archive excludes private keys, signing passwords, local SDK paths and generated build/cache files.
