# MODE Handyman 2.2.0

- Added **Employee and Subcontractor** under People and materials.
- Added profile-scoped contact management, configurable pay increments, fixed-period pay, tax/deduction boxes and separate employer contributions.
- Added manual timecards and UTF-8 CSV imports, clock and hours-only entries, unpaid breaks, premium multipliers and in-app entry editing.
- Added separate calculated paystub previews, approval/rejection, immutable approved snapshots and superseded revision history.
- Added branded PDF/JPG paystubs, timecards and filtered reports; PDF viewing and saving; approved timecard CSV export/share/save.
- Added weekly/biweekly/date-range/full-year filters, schedule/status filters, newest/oldest sorting and paystub year-to-date totals.
- Added a documented CSV interface and template for an external time management app.
- Added schema 237 migration and regression checks; payroll records use existing backup/restore.
- Preserved the Home-button business chooser shortcut and previous app features.
- Version name/code: **2.2.0 / 47**. Privacy & about reads the installed package version.

See `PAYROLL-GUIDE-2.2.0.md` for the workflow, CSV contract, calculation rules and record-history behavior.
