# MODE Handyman 2.1.17

- Fix Customers & Contacts list scrolling: the full search/actions/customer list is now inside a vertical ScrollView, allowing access to all records.
- Apply the same list scrolling correction to Jobs.
- Respect Android system bar and display-cutout insets at the activity root, preventing the toolbar from overlapping the status bar and the content from extending beneath the bottom navigation area.
- Update versionName to 2.1.17, versionCode to 39, Privacy & About version label, and routing User-Agent version.

Build: `./gradlew assembleRelease` (signing environment required for signed release), or `./gradlew assembleDebug` for development testing.
