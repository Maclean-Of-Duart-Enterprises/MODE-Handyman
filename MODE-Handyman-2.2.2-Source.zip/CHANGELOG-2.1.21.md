# MODE Handyman 2.1.21

## Discounts and invoice conversion

- Quote adjustments support a dollar amount or a percentage, an editable discount label, and a separate unrestricted description.
- Percentage input supports two decimal places and is applied to the subtotal before tax. It recalculates when line items change. Dollar discounts remain fixed; the applied discount is capped at the subtotal.
- Discount labels, percentages, descriptions and amounts appear on the quote/invoice screens and in PDF/JPG exports. Long labels and descriptions wrap rather than being truncated.
- Create invoice from quote copies the saved quoted items, discount type/value/label/description, tax rate and terms in one transaction. The result is checked against the quote total.
- Job > Create invoice offers the saved quotes when present. Selecting a quote includes its discount/tax. Creating from the current job items without quote adjustments is a separate explicit choice.
- Existing invoices have an Edit discount and tax action. Prior invoices are not silently changed; use this action to correct an invoice created before the fix.
- Legacy combined quote-adjustment lines on old invoices remain intact, preventing an additional discount from being applied during migration.

## Typing and export

- Explicit visible 2dp insertion cursor and selection highlighting for text fields, with theme fallbacks for main screens and dialogs.
- Quotes and invoices offer both Export/share PDF and Export/share JPG.
- JPG export renders the actual generated PDF at twice page resolution. Each page is shared as a separate JPG for multi-page documents. Image rendering runs off the main thread.
- The export provider supplies image/jpeg and grants access to every shared page.

## Compatibility

- Version name 2.1.21; version code 43. Privacy & about continues to display the installed package version.
- Database schema 234 adds discount metadata. Existing quote amount discounts, invoice totals, items and payment allocations are preserved. A new pre-upgrade recovery-copy location is used.
- Existing document branding and coupon rendering are retained.

Build with JDK 17, Android SDK Platform 36, Build Tools 35.0.0 and Gradle 8.13. Provide the existing release key through MODE_KEYSTORE, MODE_KEY_ALIAS, MODE_STORE_PASSWORD and MODE_KEY_PASSWORD; private signing material is excluded from the source archive.
