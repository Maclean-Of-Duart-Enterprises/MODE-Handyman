# MODE Handyman 2.2.2 verification

Release version code 49. The APK passed Android signature verification and alignment checks. Its signing certificate matches MODE Handyman 2.2.1.

All 93 release unit tests passed. Android lint reported 33 warnings and zero errors.

Time 1.0.4's setup parser read JSON produced by the MODE exporter. Checks covered the visible pay rate, exact rate in cents, a custom time increment, pay per period, the embedded admin PIN with leading zeroes, and leaving the PIN blank. The import screen in Time 1.0.4 retains its Apply confirmation. Phone installation and interactive device testing were not performed.
