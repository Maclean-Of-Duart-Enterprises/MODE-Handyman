# Release verification - MODE Handyman 2.1.20

- Application ID: com.macleanofduartenterprises.modehandyman
- Version: 2.1.20, code 42. Privacy & about uses the installed package version.
- assembleRelease, testReleaseUnitTest, lintRelease: passed.
- Unit tests: 34 passed, 0 failed, 0 skipped.
- Lint: 0 errors, 25 warnings.
- New tests cover document-layout preference compatibility, independent business profiles, preserving layout on pattern upload, preserving the coupon/app pattern with white document mode, and control text contrast across dark, bright and saturated palettes.
- CouponManager.kt and BrandingStore.drawPattern are unchanged from the attached 2.1.19 source. Coupon PDF/JPG rendering does not read the new document-layout setting.
- Resource XML parsed successfully.
- APK signature verified and certificate matched the attached 2.1.19 APK.
- ZIP alignment verified.
- Signing certificate SHA-256: 62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136
- APK SHA-256: b4986a2f73f340889942bfc45769c2ec72df8fb1e24e2e82133acd6dad0fb510

Visual rendering and interactive behavior have not been exercised on a phone or emulator. No device screenshot or actual Android PDF preview is claimed by these checks. Test the three document choices and profile switching on the device.

The source archive excludes private keys, signing credentials, SDK paths, Gradle caches and generated build files. Existing user data remains under the same application ID and no database migration was introduced.
