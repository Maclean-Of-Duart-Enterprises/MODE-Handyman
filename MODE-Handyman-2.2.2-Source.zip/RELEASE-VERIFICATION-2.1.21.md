# MODE Handyman 2.1.21 release verification

- Application ID: com.macleanofduartenterprises.modehandyman
- Version name: 2.1.21; version code: 43. Privacy & about uses the installed package version.
- assembleRelease, testReleaseUnitTest and lintRelease: passed.
- Unit tests: 43 passed, 0 failures/errors/skips. Includes amount/percentage discounts, exact cent rounding, subtotal changes, metadata preservation, input bounds, tax ordering and payment balance.
- Android lint: {'Warning': 25}. No errors or fatal findings.
- Host SQLite integration: PASS using the bundled database and migrations through schema 234. Existing amount discounts and paid invoices preserved, real production quote/invoice summary SELECTs executed with column-position and profile-isolation checks, foreign keys and integrity valid.
- Migration preserves existing invoices and their line adjustments. Old invoices with a missing discount can be corrected using Edit discount and tax; no existing issued invoice is automatically rewritten.
- New quote-to-invoice conversion copies structured discount and tax metadata and validates that the new total equals the saved quote total. Job invoice creation now offers saved quotes instead of silently using current job items.
- CouponManager.kt unchanged from the attached 2.1.20 source.
- APK signature verified; signing certificate matches the attached 2.1.20 APK. ZIP alignment verified.
- Certificate SHA-256: 62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136
- APK SHA-256: b6642f3f0c6253823d844335217a31c13f3ab3ea3a89b6dcf60a7e86f49ad7bb

Phone/emulator interaction, native cursor appearance, and actual PDF/JPG rendering were not exercised in this environment. JPG export uses Android PdfRenderer to render the same PDF pages at twice PDF point resolution, one JPG per page. Multi-page exports share all pages using ACTION_SEND_MULTIPLE with read grants and image/jpeg MIME types.

Private signing keys, signing passwords, SDK paths, caches and generated build outputs are excluded from the source archive.
