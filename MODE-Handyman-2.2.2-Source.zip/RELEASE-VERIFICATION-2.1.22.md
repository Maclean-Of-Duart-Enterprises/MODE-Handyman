# MODE Handyman 2.1.22 verification

- Application ID: com.macleanofduartenterprises.modehandyman
- Version: 2.1.22, code 44. Privacy & about reads the installed package version.
- assembleRelease, testReleaseUnitTest and lintRelease: passed.
- Unit tests: 53 passed, no failures/errors/skips. New coverage includes message placeholders, Unicode, link selection/deduplication, URL validation, trigger selection, disabled defaults and phone normalization/rejection.
- Android lint: {'Warning': 26}. No errors or fatal findings.
- verify_followup.py: PASS using the real schema migration and production SQL trigger definitions. Verifies unpaid-to-paid and unfinished-to-finished transitions, disabled/unconfigured profiles, no retroactive messages, transaction rollback, duplicate protection between both triggers, independent per-trigger mode, business-profile isolation, atomic message claims and duplicate part callbacks.
- verify_database.py: PASS for the prior financial schema/discounts/paid invoices, production query positions, profile isolation, integrity and foreign keys.
- CouponManager, PdfGenerator, DocumentImages and DocumentDiscount are unchanged from the last delivered 2.1.21 source.
- SEND_SMS declared; no READ_SMS or READ_PHONE_STATE permission added. The sent-status receiver is private.
- APK signature verified and certificate matches the previous 2.1.21 APK. ZIP alignment verified.
- Certificate SHA-256: 62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136
- APK SHA-256: fa01b1a58fa16f05bcd592fa64a2659709a8d64668ca91783c962c00ec4d4fb8

No live SMS messages were sent during testing. Native Android permission prompts, carrier transport, default SIM selection, multipart sent-status callbacks and device UI need a phone test. Android or the installer can restrict SMS permission; blocked sends are recorded and the manual messaging-app fallback is available.

Automatic texting defaults off, requires explicit per-profile configuration and only reacts to new transitions. No older completed jobs/paid invoices are backfilled. Retrying uncertain sends is an explicit user action because SMS transmission cannot be guaranteed exactly once after process/transport failures.

Reference APIs checked against official Android documentation:
- https://developer.android.com/reference/android/telephony/SmsManager
- https://developer.android.com/reference/android/Manifest.permission#SEND_SMS

The source archive excludes private keys, credentials, SDK paths, caches and generated build files.
