# MODE Handyman 2.2.0 — employees, subcontractors and payroll

## Start

1. Open **People and materials → Employee and Subcontractor**.
2. Add a person. Enter their name, type, phone, email and physical address. Choose **Set pay rate and tax boxes**, their default pay schedule and biweekly anchor date.
3. Open that person's profile and choose **Import timecard CSV** or **Create timecard manually**.
4. Check the pay period, pay date and schedule. Add, edit or delete time entries in the displayed timecard form. Save the draft.
5. Open **View calculated paystub preview**, then choose **Approve**, **Reject** or **Edit**. Approval creates a separate saved paystub.
6. Use **Export / share paystub** for PDF viewing, PDF sharing, PDF saving or JPG page sharing. Approved timecards also offer **Export approved timecard CSV**, with Share and Save choices.

## Contact, pay and tax settings

Each business profile keeps its own employees, subcontractors, timecards and paystubs. Profiles can be edited and archived. A person without timecard history can be deleted; archive a person to retain their history.

Time-based pay uses the dollar rate divided by the configured number of working minutes. For example, a rate of $25 per 60 working minutes gives $200 for eight worked hours. Other increment lengths and labels are supported. Time is not rounded up to an entire pay increment. Earnings are rounded half up to cents for each entry and then added.

Fixed-period pay pays the entered amount once for the entire timecard. It is not prorated by hours or multiplied by premium-time factors. Use one timecard per intended paid period.

Each tax/deduction box has a name, description, percentage or fixed-dollar value, enabled switch and treatment: employee deduction or employer contribution. Percentages apply independently to gross pay; fixed amounts apply once per paystub. Employer contributions do not reduce net pay. Deductions greater than gross pay must be corrected before approval. All money is USD, consistent with the app's existing documents.

These are configurable calculations using your entered values. Set the applicable tax/deduction values yourself. Premium hours are identified manually with a multiplier, such as 1.5. The weekly and biweekly schedules organize pay periods and reports.

Timecards copy the person's pay settings when created. Later profile edits do not silently change existing cards. **Edit this timecard's pay / taxes** allows a card-specific change; **Use current person pay / tax settings** explicitly refreshes its settings.

## Time entries

An entry has a work date, clock-in and clock-out or an hours-only duration, unpaid break, pay multiplier and notes. Clock-out earlier than clock-in means the next day. Work dates identify the day a shift starts. Clock entries that overlap, including across midnight, are rejected on save/approval. Split shifts longer than 24 hours into separate entries.

The hours-only editor displays hours **before** the unpaid break. The imported/exported CSV `hours` and `worked_seconds` columns are **net worked time**, after breaks. The importer adds breaks back to reconstruct editable gross duration for hours-only entries. Clock values describe local wall-clock times; use hours-only entries for actual elapsed durations across daylight-saving transitions.

For longer timecards, the editor shows 30 entries per page with Previous / Next controls. All entries remain editable in the app. Saving never changes the original CSV file.

## Approval and revision history

Draft and rejected timecards can be edited. Rejection stores a reason. Approval stores worker contact details, business identity, entries, rates, taxes, itemized calculations and approval time in a separate paystub snapshot.

To correct an approved timecard, choose **Reopen timecard for editing**. Its existing paystub becomes superseded and is removed from current pay totals. The older revision remains viewable under **Earlier paystub revisions**. Edit and approve again to create a new numbered revision. Only current approved paystubs and approved timecard CSVs can be exported. Draft/rejected timecards can be exported as clearly labeled timecard PDFs/JPGs.

The approval prompt identifies another approved paystub with an overlapping period so you can check whether hours have already been included elsewhere.

## Sorting and reports

Each person has separate **Timecards / time reports** and **Paystubs / pay reports** screens. Filters include all dates, this/previous week, this/previous biweekly period, a custom date range and a full calendar year. You can also filter by weekly, biweekly, monthly or custom schedule and sort oldest/newest first. Timecard lists also filter by draft, rejected or approved status.

Weeks run Monday–Sunday. Biweekly ranges use the person's saved anchor date. Timecard reports filter individual work dates and total only matching entries. Opening a listed timecard still shows its complete pay period. Choose Approved status for approved work totals. Paystub reports filter **pay dates**, include current approved revisions, and total gross pay, deductions, net pay and employer contributions.

Both report types export as branded PDF or JPG, using the business profile's logo, colors and selected document background. Paystubs include year-to-date totals for current approved stubs in the same calendar year through that pay date, recorded at approval. Business identity and pay calculations come from the approval snapshot; visual branding uses the profile's current branding.

## CSV interface for the future time management app

Encoding: UTF-8, optional BOM. Delimiter: comma, semicolon or tab, with one header row. Quoted fields support commas, quotes and line breaks. Imports accept up to 5,000 rows and 2,000,000 text characters. Import one person and one pay period at a time. Exceptionally large records with long notes or tax descriptions must be shortened or split to fit the Android database.

| Column | Meaning |
| --- | --- |
| `date` | Required work date: `YYYY-MM-DD` or US `M/D/YYYY` |
| `start`, `end` | Clock values `H:MM[:SS]` or `h:mm AM/PM`; both or neither |
| `break_minutes` | Unpaid break minutes; default zero |
| `hours` | Net worked hours as decimal or `H:MM[:SS]`; used instead of clocks or to cross-check them |
| `worked_seconds` | Exact net worked seconds; exported for lossless time round-trips |
| `multiplier` | Manual pay multiplier; default `1` |
| `notes` | Job, task or entry notes |
| `employee_id`, `employee_name` | Optional person identifiers; IDs must match the selected person; name is checked if ID is absent |
| `business_profile_id` | Optional MODE business profile ID; must match the active profile |
| `period_start`, `period_end` | Optional pay-period dates, preserved on approved CSV export |
| `pay_date` | Optional payment date, preserved on export |
| `pay_schedule` | Optional `Weekly`, `Biweekly`, `Monthly` or `Custom` |

Supply `date` plus clocks, `hours` or `worked_seconds`. When multiple duration fields are supplied they must agree, allowing at most one second for decimal conversion. Missing identity columns let the selected profile/person supply the association. `work_date`, `clock_in`, `clock_out`, `start_time`, `end_time`, `total_hours` and several common aliases are accepted. Export always uses the canonical headings above.

Example:

```csv
date,start,end,break_minutes,hours,multiplier,notes
2026-11-16,08:00,16:30,30,,1,Example shift
2026-11-17,,,0,4.25,1,Hours-only entry
```

Imported CSVs always create drafts for review. An approved CSV export contains the edited time entries and pay-period metadata. Reimporting creates a new draft; it does not replace an earlier approved card. Pay rates and taxes are supplied by the employee settings in MODE, rather than trusted from CSV data.

## Backups and validation

Payroll records live in the main database and are included in the existing native backup/restore. Exports use the existing private export directory and explicit Android share/save actions. Version 2.2.0 migrates to schema 237 after preserving a recovery copy; existing business data and the Home-button shortcut are retained.

See `RELEASE-VERIFICATION.md` for the executed checks and device-testing boundary. Installation, touch interaction, document rendering and third-party share targets still need verification on the intended Android phone.
