# MODE Handyman 2.1.19

- Coupons can optionally be attached to an existing customer in the active business profile.
- Select, change or remove the customer while creating or editing a coupon. General coupons remain supported.
- Customer names appear in the coupon list, coupon details and exported PDF/JPG. Open the attached contact from coupon details.
- Current contact names are used when available. A saved name remains available if a contact is later removed.
- Customer names wrap in exported coupons; the document height grows to keep the terms, used notice and issue date separate.
- Existing coupons and used status are preserved, with no database migration.
- Release version: 2.1.19 (version code 41). Settings > Privacy & about reads the installed app version directly.

Build with JDK 17, Android SDK Platform 36 and Gradle 8.13 using the included wrapper. Supply the signing key and credentials through the MODE_KEYSTORE, MODE_KEY_ALIAS, MODE_STORE_PASSWORD and MODE_KEY_PASSWORD environment variables. Private signing material is not included.
