# MODE Handyman 2.2.1

## Timecard deletion

Under **People and materials → Employee and Subcontractor**, open a person, choose **Timecards / time reports**, and open a pay period. Use **Delete time entries** to select shifts, or **Delete entire pay-period timecard**. Review the dates and hours before confirming. Selecting every entry removes the card. The original imported CSV on the device stays intact.

Removing some entries from an approved card supersedes the old paystub and returns the remaining time to draft for review and approval. Deleting the entire timecard preserves any issued paystub as a separate document in Paystubs / pay reports. Superseded revisions remain available in paystub history.

## Send an employee or subcontractor setup to Time 1.0.4

1. Open the person's profile and select **Employee setup / export for Time**.
2. Select jobs. Each uses the saved site address. Under **Edit selected job settings**, you can supply a routing address or latitude and longitude, set the clock-in pay multiplier, and enter assigned hours for the job. A destination is needed for Time to offer navigation.
3. Optionally enter daily or weekly hour limits. Time 1.0.4 displays these limits as instructions. It does not stop the timer or automatically calculate overtime. Each employee's selections are saved independently when you export or tap **Save settings**.
4. Choose **Export employee setup JSON**, then save or share. In Time open **Settings → Import employee setup JSON**, review, and apply. If admin controls are on, authorize the unsigned import with the device's admin PIN, or sign the exported file in Time using an enrolled sender. The export contains no PIN, payroll rate, taxes, paystubs, or private notes.
5. Time adds or updates the selected jobs. Its clock-in picker also retains jobs already on that installation. Worker IDs and business IDs are preserved. A job's Time code combines its MODE business and job IDs so renaming a job leaves its identity intact. The original MODE job number travels with it.

## CSV

The employee setup creator can save or share the individual worker profile CSV and the selected jobs CSV. An individual job's screen also includes **Export job profile CSV for Time**. Use the corresponding worker or job CSV import in Time.

For worked hours, open an approved card and export the whole CSV or select one job. Under **Timecards / time reports**, filter work dates and use **Export approved hours CSV** for the selected employee across periods. Select all jobs, an individual job or unassigned entries. These reports include approved worked hours only. Time 1.0.4 includes its job caption in shift notes. MODE recognizes it on import and allows a job to be selected when entering time manually.
