# MODE Handyman — Native Kotlin 2.2.2

Current release: **2.2.2, version code 49**. Employee setup JSON now includes the pay rate and an optional receiving-device admin PIN. See [employee setup export](CHANGELOG-2.2.2.md). See [timecard deletion and exporting to Time](CHANGELOG-2.2.1.md). People and materials > Employee and Subcontractor adds contact/pay/tax management, editable CSV timecards, separate approved paystubs and filtered time/pay reports. Export branded PDF/JPG documents and approved timecard CSVs. Read `PAYROLL-GUIDE-2.2.0.md` and `CHANGELOG-2.2.0.md`. Existing features, including the Home-button business chooser shortcut, are retained. Privacy & about reads the installed package version.

MODE Handyman is an offline-first native Android business-management application for the MODE Handyman division of Maclean Of Duart Enterprises Corp. It uses Kotlin, Android Views/XML, native SQLite, `PdfDocument`, the Storage Access Framework, and Android share intents.

The shipped application has no Flutter engine, Dart runtime, Sentry, Firebase, analytics, advertisements, Google Play Services, SMTP sender, or remote synchronization. Its runtime dependency graph is limited to the Kotlin standard library and JetBrains annotations. Internet access is used for requested address geocoding and trip routing. Follow-up drafts stay local until the user chooses a sharing destination. The destination app manages the sending identity and transmission.

## Build

Requirements: JDK 17, Android SDK Platform 36, Android Build Tools 35.0.0, and Gradle 8.13.

```bash
export ANDROID_HOME=/path/to/android-sdk
export MODE_KEYSTORE=/absolute/path/to/release.keystore
export MODE_KEY_ALIAS=macleanphonerelease
export MODE_STORE_PASSWORD='set-outside-source'
export MODE_KEY_PASSWORD='set-outside-source'
./gradlew testReleaseUnitTest lintRelease assembleRelease
python3 tools/verify_database.py
python3 tools/verify_followup.py
python3 tools/verify_payroll.py
```

The signed APK is written to `app/build/outputs/apk/release/app-release.apk`. Signing secrets and the private key are not stored in this project.

## Architecture

- `DatabaseManager` opens the existing `handyman.db`, preserves a pre-migration recovery copy, applies migrations through schema 238 transactionally, and verifies integrity and foreign keys.
- `ModeRepository` owns profile-scoped business operations, idempotent estimate conversion, and permanent contract linkage.
- `BusinessProfiles` supports up to five isolated business profiles.
- `SmartToolsStore` keeps additive estimator, material, cost, attachment, signature, and approval records in `mode-smart-tools.db` schema 4.
- `SmartToolsLogic` supplies deterministic job reconciliation and exact estimate component calculations.
- `PdfGenerator` produces branded quotes, invoices, reports, and signed contracts locally, using the active business profile's optional logo.
- `FloatingCalculator` provides a compact in-app calculator with a movable launcher, persisted expression and position, and no system-overlay permission.
- `BackupManager` checkpoints and validates both databases, private documents, generated PDFs, and preferences, with pre-restore rollback recovery.
- `LocalCrashReporter` stores at most 20 redacted reports locally and has no upload endpoint.

## Upgrade identity

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version code: 47
- Version name: `2.2.0`
- Minimum Android API: 30
- Target Android API: 36

See `RELEASE-VERIFICATION.md` for executed checks and the exact limits of non-device verification.

## Customer contact transfer (source update)

Customers → Export all customers or Customer → Export this customer. Choose JSON or CSV and an Android document destination. Customers → Import customer contacts selects a JSON/CSV file, destination business profile and a duplicate policy (skip, update, separate). JSON includes customer notes, custom fields and associated contact names/phone/email; CSV stores the same fields in quoted columns. Neither format includes jobs, quotes, invoices or payments. See CHANGELOG.md for unsupported photo/address fields.

## Materials and suppliers

Smart Project Tools → Material price library and Suppliers manages catalog and vendor entries; product links can be opened externally. Job task item forms and quote/invoice line forms offer Select material from catalog. The selected catalog values are copied into editable fields and remain snapshots after saving.

### Contact extras and material references
Customer edit now includes separate business, billing address, and service address fields. Open a customer profile to choose a photo. Contact-only JSON transfers include an optional embedded photo; CSV transfers omit images. Newly created invoice lines selected from the material catalog retain a separate local material-reference snapshot; historic invoice prices remain unchanged.

Contacts have dedicated required mobile-phone, email-address, and customer-number fields. Jobs have a required editable alphanumeric job number, which is used as the prefix for new quote and invoice numbers. Quotes and invoices can be edited and deleted with their dependent records, their line items can be edited or deleted, and customer signatures can be drawn directly on either document and included in its PDF.


## Work notes
From Work > Notes, create and edit notes, link a customer, and insert or remove inline photographs. Images are stored locally and included in native backups.

## Receipts, directory links and trips
Supplier and manufacturer records support validated HTTP(S) website links and explicit browser opening. Receipts can be edited or deleted and can store profile-scoped local photographs. Trip entry and display follow the active profile's metric or US-customary setting while storing a single metre value internally.


## License and source code

MODE Handyman is licensed under the **GNU Affero General Public License v3.0** (`AGPL-3.0-only`). The full terms are at https://www.gnu.org/licenses/agpl-3.0.html. The project source and releases are available at https://github.com/Maclean-Of-Duart-Enterprises/MODE-Handyman/releases. Settings → Open-source license displays the license notice and links.
