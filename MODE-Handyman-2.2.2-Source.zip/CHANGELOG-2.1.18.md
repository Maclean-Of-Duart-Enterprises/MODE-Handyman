# MODE Handyman 2.1.18

- Corrected invoice and quote PDF footer to display only the active business name at left and PDF creation date at right.
- Added per-business-profile coupon creation, editing, code uniqueness, expiry, offer, terms, used/reactivated status, PDF and JPG exports via Android sharing.
- Added per-business-profile branding accent/text HSV hue and saturation controls, built-in patterns and uploaded pattern images.
- Applied document branding colors and patterns to quote and invoice PDFs and coupon exports; retained business logos.
- Updated versionName to 2.1.18, versionCode to 40, and Privacy & About version.
