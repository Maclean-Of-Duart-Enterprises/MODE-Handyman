# MODE Handyman 2.0.6 — release verification

Verification date: 2026-10-24

## Release update

Version 2.0.6 adds managed receipt photographs, receipt editing/deletion, tax-aware totals, profile-scoped supplier/manufacturer web links, non-destructive legacy URL migration, and trip entry/display in kilometres or miles. Trip distances continue to use metres as the single internal storage unit.

The final source centralizes platform-independent URL, receipt-total, and trip-conversion rules and includes focused regression tests. US-customary distance conversion now uses deterministic decimal rounding to the nearest metre rather than floating-point truncation.

## Executed without an emulator

| Check | Result |
|---|---|
| Clean Kotlin debug and release compilation | Passed with no compiler warnings |
| Debug JVM unit tests | Passed: 20 tests, 0 failures, 0 errors, 0 skipped |
| Release JVM unit tests | Passed: 20 tests, 0 failures, 0 errors, 0 skipped |
| Directory links | HTTP(S) validation, unsafe/missing-scheme rejection, and non-destructive legacy extraction passed |
| Trip units | Kilometre/mile input conversion, metre storage, display conversion, and negative-value rejection passed |
| Receipt calculations | Tax-inclusive, excluding-tax, and invalid-tax rules passed |
| 2.0.6 SQLite lifecycle | URL scoping, receipt photo storage, tax-aware edit, transactional deletion, trip storage, integrity and foreign keys passed |
| Main database migration | Passed: schema 227 → 228 → 229, integrity and foreign-key checks |
| Smart Tools migration | Passed: representative schema 3 → 4 with unresolved data preserved |
| Existing calculations and workflows | Invoice balances, estimate conversion, contract linkage, calculator, note markers, crash redaction and SQL splitting passed |
| Android lint release | Passed: 0 errors and 0 warnings |
| R8 shrinking/resource optimization | Passed |
| Signed universal release assembly | Passed |
| APK ZIP alignment | Passed |
| APK signature and signing identity | Passed |

## Release package identity

- Package: `com.macleanofduartenterprises.modehandyman`
- Application label: `MODE Handyman`
- Version: `2.0.6` (`versionCode 12`)
- Minimum Android API: 30
- Target Android API: 36
- APK size: 548,263 bytes
- APK SHA-256: `a1dd0437768284b32081f9b789e3f7978d4d844a7a8239d64a097329ae1b6a6c`
- APK Signature Scheme v2: verified
- Signers: 1
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`

## Static security and privacy checks

- The original package identifier and release certificate were preserved.
- The only requested permission is `POST_NOTIFICATIONS`; the manifest has no `INTERNET`, system-overlay, phone, SMS, contacts, broad storage, advertising ID, or location permission.
- Only the launcher activity is exported. The file provider, Smart Tools activity, and reminder receiver remain unexported.
- No Flutter, Dart, Sentry, Firebase, Crashlytics, analytics, Google Play Services, SMTP sender, SMS-template runtime, `libflutter.so`, or `libapp.so` artifact was found in the APK.
- The release runtime dependency graph contains only Kotlin standard library 2.1.20 and JetBrains annotations 13.0.
- The signing password and private key are excluded from the source archive.

## Verification boundary

No Android emulator was used, as requested, and no physical Android device was available. Installation as an update, migration using the production phone database, browser handoff, receipt photo selection/rendering/removal, touchscreen receipt editing, keyboard behavior, notifications, sharing, PDFs, and a live backup/restore round trip still require testing on the intended phone.

The supplied native base does not expose every historical Flutter-era screen described in `FEATURE-VERIFICATION.md`. Version 2.0.6 preserves and verifies the supplied native functionality but is not claimed to have physical-device or screen-for-screen parity testing.
