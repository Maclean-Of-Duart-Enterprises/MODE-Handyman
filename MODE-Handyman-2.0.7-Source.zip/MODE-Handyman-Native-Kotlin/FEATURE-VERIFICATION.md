# Feature verification

This inventory separates implemented source behavior from device-tested behavior. No emulator or physical Android device was used.

| Area | Native source status | Verification boundary |
|---|---|---|
| Customers and contacts | Profile-scoped search/create/edit/linking; email and phone optional | Compiled; device UI not executed |
| Jobs, tasks, materials, time | Core create/edit/list, billing, task items, timer start/stop data paths | Compiled and database chain tested; device timer flow not executed |
| Quotes | Lines, discount, tax, terms, states, PDF/share, all job billing types | Financial math/unit tests passed; device PDF appearance not executed |
| Smart estimates | Material/labor/markup component records and exact quote transfer | Unit and schema tests passed |
| Estimate conversion recovery | Main-database journal, uniqueness, retry repair | Database uniqueness test passed; process-kill recovery not device-tested |
| Contract approval | Explicit consent, handwritten signature, signed PDF, content SHA-256, permanent profile/customer/job/quote linkage | Compiled and linkage schema tested; touch/PDF/device workflow not executed |
| Job-ID reconciliation | Exact IDs and unique titles auto-link; ambiguous/missing records preserved for manual linking | Unit tests passed |
| Invoices and payments | Lines, unchanged invoice total, payment total, zero/full or remaining/partial balance, paid status, PDF/share | Invoice balance unit test and representative database chain passed |
| Schedule and reminders | Local appointments, todo dates, AlarmManager reminders | Compiled; actual notification delivery not executed |
| Business profiles | Up to five profiles; configuration/preferences and root data isolation | Compiled and schema verified |
| Business logos | Profile-specific logo import/remove and inclusion in quote, invoice, and report PDFs | Compiled and statically traced; document picker and rendered PDF appearance require device testing |
| Floating calculator | Compact in-app panel, movable launcher, persisted expression/position, disable setting, and Smart Tools access | Calculation engine unit tested; touch dragging and dialog dimensions require device testing |
| Work notes | Profile-scoped notes, optional customer linkage, local photographs inserted at the cursor and displayed inline while viewing and editing | Marker insertion/order/removal unit tested and compiled; photo picker, touch editing, and image rendering require device testing |
| Supplier/manufacturer links | Profile-scoped validated HTTP(S) URLs, non-destructive legacy URL migration, explicit browser opening | URL validation/extraction unit tested and compiled; installed browser handoff requires device testing |
| Receipts | Profile-scoped creation, editing, tax-aware totals, photographs, individual photo removal, and transactional receipt/photo deletion | Rule and representative SQLite lifecycle tests passed; Android photo picker and gallery require device testing |
| Measurements and trips | Per-profile metric setting, Smart Tools construction calculators, kilometre/mile input and display with metres retained internally | Metric/US conversion unit tested; whole-device presentation not executed |
| Backup/restore | Both DBs, documents, attachments, PDFs, preferences; staged validation and rollback | Compiled/static-reviewed; Android round-trip not executed |
| Crash diagnostics | Private, redacted, capped local reports; manual share/delete | Unit redaction test passed |
| Privacy | No INTERNET permission or runtime tracking SDK | Manifest and dependency scan passed |

## Historical parity boundary

The supplied native base still has narrower coverage than the former Flutter application in areas such as full accounting/credit workflows, advanced inventory quantities, mailings/labels, GPS trip capture, specialized plaster estimates, and some legacy administrative screens. Those preserved database tables are not deleted. Version 2.0.6 retains the requested job linking, conversion, signing, keyboard-handling source, database, business-logo reporting, corrected invoice balances, compact movable calculator, visual inline work notes, directory links, managed receipts, and corrected trip units without removing existing native features, but it does not create evidence of unimplemented historical screens or physical-device behavior.
