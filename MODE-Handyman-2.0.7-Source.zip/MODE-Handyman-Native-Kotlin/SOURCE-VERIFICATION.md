# Source verification

Source-only inspection performed. No Gradle, Android compiler, APK signing or emulator used.

Reviewed: contact import transaction boundaries; profile ownership filters; duplicate policies; CSV quote escaping; material selector; additive supplier schema migration (v5). Existing financial tables are not part of the contact transfer format.

Unverified: Kotlin compilation, device picker flows, existing database migration on physical devices, PDF formatting, regression testing. Known limitations are listed in CHANGELOG.md. This archive must not be treated as a verified release build.


## Additional source changes (2026-10-24)
- Added multi-selection of customers for contact-only export.
- CSV exports now use transfer_id to preserve distinct customers with identical names.
- The remaining requested photo, address and invoice-line reference integration has NOT been completed or tested.
- No Gradle build or Android runtime tests were executed.

### Latest source review (not compiled)
- Added additive local tables `mode_customer_contact_extra` and `mode_invoice_material_ref` initialized by the repository; existing financial tables are not rewritten.
- Customer photos are embedded only in JSON contact transfers, not CSV; maximum input photo size 2 MB.
- Existing invoice lines are preserved and new catalog-linked invoice lines record material ID, unit and captured unit price. Supplier ID and URL are not yet populated by the invoice picker.
- No Gradle build, APK compilation, or physical device test was run. End-to-end behavior and migrations remain unverified.

### Final follow-up review (source only)
- Preferred supplier selection is constrained by matching Smart Tools profile and material ID; invoice line records capture supplier ID, product URL, unit and unit price rather than relying on live catalog lookups.
- Source search found no pre-existing customer-photo field or legacy customer-photo directory mapping. No speculative photo migration was added; such a migration requires a real legacy storage location/schema.
- Not compiled, built, signed or device-tested. Kotlin type checking, database upgrade tests and end-to-end customer/photo transfer tests remain pending.


Work notes source reviewed for profile-scoped access, image size checks, and backup inclusion. Android compilation and device tests not performed.

