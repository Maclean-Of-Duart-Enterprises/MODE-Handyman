# Flutter/Dart to native Kotlin migration

## Source audit

The supplied 1.0.2 source contains 829 Dart files, 255 Dart tests, and 225 historical SQL migrations. The final supplied schema is version 227. The migration retained the original application ID, icon assets, dark navy/gold palette, private database filename (`handyman.db`), min SDK 30, target SDK 36, and the supplied release identity.

The Flutter application used a broad route tree covering jobs, tasks, customers, contacts, sites, quotes, invoices, payments, schedule, todo, accounting, reports, receipts, suppliers, tools, mailings, backups, trip capture, plasterboard estimation, settings, setup, and remote accounting/integration screens.

## Native replacements

| Flutter-era component | Native replacement |
|---|---|
| Flutter widgets/routes | Android `Activity`, Views, XML, and programmatic view composition |
| Dart runtime / Flutter engine | Kotlin/JVM and Android framework APIs |
| sqflite | `android.database.sqlite.SQLiteDatabase` |
| PDF package | `android.graphics.pdf.PdfDocument` |
| share/file plugins | Android share intents and a narrow read-only `ContentProvider` |
| path-provider | Private Android app directories and Storage Access Framework |
| Sentry | Local Kotlin exception handler with redaction, retention, viewer, delete, and manual share |
| SMTP and SMS templates | Removed from executable workflows; no SMTP client or SMS-template UI is present |
| cloud/accounting integrations | Not carried into the offline build |

Schema migrations 226 and 227 are retained byte-for-byte. Native migration 228 adds profile ownership to top-level business data and repairs historical foreign-key targets left by earlier table rebuilds. Migration 229 adds an idempotent estimate-conversion journal and permanent contract-approval linkage. Existing rows are assigned to the profile active at migration time; they are never deleted or reset.

## Compatibility notes

The database remains at the same Android application-private path, so an in-place signed update sees the existing database. Existing inactive business profiles did not own separate operational records in schema 227; migration 228 assigns pre-existing global records to the active profile to prevent cross-profile mixing. Newly created profiles start with isolated operational data.

Legacy SMTP columns and the legacy message-template table remain dormant in SQLite solely to avoid destructive data loss and preserve downgrade/recovery options. No native code reads, sends, or uploads through them.

## Deliberate platform boundary

Android itself, the Android SDK, Android Gradle Plugin, and Kotlin toolchain include Google-developed platform/build code. The shipped application does not include Google Play Services, Firebase, proprietary Google APIs, or Google tracking libraries.
