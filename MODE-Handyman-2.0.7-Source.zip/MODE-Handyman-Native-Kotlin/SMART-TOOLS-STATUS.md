# MODE Smart Job Tools — 2.0.3 status

Smart Tools uses the private `mode-smart-tools.db` database and links records to the authoritative `handyman.db` by verified numeric identifiers.

Implemented in 2.0.3:

- Exact-ID and unique-title migration for legacy text job references.
- Ambiguous or missing matches remain preserved and appear in a manual reconciliation screen.
- New costs, revenue, photos, signatures, and estimates require a selected job.
- Estimate conversion writes separate material, labor, and markup quote lines.
- A main-database conversion journal and unique key prevent duplicate conversion; retry repairs an interrupted secondary link.
- Approval requires explicit consent and an on-screen handwritten signature.
- A signed contract PDF contains the customer, job, quote, terms, totals, signer, consent statement, timestamp, and signature image.
- Contract approvals are permanently linked by profile, customer, job, and quote IDs, and approved contracts cannot be deleted from Smart Tools.
- Backups include the Smart Tools database, job documents, signatures, generated signed contracts, attachments, and preferences.

The handwritten signature is evidence captured by the application, not a certificate-backed cryptographic digital signature. Legal sufficiency depends on the agreement and applicable law.
