# MODE Handyman 2.0.7 — Smart Tools crash fix

- Updated Android versionName to 2.0.7 and versionCode to 13.
- Removed unsafe deferred `ScrollView.requestChildFocus()` from `SmartToolsActivity.field()`.
- Android's owning scroll container now handles focus for both main-page inputs and dialog inputs, avoiding cross-hierarchy requests.
- Root cause established from uploaded Android bug report: two crashes in `SmartToolsActivity` on October 24 with `IllegalArgumentException: parameter must be a descendant of this view`, originating in `ScrollView.requestChildFocus`.
- No supplier or product-link records are deleted or migrated by this fix.

## Verification
- Static inspection of the crash stack and source: completed.
- Archive integrity: checked.
- Android compilation, on-device reproduction, and regression testing: NOT performed.

## On-device regression checks
1. Open Smart Tools → Material price library → Associate supplier and product link.
2. Select material and supplier; focus URL and purchase-price fields, including with the keyboard open.
3. Save and reopen the association; open the URL.
4. Navigate to other Smart Tools screens and edit fields near the bottom of the page.
5. Confirm previously saved business profiles and records remain intact.
