# Database migration and preservation

## Main database

- Private file: `handyman.db`
- Accepted input schemas: 225–229
- Current schema: 229
- Existing schemas 226–228 remain unchanged and are applied in order.
- Schema 229 adds an authoritative estimate-conversion journal and permanent contract-approval linkage with foreign keys to business profile, customer, job, and quote.

Before migration the app copies the database and WAL/SHM sidecars to private recovery storage. Each migration runs in a SQLite transaction. Startup enables foreign keys and requires both `PRAGMA integrity_check = ok` and an empty `PRAGMA foreign_key_check`. A failed open never resets or deletes the database.

## Smart Tools database

- Private file: `mode-smart-tools.db`
- Current schema: 4
- Existing text references are retained.
- Existing numeric links are checked against jobs in the same business profile.
- Exact numeric IDs and unique exact titles are verified automatically.
- Ambiguous, missing, or cross-profile references keep their data with `ambiguous` or `unresolved` status until manually linked.
- Estimate component rows preserve material, labor, and markup amounts independently.
- Approval rows retain signature, contract, consent, content hash, and authoritative approval ID.

## Backup and restore

Backups checkpoint and include both databases, attachments, job documents, generated PDFs, and native preferences. Restore rejects traversal paths, excessive entry counts, and oversized archives. It stages and validates both databases before replacing anything. It then keeps a pre-restore copy of databases, files, and preferences and automatically rolls back if application or post-restore validation fails.

## Executed migration checks

- The schema-227 template migrated through 228 and 229.
- Representative customer, job, task, quote, quote line, invoice, payment, todo, appointment, conversion-journal, and contract-approval records passed integrity and foreign-key checks.
- A duplicate estimate conversion was rejected by the schema constraint.
- A representative Smart Tools v3 database migrated to v4 without losing estimates, costs, attachments, or unresolved text references.

No personal production database was supplied, so final upgrade comparison against the user's actual records remains a physical-device acceptance test.
