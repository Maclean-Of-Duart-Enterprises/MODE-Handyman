package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class NotePhotoMarkersTest {
    @Test fun insertsAtExactCursorAndPreservesSurroundingText() {
        assertEquals("before\n[[mode-photo:42]]\nafter", NotePhotoMarkers.insert("beforeafter", 6, 42))
    }

    @Test fun findsMultipleImagesInDocumentOrder() {
        val body = "A [[mode-photo:9]] B [[mode-photo:3]] C"
        assertEquals(listOf(9L, 3L), NotePhotoMarkers.photoIds(body))
    }

    @Test fun removalTargetsOnlyTheChosenPhoto() {
        val body = "[[mode-photo:9]] and [[mode-photo:3]]"
        assertEquals(" and [[mode-photo:3]]", NotePhotoMarkers.remove(body, 9))
    }

    @Test fun rejectsInvalidIdentifiersAndOffsets() {
        assertThrows(IllegalArgumentException::class.java) { NotePhotoMarkers.marker(0) }
        assertThrows(IllegalArgumentException::class.java) { NotePhotoMarkers.insert("text", 5, 1) }
    }
}
