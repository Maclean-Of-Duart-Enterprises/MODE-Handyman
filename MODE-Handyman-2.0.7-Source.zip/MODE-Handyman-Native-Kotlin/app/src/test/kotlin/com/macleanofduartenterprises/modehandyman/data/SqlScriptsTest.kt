package com.macleanofduartenterprises.modehandyman.data

import org.junit.Assert.assertEquals
import org.junit.Test

class SqlScriptsTest {
    @Test fun splitPreservesSemicolonsAndEscapedQuotesInsideStrings() {
        val statements = SqlScripts.split("-- comment\nINSERT INTO x VALUES('a;it''s'); /* c */ UPDATE x SET y=2;")
        assertEquals(2, statements.size)
        assertEquals("INSERT INTO x VALUES('a;it''s')", statements[0])
        assertEquals("UPDATE x SET y=2", statements[1])
    }
}
