package com.macleanofduartenterprises.modehandyman.diagnostics

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalCrashReporterTest {
    @Test fun sensitiveValuesAreRedacted() {
        val redacted = LocalCrashReporter.redact("password=hunter2 email me@example.com phone 604-555-1212 bearer abc.def")
        assertFalse(redacted.contains("hunter2"))
        assertFalse(redacted.contains("me@example.com"))
        assertFalse(redacted.contains("604-555-1212"))
        assertFalse(redacted.contains("abc.def"))
        assertTrue(redacted.contains("REDACTED"))
    }
}
