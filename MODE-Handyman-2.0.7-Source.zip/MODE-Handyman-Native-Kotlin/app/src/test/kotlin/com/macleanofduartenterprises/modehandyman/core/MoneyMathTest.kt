package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.assertEquals
import org.junit.Test

class MoneyMathTest {
    @Test fun lineTotalsUseThousandthQuantities() {
        assertEquals(1875L, MoneyMath.lineTotal(1500, 1250))
        assertEquals(333L, MoneyMath.lineTotal(333, 1000))
    }

    @Test fun quoteDiscountAndTaxAreAppliedInOrder() {
        assertEquals(9900L, MoneyMath.quoteTotal(10_000, 1_000, 1_000))
    }

    @Test fun parsersRoundAtCurrencyPrecision() {
        assertEquals(1235L, MoneyMath.parseCents("$12.345"))
        assertEquals(1250L, MoneyMath.parseQuantity("1.25"))
    }

    @Test fun invoiceBalancePreservesTotalAndTracksPayments() {
        val total = 54_000L
        assertEquals(54_000L, total)
        assertEquals(34_000L, MoneyMath.invoiceBalance(total, 20_000L))
        assertEquals(0L, MoneyMath.invoiceBalance(total, 54_000L))
        assertEquals(false, MoneyMath.invoicePaid(total, 20_000L))
        assertEquals(true, MoneyMath.invoicePaid(total, 54_000L))
    }
}
