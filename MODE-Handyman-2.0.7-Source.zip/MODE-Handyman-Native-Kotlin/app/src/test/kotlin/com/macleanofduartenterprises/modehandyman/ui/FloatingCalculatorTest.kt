package com.macleanofduartenterprises.modehandyman.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class FloatingCalculatorTest {
    @Test fun appliesOperatorPrecedence() {
        assertEquals("14", FloatingCalculator.calculate("2+3×4"))
        assertEquals("5", FloatingCalculator.calculate("20÷4"))
    }

    @Test fun supportsParenthesesDecimalsAndSignedValues() {
        assertEquals("-10", FloatingCalculator.calculate("-(2+3)×2"))
        assertEquals("7.5", FloatingCalculator.calculate("(1.5+1)×3"))
    }

    @Test fun rejectsIncompleteOrUnexpectedInput() {
        assertThrows(IllegalArgumentException::class.java) { FloatingCalculator.calculate("2+") }
        assertThrows(IllegalArgumentException::class.java) { FloatingCalculator.calculate("2a3") }
    }
}
