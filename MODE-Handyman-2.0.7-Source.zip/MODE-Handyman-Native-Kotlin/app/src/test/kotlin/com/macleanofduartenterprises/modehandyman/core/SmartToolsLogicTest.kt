package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SmartToolsLogicTest {
    private val jobs = listOf(
        JobIdentity(10, "Kitchen repair"),
        JobIdentity(11, "Deck repair"),
        JobIdentity(12, "Deck repair")
    )

    @Test fun exactIdsAndUniqueTitlesAreVerified() {
        assertEquals(10L, SmartToolsLogic.resolveJob("#10", jobs).jobId)
        assertEquals(10L, SmartToolsLogic.resolveJob(" kitchen   repair ", jobs).jobId)
    }

    @Test fun ambiguousAndMissingReferencesStayUnresolved() {
        val ambiguous = SmartToolsLogic.resolveJob("Deck repair", jobs)
        assertNull(ambiguous.jobId)
        assertEquals("ambiguous", ambiguous.status)
        assertNull(SmartToolsLogic.resolveJob("Unknown", jobs).jobId)
    }

    @Test fun estimateBreakdownExactlyMatchesTheCalculatedTotal() {
        val total = ConstructionMath.estimateCents(10_000, 2.5, 5_000, 10.0)
        val parts = SmartToolsLogic.estimateComponents("Repair", "Exterior", 3.0, "windows", 10_000, 2.5, 5_000, total)
        assertEquals(listOf("material", "labor", "markup"), parts.map { it.kind })
        assertEquals(total, parts.sumOf { it.lineTotalCents })
        assertEquals(2_500L, parts.first { it.kind == "labor" }.quantityThousandths)
    }
}
