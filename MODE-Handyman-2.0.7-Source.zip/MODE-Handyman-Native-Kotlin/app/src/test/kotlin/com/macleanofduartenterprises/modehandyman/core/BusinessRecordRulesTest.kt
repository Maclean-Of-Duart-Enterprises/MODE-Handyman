package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class BusinessRecordRulesTest {
    @Test fun acceptsOnlyExplicitHttpAndHttpsDirectoryLinks() {
        assertTrue(BusinessRecordRules.isHttpUrl("https://supplier.example/product"))
        assertTrue(BusinessRecordRules.isHttpUrl("http://manufacturer.example"))
        assertFalse(BusinessRecordRules.isHttpUrl("javascript:alert(1)"))
        assertFalse(BusinessRecordRules.isHttpUrl("supplier.example"))
    }

    @Test fun extractsAValidatedLegacyUrlWithoutMovingOrdinaryText() {
        assertEquals("https://supplier.example/item", BusinessRecordRules.firstHttpUrl("Order at https://supplier.example/item."))
        assertNull(BusinessRecordRules.firstHttpUrl("Call the supplier for pricing"))
    }

    @Test fun convertsAndDisplaysMetricAndUsCustomaryTrips() {
        assertEquals(1000L, BusinessRecordRules.distanceToMetres("1", true))
        assertEquals(1609L, BusinessRecordRules.distanceToMetres("1", false))
        assertEquals("1.00 km", BusinessRecordRules.distanceLabel(1000, true))
        assertEquals("1.00 mi", BusinessRecordRules.distanceLabel(1609, false))
    }

    @Test fun rejectsNegativeTripsAndInvalidReceiptTax() {
        assertThrows(IllegalArgumentException::class.java) { BusinessRecordRules.distanceToMetres("-1", false) }
        assertEquals(900L to 100L, BusinessRecordRules.receiptAmounts(1000, 100))
        assertThrows(IllegalArgumentException::class.java) { BusinessRecordRules.receiptAmounts(1000, 1001) }
    }
}
