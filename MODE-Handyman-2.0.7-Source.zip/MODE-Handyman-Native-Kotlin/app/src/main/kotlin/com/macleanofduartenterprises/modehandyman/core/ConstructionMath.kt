package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.ceil

/** Pure offline estimators. Inputs are feet/square feet; quantities are estimates, not engineering specifications. */
object ConstructionMath {
    fun concreteYards(lengthFt: Double, widthFt: Double, depthIn: Double, waste: Double = 0.10): Double {
        positive(lengthFt, widthFt, depthIn); require(waste in 0.0..1.0)
        return lengthFt * widthFt * depthIn / 324.0 * (1 + waste)
    }
    fun gravelTons(lengthFt: Double, widthFt: Double, depthIn: Double, tonsPerYard: Double = 1.4): Double {
        positive(lengthFt, widthFt, depthIn, tonsPerYard)
        return lengthFt * widthFt * depthIn / 324.0 * tonsPerYard
    }
    fun area(lengthFt: Double, widthFt: Double): Double { positive(lengthFt, widthFt); return lengthFt * widthFt }
    fun paintGallons(areaSqFt: Double, coverageSqFt: Double = 350.0, coats: Double = 2.0): Int {
        positive(areaSqFt, coverageSqFt, coats); return ceil(areaSqFt * coats / coverageSqFt).toInt()
    }
    fun drywallSheets(areaSqFt: Double, sheetSqFt: Double = 32.0, waste: Double = 0.1): Int {
        positive(areaSqFt, sheetSqFt); require(waste in 0.0..1.0)
        return ceil(areaSqFt * (1 + waste) / sheetSqFt).toInt()
    }
    fun estimateCents(materialCents: Long, laborHours: Double, hourlyCents: Long, markupPercent: Double): Long {
        require(materialCents >= 0 && laborHours >= 0 && hourlyCents >= 0 && markupPercent in 0.0..1000.0)
        val base = BigDecimal.valueOf(materialCents).add(BigDecimal.valueOf(laborHours).multiply(BigDecimal.valueOf(hourlyCents)))
        return base.multiply(BigDecimal.ONE.add(BigDecimal.valueOf(markupPercent).movePointLeft(2))).setScale(0, RoundingMode.HALF_UP).longValueExact()
    }
    private fun positive(vararg numbers: Double) { require(numbers.all { it.isFinite() && it > 0 }) { "Enter positive, finite measurements" } }
}
