package com.macleanofduartenterprises.modehandyman

import android.app.Application
import com.macleanofduartenterprises.modehandyman.data.DatabaseManager
import com.macleanofduartenterprises.modehandyman.diagnostics.LocalCrashReporter

class ModeApplication : Application() {
    lateinit var databaseManager: DatabaseManager
        private set

    override fun onCreate() {
        super.onCreate()
        LocalCrashReporter.install(this)
        databaseManager = DatabaseManager(this)
    }
}
