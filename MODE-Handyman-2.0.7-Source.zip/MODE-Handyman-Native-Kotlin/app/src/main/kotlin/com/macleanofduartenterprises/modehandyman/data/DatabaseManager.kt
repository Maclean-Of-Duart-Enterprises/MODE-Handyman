package com.macleanofduartenterprises.modehandyman.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.time.Instant

class DatabaseManager(private val context: Context) {
    companion object {
        const val DB_NAME = "handyman.db"
        const val SCHEMA_VERSION = 229
    }

    @Volatile private var instance: SQLiteDatabase? = null

    @Synchronized
    fun open(): SQLiteDatabase {
        instance?.takeIf { it.isOpen }?.let { return it }
        val path = context.getDatabasePath(DB_NAME)
        if (!path.exists()) {
            path.parentFile?.mkdirs()
            context.assets.open("handyman-template.db").use { input ->
                path.outputStream().use { output -> input.copyTo(output) }
            }
        } else {
            preservePreMigrationCopy(path)
        }

        val db = SQLiteDatabase.openDatabase(path.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            // PRAGMA statements return result rows on Android and therefore must
            // be executed through rawQuery(), not execSQL(). Newer Android SQLite
            // wrappers reject query-producing statements passed to execSQL().
            db.rawQuery("PRAGMA busy_timeout=5000", null).use { cursor ->
                check(cursor.moveToFirst()) { "Unable to configure the SQLite busy timeout" }
            }

            migrate(db)

            // Use the Android API instead of executing PRAGMA foreign_keys as SQL.
            // This is called outside a transaction, as required by SQLiteDatabase.
            db.setForeignKeyConstraintsEnabled(true)
            require(db.rawQuery("PRAGMA integrity_check", null).use { cursor ->
                cursor.moveToFirst() && cursor.getString(0) == "ok"
            }) {
                "The MODE Handyman database failed its integrity check. The original database was not deleted."
            }
            require(db.rawQuery("PRAGMA foreign_key_check", null).use { cursor -> !cursor.moveToFirst() }) {
                "The MODE Handyman database contains invalid record relationships. The original database was not deleted."
            }
            instance = db
            return db
        } catch (error: Throwable) {
            // Do not retain a half-open handle after initialization fails. The
            // database and its pre-migration recovery copy remain untouched.
            db.close()
            throw error
        }
    }

    fun close() {
        synchronized(this) {
            instance?.close()
            instance = null
        }
    }

    private fun migrate(db: SQLiteDatabase) {
        var version = db.version
        require(version in 225..SCHEMA_VERSION) {
            "Unsupported database schema $version. This build safely supports MODE schemas 225 through $SCHEMA_VERSION."
        }
        if (version < 226) apply(db, 226)
        if (version < 227) apply(db, 227)
        BusinessProfiles(context, db).ensureInitialized()
        if (version < 228) apply(db, 228)
        if (version < 229) apply(db, 229)
        version = db.version
        check(version == SCHEMA_VERSION) { "Database migration stopped at $version" }
    }

    private fun apply(db: SQLiteDatabase, version: Int) {
        db.beginTransaction()
        try {
            SqlScripts.executeAsset(context, db, "v$version.sql")
            db.version = version
            db.execSQL(
                "INSERT INTO version(db_version,code_version,created_date,modified_date) VALUES(?,?,?,?)",
                arrayOf<Any>(version, "2.0.3", Instant.now().toString(), Instant.now().toString())
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun preservePreMigrationCopy(database: File) {
        val marker = File(context.filesDir, "migration-backups/schema-229.complete")
        if (marker.exists()) return
        val directory = marker.parentFile ?: return
        directory.mkdirs()
        listOf("", "-wal", "-shm").forEach { suffix ->
            val source = File(database.absolutePath + suffix)
            if (source.exists()) source.copyTo(File(directory, DB_NAME + suffix + ".pre-native"), overwrite = true)
        }
    }

    fun markMigrationComplete() {
        val marker = File(context.filesDir, "migration-backups/schema-229.complete")
        marker.parentFile?.mkdirs()
        marker.writeText(Instant.now().toString())
    }
}
