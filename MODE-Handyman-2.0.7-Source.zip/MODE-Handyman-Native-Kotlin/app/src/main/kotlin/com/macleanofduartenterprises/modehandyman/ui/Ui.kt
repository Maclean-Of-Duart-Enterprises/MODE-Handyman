package com.macleanofduartenterprises.modehandyman.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.macleanofduartenterprises.modehandyman.R

object Ui {
    const val BG = 0xff0d1e2e.toInt()
    const val SURFACE = 0xff172d40.toInt()
    const val GOLD = 0xffd9bd63.toInt()
    const val TEXT = 0xfff1eff4.toInt()
    const val MUTED = 0xffb9b7be.toInt()
    const val ERROR = 0xffda6379.toInt()

    fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    fun column(context: Context, pad: Int = 16) = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(context.dp(pad), context.dp(pad), context.dp(pad), context.dp(32))
    }

    fun scroll(context: Context, child: View): ScrollView = ScrollView(context).apply {
        isFillViewport = true
        clipToPadding = false
        setPadding(0, 0, 0, context.dp(96))
        setBackgroundColor(BG)
        addView(child, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun title(context: Context, text: String, size: Float = 26f) = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(TEXT)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, context.dp(8), 0, context.dp(12))
    }

    fun label(context: Context, text: String, color: Int = MUTED, size: Float = 15f) = TextView(context).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        setPadding(0, context.dp(3), 0, context.dp(3))
    }

    fun button(context: Context, text: String, onClick: () -> Unit) = Button(context).apply {
        this.text = text
        isAllCaps = false
        setTextColor(0xff11273b.toInt())
        setTypeface(typeface, Typeface.BOLD)
        setBackgroundResource(R.drawable.mode_button)
        setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(50)).apply {
            setMargins(0, context.dp(5), 0, context.dp(5))
        }
    }

    fun field(context: Context, hint: String, value: String = "", multiline: Boolean = false): EditText = EditText(context).apply {
        this.hint = hint
        setHintTextColor(0xff85858b.toInt())
        setTextColor(TEXT)
        setText(value)
        textSize = 16f
        setBackgroundResource(R.drawable.mode_field)
        setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        inputType = if (multiline) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
        minLines = if (multiline) 3 else 1
        gravity = if (multiline) Gravity.TOP else Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, context.dp(5), 0, context.dp(5))
        }
        setOnFocusChangeListener { view, focused ->
            if (focused) view.post {
                var parent = view.parent
                while (parent is View && parent !is ScrollView) parent = parent.parent
                (parent as? ScrollView)?.requestChildFocus(view, view)
            }
        }
    }

    fun moneyField(context: Context, hint: String, cents: Long = 0) = field(context, hint, if (cents == 0L) "" else "%.2f".format(cents / 100.0)).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    fun card(context: Context, title: String, subtitle: String = "", trailing: String = "", status: String = "", onClick: (() -> Unit)? = null): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.mode_card)
            setPadding(context.dp(14), context.dp(12), context.dp(14), context.dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, context.dp(4), 0, context.dp(4))
            }
        }
        val words = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        words.addView(label(context, title, TEXT, 18f))
        if (subtitle.isNotBlank()) words.addView(label(context, subtitle))
        if (status.isNotBlank()) words.addView(label(context, status, GOLD, 13f))
        row.addView(words, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing.isNotBlank()) row.addView(label(context, trailing, GOLD, 16f))
        if (onClick != null) {
            row.isClickable = true
            row.isFocusable = true
            row.setOnClickListener { onClick() }
        }
        return row
    }

    fun section(context: Context, text: String) = label(context, text.uppercase(), GOLD, 13f).apply {
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, context.dp(18), 0, context.dp(5))
    }
}
