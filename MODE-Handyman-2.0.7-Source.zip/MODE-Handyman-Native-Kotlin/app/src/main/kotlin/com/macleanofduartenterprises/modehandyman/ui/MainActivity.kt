package com.macleanofduartenterprises.modehandyman.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.style.ImageSpan
import android.graphics.drawable.BitmapDrawable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import com.macleanofduartenterprises.modehandyman.ModeApplication
import com.macleanofduartenterprises.modehandyman.R
import com.macleanofduartenterprises.modehandyman.core.*
import com.macleanofduartenterprises.modehandyman.data.*
import com.macleanofduartenterprises.modehandyman.diagnostics.LocalCrashReporter
import com.macleanofduartenterprises.modehandyman.export.BackupManager
import com.macleanofduartenterprises.modehandyman.export.PdfGenerator
import java.io.File
import java.time.LocalDate
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var calculatorButton: Button
    private lateinit var content: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var back: Button
    private lateinit var home: Button
    private var repositoryState: ModeRepository? = null
    private val repository: ModeRepository
        get() = checkNotNull(repositoryState) { "The local database is not ready" }
    private val pages = ArrayDeque<Page>()
    private val logoRequestCode = 6204
    private var customerExportIds: List<Long> = emptyList()
    private var customerExportCsv = false
    private var pendingReceiptPhotoId: Long? = null
    private var pendingCustomerPhotoId: Long? = null
    private var pendingNotePhotoId: Long? = null
    private var pendingNotePhotoOffset: Int = -1
    private var selectedMaterialForLine: Map<String,String>? = null
    private var backupExportPending = false
    private var backupRestorePending = false
    private data class Page(val title: String, val render: () -> View)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        calculatorButton = FloatingCalculator.install(this)
        content = findViewById(R.id.content)
        titleView = findViewById(R.id.title)
        back = findViewById(R.id.back_button)
        home = findViewById(R.id.home_button)
        back.setOnClickListener { navigateBack() }
        home.isEnabled = false
        home.setOnClickListener {
            if (repositoryState != null) dashboard(reset = true)
        }
        loading("Opening your local business data…")
        thread(name = "mode-database-open") {
            runCatching {
                val manager = (application as ModeApplication).databaseManager
                val openedRepository = ModeRepository(applicationContext, manager.open())
                SmartToolsStore(applicationContext).use { smart ->
                    openedRepository.allJobIdentities().forEach { (profile, jobs) -> smart.reconcileJobIds(profile, jobs) }
                }
                manager.markMigrationComplete()
                openedRepository
            }.onSuccess { openedRepository ->
                runOnUiThread {
                    repositoryState = openedRepository
                    home.isEnabled = true
                    dashboard(reset = true)
                }
            }.onFailure { error ->
                runOnUiThread {
                    repositoryState = null
                    home.isEnabled = false
                    fatal(error)
                }
            }
        }
    }

    @Deprecated("Uses native back handling for API 30 compatibility")
    override fun onBackPressed() = navigateBack()

    private fun navigateBack() {
        if (pages.size <= 1) { finish(); return }
        pages.removeLast()
        display(pages.last())
    }

    private fun open(title: String, render: () -> View) {
        val page = Page(title, render)
        pages.addLast(page)
        display(page)
    }

    private fun refresh() = display(pages.last())

    private fun display(page: Page) {
        titleView.text = page.title
        back.visibility = if (pages.size > 1) View.VISIBLE else View.INVISIBLE
        content.removeAllViews()
        runCatching { page.render() }
            .onSuccess { content.addView(it, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)) }
            .onFailure { error -> content.addView(errorView(error)) }
    }

    private fun loading(message: String) {
        titleView.text = getString(R.string.app_name)
        content.removeAllViews()
        content.addView(Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, "MODE Handyman"))
            addView(Ui.label(this@MainActivity, message))
            addView(ProgressBar(this@MainActivity))
        }))
    }

    private fun fatal(error: Throwable) {
        titleView.setText(R.string.database_error)
        content.removeAllViews()
        content.addView(errorView(error))
    }

    private fun errorView(error: Throwable): View = Ui.scroll(this, Ui.column(this).apply {
        addView(Ui.title(this@MainActivity, "Unable to open this screen"))
        addView(Ui.label(this@MainActivity, error.message ?: error.javaClass.simpleName, Ui.ERROR))
        addView(Ui.label(this@MainActivity, "Your existing data has not been reset or deleted."))
        addView(Ui.button(this@MainActivity, "Back") { navigateBack() })
    })

    private fun dashboard(reset: Boolean = false) {
        if (reset) pages.clear()
        open("MODE Handyman") {
            val counts = repository.dashboardCounts()
            Ui.scroll(this, Ui.column(this).apply {
                val active = repository.profiles.all().first { it.active }
                addView(Ui.title(this@MainActivity, active.name))
                addView(Ui.label(this@MainActivity, "Private, offline business management", Ui.GOLD))
                addView(Ui.section(this@MainActivity, "Work"))
                addMenu("Jobs", counts["Jobs"], ::jobsScreen)
                addMenu("Notes", null, ::notesScreen)
                addMenu("Quotes", counts["Quotes"], ::quotesScreen)
                addMenu("Invoices & payments", counts["Invoices"], ::invoicesScreen)
                addMenu("Schedule", null, ::scheduleScreen)
                addMenu("Todo", counts["Todo"], ::todosScreen)
                addView(Ui.section(this@MainActivity, "People and materials"))
                addMenu("Customers & contacts", counts["Customers"], ::customersScreen)
                addMenu("Suppliers", null) { simpleScreen("Suppliers", "suppliers") }
                addMenu("Manufacturers", null) { simpleScreen("Manufacturers", "manufacturers") }
                addMenu("Tools", counts["Tools"]) { simpleScreen("Tools", "tools") }
                addMenu("Receipts & expenses", null) { simpleScreen("Receipts", "receipts") }
                addMenu("Trips", null) { simpleScreen("Trips", "trips") }
                addView(Ui.section(this@MainActivity, "Smart project tools"))
                addMenu("Estimator, materials, profitability, photos & signatures", null) { startActivity(Intent(this@MainActivity, SmartToolsActivity::class.java).putExtra("profile", repository.profiles.all().first { it.active }.id.toString())) }
                addView(Ui.section(this@MainActivity, "Business"))
                addMenu("Reports", null, ::reportsScreen)
                addMenu("Settings, profiles & backups", null, ::settingsScreen)
            })
        }
    }

    private fun LinearLayout.addMenu(name: String, count: Int?, action: () -> Unit) {
        addView(Ui.card(this@MainActivity, name, if (count == null) "" else "$count records", "›", onClick = action))
    }

    private fun notesScreen() = open("Work notes") {
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,"Work notes"))
            addView(Ui.button(this@MainActivity,"+ New note") { noteForm(null) })
            repository.workNotes().forEach { note ->
                val customer=note.customerId?.let { id -> repository.customerChoices().firstOrNull{it.id==id}?.label } ?: "No customer linked"
                addView(Ui.card(this@MainActivity,note.title,customer,note.updated){noteScreen(note.id)})
            }
        })
    }
    private fun noteScreen(id:Long) = open("Note") {
        val note=repository.workNote(id)
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,note.title))
            // Photo markers are persisted in the note body at the exact insertion position.
            // Older notes without markers retain their original gallery as a fallback.
            val photos=repository.notePhotos(id)
            val photoById=photos.associateBy { it.id }
            val inlinePattern=NotePhotoMarkers.pattern
            var cursor=0
            val rendered=mutableSetOf<Long>()
            fun renderPhoto(photo: ModeRepository.WorkNotePhoto) {
                val file=File(filesDir,"work-note-photos/${photo.fileName}")
                if(file.isFile) BitmapFactory.decodeFile(file.absolutePath)?.let { bitmap ->
                    addView(ImageView(this@MainActivity).apply {
                        setImageBitmap(bitmap);adjustViewBounds=true
                        maxHeight=(resources.displayMetrics.density*320).toInt()
                        scaleType=ImageView.ScaleType.FIT_CENTER
                    })
                }
                if(photo.caption.isNotBlank()) addView(Ui.label(this@MainActivity,photo.caption))
                addView(Ui.button(this@MainActivity,"Remove photo") { confirm("Remove this note photo?") {
                    val updated=NotePhotoMarkers.remove(repository.workNote(id).body, photo.id)
                    repository.saveWorkNote(id,note.customerId,note.title,updated)
                    repository.deleteNotePhoto(id,photo.id)?.let { File(filesDir,"work-note-photos/$it").delete() }
                    refresh()
                } })
                rendered.add(photo.id)
            }
            inlinePattern.findAll(note.body).forEach { match ->
                val paragraph=note.body.substring(cursor,match.range.first)
                if(paragraph.isNotEmpty()) addView(Ui.label(this@MainActivity,paragraph))
                match.groupValues[1].toLongOrNull()?.let { photoById[it] }?.let(::renderPhoto)
                cursor=match.range.last+1
            }
            val trailing=note.body.substring(cursor)
            if(trailing.isNotEmpty()) addView(Ui.label(this@MainActivity,trailing))
            if(photos.any { it.id !in rendered }) {
                addView(Ui.section(this@MainActivity,"Earlier photos"))
                photos.filter { it.id !in rendered }.forEach(::renderPhoto)
            }
            note.customerId?.let { customerId -> addView(Ui.button(this@MainActivity,"Open linked customer") { customerScreen(customerId) }) }
            addView(Ui.button(this@MainActivity,"Edit note") { noteForm(id) })
            addView(Ui.button(this@MainActivity,"+ Insert photo between paragraphs") { noteForm(id) })
            addView(Ui.button(this@MainActivity,"Delete note") { confirm("Delete this note and its photos?") {
                val files=repository.notePhotos(id).map{it.fileName};repository.deleteWorkNote(id)
                files.forEach { File(filesDir,"work-note-photos/$it").delete() };navigateBack();refresh()
            } })
        })
    }
    /** Display stored photo markers as actual inline images in the editable text.
     * The underlying marker text remains unchanged for lossless persistence and export.
     */
    private fun renderEditableNotePhotos(editor: EditText, noteId: Long) {
        val images = repository.notePhotos(noteId).associateBy { it.id }
        val editable = editor.text
        val pattern = NotePhotoMarkers.pattern
        // Span changes must not trigger text replacement: the original marker is the stored format.
        editable.getSpans(0, editable.length, ImageSpan::class.java).forEach(editable::removeSpan)
        pattern.findAll(editable.toString()).forEach { match ->
            val id = match.groupValues[1].toLongOrNull() ?: return@forEach
            val photo = images[id] ?: return@forEach
            val file = File(filesDir, "work-note-photos/${photo.fileName}")
            if (!file.isFile) return@forEach
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@forEach
            val maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt().coerceAtLeast(1)
            val maxHeight = (resources.displayMetrics.density * 240).toInt().coerceAtLeast(1)
            val sample = BitmapFactory.Options().apply {
                inSampleSize = generateSequence(1) { it * 2 }.takeWhile {
                    bounds.outWidth / it > maxWidth * 2 || bounds.outHeight / it > maxHeight * 2
                }.lastOrNull() ?: 1
            }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, sample) ?: return@forEach
            val scale = minOf(maxWidth.toFloat() / bitmap.width, maxHeight.toFloat() / bitmap.height, 1f)
            val drawable = BitmapDrawable(resources, bitmap).apply {
                setBounds(0, 0, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1))
            }
            editable.setSpan(ImageSpan(drawable, ImageSpan.ALIGN_BOTTOM), match.range.first,
                match.range.last + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun noteForm(id:Long?) {
        val existing=id?.let{repository.workNote(it)}
        val body=Ui.column(this,8)
        val title=Ui.field(this,"Note title",existing?.title.orEmpty())
        val text=Ui.field(this,"Note text",existing?.body.orEmpty(),true)
        if (id != null) renderEditableNotePhotos(text, id)
        val customers=repository.customerChoices()
        val names=listOf("No linked customer")+customers.map{it.label}
        val selected=existing?.customerId?.let{wanted->customers.indexOfFirst{it.id==wanted}+1}?:0
        val customer=spinner(names,selected.coerceAtLeast(0))
        listOf(title,Ui.label(this,"Linked customer"),customer,text).forEach(body::addView)
        body.addView(Ui.label(this,"Position the cursor to insert a photo. Existing photos display directly in the editor."))
        body.addView(Ui.button(this,"Insert photo at cursor") {
            val customerId=if(customer.selectedItemPosition==0)null else customers[customer.selectedItemPosition-1].id
            runCatching {
                val offset=text.selectionStart.coerceIn(0,text.text.length)
                val saved=repository.saveWorkNote(id,customerId,title.text.toString(),text.text.toString())
                pendingNotePhotoId=saved
                pendingNotePhotoOffset=offset
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="image/*" },6213)
            }.onFailure { toast(it.message?:"Could not save note") }
        })
        formDialog(if(id==null)"New work note" else "Edit work note",body) {
            val customerId=if(customer.selectedItemPosition==0)null else customers[customer.selectedItemPosition-1].id
            val saved=repository.saveWorkNote(id,customerId,title.text.toString(),text.text.toString())
            if(id==null) noteScreen(saved) else refresh()
        }
    }
    private fun customersScreen() = open("Customers") {
        searchableList("Search customers", repository::customers) { id -> customerScreen(id) }
            .also {
                it.addView(Ui.button(this, "Import customer contacts (JSON/CSV)") { pickCustomerImport() }, 0)
                it.addView(Ui.button(this, "Export all customers (JSON/CSV)") { chooseCustomerExport(repository.customers().map { row -> row.id }) }, 0)
                it.addView(Ui.button(this, "Select customers to export") { selectCustomersForExport() }, 0)
                it.addView(Ui.button(this, "+ Add customer") { customerForm(null) }, 0)
            }
    }

    /** Multi-customer export is explicitly selected; no unrelated business data is included. */
    private fun selectCustomersForExport() {
        val records = repository.customers()
        if (records.isEmpty()) { toast("No customers to export"); return }
        val selected = BooleanArray(records.size)
        AlertDialog.Builder(this)
            .setTitle("Select customer contacts")
            .setMultiChoiceItems(records.map { it.title }.toTypedArray(), selected) { _, which, checked ->
                selected[which] = checked
            }
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val ids = records.indices.filter { selected[it] }.map { records[it].id }
                if (ids.isEmpty()) toast("Select at least one customer") else chooseCustomerExport(ids)
            }.show()
    }

    private fun customerScreen(id: Long) = open("Customer") {
        val customer = repository.customer(id)
        Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, customer.name))
            addView(Ui.label(this@MainActivity, customer.description.ifBlank { "No description" }))
            if (customer.groups.isNotBlank()) addView(Ui.label(this@MainActivity, "Groups: ${customer.groups}", Ui.GOLD))
            addView(Ui.button(this@MainActivity, "Edit customer") { customerForm(customer) })
            addView(Ui.button(this@MainActivity,"Choose customer photo") { pendingCustomerPhotoId=id; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6212) })
            addView(Ui.button(this@MainActivity, "Export this customer") { chooseCustomerExport(listOf(id)) })
            addView(Ui.button(this@MainActivity,"Copy / Delete customer"){recordActions("customer",id,"customer")})
            addView(Ui.button(this@MainActivity,"Copy contact to another business profile") {
                val destinations=repository.profiles.all().filter { !it.active }
                if(destinations.isEmpty()) android.widget.Toast.makeText(this@MainActivity,"Create another business profile first",android.widget.Toast.LENGTH_LONG).show()
                else android.app.AlertDialog.Builder(this@MainActivity).setTitle("Copy customer contact to")
                    .setItems(destinations.map { it.name }.toTypedArray()) { _,which ->
                        val target=destinations[which]
                        android.app.AlertDialog.Builder(this@MainActivity).setTitle("Confirm contact copy")
                            .setMessage("Copy customer name, notes, custom fields and contacts to ${target.name}? No jobs, quotes, invoices or payments will be transferred. Duplicate names will be rejected.")
                            .setNegativeButton("Cancel",null).setPositiveButton("Copy") { _,_ ->
                                runCatching { repository.copyCustomerContactOnly(id,target.id) }
                                    .onSuccess { android.widget.Toast.makeText(this@MainActivity,"Contact copied",android.widget.Toast.LENGTH_LONG).show() }
                                    .onFailure { android.widget.Toast.makeText(this@MainActivity,it.message,android.widget.Toast.LENGTH_LONG).show() }
                            }.show()
                    }.show()
            })
            addView(Ui.section(this@MainActivity, "Contacts"))
            repository.contacts(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing) { contactForm(repository.contact(row.id), id) }) }
            addView(Ui.button(this@MainActivity, "+ Add contact") { contactForm(null, id) })
            addView(Ui.section(this@MainActivity, "Jobs"))
            repository.jobs().filter { job -> repository.job(job.id).customerId == id }.forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing, row.status) { jobScreen(row.id) }) }
        })
    }

    private fun customerForm(existing: CustomerDraft?) {
        val body = Ui.column(this, 8)
        val name = Ui.field(this, "Customer or company name", existing?.name.orEmpty())
        val description = Ui.field(this, "Description", existing?.description.orEmpty(), true)
        val groups = Ui.field(this, "Groups (comma separated)", existing?.groups.orEmpty())
        val fields = Ui.field(this, "Custom fields", existing?.customFields.orEmpty(), true)
        val extra=existing?.id?.let { repository.customerExtra(it) } ?: org.json.JSONObject()
        val business=Ui.field(this,"Business name (optional)",extra.optString("business_name"))
        val billing=Ui.field(this,"Billing address",extra.optString("billing_address"),true)
        val service=Ui.field(this,"Service address",extra.optString("service_address"),true)
        val rate = Ui.moneyField(this, "Default hourly rate", existing?.defaultHourlyRateCents ?: 0)
        listOf(name, description, groups, fields, business, billing, service, rate).forEach(body::addView)
        formDialog(if (existing == null) "Add customer" else "Edit customer", body) {
            val customerId=repository.saveCustomer(CustomerDraft(existing?.id, name.text.toString(), description.text.toString(), groups.text.toString(), fields.text.toString(), MoneyMath.parseCents(rate.text.toString())))
            repository.saveCustomerExtra(customerId,business.text.toString(),billing.text.toString(),service.text.toString())
            refresh()
        }
    }

    private fun contactForm(existing: ContactDraft?, customerId: Long?) {
        val body = Ui.column(this, 8)
        val first = Ui.field(this, "First name", existing?.firstName.orEmpty())
        val last = Ui.field(this, "Surname", existing?.surname.orEmpty())
        val email = Ui.field(this, "Email (optional)", existing?.email.orEmpty())
        val phone = Ui.field(this, "Phone (optional)", existing?.phone.orEmpty())
        listOf(first, last, email, phone).forEach(body::addView)
        formDialog(if (existing == null) "Add contact" else "Edit contact", body) {
            repository.saveContact(ContactDraft(existing?.id, first.text.toString(), last.text.toString(), email.text.toString(), phone.text.toString()), customerId)
            refresh()
        }
    }

    private fun jobsScreen() = open("Jobs") {
        searchableList("Search jobs", repository::jobs) { id -> jobScreen(id) }
            .also { it.addView(Ui.button(this, "+ Add job") { jobForm(null) }, 0) }
    }

    private fun jobScreen(id: Long) = open("Job") {
        val job = repository.job(id)
        Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, job.summary))
            addView(Ui.label(this@MainActivity, "${job.status} • ${job.billingType}", Ui.GOLD))
            addView(Ui.label(this@MainActivity, job.description.ifBlank { "No description" }))
            addView(Ui.button(this@MainActivity, "Edit job") { jobForm(job) })
            addView(Ui.button(this@MainActivity,"Rename / Copy / Delete job"){recordActions("job",id,"job")})
            addView(Ui.button(this@MainActivity, "Create quote") { confirm("Create quote for this job?") { quoteScreen(repository.createQuote(id)) } })
            addView(Ui.button(this@MainActivity, "Create invoice") { confirm("Create invoice for this job?") { invoiceScreen(repository.createInvoice(id)) } })
            addView(Ui.section(this@MainActivity, "Tasks"))
            repository.tasks(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing, row.status)) }
            addView(Ui.button(this@MainActivity, "+ Add task") { taskForm(id) })
            addView(Ui.section(this@MainActivity, "Materials and labour"))
            repository.taskItems(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing)) }
            addView(Ui.button(this@MainActivity, "+ Add material/labour item") { taskItemForm(id) })
            addView(Ui.section(this@MainActivity, "Time entries"))
            repository.timeEntries(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, status = row.status)) }
            addView(Ui.button(this@MainActivity, "Start timer") { timerForm(id) })
        })
    }

    private fun jobForm(existing: JobDraft?) {
        val body = Ui.column(this, 8)
        val customers = repository.customerChoices()
        val customer = spinner(customers.map { it.label }, existing?.customerId?.let { wanted -> customers.indexOfFirst { it.id == wanted }.coerceAtLeast(0) } ?: 0)
        val summary = Ui.field(this, "Job summary", existing?.summary.orEmpty())
        val description = Ui.field(this, "Description", existing?.description.orEmpty(), true)
        val notes = Ui.field(this, "Internal notes", existing?.notes.orEmpty(), true)
        val billing = spinner(listOf("timeAndMaterial", "fixedPrice", "nonBillable"), listOf("timeAndMaterial", "fixedPrice", "nonBillable").indexOf(existing?.billingType).coerceAtLeast(0))
        val status = spinner(listOf("Prospecting", "In Progress", "On Hold", "Completed", "Rejected"), listOf("Prospecting", "In Progress", "On Hold", "Completed", "Rejected").indexOf(existing?.status).coerceAtLeast(0))
        val rate = Ui.moneyField(this, "Hourly rate", existing?.hourlyRateCents ?: 0)
        listOf(Ui.label(this,"Customer"), customer, summary, description, notes, Ui.label(this,"Billing type"), billing, Ui.label(this,"Status"), status, rate).forEach(body::addView)
        formDialog(if (existing == null) "Add job" else "Edit job", body) {
            require(customers.isNotEmpty()) { "Add a customer first" }
            repository.saveJob(JobDraft(existing?.id, customers[customer.selectedItemPosition].id, summary.text.toString(), description.text.toString(), notes.text.toString(), billing.selectedItem.toString(), status.selectedItem.toString(), MoneyMath.parseCents(rate.text.toString()), existing?.bookingFeeCents ?: 0))
            refresh()
        }
    }

    private fun taskForm(jobId: Long) {
        val body=Ui.column(this,8); val name=Ui.field(this,"Task name"); val description=Ui.field(this,"Description","",true); val billing=spinner(listOf("timeAndMaterial","fixedPrice","nonBillable"))
        listOf(name,description,Ui.label(this,"Billing type"),billing).forEach(body::addView)
        formDialog("Add task",body){repository.saveTask(jobId,null,name.text.toString(),description.text.toString(),billing.selectedItem.toString(),1);refresh()}
    }

    private fun addMaterialCatalogPicker(body: LinearLayout, description: EditText, price: EditText, quantity: EditText) {
        body.addView(Ui.button(this, "Select material from catalog") {
            val profile = repository.profiles.all().first { it.active }.id.toString()
            val materials = SmartToolsStore(this).use { it.rows("materials",profile) }
            if (materials.isEmpty()) { toast("No materials saved in Smart Project Tools"); return@button }
            AlertDialog.Builder(this).setTitle("Material catalog").setItems(materials.map { "${it["name"]} · ${it["unit"]}" }.toTypedArray()) { _, index ->
                val material = materials[index]
                selectedMaterialForLine=material
                val materialLabel=listOfNotNull(material["name"], material["description"]?.takeIf { it.isNotBlank() }).joinToString(" — ")
                description.setText(getString(R.string.material_description_with_unit,materialLabel,material["unit"].orEmpty()))
                val cents = material["selling_cents"]?.toLongOrNull()?.takeIf { it > 0 } ?: material["cents"]?.toLongOrNull() ?: 0L
                price.setText(MoneyMath.format(cents).replace("$", "").replace(",", ""))
                quantity.setText(material["quantity"]?.takeIf { it.toDoubleOrNull()?.let { q -> q > 0 } == true } ?: "1")
            }.show()
        })
    }

    private fun taskItemForm(jobId: Long) {
        val tasks=repository.taskChoices(jobId); if(tasks.isEmpty()){toast("Add a task first");return}
        val body=Ui.column(this,8);val task=spinner(tasks.map{it.label});val description=Ui.field(this,"Item description");val quantity=Ui.field(this,"Quantity","1");val cost=Ui.moneyField(this,"Unit cost")
        listOf(Ui.label(this,"Task"),task,description,quantity,cost).forEach(body::addView)
        addMaterialCatalogPicker(body,description,cost,quantity)
        formDialog("Add material/labour",body){repository.addTaskItem(tasks[task.selectedItemPosition].id,description.text.toString(),MoneyMath.parseQuantity(quantity.text.toString()),MoneyMath.parseCents(cost.text.toString()),0);refresh()}
    }

    private fun timerForm(jobId: Long) {
        val tasks=repository.taskChoices(jobId);if(tasks.isEmpty()){toast("Add a task first");return};val body=Ui.column(this,8);val task=spinner(tasks.map{it.label});val note=Ui.field(this,"Timer note")
        listOf(task,note).forEach(body::addView);formDialog("Start timer",body){repository.startTimer(tasks[task.selectedItemPosition].id,note.text.toString());refresh()}
    }

    private fun quotesScreen() = open("Quotes") {
        listPage(repository.quotes()) { quoteScreen(it) }
    }

    private fun quoteScreen(id: Long) = open("Quote") {
        val quote=repository.quote(id);val lines=repository.quoteLines(id)
        Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,quote.number));addView(Ui.label(this@MainActivity,"${quote.customer} • ${quote.job}"));addView(Ui.label(this@MainActivity,quote.state.uppercase(),Ui.GOLD))
            lines.forEach{line->addView(Ui.card(this@MainActivity,line.description,"${MoneyMath.quantityText(line.quantityThousandths)} × ${MoneyMath.format(line.unitCents)}",MoneyMath.format(line.totalCents)))}
            addView(Ui.button(this@MainActivity,"Edit / Copy / Delete quote"){recordActions("quote",id,"quote")})
            addView(Ui.button(this@MainActivity,"+ Add line"){documentLineForm(true,id)})
            addView(Ui.card(this@MainActivity,"Subtotal",trailing=MoneyMath.format(quote.subtotalCents)))
            if(quote.discountCents>0)addView(Ui.card(this@MainActivity,"Discount",trailing="-${MoneyMath.format(quote.discountCents)}"))
            addView(Ui.card(this@MainActivity,"Total",trailing=MoneyMath.format(quote.totalCents)))
            addView(Ui.button(this@MainActivity,"Edit discount, tax and terms"){quoteAdjustments(quote)})
            addView(Ui.button(this@MainActivity,"Change status"){quoteState(id,quote.state)})
            addView(Ui.button(this@MainActivity,"Export/share PDF"){shareQuote(id)})
        })
    }

    private fun quoteAdjustments(q: QuoteSummary){val body=Ui.column(this,8);val discount=Ui.moneyField(this,"Discount",q.discountCents);val tax=Ui.field(this,"Tax percent",(q.taxHundredths/100.0).toString());val terms=Ui.field(this,"Terms",q.terms,true);val valid=Ui.field(this,"Valid until YYYY-MM-DD",q.validUntil.orEmpty());listOf(discount,tax,terms,valid).forEach(body::addView);formDialog("Quote adjustments",body){repository.updateQuoteAdjustments(q.id,MoneyMath.parseCents(discount.text.toString()),((tax.text.toString().toDoubleOrNull()?:0.0)*100).toInt(),terms.text.toString(),valid.text.toString());refresh()}}
    private fun quoteState(id:Long,current:String){val states=arrayOf("reviewing","sent","approved","rejected","withdrawn","invoiced");AlertDialog.Builder(this).setTitle("Quote status").setSingleChoiceItems(states,states.indexOf(current)){d,w->repository.setQuoteState(id,states[w]);d.dismiss();refresh()}.setNegativeButton("Cancel",null).show()}

    private fun invoicesScreen() = open("Invoices & payments") { listPage(repository.invoices()) { invoiceScreen(it) } }

    private fun invoiceScreen(id: Long) = open("Invoice") {
        val invoice=repository.invoice(id);val lines=repository.invoiceLines(id)
        Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,invoice.number));addView(Ui.label(this@MainActivity,"${invoice.customer} • ${invoice.job}"));addView(Ui.label(this@MainActivity,if(invoice.paid)"PAID" else "OPEN • Due ${invoice.dueDate?:"not set"}",Ui.GOLD))
            lines.forEach{line->addView(Ui.card(this@MainActivity,line.description,"${MoneyMath.quantityText(line.quantityThousandths)} × ${MoneyMath.format(line.unitCents)}",MoneyMath.format(line.totalCents)))}
            addView(Ui.button(this@MainActivity,"Edit / Copy / Delete invoice"){recordActions("invoice",id,"invoice")})
            addView(Ui.button(this@MainActivity,"+ Add line"){documentLineForm(false,id)})
            addView(Ui.card(this@MainActivity,"Invoice total",trailing=MoneyMath.format(invoice.totalCents)))
            addView(Ui.card(this@MainActivity,"Paid",trailing=MoneyMath.format(invoice.paidCents)))
            addView(Ui.card(this@MainActivity,"Balance due",trailing=MoneyMath.format(invoice.balanceCents)))
            if(!invoice.paid)addView(Ui.button(this@MainActivity,"Record payment"){paymentForm(id)})
            addView(Ui.button(this@MainActivity,"Export/share PDF"){shareInvoice(id)})
        })
    }

    private fun documentLineForm(quote:Boolean,id:Long){
        selectedMaterialForLine=null
        val body=Ui.column(this,8);val description=Ui.field(this,"Description");val quantity=Ui.field(this,"Quantity","1");val unit=Ui.moneyField(this,"Unit price")
        listOf(description,quantity,unit).forEach(body::addView)
        addMaterialCatalogPicker(body,description,unit,quantity)
        formDialog("Add line",body){
            val cents=MoneyMath.parseCents(unit.text.toString())
            val count=MoneyMath.parseQuantity(quantity.text.toString())
            if(quote) repository.addQuoteLine(id,description.text.toString(),count,cents)
            else {
                val lineId=repository.addInvoiceLine(id,description.text.toString(),count,cents)
                selectedMaterialForLine?.let { material ->
                    material["id"]?.toLongOrNull()?.let { materialId ->
                        val profile = repository.profiles.all().first { it.active }.id.toString()
                        val supplier = SmartToolsStore(this@MainActivity).use { it.preferredSupplierLink(profile, materialId) }
                        repository.saveInvoiceMaterialReference(
                            lineId, materialId, supplier?.get("supplier_id")?.toLongOrNull(),
                            supplier?.get("product_url").orEmpty(), description.text.toString(),
                            material["unit"].orEmpty(), cents
                        )
                    }
                }
            }
            selectedMaterialForLine=null
            refresh()
        }
    }
    private fun paymentForm(id:Long){val body=Ui.column(this,8);val amount=Ui.moneyField(this,"Amount");val method=spinner(listOf("Cash","Card","Bank transfer","Cheque","Other"));val reference=Ui.field(this,"Reference (optional)");listOf(amount,method,reference).forEach(body::addView);formDialog("Record payment",body){repository.recordPayment(id,MoneyMath.parseCents(amount.text.toString()),method.selectedItem.toString(),reference.text.toString());refresh()}}

    private fun todosScreen() = open("Todo") { listPage(repository.todos()) { recordActions("to_do",it,"todo") } .also { it.addView(Ui.button(this,"+ Add todo"){todoForm()},0) } }
    private fun todoForm(){val body=Ui.column(this,8);val title=Ui.field(this,"Title");val note=Ui.field(this,"Notes","",true);val due=Ui.field(this,"Due date YYYY-MM-DD",LocalDate.now().toString());val remind=Ui.field(this,"Optional reminder YYYY-MM-DDTHH:MM");val priority=spinner(listOf("medium","high","low","none"));listOf(title,note,due,remind,priority).forEach(body::addView);formDialog("Add todo",body){val id=repository.saveTodo(null,title.text.toString(),note.text.toString(),due.text.toString(),remind.text.toString(),priority.selectedItem.toString(),"open");if(remind.text.isNotBlank()){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),71);ReminderScheduler.schedule(this,id,title.text.toString(),note.text.toString(),remind.text.toString())};refresh()}}

    private fun scheduleScreen() = open("Schedule") { listPage(repository.schedule()) { recordActions("job_activity",it,"appointment") }.also { it.addView(Ui.button(this,"+ Add appointment"){appointmentForm()},0) } }
    private fun appointmentForm(){val jobs=repository.jobChoices();if(jobs.isEmpty()){toast("Add a job first");return};val body=Ui.column(this,8);val job=spinner(jobs.map{it.label});val start=Ui.field(this,"Start (ISO date/time)","${LocalDate.now()}T09:00:00");val end=Ui.field(this,"End (ISO date/time)","${LocalDate.now()}T10:00:00");val notes=Ui.field(this,"Notes","",true);listOf(job,start,end,notes).forEach(body::addView);formDialog("Add appointment",body){repository.addAppointment(jobs[job.selectedItemPosition].id,start.text.toString(),end.text.toString(),notes.text.toString());refresh()}}

    private fun simpleScreen(title:String,kind:String)=open(title) {
        val rows=repository.simpleRows(kind)
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.button(this@MainActivity,"+ Add ${title.lowercase().removeSuffix("s")}"){simpleForm(kind,title)})
            if(rows.isEmpty())addView(Ui.label(this@MainActivity,"No records for this business profile."))
            rows.forEach { row ->
                addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status) {
                    when(kind) {
                        "receipts" -> receiptActions(row.id)
                        "suppliers","manufacturers" -> directoryActions(if(kind=="suppliers")"supplier" else "manufacturer",row.id,row.title)
                        else -> recordActions(if(kind=="tools")"tool" else "trip_log",row.id,row.title)
                    }
                })
            }
        })
    }
    private fun simpleForm(kind:String,title:String){
        val body=Ui.column(this,8);val name=Ui.field(this,if(kind=="trips")"Purpose" else "Name");val detail=Ui.field(this,if(kind=="trips")"From address / notes" else "Description or service","",true);val amount=Ui.moneyField(this,if(kind=="trips")if(repository.preferredMetric())"Distance in kilometres" else "Distance in miles" else "Amount / cost")
        body.addView(name);body.addView(detail);body.addView(amount)
        val suppliers=if(kind=="receipts")repository.supplierChoices() else emptyList();val supplier=if(suppliers.isNotEmpty())spinner(suppliers.map{it.label}) else null
        if(kind=="receipts"){body.addView(Ui.label(this,"Supplier"));if(supplier!=null)body.addView(supplier) else body.addView(Ui.label(this,"Add a supplier before adding a receipt",Ui.ERROR))}
        formDialog("Add ${title.lowercase().removeSuffix("s")}",body){if(kind=="receipts")require(supplier!=null){"Add a supplier first"};repository.addSimple(kind,name.text.toString(),detail.text.toString(),if(kind=="trips")BusinessRecordRules.distanceToMetres(amount.text.toString(),repository.preferredMetric()) else MoneyMath.parseCents(amount.text.toString()),supplier?.let{suppliers[it.selectedItemPosition].id});refresh()}
    }

    private fun directoryActions(kind:String,id:Long,label:String) {
        val actions=arrayOf("Open website","Edit website URL","Edit record","Delete record")
        AlertDialog.Builder(this).setTitle(label).setItems(actions){_,choice->when(choice){
            0->runCatching {openExternalUrl(repository.directoryUrl(kind,id))}.onFailure{toast(it.message?:"Invalid URL")}
            1->{val url=Ui.field(this,"Website URL",repository.directoryUrl(kind,id));formDialog("Website",Ui.column(this).apply{addView(url)}){repository.setDirectoryUrl(kind,id,url.text.toString());refresh()}}
            2->recordEditor(kind,id,false)
            3->confirm("Delete this $kind?"){repository.deleteRecord(kind,id);refresh()}
        }}.setNegativeButton("Cancel",null).show()
    }
    private fun openExternalUrl(raw:String) {
        val url=raw.trim();val parsed=Uri.parse(url)
        require(BusinessRecordRules.isHttpUrl(url)) {"No valid website URL saved"}
        startActivity(Intent(Intent.ACTION_VIEW,parsed).addCategory(Intent.CATEGORY_BROWSABLE))
    }
    private fun receiptActions(id:Long) {
        AlertDialog.Builder(this).setTitle("Receipt").setItems(arrayOf("View photos","Add receipt photo","Edit receipt","Delete receipt")){_,choice->when(choice){
            0->receiptPhotoGallery(id)
            1->{pendingReceiptPhotoId=id;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6214)}
            2->receiptEditor(id)
            3->confirm("Permanently delete this receipt and its photos?"){repository.deleteReceipt(id);refresh()}
        }}.setNegativeButton("Cancel",null).show()
    }
    private fun receiptEditor(id:Long) {
        val record=repository.recordValues("receipt",id);val choices=repository.supplierChoices()
        if(choices.isEmpty()){toast("Add a supplier first");return}
        val date=Ui.field(this,"Receipt date YYYY-MM-DD",record["receipt_date"].orEmpty())
        val amount=Ui.moneyField(this,"Total including tax ($)",record["total_including_tax"]?.toLongOrNull()?:0L)
        val tax=Ui.moneyField(this,"Tax included ($)",record["tax"]?.toLongOrNull()?:0L)
        val supplier=spinner(choices.map{it.label},choices.indexOfFirst{it.id.toString()==record["supplier_id"]}.coerceAtLeast(0))
        val body=Ui.column(this).apply{addView(Ui.label(this@MainActivity,"Supplier"));addView(supplier);addView(date);addView(amount);addView(tax)}
        formDialog("Edit receipt",body){repository.updateReceipt(id,choices[supplier.selectedItemPosition].id,MoneyMath.parseCents(amount.text.toString()),date.text.toString(),MoneyMath.parseCents(tax.text.toString()));refresh()}
    }
    private fun receiptPhotoGallery(id:Long) {
        open("Receipt photos") { Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.button(this@MainActivity,"+ Add photo"){pendingReceiptPhotoId=id;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6214)})
            val photos=repository.receiptPhotos(id)
            if(photos.isEmpty())addView(Ui.label(this@MainActivity,"No receipt photos"))
            photos.forEach { (photoId,bytes) ->
                val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                if(bitmap!=null)addView(ImageView(this@MainActivity).apply{setImageBitmap(bitmap);adjustViewBounds=true;maxHeight=700})
                addView(Ui.button(this@MainActivity,"Delete photo"){confirm("Delete this receipt photo?"){repository.deleteReceiptPhoto(id,photoId);receiptPhotoGallery(id)}})
            }
        }) }
    }

    private fun reportsScreen()=open("Reports") { Ui.scroll(this,Ui.column(this).apply {
        addView(Ui.title(this@MainActivity,"Financial reports"))
        addView(Ui.button(this@MainActivity,"Revenue by month"){reportScreen("Revenue","revenue")})
        addView(Ui.button(this@MainActivity,"Aged/open receivables"){reportScreen("Receivables","receivables")})
        addView(Ui.button(this@MainActivity,"Expenses by month"){reportScreen("Expenses","expenses")})
    }) }
    private fun reportScreen(title:String,type:String)=open(title){
        val rows = repository.reportRows(type)
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,title))
            addView(Ui.button(this@MainActivity,"Export branded PDF") {
                try {
                    val businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() }
                    val business=businessDetails["business_name"].orEmpty().ifBlank { "MODE Handyman" }
                    val file=PdfGenerator.createReport(this@MainActivity,title,business,
                        "Generated ${LocalDate.now()}",rows,businessDetails,activeLogoFile().takeIf(File::isFile))
                    shareFile(file,"application/pdf")
                } catch(error:Exception) { toast("Report export failed: ${error.message ?: "Unknown error"}") }
            })
            if(rows.isEmpty()) addView(Ui.label(this@MainActivity,"No records for this business profile."))
            rows.forEach { row -> addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status) {}) }
        })
    }

    private fun settingsScreen()=open("Settings") { val metric=repository.preferredMetric();Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Business & privacy"))
        addView(Ui.button(this@MainActivity,"Business setup"){businessSetup()})
        addView(Ui.button(this@MainActivity,"Business profiles (up to 5)"){profilesScreen()})
        val toggle=CheckBox(this@MainActivity).apply{setText(R.string.metric_measurements);isChecked=metric;setTextColor(Ui.TEXT);setOnCheckedChangeListener{_,checked->repository.setPreferredMetric(checked);toast(if(checked)"Metric units enabled" else "US customary units enabled")}}
        addView(toggle)
        addView(CheckBox(this@MainActivity).apply {
            setText(R.string.calculator_enabled_all_pages)
            setTextColor(Ui.TEXT)
            isChecked = FloatingCalculator.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                FloatingCalculator.setEnabled(this@MainActivity, checked)
                calculatorButton.visibility = if (checked) View.VISIBLE else View.GONE
            }
        })
        addView(Ui.button(this@MainActivity,"Open calculator") { FloatingCalculator.show(this@MainActivity) })
        addView(Ui.button(this@MainActivity,"Create local backup"){createBackup()})
        addView(Ui.button(this@MainActivity,"Restore local backup"){confirm("Restore replaces the active local database after creating a recovery copy. Continue?"){restoreBackup()}})
        addView(Ui.button(this@MainActivity,"Crash diagnostics"){crashesScreen()})
        addView(Ui.button(this@MainActivity,"Privacy & about"){aboutScreen()})
    }) }

    private fun activeLogoFile(): File {
        val profile = repository.profiles.all().first { it.active }.id
        return File(filesDir, "business-logos/profile-$profile.png")
    }

    private fun chooseCustomerExport(ids: List<Long>) {
        if (ids.isEmpty()) { toast("No customers to export"); return }
        AlertDialog.Builder(this).setTitle("Export ${ids.size} customer(s)").setItems(arrayOf("JSON", "CSV")) { _, which ->
            customerExportIds = ids; customerExportCsv = which == 1
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = if (customerExportCsv) "text/csv" else "application/json"
                putExtra(Intent.EXTRA_TITLE, "MODE-customers.${if(customerExportCsv) "csv" else "json"}")
            }, 6210)
        }.show()
    }

    private fun pickCustomerImport() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/csv", "text/plain", "application/octet-stream"))
    }, 6211)

    private fun previewCustomerImport(payload: org.json.JSONObject) {
        runCatching {
            require(payload.optString("format") == "mode-customer-contacts" && payload.optInt("version") == 1)
            val profiles = repository.profiles.all()
            AlertDialog.Builder(this).setTitle("Import into business profile").setItems(profiles.map { it.name }.toTypedArray()) { _, index ->
                val target = profiles[index]
                runCatching {
                    val total = payload.getJSONArray("customers").length()
                    val duplicates = repository.customerDuplicateCount(payload, target.id)
                    AlertDialog.Builder(this).setTitle("Review customer import")
                        .setMessage("$total customers; $duplicates potential name duplicates. Destination: ${target.name}. Only contact data will be transferred; jobs and finances are excluded.")
                        .setItems(arrayOf("Skip duplicates", "Update existing contacts", "Create separate customers")) { _, policyIndex ->
                            val policy = listOf("skip", "update", "separate")[policyIndex]
                            AlertDialog.Builder(this).setTitle("Confirm import").setMessage("Import contact information into ${target.name} using '$policy' duplicate handling?")
                                .setNegativeButton("Cancel",null).setPositiveButton("Import") { _, _ ->
                                    runCatching { repository.importCustomerContacts(payload,target.id,policy) }
                                        .onSuccess { toast("Imported ${it.first}; skipped ${it.second}"); refresh() }
                                        .onFailure { toast(it.message ?: "Import failed") }
                                }.show()
                        }.show()
                }.onFailure { toast(it.message ?: "Invalid import") }
            }.show()
        }.onFailure { toast(it.message ?: "Invalid customer file") }
    }

    private fun pickBusinessLogo() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, logoRequestCode)
    }

    @Deprecated("Uses Android document picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            6214 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val receiptId=pendingReceiptPhotoId;pendingReceiptPhotoId=null
                if(receiptId!=null)runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: error("Cannot read photo")
                    require(bytes.size<=8_000_000){"Image is too large"}
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)?:error("Invalid image")
                    val scale=minOf(1f,1400f/maxOf(bitmap.width,bitmap.height))
                    val reduced=if(scale<1f)Bitmap.createScaledBitmap(bitmap,(bitmap.width*scale).toInt().coerceAtLeast(1),(bitmap.height*scale).toInt().coerceAtLeast(1),true) else bitmap
                    val output=ByteArrayOutputStream();require(reduced.compress(Bitmap.CompressFormat.JPEG,80,output))
                    repository.addReceiptPhoto(receiptId,output.toByteArray())
                }.onSuccess{toast("Receipt photo saved");receiptPhotoGallery(receiptId)}.onFailure{toast(it.message?:"Photo failed")}
            }

            6210 -> if (resultCode == Activity.RESULT_OK) data?.data?.let { uri ->
                runCatching {
                    val json = repository.exportCustomerContacts(customerExportIds)
                    val output = if (customerExportCsv) CustomerTransfer.toCsv(json) else json.toString(2)
                    contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(output) } ?: error("Unable to write export")
                }.onSuccess { toast("Customer contacts exported") }.onFailure { toast(it.message ?: "Export failed") }
            }
            6211 -> if (resultCode == Activity.RESULT_OK) data?.data?.let { uri ->
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Unable to read file")
                    require(text.length <= 8_000_000) { "Import file too large" }
                    if (text.trimStart().startsWith("{")) org.json.JSONObject(text) else CustomerTransfer.fromCsv(text)
                }.onSuccess { previewCustomerImport(it) }.onFailure { toast(it.message ?: "Import failed") }
            }
            6213 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val noteId=pendingNotePhotoId;pendingNotePhotoId=null
                if(noteId!=null) runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read image")
                    require(bytes.size<=8_000_000) { "Image exceeds 8 MB" }
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: error("Invalid image")
                    val scaled=if(bitmap.width>1600||bitmap.height>1600){val factor=minOf(1600f/bitmap.width,1600f/bitmap.height);Bitmap.createScaledBitmap(bitmap,(bitmap.width*factor).toInt().coerceAtLeast(1),(bitmap.height*factor).toInt().coerceAtLeast(1),true)} else bitmap
                    val name="note-${noteId}-${java.util.UUID.randomUUID()}.jpg"
                    val dir=File(filesDir,"work-note-photos").apply{mkdirs()}
                    val target=File(dir,name)
                    try {
                        target.outputStream().use { require(scaled.compress(Bitmap.CompressFormat.JPEG,85,it)) { "Unable to save photo" } }
                        val photoId=repository.addNotePhoto(noteId,name)
                        val note=repository.workNote(noteId)
                        val offset=pendingNotePhotoOffset.coerceIn(0,note.body.length)
                        repository.saveWorkNote(noteId,note.customerId,note.title,NotePhotoMarkers.insert(note.body,offset,photoId))
                    } catch(e:Exception) { target.delete();throw e }
                }.onSuccess { pendingNotePhotoOffset=-1;toast("Photo inserted");noteForm(noteId) }.onFailure { toast(it.message?:"Photo import failed") }
            }
            6212 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val customerId=pendingCustomerPhotoId
                pendingCustomerPhotoId=null
                if(customerId!=null) runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use { input -> input.readBytes() } ?: error("Unable to read photo")
                    require(bytes.size<=2_000_000) { "Select an image smaller than 2 MB" }
                    require(BitmapFactory.decodeByteArray(bytes,0,bytes.size)!=null) { "Invalid image" }
                    repository.saveCustomerPhoto(customerId,android.util.Base64.encodeToString(bytes,android.util.Base64.NO_WRAP))
                }.onSuccess { toast("Customer photo saved") }.onFailure { toast(it.message?:"Photo import failed") }
            }
            logoRequestCode -> {
                if (resultCode == Activity.RESULT_OK) importBusinessLogo(data)
            }
            90 -> {
                val pending = backupExportPending
                backupExportPending = false
                if (resultCode == Activity.RESULT_OK && pending) {
                    val uri = data?.data ?: return
                    runCatching {
                        contentResolver.openOutputStream(uri, "w")?.use { BackupManager.export(this, it) }
                            ?: error("Unable to open the selected backup destination")
                    }.onSuccess { toast("Local backup exported") }
                        .onFailure { toast(it.message ?: "Backup failed") }
                }
            }
            91 -> {
                val pending = backupRestorePending
                backupRestorePending = false
                if (resultCode == Activity.RESULT_OK && pending) {
                    val uri = data?.data ?: return
                    runCatching {
                        contentResolver.openInputStream(uri)?.use {
                            BackupManager.restore(this, it, (application as ModeApplication).databaseManager)
                        } ?: error("Unable to open the selected backup")
                    }.onSuccess { toast("Backup restored"); recreate() }
                        .onFailure { toast(it.message ?: "Restore failed") }
                }
            }
        }
    }

    private fun importBusinessLogo(data: Intent?) {
        val uri = data?.data ?: return
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            require(bounds.outWidth in 1..12000 && bounds.outHeight in 1..12000) { "Invalid image dimensions" }
            var sample = 1
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 1400) sample *= 2
            val bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: error("Unable to read image")
            try {
                val target = activeLogoFile()
                target.parentFile?.mkdirs()
                val temporary = File(target.parentFile, target.name + ".tmp")
                temporary.outputStream().use { require(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
                require(temporary.length() in 1..8_000_000) { "Logo file is too large" }
                if (!temporary.renameTo(target)) { temporary.copyTo(target, overwrite = true); temporary.delete() }
            } finally { bitmap.recycle() }
        }.onSuccess { toast("Business logo saved"); businessSetup() }
            .onFailure { toast("Could not import logo: ${it.message}") }
    }

    private fun businessSetup(): Unit = open("Business setup") {
        val s=repository.system();Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,"Business details"))
            val logo = activeLogoFile()
            if (logo.isFile) {
                val preview = ImageView(this@MainActivity).apply {
                    setImageURI(Uri.fromFile(logo))
                    adjustViewBounds = true
                    maxHeight = 180
                }
                addView(preview)
            }
            addView(Ui.button(this@MainActivity,"Upload / change business logo") { pickBusinessLogo() })
            if (logo.isFile) addView(Ui.button(this@MainActivity,"Remove business logo") {
                confirm("Remove the logo for this business profile?") { logo.delete(); businessSetup() }
            })
            addView(Ui.label(this@MainActivity,"These details stay on this device and are stored independently for the active profile."))
            val fields=linkedMapOf<String,EditText>()
            listOf("business_name" to "Business name","business_number" to "Business number","firstname" to "First name","surname" to "Surname","address_line_1" to "Address line 1","address_line_2" to "Address line 2","suburb" to "City / suburb","state" to "State / province","postcode" to "Postal code","country_code" to "Country code","email_address" to "Email (optional)","mobile_number" to "Phone (optional)","web_url" to "Website (optional)","payment_options" to "Payment instructions","operating_hours" to "Operating hours").forEach{(key,label)->Ui.field(this@MainActivity,label,s[key]?.toString().orEmpty(),key in setOf("payment_options","operating_hours")).also{fields[key]=it;addView(it)}}
            addView(Ui.button(this@MainActivity,"Save business profile"){repository.updateSystem(fields.mapValues{it.value.text.toString()});toast("Saved locally")})
        })
    }

    private fun profilesScreen()=open("Business profiles") { Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Independent profiles"));addView(Ui.label(this@MainActivity,"Customers, jobs, quotes, invoices, inventory, and financial records are isolated by profile."))
        repository.profiles.all().forEach{p->addView(Ui.card(this@MainActivity,p.name,if(p.active)"Currently active" else "Tap to switch",if(p.active)"✓" else "›",onClick=if(p.active)null else {{repository.profiles.activate(p.id);dashboard(true)}}))}
        if(repository.profiles.all().size<5)addView(Ui.button(this@MainActivity,"+ Add business profile"){profileCreate()})
    }) }
    private fun profileCreate(){val name=Ui.field(this,"Profile name");formDialog("New business profile",name){repository.profiles.create(name.text.toString());dashboard(true)}}

    private fun crashesScreen()=open("Crash diagnostics") { val files=LocalCrashReporter.reports(this);Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Local crash reports"));addView(Ui.label(this@MainActivity,"Reports never upload automatically. Sensitive patterns are redacted."))
        if(files.isEmpty()) addView(Ui.label(this@MainActivity,"No crash reports stored."))
        files.forEach { file -> addView(Ui.card(this@MainActivity,file.name,"${file.length()} bytes","›") { crashDetail(file) }) }
        if(files.isNotEmpty())addView(Ui.button(this@MainActivity,"Delete all reports"){confirm("Permanently delete all local crash reports?"){files.forEach { LocalCrashReporter.delete(this@MainActivity, it) };refresh()}})
    }) }
    private fun crashDetail(file:File)=open(file.name){Ui.scroll(this,Ui.column(this).apply{addView(Ui.label(this@MainActivity,file.readText().take(30000),Ui.TEXT,12f));addView(Ui.button(this@MainActivity,"Share report manually"){shareFile(file,"application/json")})})}

    private fun aboutScreen()=open("Privacy & about") { Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"MODE Handyman"));addView(Ui.label(this@MainActivity,"Native Kotlin edition 2.0.3" ,Ui.GOLD));addView(Ui.label(this@MainActivity,"Maclean Of Duart Enterprises Corp — MODE Handyman"));addView(Ui.section(this@MainActivity,"Privacy"));addView(Ui.label(this@MainActivity,"No analytics, advertisements, tracking SDKs, remote synchronization, SMTP, or automatic crash uploads. Normal operation has no Internet permission. Email and phone fields are optional; PDF generation, backups, and Android share actions do not require them."));addView(Ui.section(this@MainActivity,"Storage"));addView(Ui.label(this@MainActivity,"Business data is stored in the private local SQLite database. Files leave the app only after you choose an Android destination or share target."))
    }) }

    private fun recordActions(table:String,id:Long,label:String) {
        val actions=arrayOf("Edit", "Rename", "Copy", "Delete")
        AlertDialog.Builder(this).setTitle(label).setItems(actions){_,which ->
            when(which){
                0 -> recordEditor(table,id,false)
                1 -> recordEditor(table,id,true)
                2 -> confirm("Copy this $label?"){runCatching { repository.copyRecord(table,id) }.onSuccess { dashboard(true) }.onFailure { toast(it.message ?: "Copy failed") }}
                3 -> confirm("Permanently delete this $label? This cannot be undone."){runCatching { repository.deleteRecord(table,id) }.onSuccess { dashboard(true) }.onFailure { toast(it.message ?: "Delete failed") }}
            }
        }.setNegativeButton("Cancel",null).show()
    }

    private fun recordEditor(table:String,id:Long,renameOnly:Boolean) {
        val data=repository.editableFields(table,id)
        val excluded=emptySet<String>()
        val primary=listOf("name","title","summary","number","purpose","notes","description").firstOrNull{it in data}
        val fields=data.keys.filter{it !in excluded && (!renameOnly || it==primary)}
        if(fields.isEmpty()){toast("No editable fields");return}
        val body=Ui.column(this,8)
        val inputs=fields.map { key -> key to Ui.field(this,key.replace('_',' ').replaceFirstChar{it.uppercase()},data[key].orEmpty(),key in setOf("notes","description","terms")) .also(body::addView) }
        formDialog(if(renameOnly)"Rename record" else "Edit record",body){
            repository.updateRecord(table,id,inputs.associate{it.first to it.second.text.toString()});dashboard(true)
        }
    }

    private fun searchableList(hint:String,loader:(String)->List<ListRow>,onOpen:(Long)->Unit):LinearLayout{
        val root=Ui.column(this);val search=Ui.field(this,hint);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};fun load(){list.removeAllViews();val rows=loader(search.text.toString());if(rows.isEmpty())list.addView(Ui.label(this,"No matching records."));rows.forEach{row->list.addView(Ui.card(this,row.title,row.subtitle,row.trailing,row.status){onOpen(row.id)})}};search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int)=load();override fun afterTextChanged(s:Editable?) {}});root.addView(search);root.addView(list);load();return root
    }

    private fun listPage(rows:List<ListRow>,onOpen:(Long)->Unit):LinearLayout=Ui.column(this).apply{if(rows.isEmpty())addView(Ui.label(this@MainActivity,"No records for this business profile."));rows.forEach{row->addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status,if(row.id>0){{onOpen(row.id)}}else null))}}
    private fun spinner(items:List<String>,selection:Int=0)=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);if(items.isNotEmpty())setSelection(selection.coerceIn(0,items.lastIndex));layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)}

    @Suppress("DEPRECATION")
    private fun formDialog(title:String,view:View,onSave:()->Unit){val dialog=AlertDialog.Builder(this).setTitle(title).setView(Ui.scroll(this,view)).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener{dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching(onSave).onSuccess{dialog.dismiss()}.onFailure{toast(it.message?:"Could not save")}}};dialog.show()}
    private fun confirm(message:String,action:()->Unit){AlertDialog.Builder(this).setMessage(message).setNegativeButton("Cancel",null).setPositiveButton("OK"){_,_->runCatching(action).onFailure{toast(it.message?:"Action failed")}}.show()}
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_LONG).show()

    private fun shareQuote(id:Long){val q=repository.quote(id);val lines=repository.quoteLines(id);val tax=(q.totalCents-(q.subtotalCents-q.discountCents).coerceAtLeast(0)).coerceAtLeast(0);val business=repository.system()["business_name"]?.toString().orEmpty().ifBlank{"MODE Handyman"};val profile=repository.profiles.all().first{it.active}.id.toString();val attachments=SmartToolsStore(this).use{it.attachmentsForJobId(profile,repository.jobIdForQuote(id))};shareFile(PdfGenerator.create(this,PdfGenerator.Document(kind="Quote",number=q.number,business=business,customer=q.customer,job=q.job,dateLabel="Status: ${q.state}",lines=lines,subtotal=q.subtotalCents,discount=q.discountCents,tax=tax,total=q.totalCents,terms=q.terms,businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() },attachments=attachments,logo=activeLogoFile().takeIf(File::isFile))),"application/pdf")}
    private fun shareInvoice(id:Long){val i=repository.invoice(id);val lines=repository.invoiceLines(id);val business=repository.system()["business_name"]?.toString().orEmpty().ifBlank{"MODE Handyman"};val profile=repository.profiles.all().first{it.active}.id.toString();val attachments=SmartToolsStore(this).use{it.attachmentsForJobId(profile,repository.jobIdForInvoice(id))};shareFile(PdfGenerator.create(this,PdfGenerator.Document(kind="Invoice",number=i.number,business=business,customer=i.customer,job=i.job,dateLabel=if(i.paid) "PAID" else "Due: ${i.dueDate?:"not set"}",lines=lines,subtotal=i.totalCents,total=i.totalCents,paidAmount=i.paidCents,balanceDue=i.balanceCents,businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() },attachments=attachments,logo=activeLogoFile().takeIf(File::isFile))),"application/pdf")}
    private fun shareFile(file:File,mime:String){val uri=Uri.parse("content://${packageName}.provider/${if(file.parentFile?.name=="crash-reports")"crash" else "exports"}/${Uri.encode(file.name)}");startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri(file.name,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share using"))}

    private fun createBackup(){backupExportPending=true;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,"MODE-Handyman-backup-${LocalDate.now()}.zip")},90)}
    private fun restoreBackup(){backupRestorePending=true;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip"},91)}
}
