package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode
import java.net.URI
import java.util.Locale

/** Deterministic, platform-independent validation and conversion rules for 2.0.6 records. */
object BusinessRecordRules {
    private val explicitUrl = Regex("https?://[^\\s<>\\\"']+", RegexOption.IGNORE_CASE)

    fun isHttpUrl(raw: String): Boolean = runCatching {
        val parsed = URI(raw.trim())
        parsed.scheme?.lowercase(Locale.US) in setOf("http", "https") && !parsed.host.isNullOrBlank()
    }.getOrDefault(false)

    fun firstHttpUrl(text: String): String? = explicitUrl.findAll(text)
        .map { it.value.trimEnd('.', ',', ')', ';', ']') }
        .firstOrNull(::isHttpUrl)

    fun distanceToMetres(text: String, metric: Boolean): Long {
        val value = text.trim().takeIf(String::isNotEmpty)?.let(::BigDecimal) ?: BigDecimal.ZERO
        require(value.signum() >= 0) { "Distance cannot be negative" }
        val multiplier = if (metric) BigDecimal("1000") else BigDecimal("1609.344")
        return value.multiply(multiplier).setScale(0, RoundingMode.HALF_UP).longValueExact()
    }

    fun distanceLabel(metres: Long, metric: Boolean): String {
        require(metres >= 0) { "Distance cannot be negative" }
        val divisor = if (metric) BigDecimal("1000") else BigDecimal("1609.344")
        val unit = if (metric) "km" else "mi"
        return "${BigDecimal.valueOf(metres).divide(divisor, 2, RoundingMode.HALF_UP).toPlainString()} $unit"
    }

    fun receiptAmounts(totalIncludingTax: Long, tax: Long): Pair<Long, Long> {
        require(totalIncludingTax >= 0) { "Receipt total cannot be negative" }
        require(tax in 0..totalIncludingTax) { "Tax must be between zero and the receipt total" }
        return (totalIncludingTax - tax) to tax
    }
}
