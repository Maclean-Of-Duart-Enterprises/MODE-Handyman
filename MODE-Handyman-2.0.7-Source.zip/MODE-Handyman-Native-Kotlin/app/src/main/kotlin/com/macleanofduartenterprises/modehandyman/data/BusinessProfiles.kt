package com.macleanofduartenterprises.modehandyman.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONObject
import java.time.Instant

data class BusinessProfile(val id: Long, val name: String, val active: Boolean)

class BusinessProfiles(private val context: Context, private val db: SQLiteDatabase) {
    companion object { const val MAX_PROFILES = 5 }

    fun ensureInitialized() {
        if (!tableExists("business_profile")) return
        val count = db.rawQuery("SELECT COUNT(*) FROM business_profile", null).use { it.moveToFirst(); it.getInt(0) }
        if (count > 0) return
        val system = db.rawQuery("SELECT * FROM system LIMIT 1", null).use { cursor ->
            check(cursor.moveToFirst()) { "Missing system configuration" }
            cursor.toJson(exclude = setOf("id"))
        }
        val now = Instant.now().toString()
        val values = ContentValues().apply {
            put("display_name", system.optString("business_name").ifBlank { "MODE Handyman" })
            put("configuration_json", system.toString())
            put("preferences_json", capturePreferences().toString())
            put("trip_settings_json", captureTripSettings().toString())
            put("active", 1)
            put("created_date", now)
            put("modified_date", now)
        }
        check(db.insertOrThrow("business_profile", null, values) > 0)
    }

    fun all(): List<BusinessProfile> {
        ensureInitialized()
        return db.rawQuery(
            "SELECT id,display_name,active FROM business_profile ORDER BY active DESC,display_name COLLATE NOCASE",
            null
        ).use { c -> buildList { while (c.moveToNext()) add(BusinessProfile(c.getLong(0), c.getString(1), c.getInt(2) == 1)) } }
    }

    fun activeId(): Long {
        ensureInitialized()
        return db.rawQuery("SELECT id FROM business_profile WHERE active=1 LIMIT 1", null).use {
            check(it.moveToFirst()) { "No active business profile" }
            it.getLong(0)
        }
    }

    fun create(name: String): Long {
        val clean = name.trim()
        require(clean.isNotEmpty()) { "Profile name is required" }
        require(all().size < MAX_PROFILES) { "A maximum of five business profiles is allowed" }
        saveActive()
        val systemJson = db.rawQuery("SELECT * FROM system LIMIT 1", null).use { c -> c.moveToFirst(); c.toJson(setOf("id")) }
        val now = Instant.now().toString()
        val values = ContentValues().apply {
            put("display_name", clean)
            put("configuration_json", systemJson.toString())
            put("preferences_json", capturePreferences().toString())
            put("trip_settings_json", captureTripSettings().toString())
            put("active", 0)
            put("created_date", now)
            put("modified_date", now)
        }
        val id = db.insertOrThrow("business_profile", null, values)
        activate(id)
        return id
    }

    fun rename(id: Long, name: String) {
        val clean = name.trim()
        require(clean.isNotEmpty()) { "Profile name is required" }
        val values = ContentValues().apply { put("display_name", clean); put("modified_date", Instant.now().toString()) }
        check(db.update("business_profile", values, "id=?", arrayOf(id.toString())) == 1)
    }

    fun activate(id: Long) {
        if (id == activeId()) return
        saveActive()
        val row = db.rawQuery(
            "SELECT configuration_json,preferences_json,trip_settings_json FROM business_profile WHERE id=?",
            arrayOf(id.toString())
        ).use { c -> check(c.moveToFirst()) { "Business profile not found" }; Triple(c.getString(0), c.getString(1), c.getString(2)) }
        db.beginTransaction()
        try {
            db.execSQL("UPDATE business_profile SET active=0")
            db.execSQL("UPDATE business_profile SET active=1,modified_date=? WHERE id=?", arrayOf<Any>(Instant.now().toString(), id))
            restoreSystem(JSONObject(row.first))
            restoreTrip(JSONObject(row.third))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        restorePreferences(JSONObject(row.second))
    }

    fun delete(id: Long) {
        val items = all()
        require(items.size > 1) { "At least one business profile must remain" }
        require(items.none { it.id == id && it.active }) { "Switch profiles before deleting the active profile" }
        check(db.delete("business_profile", "id=?", arrayOf(id.toString())) == 1)
    }

    fun saveActive() {
        val configuration = db.rawQuery("SELECT * FROM system LIMIT 1", null).use { c -> c.moveToFirst(); c.toJson(setOf("id")) }
        val values = ContentValues().apply {
            put("configuration_json", configuration.toString())
            put("preferences_json", capturePreferences().toString())
            put("trip_settings_json", captureTripSettings().toString())
            put("modified_date", Instant.now().toString())
        }
        db.update("business_profile", values, "active=1", null)
    }

    private fun restoreSystem(json: JSONObject) {
        val allowed = db.rawQuery("PRAGMA table_info(system)", null).use { c -> buildSet { while (c.moveToNext()) add(c.getString(1)) } }
        val values = ContentValues()
        json.keys().forEach { key ->
            if (key !in allowed || key == "id" || key == "created_date") return@forEach
            val value = json.opt(key)
            when (value) {
                null, JSONObject.NULL -> values.putNull(key)
                is Int -> values.put(key, value)
                is Long -> values.put(key, value)
                is Double -> values.put(key, value)
                is Boolean -> values.put(key, if (value) 1 else 0)
                else -> values.put(key, value.toString())
            }
        }
        values.put("modified_date", Instant.now().toString())
        db.update("system", values, null, null)
    }

    private fun capturePreferences(): JSONObject {
        val prefs = context.getSharedPreferences("mode_native_preferences", Context.MODE_PRIVATE)
        return JSONObject().apply { prefs.all.forEach { (k, v) -> put(k, v) } }
    }

    private fun restorePreferences(json: JSONObject) {
        val editor = context.getSharedPreferences("mode_native_preferences", Context.MODE_PRIVATE).edit().clear()
        json.keys().forEach { key ->
            when (val value = json.opt(key)) {
                is Boolean -> editor.putBoolean(key, value)
                is Int -> editor.putInt(key, value)
                is Long -> editor.putLong(key, value)
                is Float -> editor.putFloat(key, value)
                is Double -> editor.putFloat(key, value.toFloat())
                is String -> editor.putString(key, value)
            }
        }
        editor.apply()
    }

    private fun captureTripSettings(): JSONObject = if (!tableExists("trip_settings")) JSONObject() else
        db.rawQuery("SELECT * FROM trip_settings WHERE id=1", null).use { c -> if (c.moveToFirst()) c.toJson() else JSONObject() }

    private fun restoreTrip(json: JSONObject) {
        if (json.length() == 0 || !tableExists("trip_settings")) return
        val values = ContentValues()
        json.keys().forEach { key ->
            if (key == "id" || key == "active_gps_trip_id") return@forEach
            when (val value = json.opt(key)) {
                null, JSONObject.NULL -> values.putNull(key)
                is Int -> values.put(key, value)
                is Long -> values.put(key, value)
                is Double -> values.put(key, value)
                else -> values.put(key, value.toString())
            }
        }
        values.putNull("active_gps_trip_id")
        db.update("trip_settings", values, "id=1", null)
    }

    private fun tableExists(name: String): Boolean = db.rawQuery(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name)
    ).use { it.moveToFirst() }

    private fun Cursor.toJson(exclude: Set<String> = emptySet()): JSONObject = JSONObject().also { json ->
        for (index in 0 until columnCount) {
            val name = getColumnName(index)
            if (name in exclude) continue
            when (getType(index)) {
                Cursor.FIELD_TYPE_NULL -> json.put(name, JSONObject.NULL)
                Cursor.FIELD_TYPE_INTEGER -> json.put(name, getLong(index))
                Cursor.FIELD_TYPE_FLOAT -> json.put(name, getDouble(index))
                Cursor.FIELD_TYPE_BLOB -> json.put(name, android.util.Base64.encodeToString(getBlob(index), android.util.Base64.NO_WRAP))
                else -> json.put(name, getString(index))
            }
        }
    }
}
