package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

object MoneyMath {
    fun lineTotal(quantityThousandths: Long, unitCents: Long): Long =
        BigDecimal.valueOf(quantityThousandths)
            .multiply(BigDecimal.valueOf(unitCents))
            .divide(BigDecimal.valueOf(1000), 0, RoundingMode.HALF_UP)
            .longValueExact()

    fun percentage(amountCents: Long, hundredthsPercent: Int): Long =
        BigDecimal.valueOf(amountCents)
            .multiply(BigDecimal.valueOf(hundredthsPercent.toLong()))
            .divide(BigDecimal.valueOf(10_000), 0, RoundingMode.HALF_UP)
            .longValueExact()

    fun quoteTotal(subtotalCents: Long, discountCents: Long, taxHundredths: Int): Long {
        val discounted = (subtotalCents - discountCents).coerceAtLeast(0)
        return discounted + percentage(discounted, taxHundredths)
    }

    fun invoiceBalance(totalCents: Long, paidCents: Long): Long =
        (totalCents.coerceAtLeast(0) - paidCents.coerceAtLeast(0)).coerceAtLeast(0)

    fun invoicePaid(totalCents: Long, paidCents: Long): Boolean =
        totalCents > 0 && invoiceBalance(totalCents, paidCents) == 0L

    fun format(cents: Long): String = NumberFormat.getCurrencyInstance(Locale.US)
        .format(BigDecimal.valueOf(cents, 2))

    fun parseCents(text: String): Long = text.trim()
        .removePrefix("$")
        .replace(",", "")
        .takeIf { it.isNotEmpty() }
        ?.let { BigDecimal(it).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact() }
        ?: 0L

    fun parseQuantity(text: String): Long = text.trim()
        .takeIf { it.isNotEmpty() }
        ?.let { BigDecimal(it).movePointRight(3).setScale(0, RoundingMode.HALF_UP).longValueExact() }
        ?: 1000L

    fun quantityText(thousandths: Long): String = BigDecimal.valueOf(thousandths, 3)
        .stripTrailingZeros().toPlainString()
}
