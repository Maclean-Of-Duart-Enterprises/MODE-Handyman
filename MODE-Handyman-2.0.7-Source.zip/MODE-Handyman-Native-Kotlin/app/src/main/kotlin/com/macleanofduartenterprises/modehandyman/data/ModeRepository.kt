package com.macleanofduartenterprises.modehandyman.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.macleanofduartenterprises.modehandyman.core.*
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class ModeRepository(private val context: Context, val db: SQLiteDatabase) {
    init {
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_customer_contact_extra(customer_id INTEGER PRIMARY KEY, business_name TEXT NOT NULL DEFAULT '', billing_address TEXT NOT NULL DEFAULT '', service_address TEXT NOT NULL DEFAULT '', photo_base64 TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_work_notes(id INTEGER PRIMARY KEY AUTOINCREMENT, profile_id INTEGER NOT NULL, customer_id INTEGER, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_mode_work_notes_profile ON mode_work_notes(profile_id,updated_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_work_note_photos(id INTEGER PRIMARY KEY AUTOINCREMENT,note_id INTEGER NOT NULL,profile_id INTEGER NOT NULL,file_name TEXT NOT NULL,caption TEXT NOT NULL DEFAULT '',position INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_receipt_photos(id INTEGER PRIMARY KEY AUTOINCREMENT,receipt_id INTEGER NOT NULL,profile_id INTEGER NOT NULL,image BLOB NOT NULL,created_at TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_mode_receipt_photos ON mode_receipt_photos(profile_id,receipt_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_directory_urls(kind TEXT NOT NULL,record_id INTEGER NOT NULL,profile_id INTEGER NOT NULL,url TEXT NOT NULL,PRIMARY KEY(kind,record_id,profile_id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS mode_invoice_material_ref(invoice_line_id INTEGER PRIMARY KEY, material_id INTEGER NOT NULL, supplier_id INTEGER, product_url TEXT NOT NULL DEFAULT '', catalog_description TEXT NOT NULL DEFAULT '', captured_unit TEXT NOT NULL DEFAULT '', captured_price_cents INTEGER NOT NULL DEFAULT 0)")
        migrateLegacyDirectoryUrls()
    }
    data class WorkNote(val id:Long,val customerId:Long?,val title:String,val body:String,val updated:String)
    data class WorkNotePhoto(val id:Long,val fileName:String,val caption:String)
    fun workNotes():List<WorkNote> = db.rawQuery("SELECT id,customer_id,title,body,updated_at FROM mode_work_notes WHERE profile_id=? ORDER BY updated_at DESC",arrayOf(profileId.toString())).use { c ->
        buildList { while(c.moveToNext()) add(WorkNote(c.getLong(0),if(c.isNull(1))null else c.getLong(1),c.getString(2),c.getString(3),c.getString(4))) }
    }
    fun workNote(id:Long):WorkNote = workNotes().firstOrNull{it.id==id} ?: error("Note not found in active business")
    fun saveWorkNote(id:Long?,customerId:Long?,title:String,body:String):Long {
        require(title.isNotBlank()) { "Note title is required" }
        if(customerId!=null) require(db.rawQuery("SELECT 1 FROM customer WHERE id=? AND profile_id=?",arrayOf(customerId.toString(),profileId.toString())).use{it.moveToFirst()}) { "Customer belongs to another profile" }
        val now=Instant.now().toString()
        val values=ContentValues().apply{put("customer_id",customerId);put("title",title.trim());put("body",body);put("updated_at",now)}
        if(id==null){values.put("profile_id",profileId);values.put("created_at",now);return db.insertOrThrow("mode_work_notes",null,values)}
        require(db.update("mode_work_notes",values,"id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))==1) { "Note not found" }
        return id
    }
    fun notePhotos(noteId:Long):List<WorkNotePhoto> {
        workNote(noteId)
        return db.rawQuery("SELECT id,file_name,caption FROM mode_work_note_photos WHERE note_id=? AND profile_id=? ORDER BY position,id",arrayOf(noteId.toString(),profileId.toString())).use{c->buildList{while(c.moveToNext())add(WorkNotePhoto(c.getLong(0),c.getString(1),c.getString(2)))}}
    }
    fun addNotePhoto(noteId:Long,fileName:String,caption:String=""):Long {
        workNote(noteId)
        return db.insertOrThrow("mode_work_note_photos",null,ContentValues().apply{put("note_id",noteId);put("profile_id",profileId);put("file_name",fileName);put("caption",caption);put("position",notePhotos(noteId).size)})
    }
    fun deleteNotePhoto(noteId:Long,photoId:Long):String? {
        val photo=notePhotos(noteId).firstOrNull{it.id==photoId}?:return null
        db.delete("mode_work_note_photos","id=? AND note_id=? AND profile_id=?",arrayOf(photoId.toString(),noteId.toString(),profileId.toString()))
        return photo.fileName
    }
    fun deleteWorkNote(id:Long) {
        workNote(id)
        db.beginTransaction()
        try { db.delete("mode_work_note_photos","note_id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()));db.delete("mode_work_notes","id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()));db.setTransactionSuccessful() } finally{db.endTransaction()}
    }
    fun customerExtra(id: Long): JSONObject = db.rawQuery("SELECT business_name,billing_address,service_address,photo_base64 FROM mode_customer_contact_extra WHERE customer_id=?",arrayOf(id.toString())).use { c ->
        if(c.moveToFirst()) JSONObject().put("business_name",c.s(0)).put("billing_address",c.s(1)).put("service_address",c.s(2)).put("photo_base64",c.s(3)) else JSONObject()
    }
    fun saveCustomerExtra(id: Long, business: String, billing: String, service: String, photo: String? = null) {
        check(db.rawQuery("SELECT 1 FROM customer WHERE id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString())).use { it.moveToFirst() })
        val previous=customerExtra(id)
        db.insertWithOnConflict("mode_customer_contact_extra",null,ContentValues().apply {
            put("customer_id",id);put("business_name",business);put("billing_address",billing);put("service_address",service)
            put("photo_base64",photo ?: previous.optString("photo_base64"))
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun saveCustomerPhoto(id:Long, encoded:String) {
        require(encoded.length <= 2_800_000) { "Photo exceeds 2 MB" }
        val x=customerExtra(id)
        saveCustomerExtra(id,x.optString("business_name"),x.optString("billing_address"),x.optString("service_address"),encoded)
    }
    fun saveInvoiceMaterialReference(lineId:Long, materialId:Long, supplierId:Long?, productUrl:String, description:String, unit:String, cents:Long) {
        check(db.rawQuery("SELECT 1 FROM invoice_line l JOIN invoice i ON i.id=l.invoice_id WHERE l.id=? AND i.profile_id=?",arrayOf(lineId.toString(),profileId.toString())).use { it.moveToFirst() })
        require(cents >= 0) { "Captured price must not be negative" }
        require(productUrl.isBlank() || android.net.Uri.parse(productUrl).let { it.scheme in listOf("http", "https") && !it.host.isNullOrBlank() }) { "Invalid product URL" }
        db.insertWithOnConflict("mode_invoice_material_ref",null,ContentValues().apply {
            put("invoice_line_id",lineId);put("material_id",materialId);if(supplierId!=null)put("supplier_id",supplierId) else putNull("supplier_id")
            put("product_url",productUrl);put("catalog_description",description);put("captured_unit",unit);put("captured_price_cents",cents)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    val profiles = BusinessProfiles(context, db)
    private val profileId: Long get() = profiles.activeId()
    private fun now() = Instant.now().toString()

    fun dashboardCounts(): Map<String, Int> = mapOf(
        "Jobs" to scalar("SELECT COUNT(*) FROM job WHERE profile_id=? AND status_id NOT IN ('Completed','Rejected')"),
        "Customers" to scalar("SELECT COUNT(*) FROM customer WHERE profile_id=?"),
        "Todo" to scalar("SELECT COUNT(*) FROM to_do WHERE profile_id=? AND status='open'"),
        "Quotes" to scalar("SELECT COUNT(*) FROM quote WHERE profile_id=? AND state IN ('reviewing','sent')"),
        "Invoices" to scalar("""SELECT COUNT(*) FROM invoice i WHERE i.profile_id=? AND NOT (
            i.total_amount>0 AND COALESCE((SELECT SUM(a.amount) FROM debtor_payment_allocation a WHERE a.invoice_id=i.id),0)>=i.total_amount
        )"""),
        "Tools" to scalar("SELECT COUNT(*) FROM tool WHERE profile_id=?")
    )

    fun customers(search: String = ""): List<ListRow> {
        val like = "%${search.trim()}%"
        return rows(
            """SELECT id,name,COALESCE(description,''),COALESCE(mode_groups,'')
                FROM customer WHERE profile_id=? AND (name LIKE ? OR description LIKE ? OR mode_groups LIKE ?)
                ORDER BY name COLLATE NOCASE""",
            arrayOf(profileId.toString(), like, like, like)
        ) { ListRow(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)) }
    }

    fun customer(id: Long): CustomerDraft = db.rawQuery(
        "SELECT name,description,mode_groups,mode_fields,default_hourly_rate FROM customer WHERE id=? AND profile_id=?",
        arrayOf(id.toString(), profileId.toString())
    ).use { c ->
        check(c.moveToFirst()) { "Customer not found" }
        CustomerDraft(id, c.s(0), c.s(1), c.s(2), c.s(3), c.l(4))
    }

    fun saveCustomer(draft: CustomerDraft): Long {
        require(draft.name.trim().isNotEmpty()) { "Customer name is required" }
        val timestamp = now()
        val values = ContentValues().apply {
            put("name", draft.name.trim()); put("description", draft.description.trim())
            put("mode_groups", draft.groups.trim()); put("mode_fields", draft.customFields.trim())
            put("default_hourly_rate", draft.defaultHourlyRateCents); put("modifiedDate", timestamp)
            put("profile_id", profileId)
            if (draft.id == null) {
                put("primaryFirstName", ""); put("secondaryFirstName", ""); put("createdDate", timestamp)
                put("disbarred", 0); put("customerType", "residential"); put("exclude_from_mailings", 0)
            }
        }
        return if (draft.id == null) db.insertOrThrow("customer", null, values)
        else { check(db.update("customer", values, "id=? AND profile_id=?", arrayOf(draft.id.toString(), profileId.toString())) == 1); draft.id }
    }

    /** Contact-only transfer. Deliberately excludes financial, job, and service tables. */
    fun exportCustomerContacts(ids: List<Long>): org.json.JSONObject {
        val result=org.json.JSONArray()
        ids.distinct().forEach { id ->
            val customer=db.rawQuery("SELECT name,description,mode_fields FROM customer WHERE id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString())).use { c ->
                check(c.moveToFirst()) { "Customer not found in active profile" }
                org.json.JSONObject().put("name",c.s(0)).put("notes",c.s(1)).put("custom_fields",c.s(2))
            }
            val contacts=org.json.JSONArray()
            db.rawQuery("SELECT c.firstName,c.surname,c.emailAddress,c.mobileNumber,c.alternateEmail FROM contact c JOIN customer_contact cc ON cc.contact_id=c.id WHERE cc.customer_id=? AND c.profile_id=?",arrayOf(id.toString(),profileId.toString())).use { c ->
                while(c.moveToNext()) contacts.put(org.json.JSONObject().put("first",c.s(0)).put("last",c.s(1)).put("email",c.s(2)).put("phone",c.s(3)).put("alternate_email",c.s(4)))
            }
            val extra=customerExtra(id)
            for(key in listOf("business_name","billing_address","service_address","photo_base64")) customer.put(key,extra.optString(key))
            result.put(customer.put("contacts",contacts))
        }
        return org.json.JSONObject().put("format","mode-customer-contacts").put("version",1).put("customers",result)
    }

    /** Atomic copy into another existing profile, without copying linked jobs or invoices. */
    fun copyCustomerContactOnly(sourceId: Long, destinationProfileId: Long, allowDuplicate: Boolean=false): Long {
        require(destinationProfileId!=profileId) { "Choose another profile" }
        require(profiles.all().any { it.id==destinationProfileId }) { "Unknown destination profile" }
        val payload=exportCustomerContacts(listOf(sourceId)).getJSONArray("customers").getJSONObject(0)
        val name=payload.getString("name")
        db.beginTransaction()
        return try {
            val duplicate=db.rawQuery("SELECT id FROM customer WHERE profile_id=? AND name=? COLLATE NOCASE LIMIT 1",arrayOf(destinationProfileId.toString(),name)).use { it.moveToFirst() }
            require(allowDuplicate || !duplicate) { "Possible duplicate customer in destination profile" }
            val timestamp=now()
            val customerId=db.insertOrThrow("customer",null,ContentValues().apply {
                put("profile_id",destinationProfileId);put("name",name);put("description",payload.optString("notes"));put("mode_fields",payload.optString("custom_fields"));put("mode_groups","");put("default_hourly_rate",0)
                put("primaryFirstName","");put("secondaryFirstName","");put("createdDate",timestamp);put("modifiedDate",timestamp);put("disbarred",0);put("customerType","residential");put("exclude_from_mailings",0)
            })
            val extra=ContentValues().apply {put("customer_id",customerId); for(key in listOf("business_name","billing_address","service_address","photo_base64"))put(key,payload.optString(key))}
            db.insertWithOnConflict("mode_customer_contact_extra",null,extra,SQLiteDatabase.CONFLICT_REPLACE)
            val contacts=payload.getJSONArray("contacts")
            for(i in 0 until contacts.length()) {
                val item=contacts.getJSONObject(i)
                val contactId=db.insertOrThrow("contact",null,ContentValues().apply {
                    put("profile_id",destinationProfileId);put("firstName",item.optString("first"));put("surname",item.optString("last"));put("emailAddress",item.optString("email"));put("mobileNumber",item.optString("phone"));put("alternateEmail",item.optString("alternate_email"));put("createdDate",timestamp);put("modifiedDate",timestamp)
                })
                db.insertOrThrow("customer_contact",null,ContentValues().apply {put("customer_id",customerId);put("contact_id",contactId);put("primary",if(i==0)1 else 0);put("createdDate",timestamp);put("modifiedDate",timestamp)})
            }
            db.setTransactionSuccessful();customerId
        } finally { db.endTransaction() }
    }

    /** Contact-only import. Each customer is committed atomically, without any financial relationships. */
    fun importCustomerContacts(payload: org.json.JSONObject, destinationProfile: Long, policy: String): Pair<Int, Int> {
        require(payload.optString("format") == "mode-customer-contacts" && payload.optInt("version") == 1)
        require(profiles.all().any { it.id == destinationProfile })
        require(policy in setOf("skip", "update", "separate"))
        val customers = payload.getJSONArray("customers")
        require(customers.length() <= 10000) { "Import exceeds 10,000 customers" }
        var changed = 0; var skipped = 0
        for (i in 0 until customers.length()) {
            val item = customers.getJSONObject(i)
            val name = item.getString("name").trim()
            require(name.isNotBlank() && name.length <= 500) { "Invalid customer name" }
            val contacts = item.optJSONArray("contacts") ?: org.json.JSONArray()
            require(contacts.length() <= 100) { "Too many contacts" }
            db.beginTransaction()
            try {
                val duplicateId = db.rawQuery("SELECT id FROM customer WHERE profile_id=? AND name=? COLLATE NOCASE LIMIT 1", arrayOf(destinationProfile.toString(), name)).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
                if (duplicateId != null && policy == "skip") { skipped++ }
                else {
                    val stamp = now()
                    val customerId = if (duplicateId != null && policy == "update") {
                        db.update("customer", ContentValues().apply { put("description", item.optString("notes")); put("mode_fields", item.optString("custom_fields")); put("modifiedDate", stamp) }, "id=? AND profile_id=?", arrayOf(duplicateId.toString(), destinationProfile.toString()))
                        duplicateId
                    } else db.insertOrThrow("customer", null, ContentValues().apply {
                        put("profile_id", destinationProfile); put("name", name); put("description", item.optString("notes")); put("mode_fields", item.optString("custom_fields")); put("mode_groups", ""); put("default_hourly_rate", 0)
                        put("primaryFirstName", ""); put("secondaryFirstName", ""); put("createdDate", stamp); put("modifiedDate", stamp); put("disbarred", 0); put("customerType", "residential"); put("exclude_from_mailings", 0)
                    })
                    val oldExtra=customerExtra(customerId)
                    db.insertWithOnConflict("mode_customer_contact_extra",null,ContentValues().apply {
                        put("customer_id",customerId)
                        for(key in listOf("business_name","billing_address","service_address","photo_base64")) {
                            val incoming=item.optString(key)
                            put(key,if(incoming.isNotBlank()) incoming else oldExtra.optString(key))
                        }
                    },SQLiteDatabase.CONFLICT_REPLACE)
                    // Updating existing contact data never deletes pre-existing linked contacts.
                    for (j in 0 until contacts.length()) {
                        val c = contacts.getJSONObject(j)
                        val first = c.optString("first"); val last = c.optString("last"); val phone = c.optString("phone"); val email = c.optString("email")
                        val already = if (duplicateId != null && policy == "update") db.rawQuery("SELECT 1 FROM contact c JOIN customer_contact cc ON cc.contact_id=c.id WHERE cc.customer_id=? AND c.profile_id=? AND c.firstName=? AND c.surname=? AND c.emailAddress=? AND c.mobileNumber=? LIMIT 1", arrayOf(customerId.toString(),destinationProfile.toString(),first,last,email,phone)).use { it.moveToFirst() } else false
                        if (!already) {
                            val contactId = db.insertOrThrow("contact", null, ContentValues().apply { put("profile_id",destinationProfile); put("firstName",first); put("surname",last); put("emailAddress",email); put("mobileNumber",phone); put("alternateEmail",c.optString("alternate_email")); put("createdDate",stamp); put("modifiedDate",stamp) })
                            db.insertOrThrow("customer_contact",null,ContentValues().apply { put("customer_id",customerId); put("contact_id",contactId); put("primary",if(j==0 && duplicateId==null)1 else 0); put("createdDate",stamp); put("modifiedDate",stamp) })
                        }
                    }
                    changed++
                }
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
        return changed to skipped
    }

    fun customerDuplicateCount(payload: org.json.JSONObject, destinationProfile: Long): Int {
        val records = payload.getJSONArray("customers")
        return (0 until records.length()).count { i ->
            val name = records.getJSONObject(i).optString("name")
            db.rawQuery("SELECT 1 FROM customer WHERE profile_id=? AND name=? COLLATE NOCASE LIMIT 1",arrayOf(destinationProfile.toString(),name)).use { it.moveToFirst() }
        }
    }

    fun deleteCustomer(id: Long) = deleteOwned("customer", id)

    fun contacts(customerId: Long? = null): List<ListRow> {
        val sql: String
        val args: Array<String>
        if (customerId == null) {
            sql = "SELECT id,TRIM(COALESCE(firstName,'') || ' ' || COALESCE(surname,'')),COALESCE(emailAddress,''),COALESCE(mobileNumber,'') FROM contact WHERE profile_id=? ORDER BY surname,firstName"
            args = arrayOf(profileId.toString())
        } else {
            sql = """SELECT c.id,TRIM(COALESCE(c.firstName,'') || ' ' || COALESCE(c.surname,'')),COALESCE(c.emailAddress,''),COALESCE(c.mobileNumber,'')
                FROM contact c JOIN customer_contact cc ON cc.contact_id=c.id
                WHERE c.profile_id=? AND cc.customer_id=? ORDER BY cc.`primary` DESC,c.surname,c.firstName"""
            args = arrayOf(profileId.toString(), customerId.toString())
        }
        return rows(sql, args) { ListRow(it.getLong(0), it.s(1).ifBlank { "Unnamed contact" }, it.s(2), it.s(3)) }
    }

    fun contact(id: Long): ContactDraft = db.rawQuery(
        "SELECT firstName,surname,emailAddress,mobileNumber,alternateEmail FROM contact WHERE id=? AND profile_id=?",
        arrayOf(id.toString(), profileId.toString())
    ).use { c -> check(c.moveToFirst()); ContactDraft(id, c.s(0), c.s(1), c.s(2), c.s(3), c.s(4)) }

    fun saveContact(draft: ContactDraft, customerId: Long? = null): Long {
        require(draft.firstName.isNotBlank() || draft.surname.isNotBlank()) { "A contact name is required" }
        val timestamp = now()
        val values = ContentValues().apply {
            put("firstName", draft.firstName.trim()); put("surname", draft.surname.trim())
            put("emailAddress", draft.email.trim().ifBlank { null as String? })
            put("mobileNumber", draft.phone.trim().ifBlank { null as String? })
            put("alternateEmail", draft.alternateEmail.trim().ifBlank { null as String? })
            put("modifiedDate", timestamp); put("profile_id", profileId)
            if (draft.id == null) put("createdDate", timestamp)
        }
        val id = if (draft.id == null) db.insertOrThrow("contact", null, values)
        else { check(db.update("contact", values, "id=? AND profile_id=?", arrayOf(draft.id.toString(), profileId.toString())) == 1); draft.id }
        if (customerId != null) {
            db.insertWithOnConflict("customer_contact", null, ContentValues().apply {
                put("customer_id", customerId); put("contact_id", id); put("primary", if (contacts(customerId).isEmpty()) 1 else 0)
                put("createdDate", timestamp); put("modifiedDate", timestamp)
            }, SQLiteDatabase.CONFLICT_IGNORE)
        }
        return id
    }

    fun jobs(search: String = "", includeCompleted: Boolean = true): List<ListRow> {
        val statusClause = if (includeCompleted) "" else "AND j.status_id NOT IN ('Completed','Rejected')"
        val like = "%${search.trim()}%"
        return rows(
            """SELECT j.id,j.summary,COALESCE(c.name,'No customer'),j.status_id,j.billing_type
                FROM job j LEFT JOIN customer c ON c.id=j.customer_id
                WHERE j.profile_id=? $statusClause AND (j.summary LIKE ? OR j.description LIKE ? OR c.name LIKE ?)
                ORDER BY j.last_active DESC,j.modified_date DESC""",
            arrayOf(profileId.toString(), like, like, like)
        ) { ListRow(it.getLong(0), it.s(1), it.s(2), it.s(4), it.s(3)) }
    }

    fun job(id: Long): JobDraft = db.rawQuery(
        "SELECT customer_id,summary,description,internal_notes,billing_type,status_id,hourly_rate,booking_fee FROM job WHERE id=? AND profile_id=?",
        arrayOf(id.toString(), profileId.toString())
    ).use { c ->
        check(c.moveToFirst()) { "Job not found" }
        JobDraft(id, if (c.isNull(0)) null else c.getLong(0), c.s(1), c.s(2), c.s(3), c.s(4), c.s(5), c.l(6), c.l(7))
    }

    fun saveJob(draft: JobDraft): Long {
        require(draft.summary.trim().isNotEmpty()) { "Job summary is required" }
        val timestamp = now()
        val values = ContentValues().apply {
            draft.customerId?.let { put("customer_id", it) } ?: putNull("customer_id")
            put("summary", draft.summary.trim()); put("description", draft.description.trim())
            put("internal_notes", draft.notes.trim()); put("billing_type", draft.billingType)
            put("status_id", draft.status); put("hourly_rate", draft.hourlyRateCents)
            put("booking_fee", draft.bookingFeeCents); put("modified_date", timestamp); put("profile_id", profileId)
            if (draft.id == null) {
                put("last_active", 1); put("booking_fee_invoiced", 0); put("created_date", timestamp)
                put("assumption", ""); put("billing_party", "customer"); put("is_stock", 0); put("estimate_margin", 0)
            }
        }
        return if (draft.id == null) db.insertOrThrow("job", null, values)
        else { check(db.update("job", values, "id=? AND profile_id=?", arrayOf(draft.id.toString(), profileId.toString())) == 1); draft.id }
    }

    fun tasks(jobId: Long): List<ListRow> = rows(
        "SELECT id,name,COALESCE(description,''),billing_type,task_status_id FROM task WHERE job_id=? ORDER BY id",
        arrayOf(jobId.toString())
    ) { ListRow(it.getLong(0), it.s(1), it.s(2), it.s(3), taskStatusName(it.i(4))) }

    fun saveTask(jobId: Long, id: Long?, name: String, description: String, billingType: String, statusId: Int): Long {
        require(name.trim().isNotEmpty()) { "Task name is required" }
        check(ownsJob(jobId))
        val timestamp = now()
        val values = ContentValues().apply {
            put("job_id", jobId); put("name", name.trim()); put("description", description.trim())
            put("billing_type", billingType); put("task_status_id", statusId); put("modifiedDate", timestamp)
            if (id == null) { put("createdDate", timestamp); put("assumption", ""); put("internal_notes", ""); put("estimate_complete", 0) }
        }
        return if (id == null) db.insertOrThrow("task", null, values)
        else { check(db.update("task", values, "id=? AND job_id=?", arrayOf(id.toString(), jobId.toString())) == 1); id }
    }

    fun taskItems(jobId: Long): List<ListRow> = rows(
        """SELECT ti.id,ti.description,COALESCE(ti.estimated_quantity,1000),COALESCE(ti.estimated_unit_cost,0),COALESCE(ti.total_line_charge,0)
            FROM task_item ti JOIN task t ON t.id=ti.task_id WHERE t.job_id=? ORDER BY ti.id""",
        arrayOf(jobId.toString())
    ) { ListRow(it.getLong(0), it.s(1), "${MoneyMath.quantityText(it.l(2))} × ${MoneyMath.format(it.l(3))}", MoneyMath.format(it.l(4))) }

    fun addTaskItem(taskId: Long, description: String, quantity: Long, unitCost: Long, marginThousandths: Int): Long {
        require(description.trim().isNotEmpty())
        val timestamp = now()
        val base = MoneyMath.lineTotal(quantity, unitCost)
        val charge = base + MoneyMath.percentage(base, marginThousandths / 10)
        return db.insertOrThrow("task_item", null, ContentValues().apply {
            put("task_id", taskId); put("description", description.trim()); put("item_type_id", 1)
            put("estimated_price_mode", "items"); put("estimated_quantity", quantity); put("estimated_unit_cost", unitCost)
            put("margin", marginThousandths); put("total_line_charge", charge); put("charge_mode", "calculated")
            put("completed", 0); put("billed", 0); put("labour_entry_mode", "hours"); put("is_return", 0)
            put("created_date", timestamp); put("modified_date", timestamp)
        })
    }

    fun timeEntries(jobId: Long): List<ListRow> = rows(
        """SELECT te.id,t.name,te.start_time,COALESCE(te.end_time,''),COALESCE(te.notes,'')
            FROM time_entry te JOIN task t ON t.id=te.task_id WHERE t.job_id=? ORDER BY te.start_time DESC""",
        arrayOf(jobId.toString())
    ) { ListRow(it.getLong(0), it.s(1), "${it.s(2)}${if (it.s(3).isBlank()) " — running" else " — ${it.s(3)}"}", it.s(4)) }

    fun startTimer(taskId: Long, notes: String): Long {
        val timestamp = now()
        require(db.rawQuery("SELECT COUNT(*) FROM time_entry WHERE end_time IS NULL", null).use { it.moveToFirst(); it.getInt(0) } == 0) {
            "Stop the currently running timer first"
        }
        return db.insertOrThrow("time_entry", null, ContentValues().apply {
            put("task_id", taskId); put("start_time", timestamp); put("created_date", timestamp); put("modified_date", timestamp)
            put("notes", notes); put("billed", 0); put("billable", 1); put("show_on_invoice", 0)
        })
    }

    fun stopTimer(id: Long) {
        val timestamp = now()
        db.update("time_entry", ContentValues().apply { put("end_time", timestamp); put("modified_date", timestamp) }, "id=? AND end_time IS NULL", arrayOf(id.toString()))
    }

    fun quotes(): List<ListRow> = rows(
        """SELECT q.id,COALESCE(q.quote_num,'Quote #'||q.id),COALESCE(c.name,'No customer'),q.state,q.total_amount
            FROM quote q LEFT JOIN job j ON j.id=q.job_id LEFT JOIN customer c ON c.id=j.customer_id
            WHERE q.profile_id=? ORDER BY q.modified_date DESC""",
        arrayOf(profileId.toString())
    ) { ListRow(it.getLong(0), it.s(1), it.s(2), MoneyMath.format(it.l(4)), it.s(3)) }

    fun createQuote(jobId: Long): Long {
        check(ownsJob(jobId))
        val timestamp = now()
        val next = scalarRaw("SELECT COALESCE(MAX(id),0)+1 FROM quote")
        return db.insertOrThrow("quote", null, ContentValues().apply {
            put("job_id", jobId); put("total_amount", 0); put("created_date", timestamp); put("modified_date", timestamp)
            put("quote_num", "Q-${LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)}-$next")
            put("state", "reviewing"); put("assumption", ""); put("summary", ""); put("description", "")
            put("quote_margin", 0); put("mode_discount_cents", 0); put("mode_tax_hundredths", 0); put("mode_terms", "")
            put("profile_id", profileId)
        })
    }

    fun quoteBelongsToJob(quoteId: Long, jobId: Long): Boolean = db.rawQuery(
        "SELECT 1 FROM quote WHERE id=? AND job_id=? AND profile_id=?",
        arrayOf(quoteId.toString(),jobId.toString(),profileId.toString())
    ).use { it.moveToFirst() }

    /**
     * Converts one Smart Tools estimate exactly once. The authoritative conversion
     * journal and the quote are committed in the same main-database transaction.
     * A later retry repairs the secondary-database link after an interrupted process.
     */
    fun convertSmartEstimate(store: SmartToolsStore, profile: String, estimateId: Long, jobId: Long): Long {
        check(ownsJob(jobId)) { "Job does not belong to the active business profile" }
        require(profile == profileId.toString()) { "Business profile mismatch" }
        val estimate = store.estimate(profile, estimateId)
        check(estimate["job_id"] == jobId.toString() && estimate["link_status"] == "verified") {
            "The estimate must be linked to a verified job identifier first"
        }
        store.linkedQuote(profile,estimateId,jobId)?.let { existing ->
            check(quoteBelongsToJob(existing, jobId)) { "Stored quote link does not match this job" }
            return existing
        }

        val marker = "[MODE-SMART-ESTIMATE:${profile}:${estimateId}]"
        var quoteId = 0L
        db.beginTransaction()
        try {
            quoteId = db.rawQuery(
                "SELECT quote_id FROM mode_smart_estimate_conversion WHERE profile_id=? AND estimate_id=? AND job_id=?",
                arrayOf(profile,estimateId.toString(),jobId.toString())
            ).use { c -> if(c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }

            // Recover conversions produced by the preceding handoff build.
            if (quoteId == 0L) quoteId = db.rawQuery(
                "SELECT id FROM quote WHERE job_id=? AND profile_id=? AND mode_terms LIKE ? ORDER BY id LIMIT 1",
                arrayOf(jobId.toString(),profile,"%$marker%")
            ).use { c -> if(c.moveToFirst()) c.getLong(0) else 0L }

            if (quoteId == 0L) {
                val timestamp = now()
                db.insertWithOnConflict("mode_smart_estimate_conversion",null,ContentValues().apply {
                    put("profile_id",profileId);put("estimate_id",estimateId);put("job_id",jobId)
                    put("state","pending");put("created_date",timestamp);put("modified_date",timestamp)
                },SQLiteDatabase.CONFLICT_IGNORE)

                val storedJob = db.rawQuery(
                    "SELECT job_id,quote_id FROM mode_smart_estimate_conversion WHERE profile_id=? AND estimate_id=?",
                    arrayOf(profile,estimateId.toString())
                ).use { c -> check(c.moveToFirst()); Pair(c.getLong(0),if(c.isNull(1)) 0L else c.getLong(1)) }
                check(storedJob.first == jobId) { "This estimate is already assigned to a different job" }
                quoteId = storedJob.second
            }

            if (quoteId == 0L) {
                val total = estimate.getValue("total_cents").toLong()
                var components = store.estimateComponents(profile,estimateId)
                if (components.isEmpty()) {
                    val labor = estimate.getValue("labor_cents").toLong()
                    val materials = estimate.getValue("materials_cents").toLong()
                    val base = Math.addExact(materials,labor)
                    require(total >= base)
                    components = buildList {
                        if(materials>0) add(EstimateComponent("material","Materials — ${estimate["title"].orEmpty()}",1000,"total",materials,materials))
                        if(labor>0) add(EstimateComponent("labor","Labor — ${estimate["title"].orEmpty()}",1000,"total",labor,labor))
                        if(total>base) add(EstimateComponent("markup","Markup / overhead — ${estimate["title"].orEmpty()}",1000,"total",total-base,total-base))
                        if(isEmpty()) add(EstimateComponent("other",estimate["title"].orEmpty().ifBlank{"Estimate"},1000,"total",0,0))
                    }
                }
                require(components.fold(0L) { sum, item -> Math.addExact(sum,item.lineTotalCents) } == total) {
                    "Estimate component total does not match the saved estimate"
                }
                quoteId = createQuote(jobId)
                components.forEach { component ->
                    val createdLine = addQuoteLine(quoteId,component.description,component.quantityThousandths,component.unitCents)
                    check(db.rawQuery("SELECT line_total FROM quote_line WHERE id=?",arrayOf(createdLine.toString())).use { it.moveToFirst();it.getLong(0) } == component.lineTotalCents) {
                        "Quote line rounding changed the estimate amount"
                    }
                }
                updateQuoteAdjustments(quoteId,0L,0,"Source estimate $estimateId $marker",null)
            }

            check(quoteBelongsToJob(quoteId,jobId)) { "Recovered quote does not belong to the selected job" }
            val timestamp = now()
            db.insertWithOnConflict("mode_smart_estimate_conversion",null,ContentValues().apply {
                put("profile_id",profileId);put("estimate_id",estimateId);put("job_id",jobId);put("quote_id",quoteId)
                put("state","completed");put("created_date",timestamp);put("modified_date",timestamp)
            },SQLiteDatabase.CONFLICT_IGNORE)
            check(db.update("mode_smart_estimate_conversion",ContentValues().apply {
                put("quote_id",quoteId);put("state","completed");put("modified_date",timestamp)
            },"profile_id=? AND estimate_id=? AND job_id=?",arrayOf(profile,estimateId.toString(),jobId.toString())) == 1)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }

        check(store.setLinkedQuote(profile,estimateId,jobId,quoteId)) {
            "Quote saved; rerun conversion to repair the secondary link"
        }
        return quoteId
    }

    fun allJobIdentities(): Map<String,List<JobIdentity>> = rows(
        "SELECT profile_id,id,summary FROM job WHERE profile_id IS NOT NULL ORDER BY profile_id,id", emptyArray()
    ) { Triple(it.getLong(0).toString(),it.getLong(1),it.s(2)) }
        .groupBy({ it.first }, { JobIdentity(it.second,it.third) })

    fun jobIdForQuote(id: Long): Long = db.rawQuery(
        "SELECT job_id FROM quote WHERE id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString())
    ).use { c -> check(c.moveToFirst() && !c.isNull(0));c.getLong(0) }

    fun jobIdForInvoice(id: Long): Long = db.rawQuery(
        "SELECT job_id FROM invoice WHERE id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString())
    ).use { c -> check(c.moveToFirst() && !c.isNull(0));c.getLong(0) }

    fun contractLink(quoteId: Long, jobId: Long): ContractLink = db.rawQuery(
        """SELECT q.profile_id,j.customer_id,COALESCE(c.name,''),j.id,j.summary,q.id,COALESCE(q.quote_num,'Quote #'||q.id)
            FROM quote q JOIN job j ON j.id=q.job_id LEFT JOIN customer c ON c.id=j.customer_id
            WHERE q.id=? AND j.id=? AND q.profile_id=? AND j.profile_id=q.profile_id""",
        arrayOf(quoteId.toString(),jobId.toString(),profileId.toString())
    ).use { c ->
        check(c.moveToFirst()) { "Quote and job are not linked in the active business profile" }
        require(!c.isNull(1)) { "Assign a customer to this job before contract approval" }
        ContractLink(c.getLong(0),c.getLong(1),c.s(2),c.getLong(3),c.s(4),c.getLong(5),c.s(6))
    }

    fun approveContract(
        smartApprovalId: Long,
        link: ContractLink,
        signer: String,
        agreement: String,
        consent: String,
        approvedAt: String,
        signatureFile: String,
        contractFile: String,
        contentSha256: String
    ): Long {
        require(signer.isNotBlank() && agreement.isNotBlank() && consent.isNotBlank())
        check(contractLink(link.quoteId,link.jobId) == link) { "Contract linkage changed before approval" }
        db.beginTransaction()
        return try {
            val existing = db.rawQuery(
                "SELECT id,customer_id,job_id,content_sha256 FROM mode_contract_approval WHERE profile_id=? AND quote_id=?",
                arrayOf(profileId.toString(),link.quoteId.toString())
            ).use { c -> if(c.moveToFirst()) listOf(c.getLong(0).toString(),c.getLong(1).toString(),c.getLong(2).toString(),c.s(3)) else emptyList() }
            val id = if(existing.isNotEmpty()) {
                check(existing[1].toLong()==link.customerId && existing[2].toLong()==link.jobId && existing[3]==contentSha256) {
                    "A different signed approval already exists for this quote"
                }
                existing[0].toLong()
            } else db.insertOrThrow("mode_contract_approval",null,ContentValues().apply {
                put("profile_id",link.profileId);put("customer_id",link.customerId);put("job_id",link.jobId);put("quote_id",link.quoteId)
                put("smart_approval_id",smartApprovalId);put("signer_name",signer);put("agreement_text",agreement);put("consent_text",consent)
                put("approved_at",approvedAt);put("signature_file",signatureFile);put("contract_file",contractFile);put("content_sha256",contentSha256);put("created_date",now())
            })
            val changed=db.update("quote",ContentValues().apply { put("state","approved");put("date_approved",approvedAt);put("modified_date",now()) },
                "id=? AND job_id=? AND profile_id=?",arrayOf(link.quoteId.toString(),link.jobId.toString(),link.profileId.toString()))
            check(changed==1)
            db.setTransactionSuccessful();id
        } finally { db.endTransaction() }
    }

    fun quote(id: Long): QuoteSummary = db.rawQuery(
        """SELECT q.quote_num,COALESCE(c.name,'No customer'),COALESCE(j.summary,''),q.state,
            COALESCE((SELECT SUM(line_total) FROM quote_line WHERE quote_id=q.id),0),q.mode_discount_cents,q.mode_tax_hundredths,q.total_amount,q.mode_terms,q.valid_until
            FROM quote q LEFT JOIN job j ON j.id=q.job_id LEFT JOIN customer c ON c.id=j.customer_id
            WHERE q.id=? AND q.profile_id=?""",
        arrayOf(id.toString(), profileId.toString())
    ).use { c -> check(c.moveToFirst()); QuoteSummary(id, c.s(0), c.s(1), c.s(2), c.s(3), c.l(4), c.l(5), c.i(6), c.l(7), c.s(8), if(c.isNull(9)) null else c.s(9)) }

    fun quoteLines(id: Long): List<DocumentLine> = rows(
        "SELECT id,description,quantity,unit_charge,line_total FROM quote_line WHERE quote_id=? ORDER BY id",
        arrayOf(id.toString())
    ) { DocumentLine(it.getLong(0), it.s(1), it.l(2), it.l(3), it.l(4)) }

    fun addQuoteLine(quoteId: Long, description: String, quantity: Long, unitCents: Long): Long {
        check(quote(quoteId).id == quoteId)
        val timestamp = now()
        val id = db.insertOrThrow("quote_line", null, ContentValues().apply {
            put("quote_id", quoteId); put("description", description.trim()); put("quantity", quantity)
            put("unit_charge", unitCents); put("line_total", MoneyMath.lineTotal(quantity, unitCents))
            put("created_date", timestamp); put("modified_date", timestamp); put("line_chargeable_status", "normal")
        })
        recalculateQuote(quoteId)
        return id
    }

    fun updateQuoteAdjustments(id: Long, discount: Long, taxHundredths: Int, terms: String, validUntil: String?) {
        val values = ContentValues().apply {
            put("mode_discount_cents", discount.coerceAtLeast(0)); put("mode_tax_hundredths", taxHundredths.coerceAtLeast(0))
            put("mode_terms", terms); validUntil?.takeIf { it.isNotBlank() }?.let { put("valid_until", it) } ?: putNull("valid_until")
            put("modified_date", now())
        }
        check(db.update("quote", values, "id=? AND profile_id=?", arrayOf(id.toString(), profileId.toString())) == 1)
        recalculateQuote(id)
    }

    fun setQuoteState(id: Long, state: String) {
        val allowed = setOf("reviewing", "sent", "rejected", "withdrawn", "approved", "invoiced")
        require(state in allowed)
        val values = ContentValues().apply {
            put("state", state); put("modified_date", now())
            if (state == "sent") put("date_sent", now())
            if (state == "approved") put("date_approved", now())
        }
        db.update("quote", values, "id=? AND profile_id=?", arrayOf(id.toString(), profileId.toString()))
    }

    private fun recalculateQuote(id: Long) {
        val q = quote(id)
        val total = MoneyMath.quoteTotal(q.subtotalCents, q.discountCents, q.taxHundredths)
        db.update("quote", ContentValues().apply { put("total_amount", total); put("modified_date", now()) }, "id=?", arrayOf(id.toString()))
    }

    fun invoices(): List<ListRow> = rows(
        """SELECT i.id,COALESCE(i.invoice_num,'Invoice #'||i.id),COALESCE(c.name,'No customer'),COALESCE(i.due_date,''),i.total_amount,
            COALESCE((SELECT SUM(a.amount) FROM debtor_payment_allocation a WHERE a.invoice_id=i.id),0)
            FROM invoice i LEFT JOIN job j ON j.id=i.job_id LEFT JOIN customer c ON c.id=COALESCE(i.billing_customer_id,j.customer_id)
            WHERE i.profile_id=? ORDER BY i.modified_date DESC""",
        arrayOf(profileId.toString())
    ) { ListRow(it.getLong(0), it.s(1), "${it.s(2)} • Due ${it.s(3).ifBlank { "not set" }}", MoneyMath.format(it.l(4)), if(MoneyMath.invoicePaid(it.l(4),it.l(5))) "Paid" else "Open") }

    fun createInvoice(jobId: Long): Long {
        check(ownsJob(jobId))
        val timestamp = now()
        val next = scalarRaw("SELECT COALESCE(MAX(id),0)+1 FROM invoice")
        return db.insertOrThrow("invoice", null, ContentValues().apply {
            put("job_id", jobId); put("total_amount", 0); put("created_date", timestamp); put("modified_date", timestamp)
            put("invoice_num", "I-${LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)}-$next")
            put("due_date", LocalDate.now().plusDays(paymentTerms().toLong()).toString())
            put("sent", 0); put("paid", 0); put("external_sync_status", 0); put("payment_source", 0); put("profile_id", profileId)
        })
    }

    fun invoice(id: Long): InvoiceSummary = db.rawQuery(
        """SELECT COALESCE(i.invoice_num,'Invoice #'||i.id),COALESCE(c.name,'No customer'),COALESCE(j.summary,''),i.due_date,i.total_amount,i.paid,
            COALESCE((SELECT SUM(a.amount) FROM debtor_payment_allocation a WHERE a.invoice_id=i.id),0)
            FROM invoice i LEFT JOIN job j ON j.id=i.job_id LEFT JOIN customer c ON c.id=COALESCE(i.billing_customer_id,j.customer_id)
            WHERE i.id=? AND i.profile_id=?""",
        arrayOf(id.toString(), profileId.toString())
    ).use { c ->
        check(c.moveToFirst())
        val total = c.l(4)
        val paid = c.l(6)
        InvoiceSummary(id, c.s(0), c.s(1), c.s(2), if(c.isNull(3)) null else c.s(3), total, MoneyMath.invoicePaid(total, paid), paid, MoneyMath.invoiceBalance(total, paid))
    }

    fun invoiceLines(id: Long): List<DocumentLine> = rows(
        "SELECT id,description,quantity,unit_price,line_total FROM invoice_line WHERE invoice_id=? ORDER BY id",
        arrayOf(id.toString())
    ) { DocumentLine(it.getLong(0), it.s(1), it.l(2), it.l(3), it.l(4)) }

    fun addInvoiceLine(invoiceId: Long, description: String, quantity: Long, unitCents: Long): Long {
        check(invoice(invoiceId).id == invoiceId)
        val timestamp = now()
        val id = db.insertOrThrow("invoice_line", null, ContentValues().apply {
            put("invoice_id", invoiceId); put("description", description.trim()); put("quantity", quantity)
            put("unit_price", unitCents); put("line_total", MoneyMath.lineTotal(quantity, unitCents)); put("tax_amount", 0)
            put("created_date", timestamp); put("modified_date", timestamp); put("status", "active"); put("from_booking_fee", 0)
        })
        recalculateInvoice(invoiceId)
        return id
    }

    private fun recalculateInvoice(id: Long) {
        val total = db.rawQuery("SELECT COALESCE(SUM(line_total+COALESCE(tax_amount,0)),0) FROM invoice_line WHERE invoice_id=?", arrayOf(id.toString())).use { it.moveToFirst(); it.getLong(0) }
        val allocated = db.rawQuery("SELECT COALESCE(SUM(amount),0) FROM debtor_payment_allocation WHERE invoice_id=?", arrayOf(id.toString())).use { it.moveToFirst(); it.getLong(0) }
        db.update("invoice", ContentValues().apply {
            put("total_amount", total); put("modified_date", now())
            val fullyPaid = MoneyMath.invoicePaid(total, allocated)
            put("paid", if (fullyPaid) 1 else 0)
            if (fullyPaid) put("paid_date", LocalDate.now().toString()) else putNull("paid_date")
        }, "id=? AND profile_id=?", arrayOf(id.toString(), profileId.toString()))
    }

    fun recordPayment(invoiceId: Long, amountCents: Long, method: String, reference: String) {
        require(amountCents > 0)
        val invoice = invoice(invoiceId)
        require(amountCents <= invoice.balanceCents) { "Payment exceeds outstanding invoice balance" }
        val customerId = db.rawQuery("SELECT COALESCE(billing_customer_id,(SELECT customer_id FROM job WHERE id=invoice.job_id)) FROM invoice WHERE id=?", arrayOf(invoiceId.toString())).use { it.moveToFirst(); if(it.isNull(0)) null else it.getLong(0) }
        require(customerId != null) { "Invoice has no billing customer" }
        val timestamp = now()
        db.beginTransaction()
        try {
            val paymentId = db.insertOrThrow("debtor_payment", null, ContentValues().apply {
                put("customer_id", customerId); put("payment_date", LocalDate.now().toString()); put("amount", amountCents)
                put("payment_method", method); put("reference", reference); put("notes", ""); put("created_date", timestamp); put("modified_date", timestamp)
            })
            db.insertOrThrow("debtor_payment_allocation", null, ContentValues().apply {
                put("payment_id", paymentId); put("invoice_id", invoiceId); put("amount", amountCents)
                put("allocated_date", LocalDate.now().toString()); put("created_date", timestamp); put("modified_date", timestamp)
            })
            val allocated = db.rawQuery("SELECT COALESCE(SUM(amount),0) FROM debtor_payment_allocation WHERE invoice_id=?", arrayOf(invoiceId.toString())).use { it.moveToFirst(); it.getLong(0) }
            db.update("invoice", ContentValues().apply {
                val fullyPaid = MoneyMath.invoicePaid(invoice.totalCents, allocated)
                put("paid", if (fullyPaid) 1 else 0)
                if (fullyPaid) put("paid_date", LocalDate.now().toString()) else putNull("paid_date")
            }, "id=? AND profile_id=?", arrayOf(invoiceId.toString(), profileId.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun todos(): List<ListRow> = rows(
        "SELECT id,title,COALESCE(note,''),COALESCE(due_date,''),priority,status FROM to_do WHERE profile_id=? ORDER BY status='open' DESC,due_date IS NULL,due_date,id DESC",
        arrayOf(profileId.toString())
    ) { ListRow(it.getLong(0), it.s(1), it.s(2), it.s(3), "${it.s(4)} • ${it.s(5)}") }

    fun saveTodo(id: Long?, title: String, note: String, due: String?, remindAt: String?, priority: String, status: String): Long {
        require(title.trim().isNotEmpty())
        val timestamp=now(); val values=ContentValues().apply {
            put("title",title.trim()); put("note",note.trim()); due?.takeIf{it.isNotBlank()}?.let{put("due_date",it)}?:putNull("due_date")
            remindAt?.takeIf { it.isNotBlank() }?.let { put("remind_at", it) } ?: putNull("remind_at")
            put("priority",priority); put("status",status); put("modified_date",timestamp); put("profile_id",profileId)
            if(id==null) put("created_date",timestamp)
            if(status=="done") put("completed_date",timestamp) else putNull("completed_date")
        }
        return if(id==null) db.insertOrThrow("to_do",null,values) else { check(db.update("to_do",values,"id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))==1); id }
    }

    fun schedule(): List<ListRow> = rows(
        """SELECT a.id,j.summary,a.start_date,a.end_date,COALESCE(a.notes,''),a.status FROM job_activity a JOIN job j ON j.id=a.job_id
            WHERE j.profile_id=? ORDER BY a.start_date""", arrayOf(profileId.toString())
    ) { ListRow(it.getLong(0), it.s(1), "${it.s(2)} — ${it.s(3)}", it.s(4), it.s(5)) }

    fun addAppointment(jobId: Long, start: String, end: String, notes: String): Long {
        check(ownsJob(jobId)); val timestamp=now()
        return db.insertOrThrow("job_activity",null,ContentValues().apply {
            put("job_id",jobId); put("start_date",start); put("end_date",end); put("notes",notes)
            put("status","scheduled"); put("created_date",timestamp); put("modified_date",timestamp)
        })
    }

    fun simpleRows(kind: String): List<ListRow> = when(kind) {
        "suppliers" -> rows("SELECT id,name,COALESCE(service,''),COALESCE(description,'') FROM supplier WHERE profile_id=? ORDER BY name",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),it.s(3))}
        "manufacturers" -> rows("SELECT id,name,COALESCE(description,''),COALESCE(contactNumber,'') FROM manufacturer WHERE profile_id=? ORDER BY name",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),it.s(3))}
        "tools" -> rows("SELECT id,name,COALESCE(location,''),COALESCE(lent_to,''),COALESCE(cost,0) FROM tool WHERE profile_id=? ORDER BY name",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),MoneyMath.format(it.l(4)),it.s(3))}
        "receipts" -> rows("SELECT r.id,COALESCE(s.name,'Supplier'),r.receipt_date,r.total_including_tax FROM receipt r LEFT JOIN supplier s ON s.id=r.supplier_id WHERE r.profile_id=? ORDER BY r.receipt_date DESC",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),MoneyMath.format(it.l(3)))}
        "trips" -> rows("SELECT id,COALESCE(purpose,'Trip'),arrived_at,COALESCE(from_address,''),COALESCE(distance_metres,0) FROM trip_log WHERE profile_id=? ORDER BY arrived_at DESC",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),tripDistanceLabel(it.l(4)),it.s(3))}
        else -> emptyList()
    }

    fun addSimple(kind: String, name: String, detail: String = "", amountCents: Long = 0, relatedId: Long? = null): Long {
        require(name.trim().isNotEmpty()) { "A name or purpose is required" }
        val timestamp = now()
        return when (kind) {
            "suppliers" -> db.insertOrThrow("supplier", null, ContentValues().apply {
                put("name", name.trim()); put("description", detail.trim()); put("service", detail.trim())
                put("createdDate", timestamp); put("modifiedDate", timestamp); put("lastAccessed", timestamp); put("profile_id", profileId)
            })
            "manufacturers" -> db.insertOrThrow("manufacturer", null, ContentValues().apply {
                put("name", name.trim()); put("description", detail.trim()); put("contactNumber", ""); put("email", ""); put("address", "")
                put("createdDate", timestamp); put("modifiedDate", timestamp); put("profile_id", profileId)
            })
            "tools" -> db.insertOrThrow("tool", null, ContentValues().apply {
                put("name", name.trim()); put("description", detail.trim()); put("cost", amountCents); put("location", ""); put("lent_to", "")
                put("createdDate", timestamp); put("modifiedDate", timestamp); put("profile_id", profileId)
            })
            "receipts" -> {
                require(relatedId != null) { "A supplier is required" }
                db.insertOrThrow("receipt", null, ContentValues().apply {
                    put("receipt_date", LocalDate.now().toString()); put("supplier_id", relatedId)
                    put("total_excluding_tax", amountCents); put("tax", 0); put("total_including_tax", amountCents)
                    put("created_date", timestamp); put("modified_date", timestamp); put("profile_id", profileId)
                })
            }
            "trips" -> db.insertOrThrow("trip_log", null, ContentValues().apply {
                put("departed_at", timestamp); put("arrived_at", timestamp); put("from_address", detail.trim())
                put("to_latitude", 0.0); put("to_longitude", 0.0); put("distance_metres", amountCents)
                put("duration_seconds", 0); put("purpose", name.trim()); put("business", 1); put("classified", 1)
                put("distance_source", "manual"); put("profile_id", profileId)
            })
            else -> error("Unsupported catalog")
        }
    }

    fun receiptPhotos(id:Long):List<Pair<Long,ByteArray>> {
        recordValues("receipt",id)
        return db.rawQuery("SELECT id,image FROM mode_receipt_photos WHERE receipt_id=? AND profile_id=? ORDER BY id",arrayOf(id.toString(),profileId.toString())).use { c ->
            buildList { while(c.moveToNext()) add(c.getLong(0) to c.getBlob(1)) }
        }
    }
    fun addReceiptPhoto(id:Long,bytes:ByteArray) {
        recordValues("receipt",id)
        require(bytes.isNotEmpty() && bytes.size <= 3_000_000) { "Receipt photo must be 3 MB or less" }
        db.insertOrThrow("mode_receipt_photos",null,ContentValues().apply {put("receipt_id",id);put("profile_id",profileId);put("image",bytes);put("created_at",now())})
    }
    fun deleteReceiptPhoto(id:Long,photoId:Long) {
        recordValues("receipt",id)
        check(db.delete("mode_receipt_photos","id=? AND receipt_id=? AND profile_id=?",arrayOf(photoId.toString(),id.toString(),profileId.toString()))==1)
    }
    /** Preserve the existing tax amount when editing receipt totals. The entered total is tax-inclusive. */
    fun updateReceipt(id:Long,supplierId:Long,amount:Long,date:String,taxCents:Long?=null) {
        val old = recordValues("receipt",id)
        require(amount>=0 && date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { "Invalid receipt amount or date" }
        LocalDate.parse(date)
        require(supplierChoices().any{it.id==supplierId}) { "Supplier is not in this business profile" }
        val tax = taxCents ?: (old["tax"]?.toLongOrNull() ?: 0L)
        val (excludingTax,validatedTax)=BusinessRecordRules.receiptAmounts(amount,tax)
        val values=ContentValues().apply {put("supplier_id",supplierId);put("receipt_date",date);put("total_excluding_tax",excludingTax);put("tax",validatedTax);put("total_including_tax",amount);put("modified_date",now())}
        check(db.update("receipt",values,"id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))==1)
    }
    fun deleteReceipt(id:Long) {
        recordValues("receipt",id)
        db.beginTransaction()
        try {
            db.delete("mode_receipt_photos","receipt_id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))
            check(db.delete("receipt","id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))==1)
            db.setTransactionSuccessful()
        } finally {db.endTransaction()}
    }
    /** Non-destructive, repeatable import of explicit URLs from legacy supplier/manufacturer fields. */
    private fun migrateLegacyDirectoryUrls() {
        db.beginTransaction()
        try {
            for (kind in listOf("supplier","manufacturer")) {
                val fields=db.rawQuery("PRAGMA table_info($kind)",null).use { c ->
                    buildSet { while(c.moveToNext()) add(c.getString(1)) }
                }
                val candidates=listOf("website","website_url","web_url","url","description","service","notes").filter { it in fields }
                if (candidates.isEmpty() || "profile_id" !in fields) continue
                val query="SELECT id,profile_id,"+candidates.joinToString(",")+" FROM $kind"
                db.rawQuery(query,null).use { cursor ->
                    while(cursor.moveToNext()) {
                        val id=cursor.getLong(0);val profile=cursor.getLong(1)
                        val exists=db.rawQuery("SELECT url FROM mode_directory_urls WHERE kind=? AND record_id=? AND profile_id=?",arrayOf(kind,id.toString(),profile.toString())).use{it.moveToFirst()}
                        if(exists) continue
                        val url=(2 until cursor.columnCount).asSequence().mapNotNull { index ->
                            if(cursor.isNull(index)) null else BusinessRecordRules.firstHttpUrl(cursor.getString(index))
                        }.firstOrNull() ?: continue
                        db.insertWithOnConflict("mode_directory_urls",null,ContentValues().apply {
                            put("kind",kind);put("record_id",id);put("profile_id",profile);put("url",url)
                        },SQLiteDatabase.CONFLICT_IGNORE)
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun directoryUrl(kind:String,id:Long):String {
        require(kind in setOf("supplier","manufacturer"));recordValues(kind,id)
        return db.rawQuery("SELECT url FROM mode_directory_urls WHERE kind=? AND record_id=? AND profile_id=?",arrayOf(kind,id.toString(),profileId.toString())).use {if(it.moveToFirst())it.getString(0) else ""}
    }
    fun setDirectoryUrl(kind:String,id:Long,url:String) {
        require(kind in setOf("supplier","manufacturer"));recordValues(kind,id)
        val normalized=url.trim()
        require(normalized.isEmpty() || BusinessRecordRules.isHttpUrl(normalized)) {"Use a valid http(s) website URL"}
        db.insertWithOnConflict("mode_directory_urls",null,ContentValues().apply {put("kind",kind);put("record_id",id);put("profile_id",profileId);put("url",normalized)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun tripDistanceLabel(metres:Long):String = BusinessRecordRules.distanceLabel(metres,preferredMetric())

    fun supplierChoices(): List<Choice> = rows(
        "SELECT id,name FROM supplier WHERE profile_id=? ORDER BY name", arrayOf(profileId.toString())
    ) { Choice(it.getLong(0), it.s(1)) }

    fun reportRows(type: String): List<ListRow> = when(type) {
        "revenue" -> rows("SELECT substr(created_date,1,7),COUNT(*),COALESCE(SUM(total_amount),0) FROM invoice WHERE profile_id=? GROUP BY substr(created_date,1,7) ORDER BY 1 DESC",arrayOf(profileId.toString())){ListRow(0,it.s(0),"${it.i(1)} invoices",MoneyMath.format(it.l(2)))}
        "receivables" -> rows("SELECT i.id,COALESCE(i.invoice_num,'Invoice'),COALESCE(c.name,'Customer'),i.total_amount-COALESCE((SELECT SUM(a.amount) FROM debtor_payment_allocation a WHERE a.invoice_id=i.id),0) FROM invoice i LEFT JOIN customer c ON c.id=i.billing_customer_id WHERE i.profile_id=? AND i.paid=0 ORDER BY i.due_date",arrayOf(profileId.toString())){ListRow(it.getLong(0),it.s(1),it.s(2),MoneyMath.format(it.l(3)))}
        "expenses" -> rows("SELECT substr(receipt_date,1,7),COUNT(*),COALESCE(SUM(total_including_tax),0) FROM receipt WHERE profile_id=? GROUP BY substr(receipt_date,1,7) ORDER BY 1 DESC",arrayOf(profileId.toString())){ListRow(0,it.s(0),"${it.i(1)} receipts",MoneyMath.format(it.l(2)))}
        else -> emptyList()
    }

    fun system(): Map<String, Any?> = db.rawQuery("SELECT * FROM system LIMIT 1",null).use { c ->
        check(c.moveToFirst()); buildMap { for(i in 0 until c.columnCount) put(c.getColumnName(i), when(c.getType(i)){Cursor.FIELD_TYPE_NULL->null;Cursor.FIELD_TYPE_INTEGER->c.getLong(i);Cursor.FIELD_TYPE_FLOAT->c.getDouble(i);else->c.getString(i)}) }
    }

    fun updateSystem(values: Map<String, Any?>) {
        val allowed=db.rawQuery("PRAGMA table_info(system)",null).use{c->buildSet{while(c.moveToNext()) add(c.getString(1))}}
        val cv=ContentValues(); values.forEach{(k,v)-> if(k in allowed && k!="id" && k!="created_date") when(v){null->cv.putNull(k);is String->cv.put(k,v);is Int->cv.put(k,v);is Long->cv.put(k,v);is Double->cv.put(k,v);is Boolean->cv.put(k,if(v)1 else 0)}}
        cv.put("modified_date",now()); db.update("system",cv,null,null); profiles.saveActive()
    }

    fun preferredMetric(): Boolean = (system()["use_metric_units"] as? Number)?.toInt() != 0
    fun setPreferredMetric(metric: Boolean) = updateSystem(mapOf("use_metric_units" to if(metric)1 else 0))

    fun customerChoices(): List<Choice> = rows("SELECT id,name FROM customer WHERE profile_id=? ORDER BY name",arrayOf(profileId.toString())){Choice(it.getLong(0),it.s(1))}
    fun jobChoices(): List<Choice> = rows("SELECT id,summary FROM job WHERE profile_id=? ORDER BY modified_date DESC",arrayOf(profileId.toString())){Choice(it.getLong(0),it.s(1))}
    fun taskChoices(jobId: Long): List<Choice> = rows("SELECT id,name FROM task WHERE job_id=? ORDER BY id",arrayOf(jobId.toString())){Choice(it.getLong(0),it.s(1))}

    fun deleteOwned(table: String, id: Long) {
        require(table in setOf("customer","contact","job","quote","invoice","supplier","manufacturer","tool","to_do","receipt","trip_log"))
        check(db.delete(table,"id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString()))==1)
    }

    /** Profile-scoped record actions. Child activities are scoped through their parent job. */
    fun recordValues(table: String, id: Long): Map<String, String> {
        val allowed = setOf("customer","contact","job","quote","invoice","to_do","job_activity","supplier","manufacturer","tool","receipt","trip_log")
        require(table in allowed)
        val sql = if (table == "job_activity") "SELECT a.* FROM job_activity a JOIN job j ON j.id=a.job_id WHERE a.id=? AND j.profile_id=?" else if(table == "contact") "SELECT c.* FROM contact c JOIN customer u ON u.id=c.customer_id WHERE c.id=? AND u.profile_id=?" else "SELECT * FROM $table WHERE id=? AND profile_id=?"
        return db.rawQuery(sql,arrayOf(id.toString(),profileId.toString())).use { c ->
            check(c.moveToFirst()) { "Record not found in active profile" }
            (0 until c.columnCount).associate { i -> c.getColumnName(i) to (if(c.isNull(i)) "" else c.getString(i)) }
        }
    }

    /** Only descriptive fields are editable through the generic editor. Financial and
     * relational fields must be changed through their dedicated, validated workflows. */
    private val genericEditable = mapOf(
        "customer" to setOf("name","email","phone","address","notes"),
        "contact" to setOf("name","email","phone","notes"),
        "job" to setOf("summary","description","notes"),
        "quote" to setOf("notes","terms"),
        "invoice" to setOf("notes","terms"),
        "to_do" to setOf("title","notes","description","priority","status"),
        "job_activity" to setOf("name","description","notes"),
        "supplier" to setOf("name","description","contactNumber","email","address"),
        "manufacturer" to setOf("name","description","contactNumber","email","address"),
        "tool" to setOf("name","description","location","lent_to"),
        "receipt" to emptySet(),
        "trip_log" to setOf("purpose","from_address")
    )

    fun editableFields(table: String, id: Long): Map<String,String> {
        val record = recordValues(table,id)
        return record.filterKeys { it in genericEditable.getValue(table) }
    }

    fun updateRecord(table: String, id: Long, changes: Map<String,String>) {
        val original = recordValues(table,id)
        val permitted = genericEditable.getValue(table).intersect(original.keys)
        require(changes.isNotEmpty() && changes.keys.all { it in permitted }) { "Unsupported edit; use the dedicated form" }
        val cv=ContentValues()
        changes.forEach { (key,value) ->
            require(value.length <= 10000) { "Field too long: $key" }
            if(key in setOf("name","title","summary") || (key=="purpose" && table=="trip_log"))
                require(value.isNotBlank()) { "$key cannot be empty" }
            cv.put(key,value.trim())
        }
        val modified=if("modified_date" in original) "modified_date" else if("modifiedDate" in original) "modifiedDate" else null
        if(modified!=null) cv.put(modified,now())
        val where=if(table=="job_activity") "id=? AND job_id IN (SELECT id FROM job WHERE profile_id=?)" else if(table=="contact") "id=? AND customer_id IN (SELECT id FROM customer WHERE profile_id=?)" else "id=? AND profile_id=?"
        db.beginTransaction()
        try {
            check(db.update(table,cv,where,arrayOf(id.toString(),profileId.toString()))==1)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun deleteRecord(table:String,id:Long) {
        recordValues(table,id)
        // Financial records and entities with dependent business records must never be
        // silently cascade-deleted from the generic record menu.
        require(table !in setOf("invoice","quote","receipt","customer","job")) {
            "Deletion is restricted for records with financial or dependent history; archive or use a dedicated workflow"
        }
        val where=if(table=="job_activity") "id=? AND job_id IN (SELECT id FROM job WHERE profile_id=?)" else if(table=="contact") "id=? AND customer_id IN (SELECT id FROM customer WHERE profile_id=?)" else "id=? AND profile_id=?"
        db.beginTransaction()
        try {
            check(db.delete(table,where,arrayOf(id.toString(),profileId.toString()))==1)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun copyRecord(table:String,id:Long):Long {
        val values=recordValues(table,id)
        // Cloning financial and relational entities needs a dedicated business workflow.
        require(table in setOf("to_do","supplier","manufacturer","tool","trip_log")) {
            "Copying this record requires a dedicated workflow to preserve linked data"
        }
        val writable=ContentValues()
        values.forEach { (col,v) ->
            if(col !in setOf("id","created_date","modified_date","createdDate","modifiedDate")) {
                if(col in setOf("name","title","purpose")) writable.put(col,"$v (copy)")
                else if(v.isEmpty()) writable.putNull(col) else writable.put(col,v)
            }
        }
        val timestamp=now()
        if("created_date" in values) writable.put("created_date",timestamp)
        if("modified_date" in values) writable.put("modified_date",timestamp)
        if("createdDate" in values) writable.put("createdDate",timestamp)
        if("modifiedDate" in values) writable.put("modifiedDate",timestamp)
        db.beginTransaction()
        return try {
            val newId=db.insertOrThrow(table,null,writable)
            db.setTransactionSuccessful()
            newId
        } finally { db.endTransaction() }
    }

    private fun ownsJob(id: Long): Boolean = db.rawQuery("SELECT 1 FROM job WHERE id=? AND profile_id=?",arrayOf(id.toString(),profileId.toString())).use{it.moveToFirst()}
    private fun paymentTerms(): Int = db.rawQuery("SELECT COALESCE(payment_terms_in_days,14) FROM system LIMIT 1",null).use{it.moveToFirst();it.getInt(0)}
    private fun scalar(sql: String): Int = db.rawQuery(sql,arrayOf(profileId.toString())).use{it.moveToFirst();it.getInt(0)}
    private fun scalarRaw(sql: String): Int = db.rawQuery(sql,null).use{it.moveToFirst();it.getInt(0)}
    private fun <T> rows(sql:String,args:Array<String>,mapper:(Cursor)->T):List<T> = db.rawQuery(sql,args).use{c->buildList{while(c.moveToNext()) add(mapper(c))}}
    private fun Cursor.s(i:Int)=if(isNull(i)) "" else getString(i)
    private fun Cursor.l(i:Int)=if(isNull(i)) 0L else getLong(i)
    private fun Cursor.i(i:Int)=if(isNull(i)) 0 else getInt(i)
    private fun taskStatusName(id:Int)=listOf("","Awaiting Approval","Approved","In Progress","Awaiting Materials","On Hold","Completed","Cancelled").getOrElse(id){"Unknown"}
}
