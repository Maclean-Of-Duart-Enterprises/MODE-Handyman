package com.macleanofduartenterprises.modehandyman.core

import java.math.BigDecimal
import java.math.RoundingMode

data class JobIdentity(val id: Long, val title: String)

data class JobLinkDecision(
    val jobId: Long?,
    val status: String,
    val note: String
)

data class EstimateComponent(
    val kind: String,
    val description: String,
    val quantityThousandths: Long,
    val unit: String,
    val unitCents: Long,
    val lineTotalCents: Long
)

object SmartToolsLogic {
    private val explicitId = Regex("^#?(\\d+)(?:\\s*[·:-].*)?$")

    /** Only an exact, unique match is eligible for automatic migration. */
    fun resolveJob(reference: String, jobs: List<JobIdentity>): JobLinkDecision {
        val clean = reference.trim()
        if (clean.isEmpty()) return JobLinkDecision(null, "unresolved", "No legacy job reference")
        explicitId.matchEntire(clean)?.groupValues?.get(1)?.toLongOrNull()?.let { id ->
            val matches = jobs.filter { it.id == id }
            return when (matches.size) {
                1 -> JobLinkDecision(id, "verified", "Verified exact job identifier")
                else -> JobLinkDecision(null, "unresolved", "Job identifier does not exist in this business profile")
            }
        }
        val normalized = clean.lowercase().replace(Regex("\\s+"), " ")
        val matches = jobs.filter { it.title.trim().lowercase().replace(Regex("\\s+"), " ") == normalized }
        return when (matches.size) {
            1 -> JobLinkDecision(matches.single().id, "verified", "Verified unique exact job title")
            0 -> JobLinkDecision(null, "unresolved", "No exact job match; manual reconciliation required")
            else -> JobLinkDecision(null, "ambiguous", "Multiple jobs have this title; manual reconciliation required")
        }
    }

    fun estimateComponents(
        title: String,
        category: String,
        quantity: Double,
        unit: String,
        materialCents: Long,
        laborHours: Double,
        hourlyCents: Long,
        totalCents: Long
    ): List<EstimateComponent> {
        require(quantity.isFinite() && quantity > 0)
        require(laborHours.isFinite() && laborHours >= 0)
        require(materialCents >= 0 && hourlyCents >= 0 && totalCents >= 0)
        val laborQuantity = BigDecimal.valueOf(laborHours).movePointRight(3)
            .setScale(0, RoundingMode.HALF_UP).longValueExact()
        val laborTotal = MoneyMath.lineTotal(laborQuantity, hourlyCents)
        val base = Math.addExact(materialCents, laborTotal)
        require(totalCents >= base) { "Estimate total is smaller than its material and labor components" }
        val scope = listOf(category.trim(), title.trim()).filter(String::isNotBlank).joinToString(" — ")
            .ifBlank { "Estimate" }
        return buildList {
            if (materialCents > 0) add(EstimateComponent(
                "material", "Materials — $scope (${quantity.clean()} ${unit.trim().ifBlank { "units" }})",
                1000, "total", materialCents, materialCents
            ))
            if (laborTotal > 0) add(EstimateComponent(
                "labor", "Labor — $scope", laborQuantity, "hours", hourlyCents, laborTotal
            ))
            val markup = totalCents - base
            if (markup > 0) add(EstimateComponent(
                "markup", "Markup / overhead — $scope", 1000, "total", markup, markup
            ))
            if (isEmpty()) add(EstimateComponent("other", scope, 1000, "total", 0, 0))
        }.also { parts ->
            require(parts.fold(0L) { sum, part -> Math.addExact(sum, part.lineTotalCents) } == totalCents)
        }
    }

    private fun Double.clean(): String = BigDecimal.valueOf(this).stripTrailingZeros().toPlainString()
}
