package com.macleanofduartenterprises.modehandyman.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.text.TextWatcher
import android.text.Editable
import android.view.MotionEvent
import android.view.WindowManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.macleanofduartenterprises.modehandyman.R
import java.math.BigDecimal
import java.math.MathContext

/** In-app calculator: no overlay permission, network access, or external dependencies. */
object FloatingCalculator {
    private class CalculatorButton(context: Context) : Button(context) {
        override fun performClick(): Boolean = super.performClick()
    }

    private const val PREFS = "mode_calculator_preferences"
    private const val ENABLED = "floating_enabled"
    fun enabled(activity: Activity): Boolean = activity.getSharedPreferences(PREFS, 0).getBoolean(ENABLED, true)
    fun setEnabled(activity: Activity, value: Boolean) = activity.getSharedPreferences(PREFS, 0).edit().putBoolean(ENABLED, value).commit()

    private const val EXPRESSION = "expression"
    private const val POS_X = "position_x"
    private const val POS_Y = "position_y"
    private fun prefs(activity: Activity) = activity.getSharedPreferences(PREFS, 0)
    private fun dp(activity: Activity, value: Int) = (value * activity.resources.displayMetrics.density).toInt()

    fun install(activity: Activity): Button {
        val root = activity.window.decorView.findViewById<ViewGroup>(android.R.id.content) as FrameLayout
        val button = CalculatorButton(activity).apply {
            setText(R.string.calculator_symbol)
            textSize = 20f
            isAllCaps = false
            contentDescription = activity.getString(R.string.calculator_open_description)
            elevation = dp(activity, 8).toFloat()
            minWidth = 0; minHeight = 0
            setPadding(0, 0, 0, 0)
        }
        val size = dp(activity, 48)
        val margin = dp(activity, 16)
        val params = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START)
        root.addView(button, params)
        fun place() {
            val maxX = (root.width - size).coerceAtLeast(0)
            val maxY = (root.height - size).coerceAtLeast(0)
            val x = prefs(activity).getInt(POS_X, maxX - margin).coerceIn(0, maxX)
            val y = prefs(activity).getInt(POS_Y, maxY - margin).coerceIn(0, maxY)
            button.x = x.toFloat(); button.y = y.toFloat()
        }
        root.post { place() }
        var startX = 0f; var startY = 0f; var touchX = 0f; var touchY = 0f; var moved = false
        button.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = button.x; startY = button.y
                    touchX = event.rawX; touchY = event.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX; val dy = event.rawY - touchY
                    if (kotlin.math.abs(dx) > dp(activity, 6) || kotlin.math.abs(dy) > dp(activity, 6)) moved = true
                    if (moved) {
                        button.x = (startX + dx).coerceIn(0f, (root.width - size).coerceAtLeast(0).toFloat())
                        button.y = (startY + dy).coerceIn(0f, (root.height - size).coerceAtLeast(0).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs(activity).edit().putInt(POS_X, button.x.toInt()).putInt(POS_Y, button.y.toInt()).apply()
                    else button.performClick()
                    true
                }
                else -> false
            }
        }
        button.setOnClickListener { show(activity) }
        button.visibility = if (enabled(activity)) View.VISIBLE else View.GONE
        return button
    }

    fun show(activity: Activity) {
        // A compact, non-fullscreen dialog; the floating launcher remains behind it.
        val column = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 10), dp(activity, 6), dp(activity, 10), dp(activity, 8))
        }
        val header = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(activity).apply { setText(R.string.calculator_title); textSize = 17f }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = Button(activity).apply { setText(R.string.calculator_close_symbol); contentDescription = activity.getString(R.string.calculator_close_description); textSize = 20f; minHeight = 0; minWidth = 0 }
        header.addView(close, LinearLayout.LayoutParams(dp(activity, 44), dp(activity, 44)))
        column.addView(header)
        val display = EditText(activity).apply {
            setSingleLine(true)
            textSize = 23f
            hint = "0"
            setText(prefs(activity).getString(EXPRESSION, ""))
            setSelection(length())
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            showSoftInputOnFocus = false
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    prefs(activity).edit().putString(EXPRESSION, s?.toString().orEmpty()).apply()
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        column.addView(display)
        val grid = GridLayout(activity).apply { columnCount = 4 }
        val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "C", "0", ".", "+", "⌫", "(", ")", "=")
        keys.forEach { key ->
            grid.addView(Button(activity).apply {
                text = key; isAllCaps = false; textSize = 17f
                minHeight = 0; minWidth = 0; setPadding(0, 0, 0, 0)
                setOnClickListener {
                    when (key) {
                        "C" -> display.setText("")
                        "⌫" -> display.setText(display.text.toString().dropLast(1))
                        "=" -> runCatching { calculate(display.text.toString()) }
                            .onSuccess { display.setText(it); display.setSelection(display.length()) }
                            .onFailure { display.error = it.message ?: "Invalid expression" }
                        else -> { val at = display.selectionStart.coerceAtLeast(0); display.text.insert(at, key) }
                    }
                }
            }, GridLayout.LayoutParams().apply {
                width = 0; height = dp(activity, 43)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
        column.addView(grid)
        val copy = Button(activity).apply {
            setText(R.string.calculator_copy_result); isAllCaps = false
            setOnClickListener {
                val value = runCatching { calculate(display.text.toString()) }.getOrElse { display.text.toString() }
                val clipboard = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Calculator result", value))
            }
        }
        column.addView(copy)
        val dialog = AlertDialog.Builder(activity).setView(column).create()
        close.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { prefs(activity).edit().putString(EXPRESSION, display.text.toString()).apply() }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        dialog.show()
        dialog.window?.setLayout(dp(activity, 292).coerceAtMost(activity.resources.displayMetrics.widthPixels - dp(activity, 20)), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    /** Recursive descent parser; supports parentheses, unary minus and operator precedence. */
    internal fun calculate(expression: String): String {
        val source = expression.replace('×', '*').replace('÷', '/').replace('−', '-')
        require(source.length <= 200) { "Expression too long" }
        var i = 0
        fun skip() { while (i < source.length && source[i].isWhitespace()) i++ }
        lateinit var expr: () -> BigDecimal
        lateinit var term: () -> BigDecimal
        lateinit var factor: () -> BigDecimal
        factor = {
            skip()
            val sign = if (i < source.length && (source[i] == '-' || source[i] == '+')) source[i++] else '+'
            skip()
            val value = if (i < source.length && source[i] == '(') {
                i++; val result = expr(); skip(); require(i < source.length && source[i] == ')') { "Missing )" }; i++; result
            } else {
                val start = i
                while (i < source.length && (source[i].isDigit() || source[i] == '.')) i++
                require(i > start) { "Expected number" }
                source.substring(start, i).toBigDecimal()
            }
            if (sign == '-') value.negate() else value
        }
        term = {
            var value = factor(); skip()
            while (i < source.length && (source[i] == '*' || source[i] == '/')) {
                val op = source[i++]; val right = factor()
                value = if (op == '*') value.multiply(right) else value.divide(right, MathContext.DECIMAL64)
                skip()
            }
            value
        }
        expr = {
            var value = term(); skip()
            while (i < source.length && (source[i] == '+' || source[i] == '-')) {
                val op = source[i++]; val right = term()
                value = if (op == '+') value.add(right) else value.subtract(right)
                skip()
            }
            value
        }
        val result = expr(); skip(); require(i == source.length) { "Unexpected character" }
        return result.stripTrailingZeros().toPlainString()
    }
}
