package com.macleanofduartenterprises.modehandyman.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase

object SqlScripts {
    fun executeAsset(context: Context, db: SQLiteDatabase, name: String) {
        val sql = context.assets.open(name).bufferedReader().use { it.readText() }
        split(sql).forEach { statement -> db.execSQL(statement) }
    }

    internal fun split(script: String): List<String> {
        val statements = mutableListOf<String>()
        val current = StringBuilder()
        var single = false
        var double = false
        var lineComment = false
        var blockComment = false
        var i = 0
        while (i < script.length) {
            val c = script[i]
            val next = script.getOrNull(i + 1)
            if (lineComment) {
                if (c == '\n') {
                    lineComment = false
                    current.append(c)
                }
                i++
                continue
            }
            if (blockComment) {
                if (c == '*' && next == '/') {
                    blockComment = false
                    i += 2
                } else i++
                continue
            }
            if (!single && !double && c == '-' && next == '-') {
                lineComment = true
                i += 2
                continue
            }
            if (!single && !double && c == '/' && next == '*') {
                blockComment = true
                i += 2
                continue
            }
            if (c == '\'' && !double) {
                if (single && next == '\'') {
                    current.append("''")
                    i += 2
                    continue
                }
                single = !single
                current.append(c)
            } else if (c == '"' && !single) {
                double = !double
                current.append(c)
            } else if (c == ';' && !single && !double) {
                current.toString().trim().takeIf { it.isNotEmpty() }?.let(statements::add)
                current.clear()
            } else current.append(c)
            i++
        }
        current.toString().trim().takeIf { it.isNotEmpty() }?.let(statements::add)
        require(!single && !double && !blockComment) { "Unterminated SQL token" }
        return statements
    }
}
