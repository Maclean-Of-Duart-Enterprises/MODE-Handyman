package com.macleanofduartenterprises.modehandyman.diagnostics

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.concurrent.atomic.AtomicBoolean

object LocalCrashReporter {
    private const val MAX_REPORTS = 20
    private val handling = AtomicBoolean(false)

    fun install(context: Context) {
        val application = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            if (handling.compareAndSet(false, true)) {
                runCatching { write(application, thread, error) }
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun directory(context: Context): File = File(context.filesDir, "crash-reports").apply { mkdirs() }

    fun reports(context: Context): List<File> = directory(context).listFiles()
        ?.filter { it.isFile && it.extension == "json" }
        ?.sortedByDescending { it.lastModified() }
        .orEmpty()

    fun delete(context: Context, file: File): Boolean =
        file.canonicalFile.parentFile == directory(context).canonicalFile && file.delete()

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val now = Instant.now()
        val report = JSONObject().apply {
            put("format", 1)
            put("timestamp", now.toString())
            put("app", "MODE Handyman")
            put("version", "2.0.3 (9)")
            put("thread", redact(thread.name))
            put("exception", redact(error.javaClass.name))
            put("message", redact(error.message.orEmpty()))
            put("stack_trace", redact(error.stackTraceToString()))
            put("android_api", Build.VERSION.SDK_INT)
            put("manufacturer", redact(Build.MANUFACTURER))
            put("model", redact(Build.MODEL))
            put("network_uploaded", false)
        }
        val safeStamp = now.toString().replace(':', '-').replace('.', '-')
        File(directory(context), "crash-$safeStamp.json").writeText(report.toString(2))
        reports(context).drop(MAX_REPORTS).forEach { it.delete() }
    }

    internal fun redact(input: String): String {
        var result = input
        val replacements = listOf(
            Regex("(?i)(password|passwd|secret|token|api[_-]?key|authorization)\\s*[:=]\\s*[^\\s,;]+") to "$1=[REDACTED]",
            Regex("(?i)bearer\\s+[A-Za-z0-9._~+/-]+=*") to "Bearer [REDACTED]",
            Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}") to "[EMAIL REDACTED]",
            Regex("(?<!\\d)(?:\\+?1[-. ]?)?\\(?\\d{3}\\)?[-. ]?\\d{3}[-. ]?\\d{4}(?!\\d)") to "[PHONE REDACTED]"
        )
        replacements.forEach { (regex, replacement) -> result = regex.replace(result, replacement) }
        return result.take(200_000)
    }
}
