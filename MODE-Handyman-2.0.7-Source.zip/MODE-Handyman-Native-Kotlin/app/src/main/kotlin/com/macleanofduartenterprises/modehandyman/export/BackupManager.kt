package com.macleanofduartenterprises.modehandyman.export

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.macleanofduartenterprises.modehandyman.data.DatabaseManager
import com.macleanofduartenterprises.modehandyman.data.SmartToolsStore
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.time.Instant
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {
    private const val MAX_BYTES = 1_000_000_000L
    private const val MAX_ENTRIES = 10_000
    private val directoryNames = listOf("attachments", "job-documents", "exports", "business-logos", "work-note-photos")

    fun export(context: Context, output: OutputStream) {
        val main = context.getDatabasePath(DatabaseManager.DB_NAME)
        checkpoint(main)
        SmartToolsStore(context).use { smart -> smart.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { it.moveToFirst() } }
        ZipOutputStream(output.buffered()).use { zip ->
            addFile(zip,main,"database/${DatabaseManager.DB_NAME}")
            addFile(zip,context.getDatabasePath(SmartToolsStore.DB_NAME),"database/${SmartToolsStore.DB_NAME}")
            directoryNames.forEach { name ->
                zip.putNextEntry(ZipEntry("$name/"));zip.closeEntry()
                val root=File(context.filesDir,name)
                if(root.exists()) root.walkTopDown().filter(File::isFile).forEach { file -> addFile(zip,file,"$name/${file.relativeTo(root).invariantSeparatorsPath}") }
            }
            val preferences=context.getSharedPreferences("mode_native_preferences",Context.MODE_PRIVATE).all
            zip.putNextEntry(ZipEntry("preferences.json"));zip.write(JSONObject(preferences).toString().toByteArray());zip.closeEntry()
            zip.putNextEntry(ZipEntry("backup-info.txt"));zip.write("MODE Handyman native backup\ncreated=${Instant.now()}\nschema=${DatabaseManager.SCHEMA_VERSION}\nsmartSchema=${SmartToolsStore.SCHEMA_VERSION}\n".toByteArray());zip.closeEntry()
        }
    }

    fun validate(input: InputStream): Pair<Boolean,String> {
        var databaseFound=false;var entries=0;var bytes=0L
        ZipInputStream(input.buffered()).use { zip ->
            while(true) {
                val entry=zip.nextEntry?:break;entries++;if(entries>MAX_ENTRIES)return false to "Backup contains too many entries"
                val safe=entry.name.replace('\\','/');if(!safePath(safe))return false to "Unsafe path in backup"
                if(safe=="database/${DatabaseManager.DB_NAME}")databaseFound=true
                val buffer=ByteArray(32*1024);while(true){val count=zip.read(buffer);if(count<0)break;bytes+=count;if(bytes>MAX_BYTES)return false to "Backup is too large"};zip.closeEntry()
            }
        }
        return if(databaseFound) true to "$entries entries validated" else false to "Database entry is missing"
    }

    fun restore(context: Context,input: InputStream,manager: DatabaseManager) {
        val staging=File(context.cacheDir,"restore-staging-${System.currentTimeMillis()}").apply{mkdirs()}
        try {
            extract(input,staging)
            val stagedMain=File(staging,"database/${DatabaseManager.DB_NAME}")
            require(stagedMain.isFile){"Backup database is missing"}
            SQLiteDatabase.openDatabase(stagedMain.absolutePath,null,SQLiteDatabase.OPEN_READONLY).use { database ->
                val version=database.version;require(version in 225..DatabaseManager.SCHEMA_VERSION){"Unsupported backup schema $version"}
                require(check(database,"PRAGMA integrity_check","ok")){"Backup database is corrupt"}
                if(version>=228) require(noRows(database,"PRAGMA foreign_key_check")){"Backup database has invalid relationships"}
            }
            val stagedSmart=File(staging,"database/${SmartToolsStore.DB_NAME}")
            if(stagedSmart.isFile) SQLiteDatabase.openDatabase(stagedSmart.absolutePath,null,SQLiteDatabase.OPEN_READONLY).use { database ->
                require(database.version in 1..SmartToolsStore.SCHEMA_VERSION){"Unsupported Smart Tools schema ${database.version}"}
                require(check(database,"PRAGMA integrity_check","ok")){"Smart Tools backup is corrupt"}
            }
            File(staging,"preferences.json").takeIf(File::isFile)?.let { JSONObject(it.readText()) }

            val recovery=File(context.filesDir,"migration-backups/pre-restore-${System.currentTimeMillis()}").apply{mkdirs()}
            manager.close()
            val currentMain=context.getDatabasePath(DatabaseManager.DB_NAME)
            val currentSmart=context.getDatabasePath(SmartToolsStore.DB_NAME)
            val hadMain=currentMain.isFile;val hadSmart=currentSmart.isFile
            val hadDirectories=directoryNames.associateWith { File(context.filesDir,it).exists() }
            copyIfExists(currentMain,File(recovery,"database/${DatabaseManager.DB_NAME}"))
            copyIfExists(currentSmart,File(recovery,"database/${SmartToolsStore.DB_NAME}"))
            directoryNames.forEach { name -> File(context.filesDir,name).takeIf(File::exists)?.copyRecursively(File(recovery,name),overwrite=true) }
            val oldPreferences=JSONObject(context.getSharedPreferences("mode_native_preferences",Context.MODE_PRIVATE).all).toString()
            File(recovery,"preferences.json").writeText(oldPreferences)

            try {
                replaceDatabase(stagedMain,currentMain)
                if(stagedSmart.isFile) replaceDatabase(stagedSmart,currentSmart)
                directoryNames.forEach { name ->
                    val source=File(staging,name);if(source.exists()){val target=File(context.filesDir,name);target.deleteRecursively();source.copyRecursively(target,overwrite=true)}
                }
                File(staging,"preferences.json").takeIf(File::isFile)?.let { restorePreferences(context,JSONObject(it.readText())) }
                val opened=manager.open()
                require(check(opened,"PRAGMA integrity_check","ok")&&noRows(opened,"PRAGMA foreign_key_check")){"Restored database verification failed"}
                SmartToolsStore(context).use { smart ->
                    require(check(smart.readableDatabase,"PRAGMA integrity_check","ok")){"Restored Smart Tools verification failed"}
                }
            } catch(error:Throwable) {
                manager.close()
                if(hadMain)copyIfExists(File(recovery,"database/${DatabaseManager.DB_NAME}"),currentMain,true) else currentMain.delete()
                if(hadSmart)copyIfExists(File(recovery,"database/${SmartToolsStore.DB_NAME}"),currentSmart,true) else currentSmart.delete()
                directoryNames.forEach { name ->
                    val saved=File(recovery,name);val target=File(context.filesDir,name);target.deleteRecursively()
                    if(hadDirectories.getValue(name)&&saved.exists())saved.copyRecursively(target,overwrite=true)
                }
                File(recovery,"preferences.json").takeIf(File::isFile)?.let { restorePreferences(context,JSONObject(it.readText())) }
                manager.open()
                throw IllegalStateException("Restore failed and the pre-restore data was recovered",error)
            }
        } finally { staging.deleteRecursively() }
    }

    private fun extract(input:InputStream,staging:File) {
        var entries=0;var total=0L
        ZipInputStream(input.buffered()).use { zip -> while(true) {
            val entry=zip.nextEntry?:break;entries++;require(entries<=MAX_ENTRIES){"Backup contains too many entries"}
            val relative=entry.name.replace('\\','/');require(safePath(relative)){"Unsafe path in backup"}
            val allowed=relative=="database/${DatabaseManager.DB_NAME}"||relative=="database/${SmartToolsStore.DB_NAME}"||relative=="preferences.json"||directoryNames.any{relative=="$it/"||relative.startsWith("$it/")}
            if(allowed){val destination=File(staging,relative).canonicalFile;require(destination.path.startsWith(staging.canonicalPath+File.separator)){"Unsafe restore path"}
                if(entry.isDirectory)destination.mkdirs() else {destination.parentFile?.mkdirs();destination.outputStream().use { output -> val buffer=ByteArray(32*1024);while(true){val count=zip.read(buffer);if(count<0)break;total+=count;require(total<=MAX_BYTES){"Backup is too large"};output.write(buffer,0,count)} }}
            } else { val buffer=ByteArray(32*1024);while(zip.read(buffer)>=0){} }
            zip.closeEntry()
        } }
    }

    private fun restorePreferences(context:Context,json:JSONObject) {
        val editor=context.getSharedPreferences("mode_native_preferences",Context.MODE_PRIVATE).edit().clear()
        json.keys().forEach { key -> when(val value=json.get(key)){is Boolean->editor.putBoolean(key,value);is Int->editor.putInt(key,value);is Long->editor.putLong(key,value);is Number->editor.putFloat(key,value.toFloat());else->editor.putString(key,value.toString())} }
        check(editor.commit()){"Preferences could not be restored"}
    }
    private fun checkpoint(file:File){if(!file.isFile)return;SQLiteDatabase.openDatabase(file.absolutePath,null,SQLiteDatabase.OPEN_READWRITE).use{db->db.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{it.moveToFirst()}}}
    private fun replaceDatabase(source:File,target:File){target.parentFile?.mkdirs();listOf("-wal","-shm").forEach{File(target.absolutePath+it).delete()};source.copyTo(target,overwrite=true)}
    private fun copyIfExists(source:File,target:File,overwrite:Boolean=false){if(source.isFile){target.parentFile?.mkdirs();source.copyTo(target,overwrite=overwrite)}}
    private fun safePath(path:String)=path.isNotBlank()&&!path.startsWith("/")&&path.split('/').none{it==".."}
    private fun check(db:SQLiteDatabase,sql:String,expected:String)=db.rawQuery(sql,null).use{it.moveToFirst()&&it.getString(0)==expected}
    private fun noRows(db:SQLiteDatabase,sql:String)=db.rawQuery(sql,null).use{!it.moveToFirst()}
    private fun addFile(zip:ZipOutputStream,file:File,name:String){if(!file.isFile)return;zip.putNextEntry(ZipEntry(name));file.inputStream().use{it.copyTo(zip)};zip.closeEntry()}
}
