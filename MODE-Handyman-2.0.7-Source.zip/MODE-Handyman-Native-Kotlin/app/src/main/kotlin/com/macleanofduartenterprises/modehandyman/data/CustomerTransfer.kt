package com.macleanofduartenterprises.modehandyman.data

import org.json.JSONArray
import org.json.JSONObject

/** RFC-4180-compatible quoting for contact-only transfers; never includes financial fields. */
object CustomerTransfer {
    private val headers = listOf("transfer_id", "name", "notes", "custom_fields", "first", "last", "email", "phone", "alternate_email", "business_name", "billing_address", "service_address")
    fun toCsv(payload: JSONObject): String {
        val output = StringBuilder(headers.joinToString(",") + "\r\n")
        val customers = payload.getJSONArray("customers")
        for (i in 0 until customers.length()) {
            val transferId = (i + 1).toString()
            val customer = customers.getJSONObject(i)
            val contacts = customer.optJSONArray("contacts") ?: JSONArray()
            val count = maxOf(1, contacts.length())
            for (j in 0 until count) {
                val contact = if (j < contacts.length()) contacts.getJSONObject(j) else JSONObject()
                val fields = headers.map { key -> if (key == "transfer_id") transferId else if (key in listOf("name", "notes", "custom_fields", "business_name", "billing_address", "service_address")) customer.optString(key) else contact.optString(key) }
                output.append(fields.joinToString(",") { "\"" + it.replace("\"", "\"\"") + "\"" }).append("\r\n")
            }
        }
        return output.toString()
    }
    fun fromCsv(text: String): JSONObject {
        require(text.length <= 8_000_000) { "CSV too large" }
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>(); val field = StringBuilder(); var quoted = false; var index = 0
        while (index < text.length) {
            val ch = text[index]
            when {
                ch == '"' && quoted && index + 1 < text.length && text[index+1] == '"' -> { field.append('"'); index++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { row.add(field.toString()); field.setLength(0) }
                (ch == '\n' || ch == '\r') && !quoted -> {
                    row.add(field.toString()); field.setLength(0)
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    row = mutableListOf()
                    if (ch == '\r' && index + 1 < text.length && text[index+1] == '\n') index++
                }
                else -> field.append(ch)
            }
            index++
        }
        require(!quoted) { "Unclosed CSV quote" }
        if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString()); rows.add(row) }
        require(rows.isNotEmpty() && rows.first() == headers) { "Unsupported CSV headers" }
        val customers = JSONArray(); val grouped = linkedMapOf<String, JSONObject>()
        rows.drop(1).forEach { values ->
            require(values.size == headers.size) { "Invalid CSV column count" }
            val data = headers.zip(values).toMap(); val name = data.getValue("name").trim()
            require(name.isNotBlank()) { "Missing customer name" }
            val customer = grouped.getOrPut(data.getValue("transfer_id")) { JSONObject().put("name", name).put("notes",data.getValue("notes")).put("custom_fields",data.getValue("custom_fields")).put("business_name",data.getValue("business_name")).put("billing_address",data.getValue("billing_address")).put("service_address",data.getValue("service_address")).put("contacts",JSONArray()) }
            if (listOf("first","last","email","phone","alternate_email").any { data.getValue(it).isNotBlank() }) {
                val contact = JSONObject(); listOf("first","last","email","phone","alternate_email").forEach { contact.put(it,data.getValue(it)) }
                customer.getJSONArray("contacts").put(contact)
            }
        }
        grouped.values.forEach { customers.put(it) }
        return JSONObject().put("format","mode-customer-contacts").put("version",1).put("customers",customers)
    }
}
