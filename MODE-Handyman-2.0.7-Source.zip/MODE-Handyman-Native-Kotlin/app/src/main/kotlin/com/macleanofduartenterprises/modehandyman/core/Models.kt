package com.macleanofduartenterprises.modehandyman.core

data class ListRow(
    val id: Long,
    val title: String,
    val subtitle: String = "",
    val trailing: String = "",
    val status: String = ""
)

data class Choice(val id: Long, val label: String)

data class CustomerDraft(
    val id: Long? = null,
    val name: String,
    val description: String = "",
    val groups: String = "",
    val customFields: String = "",
    val defaultHourlyRateCents: Long = 0
)

data class ContactDraft(
    val id: Long? = null,
    val firstName: String,
    val surname: String,
    val email: String = "",
    val phone: String = "",
    val alternateEmail: String = ""
)

data class JobDraft(
    val id: Long? = null,
    val customerId: Long?,
    val summary: String,
    val description: String = "",
    val notes: String = "",
    val billingType: String = "timeAndMaterial",
    val status: String = "Prospecting",
    val hourlyRateCents: Long = 0,
    val bookingFeeCents: Long = 0
)

data class DocumentLine(
    val id: Long? = null,
    val description: String,
    val quantityThousandths: Long,
    val unitCents: Long,
    val totalCents: Long = MoneyMath.lineTotal(quantityThousandths, unitCents)
)

data class QuoteSummary(
    val id: Long,
    val number: String,
    val customer: String,
    val job: String,
    val state: String,
    val subtotalCents: Long,
    val discountCents: Long,
    val taxHundredths: Int,
    val totalCents: Long,
    val terms: String,
    val validUntil: String?
)

data class InvoiceSummary(
    val id: Long,
    val number: String,
    val customer: String,
    val job: String,
    val dueDate: String?,
    val totalCents: Long,
    val paid: Boolean,
    val paidCents: Long = 0,
    val balanceCents: Long = 0
)

data class ContractLink(
    val profileId: Long,
    val customerId: Long,
    val customerName: String,
    val jobId: Long,
    val jobTitle: String,
    val quoteId: Long,
    val quoteNumber: String
)
