package com.macleanofduartenterprises.modehandyman.export

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

class SecureExportProvider : ContentProvider() {
    companion object {
        fun uriFor(context: Context, file: File): Uri {
            val root = permittedRoot(context, file)
                ?: throw SecurityException("Only generated exports and local crash reports may be shared")
            return Uri.Builder()
                .scheme("content")
                .authority("${context.packageName}.provider")
                .appendPath(root.name)
                .appendPath(file.name)
                .build()
        }

        private fun permittedRoot(context: Context, file: File): File? {
            val candidate = file.canonicalFile
            return listOf(File(context.filesDir, "exports"), File(context.filesDir, "crash-reports"))
                .map { it.canonicalFile }
                .firstOrNull { candidate.parentFile == it }
        }
    }

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        require(mode == "r") { "Write access is not permitted" }
        val file = resolve(uri)
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String = when (resolve(uri).extension.lowercase()) {
        "pdf" -> "application/pdf"
        "zip" -> "application/zip"
        "csv" -> "text/csv"
        "json" -> "application/json"
        else -> "application/octet-stream"
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val file = resolve(uri)
        val columns = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val cursor = MatrixCursor(columns)
        cursor.addRow(columns.map {
            when (it) {
                OpenableColumns.DISPLAY_NAME -> file.name
                OpenableColumns.SIZE -> file.length()
                else -> null
            }
        })
        return cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()

    private fun resolve(uri: Uri): File {
        val app = context ?: throw SecurityException("Provider unavailable")
        require(uri.authority == "${app.packageName}.provider")
        val segments = uri.pathSegments
        require(segments.size == 2)
        val root = when (segments[0]) {
            "exports" -> File(app.filesDir, "exports")
            "crash-reports" -> File(app.filesDir, "crash-reports")
            else -> throw SecurityException("Invalid export root")
        }.canonicalFile
        val file = File(root, segments[1]).canonicalFile
        require(file.parentFile == root && file.isFile) { "Invalid export file" }
        return file
    }
}
