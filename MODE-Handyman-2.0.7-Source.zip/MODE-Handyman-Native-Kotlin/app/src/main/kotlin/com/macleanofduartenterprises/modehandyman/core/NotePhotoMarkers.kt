package com.macleanofduartenterprises.modehandyman.core

/** Lossless text representation for photographs embedded in work notes. */
object NotePhotoMarkers {
    val pattern = Regex("\\[\\[mode-photo:(\\d+)]]")

    fun marker(photoId: Long): String {
        require(photoId > 0) { "Photo identifier must be positive" }
        return "[[mode-photo:$photoId]]"
    }

    fun photoIds(body: CharSequence): List<Long> = pattern.findAll(body)
        .mapNotNull { it.groupValues[1].toLongOrNull() }
        .toList()

    fun insert(body: String, offset: Int, photoId: Long): String {
        require(offset in 0..body.length) { "Photo insertion position is outside the note" }
        return body.substring(0, offset) + "\n${marker(photoId)}\n" + body.substring(offset)
    }

    fun remove(body: String, photoId: Long): String = body.replace(marker(photoId), "")
}
