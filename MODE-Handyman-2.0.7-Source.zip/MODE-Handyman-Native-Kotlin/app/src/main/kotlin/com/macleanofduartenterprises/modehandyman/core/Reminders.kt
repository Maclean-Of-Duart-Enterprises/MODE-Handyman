package com.macleanofduartenterprises.modehandyman.core

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.macleanofduartenterprises.modehandyman.R
import com.macleanofduartenterprises.modehandyman.ui.MainActivity
import java.time.LocalDateTime
import java.time.ZoneId

object ReminderScheduler {
    const val CHANNEL = "mode_local_reminders"
    fun ensureChannel(context: Context) {
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Local reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Offline job, appointment, and task reminders"
            }
        )
    }

    fun schedule(context: Context, id: Long, title: String, note: String, isoLocalDateTime: String) {
        val trigger = LocalDateTime.parse(isoLocalDateTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        require(trigger > System.currentTimeMillis()) { "Reminder must be in the future" }
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("id", id.toInt()); putExtra("title", title); putExtra("note", note)
        }
        val pending = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.ensureChannel(context)
        val title = intent.getStringExtra("title") ?: "MODE Handyman reminder"
        val note = intent.getStringExtra("note") ?: "Open MODE Handyman for details"
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(context, ReminderScheduler.CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(note)
            .setAutoCancel(true).setContentIntent(open).build()
        context.getSystemService(NotificationManager::class.java).notify(intent.getIntExtra("id", 1), notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.ensureChannel(context)
    }
}
