-- Native Kotlin profile isolation. Existing rows are assigned to the active
-- profile before all subsequent reads are filtered by profile_id.
ALTER TABLE customer ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE contact ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE site ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE supplier ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE manufacturer ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE job ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE quote ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE invoice ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE receipt ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE tool ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE to_do ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE mailing ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE plaster_project ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE trip_log ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE custom_label_layout ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE check_list ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE task_estimate ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);
ALTER TABLE category ADD COLUMN profile_id INTEGER REFERENCES business_profile(id);

UPDATE customer SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE contact SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE site SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE supplier SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE manufacturer SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE job SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE quote SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE invoice SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE receipt SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE tool SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE to_do SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE mailing SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE plaster_project SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE trip_log SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE custom_label_layout SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE check_list SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE task_estimate SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;
UPDATE category SET profile_id=(SELECT id FROM business_profile WHERE active=1 LIMIT 1) WHERE profile_id IS NULL;

DROP INDEX IF EXISTS customer_name;
CREATE UNIQUE INDEX customer_profile_name_unq ON customer(profile_id, name COLLATE NOCASE);
CREATE INDEX customer_profile_idx ON customer(profile_id, name);
CREATE INDEX contact_profile_idx ON contact(profile_id, surname, firstName);
CREATE INDEX site_profile_idx ON site(profile_id, name);
CREATE INDEX supplier_profile_idx ON supplier(profile_id, name);
CREATE INDEX manufacturer_profile_idx ON manufacturer(profile_id, name);
CREATE INDEX job_profile_idx ON job(profile_id, status_id, modified_date);
CREATE INDEX quote_profile_idx ON quote(profile_id, modified_date);
CREATE INDEX invoice_profile_idx ON invoice(profile_id, due_date);
CREATE INDEX receipt_profile_idx ON receipt(profile_id, receipt_date);
CREATE INDEX tool_profile_idx ON tool(profile_id, name);
CREATE INDEX todo_profile_idx ON to_do(profile_id, status, due_date);
CREATE INDEX trip_profile_idx ON trip_log(profile_id, arrived_at);

-- Repair legacy foreign-key targets left behind by historical table rebuilds.
CREATE TABLE task_v228 (
  id INTEGER PRIMARY KEY,
  job_id INTEGER REFERENCES job(id) ON DELETE CASCADE,
  name TEXT,
  description TEXT,
  task_status_id INTEGER,
  createdDate TEXT,
  modifiedDate TEXT,
  billing_type TEXT,
  assumption TEXT NOT NULL DEFAULT '',
  internal_notes TEXT NOT NULL DEFAULT '',
  estimate_complete INTEGER NOT NULL DEFAULT 0,
  category_id INTEGER REFERENCES category(id) ON DELETE SET NULL,
  effort_quantity REAL CHECK (effort_quantity > 0),
  effort_unit TEXT NOT NULL DEFAULT '',
  effort_notes TEXT NOT NULL DEFAULT ''
);
INSERT INTO task_v228 SELECT * FROM task;
DROP TABLE task;
ALTER TABLE task_v228 RENAME TO task;
CREATE INDEX task_category_idx ON task(category_id);

CREATE TABLE time_entry_v228 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES task(id) ON DELETE CASCADE,
  start_time TEXT NOT NULL,
  end_time TEXT,
  created_date TEXT NOT NULL,
  modified_date TEXT NOT NULL,
  notes TEXT,
  billed INTEGER NOT NULL DEFAULT 0,
  invoice_line_id INTEGER,
  supplier_id INTEGER REFERENCES supplier(id) ON DELETE SET NULL,
  billable INTEGER NOT NULL DEFAULT 1,
  show_on_invoice INTEGER NOT NULL DEFAULT 0
);
INSERT INTO time_entry_v228 SELECT * FROM time_entry;
DROP TABLE time_entry;
ALTER TABLE time_entry_v228 RENAME TO time_entry;
CREATE INDEX idx_time_entry_supplier_id ON time_entry(supplier_id);

CREATE TABLE quote_line_group_v228 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quote_id INTEGER NOT NULL REFERENCES quote(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  created_date TEXT NOT NULL,
  modified_date TEXT NOT NULL,
  assumption TEXT NOT NULL DEFAULT '',
  task_id INTEGER REFERENCES task(id) ON DELETE SET NULL,
  line_approval_status TEXT NOT NULL DEFAULT 'preApproval',
  description TEXT NOT NULL DEFAULT '',
  task_margin INTEGER NOT NULL DEFAULT 0
);
INSERT INTO quote_line_group_v228 SELECT * FROM quote_line_group;
DROP TABLE quote_line_group;
ALTER TABLE quote_line_group_v228 RENAME TO quote_line_group;

CREATE TABLE quote_line_v228 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  quote_id INTEGER NOT NULL REFERENCES quote(id) ON DELETE CASCADE,
  quote_line_group_id INTEGER REFERENCES quote_line_group(id) ON DELETE SET NULL,
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_charge INTEGER NOT NULL,
  line_total INTEGER NOT NULL,
  created_date TEXT NOT NULL,
  modified_date TEXT NOT NULL,
  line_chargeable_status TEXT NOT NULL DEFAULT 'normal'
);
INSERT INTO quote_line_v228 SELECT * FROM quote_line;
DROP TABLE quote_line;
ALTER TABLE quote_line_v228 RENAME TO quote_line;

CREATE TABLE check_list_check_list_item_v228 (
  check_list_id INTEGER NOT NULL REFERENCES check_list(id) ON DELETE CASCADE,
  check_list_item_id INTEGER NOT NULL REFERENCES check_list_item(id) ON DELETE CASCADE,
  createdDate TEXT,
  modifiedDate TEXT,
  PRIMARY KEY(check_list_id, check_list_item_id)
);
INSERT OR IGNORE INTO check_list_check_list_item_v228 SELECT * FROM check_list_check_list_item;
DROP TABLE check_list_check_list_item;
ALTER TABLE check_list_check_list_item_v228 RENAME TO check_list_check_list_item;
