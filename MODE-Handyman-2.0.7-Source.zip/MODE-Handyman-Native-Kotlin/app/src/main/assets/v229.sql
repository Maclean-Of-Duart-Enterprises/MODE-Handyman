-- Durable Smart Tools linkage and contract approval records.
CREATE TABLE mode_smart_estimate_conversion (
  profile_id INTEGER NOT NULL REFERENCES business_profile(id) ON DELETE CASCADE,
  estimate_id INTEGER NOT NULL,
  job_id INTEGER NOT NULL REFERENCES job(id) ON DELETE RESTRICT,
  quote_id INTEGER REFERENCES quote(id) ON DELETE RESTRICT,
  state TEXT NOT NULL CHECK (state IN ('pending','completed')),
  created_date TEXT NOT NULL,
  modified_date TEXT NOT NULL,
  PRIMARY KEY (profile_id, estimate_id),
  UNIQUE (quote_id)
);

CREATE INDEX mode_smart_conversion_job_idx
ON mode_smart_estimate_conversion(profile_id, job_id);

CREATE TABLE mode_contract_approval (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profile_id INTEGER NOT NULL REFERENCES business_profile(id) ON DELETE RESTRICT,
  customer_id INTEGER NOT NULL REFERENCES customer(id) ON DELETE RESTRICT,
  job_id INTEGER NOT NULL REFERENCES job(id) ON DELETE RESTRICT,
  quote_id INTEGER NOT NULL REFERENCES quote(id) ON DELETE RESTRICT,
  smart_approval_id INTEGER NOT NULL UNIQUE,
  signer_name TEXT NOT NULL,
  agreement_text TEXT NOT NULL,
  consent_text TEXT NOT NULL,
  approved_at TEXT NOT NULL,
  signature_file TEXT NOT NULL,
  contract_file TEXT NOT NULL,
  content_sha256 TEXT NOT NULL,
  created_date TEXT NOT NULL,
  UNIQUE (profile_id, quote_id)
);

CREATE INDEX mode_contract_approval_job_idx
ON mode_contract_approval(profile_id, job_id, customer_id);
