-- Add locally managed business profiles. The active system row remains the
-- compatibility view used by the rest of the application.
CREATE TABLE business_profile (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  display_name TEXT NOT NULL,
  configuration_json TEXT NOT NULL,
  preferences_json TEXT NOT NULL DEFAULT '{}',
  trip_settings_json TEXT NOT NULL DEFAULT '{}',
  active INTEGER NOT NULL DEFAULT 0 CHECK (active IN (0, 1)),
  created_date TEXT NOT NULL,
  modified_date TEXT NOT NULL
);

CREATE UNIQUE INDEX business_profile_one_active
ON business_profile(active)
WHERE active = 1;
