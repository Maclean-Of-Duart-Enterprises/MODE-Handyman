-- MODE Handyman 1.0.0: retain HMB data and add local CRM/document fields.
ALTER TABLE customer ADD COLUMN mode_groups TEXT NOT NULL DEFAULT '';
ALTER TABLE customer ADD COLUMN mode_fields TEXT NOT NULL DEFAULT '';
ALTER TABLE quote ADD COLUMN valid_until TEXT;
ALTER TABLE quote ADD COLUMN mode_discount_cents INTEGER NOT NULL DEFAULT 0;
ALTER TABLE quote ADD COLUMN mode_tax_hundredths INTEGER NOT NULL DEFAULT 0;
ALTER TABLE quote ADD COLUMN mode_terms TEXT NOT NULL DEFAULT '';
CREATE TABLE mode_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO mode_settings VALUES ('footer', 'MODE Handyman - A division of Maclean Of Duart Enterprises Corp');
INSERT INTO mode_settings VALUES ('scheduling', 'https://cal.com/mode-handyman');
UPDATE system SET business_name = 'MODE Handyman',
 email_address = 'handyman@macleanofduartenterprises.com',
 from_email = 'handyman@macleanofduartenterprises.com',
 web_url = 'https://macleanofduartenterprises.com/handyman',
 mobile_number = '717-500-6202', country_code = 'US',
 enable_xero_integration = 0, enable_ihserver_integration = 0,
 billing_colour = 0xFF1A2D4A, payment_terms_in_days = 14;
