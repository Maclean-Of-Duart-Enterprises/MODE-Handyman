# MODE Handyman 2.0.6 source verification

- `app/build.gradle` declares version 2.0.6 and version code 12.
- Receipt photographs are bounded JPEG blobs in profile-scoped `mode_receipt_photos` records and are included with the main database in native backups.
- Receipt editing preserves the identifier, validates the active-profile supplier, stores consistent excluding-tax/tax/including-tax amounts, and validates the date.
- Receipt deletion removes photo records and the receipt within one SQLite transaction.
- Supplier and manufacturer URLs are profile-scoped, limited to explicit HTTP(S) addresses, and opened only through an explicit Android browser intent.
- Legacy URL migration is repeatable and non-destructive: an existing dedicated URL is retained and ordinary non-URL text is not moved.
- Trip values are entered and displayed in kilometres or miles according to `use_metric_units`, while the database retains metres.
- Decimal distance conversion rounds deterministically to the nearest metre instead of truncating floating-point values.

Executed verification:

- Clean debug and release Kotlin compilation passed without compiler warnings.
- 20 debug and 20 release JVM tests passed with no failures, errors, or skips.
- Main schema 229 verification, Smart Tools migration verification, and focused 2.0.6 SQLite lifecycle verification passed.
- Android release lint completed with zero issues.
- R8/resource shrinking and signed release assembly passed.

No emulator was used. Physical-device testing remains required for Android photo selection/rendering, browser handoff, keyboard interaction, database upgrade using the production phone data, and a live backup/restore round trip.
