# MODE Handyman 2.0.6 — limitation corrections

- Added repeatable, non-destructive migration of explicit HTTP(S) URLs from legacy supplier/manufacturer website, description, service and notes fields into the dedicated URL table. Existing dedicated URLs are never overwritten. Text without an explicit HTTP(S) URL is left unchanged.
- Receipt editor now exposes existing tax as a separate editable amount. Editing the tax-inclusive total preserves tax by default in the repository, or saves the explicitly entered tax in the UI. Excluding-tax amount is recalculated as total minus tax. Rejects negative tax and tax exceeding total.
- Added platform-independent regression tests for URL validation/extraction, trip conversion, and receipt totals.
- The final Gradle compilation, debug/release JVM suites, database checks, Android lint, R8 release assembly, signing, alignment, and privacy scans passed without an emulator. Physical-device testing remains required.
