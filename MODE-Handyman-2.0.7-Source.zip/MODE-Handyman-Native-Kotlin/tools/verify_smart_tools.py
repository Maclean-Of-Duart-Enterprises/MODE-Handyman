#!/usr/bin/env python3
"""Representative v3-to-v4 Smart Tools migration and data-preservation test."""
import sqlite3


def add_column(db, table, column, declaration):
    columns = {row[1] for row in db.execute(f"PRAGMA table_info({table})")}
    if column not in columns:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")


def main():
    db = sqlite3.connect(":memory:")
    db.executescript("""
      CREATE TABLE materials(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,name TEXT NOT NULL,supplier TEXT NOT NULL,unit TEXT NOT NULL,cents INTEGER NOT NULL,updated INTEGER NOT NULL);
      CREATE TABLE estimates(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,title TEXT NOT NULL,category TEXT NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL,materials_cents INTEGER NOT NULL,labor_cents INTEGER NOT NULL,markup_percent REAL NOT NULL,total_cents INTEGER NOT NULL,created INTEGER NOT NULL,job_id INTEGER,quote_id INTEGER);
      CREATE TABLE costs(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,description TEXT NOT NULL,type TEXT NOT NULL,cents INTEGER NOT NULL,created INTEGER NOT NULL,job_id INTEGER);
      CREATE TABLE job_revenue(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,cents INTEGER NOT NULL,created INTEGER NOT NULL,job_id INTEGER);
      CREATE TABLE attachments(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,kind TEXT NOT NULL,file TEXT NOT NULL,note TEXT NOT NULL,created INTEGER NOT NULL,job_id INTEGER);
      CREATE TABLE approvals(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,quote_id INTEGER,attachment_id INTEGER,signer TEXT NOT NULL,agreement TEXT NOT NULL,approved_at INTEGER NOT NULL,status TEXT NOT NULL,job_id INTEGER,estimate_id INTEGER);
      INSERT INTO estimates VALUES(1,'1','Unique job','scope',1,'job',10000,12500,10,24750,1,NULL,NULL);
      INSERT INTO costs VALUES(1,'1','Duplicate title','saved expense','Material',500,1,NULL);
      INSERT INTO attachments VALUES(1,'1','Unique job','photo','/private/photo','kept',1,0);
    """)
    linked = ("estimates", "costs", "job_revenue", "attachments", "approvals")
    for table in linked:
        add_column(db, table, "link_status", "TEXT NOT NULL DEFAULT 'unresolved'")
        add_column(db, table, "link_note", "TEXT NOT NULL DEFAULT ''")
        db.execute(f"UPDATE {table} SET job_id=NULL WHERE job_id=0")
        db.execute(f"UPDATE {table} SET link_status='verified',link_note='Previously selected job identifier' WHERE job_id IS NOT NULL")
    for column, declaration in (
        ("customer_id", "INTEGER"), ("signature_file", "TEXT"), ("contract_file", "TEXT"),
        ("consent_text", "TEXT"), ("content_sha256", "TEXT"), ("core_approval_id", "INTEGER"),
    ):
        add_column(db, "approvals", column, declaration)
    db.execute("CREATE TABLE estimate_components(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,estimate_id INTEGER NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,kind TEXT NOT NULL,description TEXT NOT NULL,quantity_thousandths INTEGER NOT NULL,unit TEXT NOT NULL,unit_cents INTEGER NOT NULL,line_total_cents INTEGER NOT NULL,position INTEGER NOT NULL)")
    db.execute("PRAGMA foreign_keys=ON")
    assert db.execute("SELECT title,materials_cents,labor_cents,total_cents FROM estimates WHERE id=1").fetchone() == ("Unique job",10000,12500,24750)
    assert db.execute("SELECT job_id,link_status FROM attachments WHERE id=1").fetchone() == (None,"unresolved")
    assert db.execute("SELECT job,description,cents FROM costs WHERE id=1").fetchone() == ("Duplicate title","saved expense",500)
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    print("PASS: Smart Tools v3-to-v4 migration preserves records and leaves unverified links unresolved")


if __name__ == "__main__":
    main()
