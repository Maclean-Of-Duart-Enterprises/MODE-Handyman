#!/usr/bin/env python3
"""Host-side verification of the additive 2.0.6 receipt, URL and trip data paths."""
import datetime
import pathlib
import shutil
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        database = pathlib.Path(directory) / "handyman.db"
        shutil.copy2(ASSETS / "handyman-template.db", database)
        db = sqlite3.connect(database)
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        db.execute(
            "INSERT INTO business_profile(display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",
            ("MODE Handyman", "{}", "{}", "{}", 1, now, now),
        )
        db.commit()
        db.executescript((ASSETS / "v228.sql").read_text())
        db.executescript((ASSETS / "v229.sql").read_text())
        db.execute("PRAGMA foreign_keys=ON")
        db.executescript(
            """
            CREATE TABLE mode_receipt_photos(
              id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id INTEGER NOT NULL,
              profile_id INTEGER NOT NULL, image BLOB NOT NULL, created_at TEXT NOT NULL
            );
            CREATE INDEX idx_mode_receipt_photos ON mode_receipt_photos(profile_id,receipt_id);
            CREATE TABLE mode_directory_urls(
              kind TEXT NOT NULL, record_id INTEGER NOT NULL, profile_id INTEGER NOT NULL,
              url TEXT NOT NULL, PRIMARY KEY(kind,record_id,profile_id)
            );
            """
        )
        supplier = db.execute(
            "INSERT INTO supplier(name,description,createdDate,modifiedDate,service,lastAccessed,profile_id) VALUES(?,?,?,?,?,?,?)",
            ("Supply House", "https://supplier.example/catalog", now, now, "Materials", now, 1),
        ).lastrowid
        db.execute(
            "INSERT INTO mode_directory_urls(kind,record_id,profile_id,url) VALUES(?,?,?,?)",
            ("supplier", supplier, 1, "https://supplier.example/catalog"),
        )
        receipt = db.execute(
            "INSERT INTO receipt(receipt_date,supplier_id,total_excluding_tax,tax,total_including_tax,created_date,modified_date,profile_id) VALUES(?,?,?,?,?,?,?,?)",
            ("2026-10-24", supplier, 900, 100, 1000, now, now, 1),
        ).lastrowid
        db.execute(
            "INSERT INTO mode_receipt_photos(receipt_id,profile_id,image,created_at) VALUES(?,?,?,?)",
            (receipt, 1, b"representative-jpeg", now),
        )
        db.execute(
            "UPDATE receipt SET total_excluding_tax=?,tax=?,total_including_tax=?,modified_date=? WHERE id=? AND profile_id=?",
            (1100, 100, 1200, now, receipt, 1),
        )
        trip = db.execute(
            "INSERT INTO trip_log(arrived_at,to_latitude,to_longitude,distance_metres,purpose,business,classified,distance_source,profile_id) VALUES(?,?,?,?,?,?,?,?,?)",
            (now, 0.0, 0.0, 1609, "Supply run", 1, 1, "manual", 1),
        ).lastrowid
        db.commit()

        assert db.execute("SELECT url FROM mode_directory_urls WHERE kind='supplier' AND record_id=? AND profile_id=1", (supplier,)).fetchone()[0] == "https://supplier.example/catalog"
        assert db.execute("SELECT total_excluding_tax,tax,total_including_tax FROM receipt WHERE id=?", (receipt,)).fetchone() == (1100, 100, 1200)
        assert db.execute("SELECT length(image) FROM mode_receipt_photos WHERE receipt_id=? AND profile_id=1", (receipt,)).fetchone()[0] > 0
        assert db.execute("SELECT distance_metres FROM trip_log WHERE id=? AND profile_id=1", (trip,)).fetchone()[0] == 1609

        db.execute("BEGIN")
        db.execute("DELETE FROM mode_receipt_photos WHERE receipt_id=? AND profile_id=1", (receipt,))
        db.execute("DELETE FROM receipt WHERE id=? AND profile_id=1", (receipt,))
        db.commit()
        assert db.execute("SELECT COUNT(*) FROM receipt WHERE id=?", (receipt,)).fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM mode_receipt_photos WHERE receipt_id=?", (receipt,)).fetchone()[0] == 0
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        print("PASS: 2.0.6 URL scoping, receipt photo storage, tax-aware edit, transactional deletion, trip storage, integrity and foreign keys")


if __name__ == "__main__":
    main()
