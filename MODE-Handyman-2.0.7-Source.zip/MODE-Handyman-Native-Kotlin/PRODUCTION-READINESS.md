# Production readiness

Version 2.0.6 is a compiled and signed release candidate. Automated non-emulator verification passed, including Kotlin compilation, JVM tests, receipt photos/edit/delete behavior, tax calculations, supplier/manufacturer links, metric and US-customary trip conversions, calculator and invoice calculations, Android lint, R8, database migrations, representative financial records, foreign keys, manifest inspection, signing, and APK alignment.

Before treating it as a production replacement:

1. Back up the currently installed app and keep the prior APK.
2. Install version 2.0.6 as an update on the intended phone and compare record counts.
3. Reconcile any Smart Tools records shown under **Unresolved job links**.
4. Test the bottom field of every form with the real keyboard.
5. Create and share a signed contract and inspect every PDF page.
6. Export a backup, add a test record, restore the backup, and confirm the test record and attachments revert correctly.
7. Confirm reminders and Android share targets on the phone.
8. Open supplier/manufacturer links, add and remove a receipt photograph, edit receipt tax and totals, and compare a known trip in miles and kilometres.

The signature is a captured handwritten image plus a SHA-256 content record, not a certificate-backed cryptographic digital signature. Obtain legal review of the agreement/consent language if electronic-signature enforceability is important.
