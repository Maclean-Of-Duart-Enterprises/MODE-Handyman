# Privacy and dependency audit

## Runtime dependency result

The release runtime graph contains only Kotlin standard library 2.1.20 and its JetBrains annotations dependency. JUnit is test-only. AndroidX, Compose, Google Play Services, Firebase, Sentry, analytics, ads, and remote crash-reporting SDKs are absent.

## Permissions in the release manifest

| Permission | Reason |
|---|---|
| `POST_NOTIFICATIONS` | User-created local todo reminders on Android 13+ |

There is no `INTERNET`, phone, SMS, contacts, broad storage, media, location, advertising ID, background-location, or system-overlay permission. The movable calculator remains inside the application window. File import/export uses the Storage Access Framework. Normal operation cannot open a network socket through the manifest.

## Components

- `MainActivity` is exported only because it is the launcher.
- `SecureExportProvider` is not exported, is read-only, validates canonical paths, and grants per-share URI access only for generated exports or crash reports.
- `ReminderReceiver` is not exported.
- The unused boot receiver is disabled and not exported.
- Cleartext traffic is disabled.
- Android automatic backup is disabled; backup destinations are user selected.

## Local diagnostics

The native handler writes structured JSON into private app storage, retains no more than 20 reports, and redacts common password, secret, token, bearer credential, email, and North American phone patterns. Reports have no network endpoint and are shared only after an explicit user action. This native handler was chosen instead of ACRA to avoid unnecessary transitive dependencies, as permitted by the requirements.

## Data movement

Customer, profile, job, financial, attachment, diagnostic, and preference data remains local. PDFs and ZIP backups leave private storage only through an Android chooser. Email address and phone number fields are optional and are not prerequisites for PDF creation, backup, or sharing.

## Static APK inspection

The final package scan found no filenames matching Flutter, Dart, Sentry, Firebase, Analytics, Crashlytics, `libflutter.so`, or `libapp.so`. The certificate SHA-256 is `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`, matching the supplied release keystore.
