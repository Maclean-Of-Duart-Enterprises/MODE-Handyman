# MODE Handyman 2.0.11

- Added dedicated required phone-number and email-address boxes directly below the customer/company name.
- Added database schema 231 storage for customer/company phone and email while preserving all existing customer details and photos.
- Included the fields in customer display, JSON/CSV transfer, customer copying, backups, and quote/invoice customer details.
- Maintained import compatibility with older customer CSV exports.
- Advanced the application to version 2.0.11 (version code 17).
- Verified 23 debug and 23 release JVM tests, six host-side regression suites, Android Lint with zero issues, APK alignment, release metadata, and the v2 signing certificate without an emulator.
