# MODE Handyman 2.1.11

- Quote detail: Create invoice from quote, preserving its job, itemized lines, and final total (including quote discount/tax adjustment). Existing Jobs > Create invoice remains unchanged.
- Atomic invoice creation: rolls back incomplete conversions; quote itself remains unchanged.
- Settings: remove duplicate AGPL license and source/release buttons; retain both under Privacy & about.
- Source code and releases now opens https://github.com/Maclean-Of-Duart-Enterprises/MODE-Handyman.
- Privacy & about version text corrected to 2.1.11.
- Android versionName 2.1.11 and versionCode 33.

Note: Android compilation and device runtime verification were not available in this environment.
