# MODE Handyman 2.1.10 Release Verification

## Release identity

- Package: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.1.10`
- Version code: `32`
- Minimum Android SDK: `30`
- Target and compile SDK: `36`
- APK: `MODE-Handyman-2.1.10-universal-signed.apk`
- APK SHA-256: `e853698021d1cb07bd273e17a5fddbc589c8015aa50fcf59f82c8dc2d256f6d4`

## Source correction

The attached graphical-calendar source contained an invalid `LinearLayout` Kotlin property (`baselineAligned`). It was corrected to `isBaselineAligned`, after which the complete application compiled successfully.

## Verification completed without an emulator

- Kotlin/JVM unit suite: **23 passed, 0 failed**.
- Host-side regression scripts: **11 passed, 0 failed**.
- The graphical calendar verification covers Day, Week, 2 weeks, Month and Year modes, Sunday-first columns, in-cell appointment actions, date selection and overflow labels.
- APK archive integrity: passed.
- APK resource table, manifest and launch activity inspection: passed.
- Packaged database and migration assets through `v233.sql`: present.
- DEX output: valid `classes.dex`, 1,447 class definitions.
- ZIP alignment: passed.
- APK Signature Scheme v3 verification: passed with one 4096-bit RSA signer.
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- Declared permissions are limited to notifications and boot-completed reminder restoration; no Internet permission is present.
- Static scan found no shell/process execution, dynamic code loading, privileged storage, SMS, phone-call, Internet permission or bundled native executable code.

## Testing boundary

No Android emulator was used. No physical Android device was attached, so installation, touch interaction and device-specific rendering remain for on-device acceptance testing.
