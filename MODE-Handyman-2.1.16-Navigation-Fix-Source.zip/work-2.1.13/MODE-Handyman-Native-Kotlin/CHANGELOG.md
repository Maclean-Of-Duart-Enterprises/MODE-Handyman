# MODE Handyman 2.0.15 — PDF address and signature layout

- Moved the job-site address to the right-hand Job / Project section directly below the job number on quote and invoice PDFs.
- Reduced handwritten signatures to a compact block directly beneath the typed signer name.
- Kept the complete approval block with the totals when page space allows, preventing the oversized signature-only continuation page.

## 2.0.14 — Job site address

- Added an optional job-site address directly beneath the job number.
- Included a supplied job-site address on quote and invoice screens and exported PDFs.
- Added schema 232 migration while preserving all existing jobs.

## 2.0.13 — Contact save and customer-number removal

- Removed the customer-number field from contact forms, displays, transfers, editable fields, and customer-facing documents.
- Removed customer-number requirements from quotes, invoices, and other records.
- Corrected contact-to-customer linking by safely quoting the legacy SQLite `primary` column.

## 2.0.12 — Optional phone and email

- Made customer/company and contact phone and email fields optional.
- Values entered in any phone or email field remain included in customer-facing quotes, invoices, and forms.
- Customer numbers remain required for document-linked contacts.

## 2.0.11 — Customer phone and email

- Added dedicated required phone-number and email-address boxes immediately below the customer/company name.
- Persisted the new customer/company fields through schema 231 upgrades, backups, customer copy, JSON/CSV transfer, and customer-facing quote/invoice details.
- Retained compatibility with older contact-transfer CSV files.

## 2.0.10 — Editable records, identifiers, and signatures

- Added mandatory contact email, mobile phone, and customer number fields, plus separate landline, office phone, and alternate email boxes.
- Added editable alphanumeric job numbers used as the prefix for new quote and invoice numbers.
- Corrected record editing, copying, and transaction-safe dependent deletion across customer, contact, job, quote, invoice, schedule, catalog, receipt, and trip records.
- Added quote/invoice line editing and deletion.
- Added direct customer signature capture for quotes and invoices, with signature metadata and image rendered in exported PDFs.

## 2.0.6 — Receipts, links, and trip units

- Added profile-scoped supplier and manufacturer website links with explicit browser opening.
- Added non-destructive migration of explicit legacy HTTP(S) links without overwriting a dedicated saved URL.
- Added receipt photo import, local database storage, gallery, individual removal, editing, tax-aware totals, and transactional deletion.
- Corrected trip entry and display for kilometres or miles while retaining metres internally.
- Added 2.0.6 JVM and representative SQLite regression verification.
- Built and verified the signed, R8-optimized 2.0.6 release without an emulator.

## 2.0.5 — Release build

- Advanced the Android package to version 2.0.5 (version code 11).
- Added JVM verification for exact inline-photo insertion, document-order parsing, targeted removal, invalid identifiers, and invalid cursor offsets.
- Centralized the lossless inline-photo marker format so editing, display, insertion, and removal use one implementation.
- Resolved material-label localization warnings and a Kotlin supplier-binding type warning.
- Built and verified the signed, R8-optimized release without an emulator.

## 2.0.4 — Source changes

- Added contact-only JSON and CSV export through Android's document picker, for one customer or all customers in the active business profile.
- Added JSON/CSV import preview, destination profile selection, duplicate counts and skip/update/separate policies.
- Import transactions preserve job, invoice, quote, payment, appointment and service records; no such data is serialized.
- Added a material catalog selector to job task items and quote/invoice line creation; selected descriptions, quantity and saved selling prices populate editable fields.
- Extended material creation UI to capture description, manufacturer, SKU, purchase price, selling price and markup.
- Retained supplier records, supplier product links and database version 5 migration from the supplied 2.0.4 baseline.

## Limitations

- Multi-selection export UI is not implemented (individual and all-current-profile exports are present).
- Customer photos, separate billing/service addresses, and standalone business name fields are not transferred because the inspected source does not expose those as contact-transfer fields.
- Import duplicate matching currently uses customer name, not fuzzy matching of phone/email.
- Catalog selection copies values to line-item forms, but does not persist supplier/material foreign keys on the legacy invoice/quote lines.
- Android compilation and device testing were not performed, as requested.

### Additional contact and invoice integration
- Add profile-isolated customer business name, billing/service address, and optional base64 image contact fields.
- Include those fields in contact-only JSON export/import/copy; CSV includes address and business name, without photos.
- Add customer photo selection through Android's document picker with a 2 MB size limit.
- Persist catalog material snapshots against newly created invoice lines in an additive local table.

### Final source-only follow-up
- Invoice material references now snapshot the preferred supplier ID and product URL, when available, at line creation. Historical invoice lines remain unchanged when catalog associations change.
- Added profile-scoped supplier/material join and validation of captured invoice-line price and URL.
- Audited customer photo storage: the supplied 2.0.4 source has `mode_customer_contact_extra.photo_base64`, but no identifiable pre-existing customer-photo field or file reference to migrate. Automatic legacy-photo migration is therefore not possible without a known legacy source; existing embedded photos remain preserved.

- Added profile-isolated Work Notes linked to customers, with inline local photos and backup support.

## 2.0.4 — Work notes inline editor
- Render persisted photo markers as actual inline image spans in the editable note text, retaining original marker IDs in storage.
- Reopen note editor after photo import so the inserted photo appears in editing mode.
- Downsample displayed images to limit editor memory usage; missing image files remain visible as markers.


### 2.0.8 — License text bundled
- Include complete unmodified GNU AGPLv3 license in root LICENSE and app assets.
- Settings license screen displays the complete text offline.
