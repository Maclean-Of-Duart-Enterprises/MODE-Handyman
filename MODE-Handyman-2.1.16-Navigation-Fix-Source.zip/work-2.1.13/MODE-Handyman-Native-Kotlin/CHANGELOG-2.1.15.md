# MODE Handyman 2.1.15

- Trips: calculate driving distance online using Nominatim address geocoding and OSRM routes. Manual override retained. No offline maps required for trip calculation.
- Jobs: new Navigate to job site action with Android map application chooser; uses Google navigation, geo and web maps intents.
- Privacy notice updated for network-based address lookup and external navigation.
- Updated version code to 37 and Privacy & about label to 2.1.15.
- Legacy offline map code retained internally for migration compatibility, but is no longer offered in Trips.
- Public Nominatim and OSRM services are best-effort and rate limited, not guaranteed production SLAs.
