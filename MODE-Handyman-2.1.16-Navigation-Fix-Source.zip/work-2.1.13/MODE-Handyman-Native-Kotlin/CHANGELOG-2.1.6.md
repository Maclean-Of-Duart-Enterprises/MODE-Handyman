# MODE Handyman 2.1.6

- Replaced fixed additional-reminder presets with user-configurable numeric interval and unit (minutes, hours, days, weeks).
- Supports 1 minute through 365 days before the appointment.
- Preserves the separate graphical custom notification date/time picker and notification notes.
- Existing additional reminders migrate in place without changing stored reminder records.
- Android alarm delivery can be deferred by system restrictions; this is not a guarantee of exact-time delivery.
- No emulator or device testing performed.
