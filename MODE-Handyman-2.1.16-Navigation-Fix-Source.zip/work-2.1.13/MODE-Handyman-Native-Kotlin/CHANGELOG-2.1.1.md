# MODE Handyman 2.1.1

- Job time entries now have Stop, Edit, and Delete controls.
- Duration is computed from UTC timestamps rather than an unreliable UI counter.
- Time records can be reassigned to tasks within the same job.
- Validation prevents negative duration, concurrent running timers, and editing/deleting billed entries.
- The existing time_entry database schema is preserved.
- No APK build or device test was performed.
