# MODE Handyman 2.0.12 release verification

## Release

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.0.12`
- Version code: `18`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- Database schema: `231`

## Implemented correction

- Customer/company phone number and email address are optional.
- Contact phone number and email address are optional.
- Non-empty phone and email values are still checked for valid formatting.
- Customer numbers remain mandatory.
- Any supplied customer/company or contact phone and email values remain included in quotes, invoices, and other customer-facing forms. Blank values are omitted.

## Host-side verification

- Debug JVM tests: 23 passed, 0 failed.
- Release JVM tests: 23 passed, 0 failed.
- Android Lint release analysis: 0 issues.
- Seven source/database regression suites passed.
- APK metadata confirms version `2.0.12` / code `18`.
- APK is 4-byte ZIP aligned.
- APK Signature Scheme v2 verification passed with one 4096-bit RSA signer.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK does not request Internet permission.

No emulator or physical-device UI test was performed, as requested. Verification was limited to compilation, JVM tests, SQLite migration/regression tests, static analysis, and APK inspection.
