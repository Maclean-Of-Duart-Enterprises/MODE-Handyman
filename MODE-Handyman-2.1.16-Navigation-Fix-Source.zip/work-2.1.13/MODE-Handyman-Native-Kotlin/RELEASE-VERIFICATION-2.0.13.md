# MODE Handyman 2.0.13 release verification

## Release

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.0.13`
- Version code: `19`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- Database schema: `231`

## Implemented corrections

- Removed the customer-number field from contact add/edit forms.
- Removed customer numbers from active displays, transfers, editable fields, and customer-facing documents.
- Removed the customer-number requirement from quote, invoice, and other document creation.
- Corrected the `near "primary": syntax error` by explicitly quoting the legacy SQLite relationship column.
- Made contact creation and customer linking one atomic transaction so a failed link cannot leave a partially saved contact.
- Phone and email remain optional; supplied values remain included on quotes, invoices, and other customer-facing forms.

The legacy database column is retained only for safe compatibility with existing installations and backups; the application no longer reads, writes, displays, transfers, or requires it.

## Host-side verification

- Debug JVM tests: 23 passed, 0 failed.
- Release JVM tests: 23 passed, 0 failed.
- Android Lint release analysis: 0 issues.
- Eight source/database regression suites passed.
- APK metadata confirms version `2.0.13` / code `19`.
- APK is 4-byte ZIP aligned.
- APK Signature Scheme v2 verification passed with one 4096-bit RSA signer.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK does not request Internet permission.

No emulator or physical-device UI test was performed, as requested. Verification was limited to compilation, JVM tests, SQLite regression tests, static analysis, and APK inspection.
