# MODE Handyman 2.0.15 release verification

## Release

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.0.15`
- Version code: `21`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- Database schema: `232`

## PDF layout corrections

- Separated the job-site address from customer details in the PDF data model.
- Positioned the job-site address in the right-hand **Job / Project** column directly beneath the job number and description.
- Limited handwritten signatures to a maximum area of 140 × 50 PDF points.
- Positioned the compact signature directly beneath the typed signer name in the approval block below the totals.
- Removed the separate **Handwritten signature** heading and the oversized signature rendering that produced a signature-only continuation page.
- Kept automatic pagination when a genuinely full document cannot fit the complete approval block on its current page.

## Host-side verification

- Debug JVM tests: 23 passed, 0 failed.
- Release JVM tests: 23 passed, 0 failed.
- Android Lint release analysis: 0 issues.
- Ten source/database regression suites passed.
- APK metadata confirms version `2.0.15` / code `21`.
- APK is 4-byte ZIP aligned.
- APK Signature Scheme v2 verification passed with one 4096-bit RSA signer.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK does not request Internet permission.

No emulator or physical-device UI test was performed, as requested. Verification was limited to compilation, JVM tests, SQLite regression tests, static analysis, PDF-layout source checks, and APK inspection.
