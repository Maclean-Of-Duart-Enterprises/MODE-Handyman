# MODE Handyman 2.1.13 Release Verification

## Release identity

- Package: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.1.13`
- Version code: `35`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- APK: `MODE-Handyman-2.1.13-offline-routing-universal-signed.apk`
- APK SHA-256: `ea3ccf0f4166c0976865e168b2c2028c36c6defd0120f8eb7eb1a4797f307282`

## Completed update

- Removed public Nominatim/OSRM route calculation.
- Added an embedded offline A* driving-route engine.
- Added OSM XML and gzipped OSM XML conversion into compact private road graphs.
- Added HTTPS regional-map download plus local import, selection, listing and deletion.
- Added local named-road/address matching and `latitude,longitude` fallback.
- Added one-way handling and road-speed weighting.
- Retained manual trip-distance override.
- Confirmed **Native Kotlin edition 2.1.13** under Privacy & about.

## Verification without an emulator

- Complete Kotlin source compilation: passed.
- Kotlin/JVM unit tests: **23 passed, 0 failed**.
- Host-side regression and feature scripts: **12 passed, 0 failed**.
- Compiled DEX contains the 2.1.13 About header and offline-routing controls.
- Compiled DEX does not contain the removed Nominatim or OSRM endpoints.
- APK archive integrity: passed.
- Package/version/SDK/launch activity inspection: passed.
- Packaged database and migrations through `v233.sql`: present.
- DEX output: valid, 1,489 class definitions.
- ZIP alignment: passed.
- APK Signature Scheme v3: passed with one 4096-bit RSA signer.
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.

## Permissions and boundary

The Internet permission remains solely for explicit regional-map downloads and user-opened source/release links. Route calculation and address matching are offline. No emulator, QEMU, Maclean APK Builder, or physical-device test was used. Installation, large-map performance and touch-flow acceptance should be confirmed on the target phone.
