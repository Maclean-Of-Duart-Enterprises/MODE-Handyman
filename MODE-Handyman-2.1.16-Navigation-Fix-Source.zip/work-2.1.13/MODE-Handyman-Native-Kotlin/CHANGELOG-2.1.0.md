# MODE Handyman 2.1.0 source changes

- Job material/labor cards now open an edit/delete action menu. Editing supports task, description, quantity, and unit cost, and recalculates the job item's charge with its existing margin.
- New quotes and invoices snapshot billable job task items as document lines. Already issued documents are not silently changed when a job item is edited.
- Smart Tools material price library now supports two optional supplier/product URL pairs during creation, and a separate three-link dialog for additional links on existing materials. Each link can be opened or removed.
- Smart Tools database schema upgraded from 5 to 6 with an additive `material_extra_links` table. Existing supplier associations are unchanged.
- App version 2.1.0, code 22.

## Verification limitations

Gradle compilation could not run: the Gradle wrapper distribution was not cached and this environment could not download it. No emulator or device testing was performed. Source archive integrity checked. Review quote/invoice monetary rounding for quantities that are not whole units, and test deleting task items already associated with invoice lines on a backup before production use.
