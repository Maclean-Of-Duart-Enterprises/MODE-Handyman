# MODE Handyman 2.1.5 — Appointment notifications

- Independent graphical notification date/time selector for appointments.
- Optional additional reminder at 5, 15, 30, 60, or 1440 minutes before appointment start.
- Notifications scheduled offline using AlarmManager and local NotificationManager.
- Stored reminders are profile-associated and survive database backup/restore.
- Editing and deleting appointments replaces/cancels pending alarms.
- Boot and app-update receivers restore future appointment alarms.
- Android 13+ notification permission requested when needed.

Note: Android Doze and OEM battery restrictions may delay inexact alarms. Device testing is required. No emulator testing performed.
