# MODE Handyman 2.1.9 — Recurrence editing

- Separate actions for editing/deleting an occurrence and editing/deleting the entire series.
- Add native date picker for inclusive recurrence end date; maximum five years.
- Store recurrence-series membership in additive SQLite tables; existing appointments remain intact.
- Series edits update dates, job and notes and shift reminders, while retaining occurrence-specific notes and job overrides where possible.
- Deleting a series removes its appointments and reminder alarms; deleting an occurrence affects only that occurrence.
- Existing 2.1.8 recurring appointments lack series metadata and cannot automatically be grouped retrospectively because the old format did not persist group identifiers.
- Release compiled and signed; JVM, regression, package, DEX, alignment and signature checks completed without an emulator. Physical-device testing remains for the installer.
