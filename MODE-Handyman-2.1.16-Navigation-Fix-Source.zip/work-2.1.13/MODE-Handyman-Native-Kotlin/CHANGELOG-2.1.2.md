# MODE Handyman 2.1.2 — Job time tracking

- Replaced raw ISO 8601 timestamp editing with Android native date and time pickers using device-local time, persisted as UTC instants.
- Added manual time entry creation for a selected task within the current job, including start, end and notes.
- Added aggregate tracked time per job and per-entry elapsed time (hours, minutes, seconds), including currently running entries.
- Preserved timer notes and existing edit/stop/delete actions.
- Manual entries must end after their start and cannot end in the future. Existing billed-entry restrictions remain.
- No destructive database migration.

Verification: source ZIP structure checked; Android compilation and physical device tests not performed.
