package com.macleanofduartenterprises.modehandyman.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

class SignaturePad(context: Context): View(context) {
    private val path=Path()
    private val ink=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=5f;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND }
    var hasStroke=false
        private set

    init { setBackgroundColor(Color.WHITE);minimumHeight=dp(300) }
    override fun onMeasure(widthSpec:Int,heightSpec:Int)=setMeasuredDimension(MeasureSpec.getSize(widthSpec),dp(300))
    override fun onDraw(canvas:Canvas) { super.onDraw(canvas);canvas.drawPath(path,ink) }
    override fun onTouchEvent(event:MotionEvent):Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { path.moveTo(event.x,event.y);hasStroke=true }
            MotionEvent.ACTION_MOVE -> path.lineTo(event.x,event.y)
            MotionEvent.ACTION_UP -> { path.lineTo(event.x,event.y);performClick() }
        }
        invalidate();return true
    }
    override fun performClick():Boolean { super.performClick();return true }
    fun snapshot():Bitmap=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888).also { bitmap -> Canvas(bitmap).apply {drawColor(Color.WHITE);drawPath(path,ink)} }
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()
}
