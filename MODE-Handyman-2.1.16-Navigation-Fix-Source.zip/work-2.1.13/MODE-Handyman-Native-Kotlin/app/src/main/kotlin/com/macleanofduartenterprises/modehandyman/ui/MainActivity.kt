package com.macleanofduartenterprises.modehandyman.ui

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import android.content.ClipData
import android.content.Intent
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import java.util.Locale
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.style.ImageSpan
import android.graphics.drawable.BitmapDrawable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import com.macleanofduartenterprises.modehandyman.ModeApplication
import com.macleanofduartenterprises.modehandyman.R
import com.macleanofduartenterprises.modehandyman.core.*
import com.macleanofduartenterprises.modehandyman.data.*
import com.macleanofduartenterprises.modehandyman.data.ModeRepository.JobTimeEntry
import com.macleanofduartenterprises.modehandyman.diagnostics.LocalCrashReporter
import com.macleanofduartenterprises.modehandyman.export.BackupManager
import com.macleanofduartenterprises.modehandyman.export.PdfGenerator
import com.macleanofduartenterprises.modehandyman.routing.OnlineRoutingEngine
import com.macleanofduartenterprises.modehandyman.routing.OfflineRoutingEngine
import java.io.File
import java.time.LocalDate
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var calculatorButton: Button
    private lateinit var content: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var back: Button
    private lateinit var home: Button
    private var repositoryState: ModeRepository? = null
    private val repository: ModeRepository
        get() = checkNotNull(repositoryState) { "The local database is not ready" }
    private val pages = ArrayDeque<Page>()
    private val logoRequestCode = 6204
    private var customerExportIds: List<Long> = emptyList()
    private var customerExportCsv = false
    private var pendingReceiptPhotoId: Long? = null
    private var pendingCameraReceiptId: Long? = null
    private var pendingCustomerPhotoId: Long? = null
    private var pendingNotePhotoId: Long? = null
    private var pendingNotePhotoOffset: Int = -1
    private var pendingMapRegionName: String? = null
    private var selectedMaterialForLine: Map<String,String>? = null
    private var backupExportPending = false
    private var backupRestorePending = false
    private val liveTimeHandler = Handler(Looper.getMainLooper())
    private var liveTimeUpdate: Runnable? = null
    private var liveTimeJobId: Long? = null
    private var liveTimeTotalLabel: TextView? = null
    private var liveTimeRows: List<Pair<JobTimeEntry, TextView>> = emptyList()
    private val onlineRouter by lazy { OnlineRoutingEngine() }
    private val offlineRouter by lazy { OfflineRoutingEngine(applicationContext) } // Legacy import compatibility; not used for trip routing

    private fun stopLiveTimeUpdates() {
        liveTimeUpdate?.let(liveTimeHandler::removeCallbacks)
        liveTimeUpdate = null
        liveTimeJobId = null
        liveTimeTotalLabel = null
        liveTimeRows = emptyList()
    }

    private fun startLiveTimeUpdates(jobId: Long, entries: List<Pair<JobTimeEntry, TextView>>, total: TextView) {
        stopLiveTimeUpdates()
        if (entries.none { it.first.end == null }) return
        liveTimeJobId = jobId
        liveTimeRows = entries
        liveTimeTotalLabel = total
        val updater = object : Runnable {
            override fun run() {
                if (liveTimeUpdate !== this || liveTimeJobId != jobId) return
                val now = Instant.now()
                var totalSeconds = 0L
                liveTimeRows.forEach { (entry, label) ->
                    val seconds = java.time.Duration.between(Instant.parse(entry.start), entry.end?.let(Instant::parse) ?: now).seconds.coerceAtLeast(0)
                    totalSeconds += seconds
                    label.text = "${entry.taskName} • ${durationLabel(seconds)} • ${if (entry.end == null) "Running" else "Stopped"} • Edit / Stop / Delete"
                }
                liveTimeTotalLabel?.text = "Total tracked time: ${durationLabel(totalSeconds)}"
                liveTimeHandler.postDelayed(this, 1000L)
            }
        }
        liveTimeUpdate = updater
        updater.run()
    }

    override fun onPause() {
        stopLiveTimeUpdates()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && liveTimeJobId == null && pages.lastOrNull()?.title == "Job") {
            // Rebind after returning from another activity without resetting the job's scroll position.
            val rows = resumedTimeRows
            val total = resumedTimeTotal
            val jobId = resumedTimeJobId
            if (jobId != null && total != null && rows.isNotEmpty()) startLiveTimeUpdates(jobId, rows, total)
        }
    }

    private var resumedTimeJobId: Long? = null
    private var resumedTimeRows: List<Pair<JobTimeEntry, TextView>> = emptyList()
    private var resumedTimeTotal: TextView? = null

    override fun onDestroy() {
        stopLiveTimeUpdates()
        super.onDestroy()
    }

    private data class Page(val title: String, val render: () -> View)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        calculatorButton = FloatingCalculator.install(this)
        content = findViewById(R.id.content)
        titleView = findViewById(R.id.title)
        back = findViewById(R.id.back_button)
        home = findViewById(R.id.home_button)
        back.setOnClickListener { navigateBack() }
        home.isEnabled = false
        home.setOnClickListener {
            if (repositoryState != null) dashboard(reset = true)
        }
        loading("Opening your local business data…")
        thread(name = "mode-database-open") {
            runCatching {
                val manager = (application as ModeApplication).databaseManager
                val openedRepository = ModeRepository(applicationContext, manager.open())
                SmartToolsStore(applicationContext).use { smart ->
                    openedRepository.allJobIdentities().forEach { (profile, jobs) -> smart.reconcileJobIds(profile, jobs) }
                }
                manager.markMigrationComplete()
                openedRepository
            }.onSuccess { openedRepository ->
                runOnUiThread {
                    repositoryState = openedRepository
                    home.isEnabled = true
                    dashboard(reset = true)
                }
            }.onFailure { error ->
                runOnUiThread {
                    repositoryState = null
                    home.isEnabled = false
                    fatal(error)
                }
            }
        }
    }

    @Deprecated("Uses native back handling for API 30 compatibility")
    override fun onBackPressed() = navigateBack()

    private fun navigateBack() {
        if (pages.size <= 1) { finish(); return }
        pages.removeLast()
        display(pages.last())
    }

    private fun open(title: String, render: () -> View) {
        val page = Page(title, render)
        pages.addLast(page)
        display(page)
    }

    private fun refresh() = display(pages.last())

    private fun display(page: Page) {
        stopLiveTimeUpdates()
        resumedTimeJobId = null
        resumedTimeRows = emptyList()
        resumedTimeTotal = null
        titleView.text = page.title
        back.visibility = if (pages.size > 1) View.VISIBLE else View.INVISIBLE
        content.removeAllViews()
        runCatching { page.render() }
            .onSuccess { content.addView(it, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)) }
            .onFailure { error -> content.addView(errorView(error)) }
    }

    private fun loading(message: String) {
        titleView.text = getString(R.string.app_name)
        content.removeAllViews()
        content.addView(Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, "MODE Handyman"))
            addView(Ui.label(this@MainActivity, message))
            addView(ProgressBar(this@MainActivity))
        }))
    }

    private fun fatal(error: Throwable) {
        titleView.setText(R.string.database_error)
        content.removeAllViews()
        content.addView(errorView(error))
    }

    private fun errorView(error: Throwable): View = Ui.scroll(this, Ui.column(this).apply {
        addView(Ui.title(this@MainActivity, "Unable to open this screen"))
        addView(Ui.label(this@MainActivity, error.message ?: error.javaClass.simpleName, Ui.ERROR))
        addView(Ui.label(this@MainActivity, "Your existing data has not been reset or deleted."))
        addView(Ui.button(this@MainActivity, "Back") { navigateBack() })
    })

    private fun dashboard(reset: Boolean = false) {
        if (reset) pages.clear()
        open("MODE Handyman") {
            val counts = repository.dashboardCounts()
            Ui.scroll(this, Ui.column(this).apply {
                val active = repository.profiles.all().first { it.active }
                addView(Ui.title(this@MainActivity, active.name))
                addView(Ui.label(this@MainActivity, "Private, offline business management", Ui.GOLD))
                addView(Ui.section(this@MainActivity, "Work"))
                addMenu("Jobs", counts["Jobs"], ::jobsScreen)
                addMenu("Notes", null, ::notesScreen)
                addMenu("Quotes", counts["Quotes"], ::quotesScreen)
                addMenu("Invoices & payments", counts["Invoices"], ::invoicesScreen)
                addMenu("Schedule", null, ::scheduleScreen)
                addMenu("Todo", counts["Todo"], ::todosScreen)
                addView(Ui.section(this@MainActivity, "People and materials"))
                addMenu("Customers & contacts", counts["Customers"], ::customersScreen)
                addMenu("Suppliers", null) { simpleScreen("Suppliers", "suppliers") }
                addMenu("Manufacturers", null) { simpleScreen("Manufacturers", "manufacturers") }
                addMenu("Tools", counts["Tools"]) { simpleScreen("Tools", "tools") }
                addMenu("Receipts & expenses", null) { simpleScreen("Receipts", "receipts") }
                addMenu("Trips", null) { simpleScreen("Trips", "trips") }
                addView(Ui.section(this@MainActivity, "Smart project tools"))
                addMenu("Estimator, materials, profitability, photos & signatures", null) { startActivity(Intent(this@MainActivity, SmartToolsActivity::class.java).putExtra("profile", repository.profiles.all().first { it.active }.id.toString())) }
                addView(Ui.section(this@MainActivity, "Business"))
                addMenu("Reports", null, ::reportsScreen)
                addMenu("Settings, profiles & backups", null, ::settingsScreen)
            })
        }
    }

    private fun LinearLayout.addMenu(name: String, count: Int?, action: () -> Unit) {
        addView(Ui.card(this@MainActivity, name, if (count == null) "" else "$count records", "›", onClick = action))
    }

    private fun notesScreen() = open("Work notes") {
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,"Work notes"))
            addView(Ui.button(this@MainActivity,"+ New note") { noteForm(null) })
            repository.workNotes().forEach { note ->
                val customer=note.customerId?.let { id -> repository.customerChoices().firstOrNull{it.id==id}?.label } ?: "No customer linked"
                addView(Ui.card(this@MainActivity,note.title,customer,note.updated){noteScreen(note.id)})
            }
        })
    }
    private fun noteScreen(id:Long) = open("Note") {
        val note=repository.workNote(id)
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,note.title))
            // Photo markers are persisted in the note body at the exact insertion position.
            // Older notes without markers retain their original gallery as a fallback.
            val photos=repository.notePhotos(id)
            val photoById=photos.associateBy { it.id }
            val inlinePattern=NotePhotoMarkers.pattern
            var cursor=0
            val rendered=mutableSetOf<Long>()
            fun renderPhoto(photo: ModeRepository.WorkNotePhoto) {
                val file=File(filesDir,"work-note-photos/${photo.fileName}")
                if(file.isFile) BitmapFactory.decodeFile(file.absolutePath)?.let { bitmap ->
                    addView(ImageView(this@MainActivity).apply {
                        setImageBitmap(bitmap);adjustViewBounds=true
                        maxHeight=(resources.displayMetrics.density*320).toInt()
                        scaleType=ImageView.ScaleType.FIT_CENTER
                    })
                }
                if(photo.caption.isNotBlank()) addView(Ui.label(this@MainActivity,photo.caption))
                addView(Ui.button(this@MainActivity,"Remove photo") { confirm("Remove this note photo?") {
                    val updated=NotePhotoMarkers.remove(repository.workNote(id).body, photo.id)
                    repository.saveWorkNote(id,note.customerId,note.title,updated)
                    repository.deleteNotePhoto(id,photo.id)?.let { File(filesDir,"work-note-photos/$it").delete() }
                    refresh()
                } })
                rendered.add(photo.id)
            }
            inlinePattern.findAll(note.body).forEach { match ->
                val paragraph=note.body.substring(cursor,match.range.first)
                if(paragraph.isNotEmpty()) addView(Ui.label(this@MainActivity,paragraph))
                match.groupValues[1].toLongOrNull()?.let { photoById[it] }?.let(::renderPhoto)
                cursor=match.range.last+1
            }
            val trailing=note.body.substring(cursor)
            if(trailing.isNotEmpty()) addView(Ui.label(this@MainActivity,trailing))
            if(photos.any { it.id !in rendered }) {
                addView(Ui.section(this@MainActivity,"Earlier photos"))
                photos.filter { it.id !in rendered }.forEach(::renderPhoto)
            }
            note.customerId?.let { customerId -> addView(Ui.button(this@MainActivity,"Open linked customer") { customerScreen(customerId) }) }
            addView(Ui.button(this@MainActivity,"Edit note") { noteForm(id) })
            addView(Ui.button(this@MainActivity,"+ Insert photo between paragraphs") { noteForm(id) })
            addView(Ui.button(this@MainActivity,"Delete note") { confirm("Delete this note and its photos?") {
                val files=repository.notePhotos(id).map{it.fileName};repository.deleteWorkNote(id)
                files.forEach { File(filesDir,"work-note-photos/$it").delete() };navigateBack();refresh()
            } })
        })
    }
    /** Display stored photo markers as actual inline images in the editable text.
     * The underlying marker text remains unchanged for lossless persistence and export.
     */
    private fun renderEditableNotePhotos(editor: EditText, noteId: Long) {
        val images = repository.notePhotos(noteId).associateBy { it.id }
        val editable = editor.text
        val pattern = NotePhotoMarkers.pattern
        // Span changes must not trigger text replacement: the original marker is the stored format.
        editable.getSpans(0, editable.length, ImageSpan::class.java).forEach(editable::removeSpan)
        pattern.findAll(editable.toString()).forEach { match ->
            val id = match.groupValues[1].toLongOrNull() ?: return@forEach
            val photo = images[id] ?: return@forEach
            val file = File(filesDir, "work-note-photos/${photo.fileName}")
            if (!file.isFile) return@forEach
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@forEach
            val maxWidth = (resources.displayMetrics.widthPixels * 0.72f).toInt().coerceAtLeast(1)
            val maxHeight = (resources.displayMetrics.density * 240).toInt().coerceAtLeast(1)
            val sample = BitmapFactory.Options().apply {
                inSampleSize = generateSequence(1) { it * 2 }.takeWhile {
                    bounds.outWidth / it > maxWidth * 2 || bounds.outHeight / it > maxHeight * 2
                }.lastOrNull() ?: 1
            }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, sample) ?: return@forEach
            val scale = minOf(maxWidth.toFloat() / bitmap.width, maxHeight.toFloat() / bitmap.height, 1f)
            val drawable = BitmapDrawable(resources, bitmap).apply {
                setBounds(0, 0, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1))
            }
            editable.setSpan(ImageSpan(drawable, ImageSpan.ALIGN_BOTTOM), match.range.first,
                match.range.last + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    private fun noteForm(id:Long?) {
        val existing=id?.let{repository.workNote(it)}
        val body=Ui.column(this,8)
        val title=Ui.field(this,"Note title",existing?.title.orEmpty())
        val text=Ui.field(this,"Note text",existing?.body.orEmpty(),true)
        if (id != null) renderEditableNotePhotos(text, id)
        val customers=repository.customerChoices()
        val names=listOf("No linked customer")+customers.map{it.label}
        val selected=existing?.customerId?.let{wanted->customers.indexOfFirst{it.id==wanted}+1}?:0
        val customer=spinner(names,selected.coerceAtLeast(0))
        listOf(title,Ui.label(this,"Linked customer"),customer,text).forEach(body::addView)
        body.addView(Ui.label(this,"Position the cursor to insert a photo. Existing photos display directly in the editor."))
        body.addView(Ui.button(this,"Insert photo at cursor") {
            val customerId=if(customer.selectedItemPosition==0)null else customers[customer.selectedItemPosition-1].id
            runCatching {
                val offset=text.selectionStart.coerceIn(0,text.text.length)
                val saved=repository.saveWorkNote(id,customerId,title.text.toString(),text.text.toString())
                pendingNotePhotoId=saved
                pendingNotePhotoOffset=offset
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="image/*" },6213)
            }.onFailure { toast(it.message?:"Could not save note") }
        })
        formDialog(if(id==null)"New work note" else "Edit work note",body) {
            val customerId=if(customer.selectedItemPosition==0)null else customers[customer.selectedItemPosition-1].id
            val saved=repository.saveWorkNote(id,customerId,title.text.toString(),text.text.toString())
            if(id==null) noteScreen(saved) else refresh()
        }
    }
    private fun customersScreen() = open("Customers") {
        searchableList("Search customers", repository::customers) { id -> customerScreen(id) }
            .also {
                it.addView(Ui.button(this, "Import customer contacts (JSON/CSV)") { pickCustomerImport() }, 0)
                it.addView(Ui.button(this, "Export all customers (JSON/CSV)") { chooseCustomerExport(repository.customers().map { row -> row.id }) }, 0)
                it.addView(Ui.button(this, "Select customers to export") { selectCustomersForExport() }, 0)
                it.addView(Ui.button(this, "+ Add customer") { customerForm(null) }, 0)
            }
    }

    /** Multi-customer export is explicitly selected; no unrelated business data is included. */
    private fun selectCustomersForExport() {
        val records = repository.customers()
        if (records.isEmpty()) { toast("No customers to export"); return }
        val selected = BooleanArray(records.size)
        AlertDialog.Builder(this)
            .setTitle("Select customer contacts")
            .setMultiChoiceItems(records.map { it.title }.toTypedArray(), selected) { _, which, checked ->
                selected[which] = checked
            }
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                val ids = records.indices.filter { selected[it] }.map { records[it].id }
                if (ids.isEmpty()) toast("Select at least one customer") else chooseCustomerExport(ids)
            }.show()
    }

    private fun customerScreen(id: Long) = open("Customer") {
        val customer = repository.customer(id)
        val customerDetails = repository.customerExtra(id)
        Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, customer.name))
            addView(Ui.label(this@MainActivity, "Phone: ${customerDetails.optString("customer_phone")}"))
            addView(Ui.label(this@MainActivity, "Email: ${customerDetails.optString("customer_email")}"))
            addView(Ui.label(this@MainActivity, customer.description.ifBlank { "No description" }))
            if (customer.groups.isNotBlank()) addView(Ui.label(this@MainActivity, "Groups: ${customer.groups}", Ui.GOLD))
            addView(Ui.button(this@MainActivity, "Edit customer") { customerForm(customer) })
            addView(Ui.button(this@MainActivity,"Choose customer photo") { pendingCustomerPhotoId=id; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6212) })
            addView(Ui.button(this@MainActivity, "Export this customer") { chooseCustomerExport(listOf(id)) })
            addView(Ui.button(this@MainActivity,"Copy / Delete customer"){recordActions("customer",id,"customer")})
            addView(Ui.button(this@MainActivity,"Copy contact to another business profile") {
                val destinations=repository.profiles.all().filter { !it.active }
                if(destinations.isEmpty()) android.widget.Toast.makeText(this@MainActivity,"Create another business profile first",android.widget.Toast.LENGTH_LONG).show()
                else android.app.AlertDialog.Builder(this@MainActivity).setTitle("Copy customer contact to")
                    .setItems(destinations.map { it.name }.toTypedArray()) { _,which ->
                        val target=destinations[which]
                        android.app.AlertDialog.Builder(this@MainActivity).setTitle("Confirm contact copy")
                            .setMessage("Copy customer name, notes, custom fields and contacts to ${target.name}? No jobs, quotes, invoices or payments will be transferred. Duplicate names will be rejected.")
                            .setNegativeButton("Cancel",null).setPositiveButton("Copy") { _,_ ->
                                runCatching { repository.copyCustomerContactOnly(id,target.id) }
                                    .onSuccess { android.widget.Toast.makeText(this@MainActivity,"Contact copied",android.widget.Toast.LENGTH_LONG).show() }
                                    .onFailure { android.widget.Toast.makeText(this@MainActivity,it.message,android.widget.Toast.LENGTH_LONG).show() }
                            }.show()
                    }.show()
            })
            addView(Ui.section(this@MainActivity, "Contacts"))
            repository.contacts(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing) { contactActions(row.id,id) }) }
            addView(Ui.button(this@MainActivity, "+ Add contact") { contactForm(null, id) })
            addView(Ui.section(this@MainActivity, "Jobs"))
            repository.jobs().filter { job -> repository.job(job.id).customerId == id }.forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing, row.status) { jobScreen(row.id) }) }
        })
    }

    private fun customerForm(existing: CustomerDraft?) {
        val body = Ui.column(this, 8)
        val name = Ui.field(this, "Customer or company name", existing?.name.orEmpty())
        val extra=existing?.id?.let { repository.customerExtra(it) } ?: org.json.JSONObject()
        val phone=Ui.field(this,"Phone number",extra.optString("customer_phone"))
        val email=Ui.field(this,"Email address",extra.optString("customer_email"))
        phone.inputType=android.text.InputType.TYPE_CLASS_PHONE
        email.inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        val description = Ui.field(this, "Description", existing?.description.orEmpty(), true)
        val groups = Ui.field(this, "Groups (comma separated)", existing?.groups.orEmpty())
        val fields = Ui.field(this, "Custom fields", existing?.customFields.orEmpty(), true)
        val business=Ui.field(this,"Business name (optional)",extra.optString("business_name"))
        val billing=Ui.field(this,"Billing address",extra.optString("billing_address"),true)
        val service=Ui.field(this,"Service address",extra.optString("service_address"),true)
        val rate = Ui.moneyField(this, "Default hourly rate", existing?.defaultHourlyRateCents ?: 0)
        listOf(name, phone, email, description, groups, fields, business, billing, service, rate).forEach(body::addView)
        formDialog(if (existing == null) "Add customer" else "Edit customer", body) {
            RecordRequirements.validateOptionalPhoneAndEmail(phone.text.toString(),email.text.toString())
            val customerId=repository.saveCustomer(CustomerDraft(existing?.id, name.text.toString(), description.text.toString(), groups.text.toString(), fields.text.toString(), MoneyMath.parseCents(rate.text.toString())))
            repository.saveCustomerExtra(customerId,phone.text.toString(),email.text.toString(),business.text.toString(),billing.text.toString(),service.text.toString())
            refresh()
        }
    }

    private fun contactForm(existing: ContactDraft?, customerId: Long?) {
        val body = Ui.column(this, 8)
        val first = Ui.field(this, "First name", existing?.firstName.orEmpty())
        val last = Ui.field(this, "Surname", existing?.surname.orEmpty())
        val phone = Ui.field(this, "Mobile phone (optional)", existing?.phone.orEmpty())
        val landline = Ui.field(this, "Landline", existing?.landline.orEmpty())
        val office = Ui.field(this, "Office phone", existing?.officeNumber.orEmpty())
        val email = Ui.field(this, "Email address (optional)", existing?.email.orEmpty())
        val alternate = Ui.field(this, "Alternate email", existing?.alternateEmail.orEmpty())
        listOf(first, last, phone, landline, office, email, alternate).forEach(body::addView)
        formDialog(if (existing == null) "Add contact" else "Edit contact", body) {
            repository.saveContact(ContactDraft(existing?.id, first.text.toString(), last.text.toString(), email.text.toString(), phone.text.toString(),alternate.text.toString(),landline.text.toString(),office.text.toString()), customerId)
            refresh()
        }
    }

    private fun contactActions(id:Long,customerId:Long) {
        AlertDialog.Builder(this).setTitle("Contact").setItems(arrayOf("Edit","Copy","Delete")){_,which->when(which){
            0->contactForm(repository.contact(id),customerId)
            1->confirm("Copy this contact?"){repository.copyRecord("contact",id);refresh()}
            2->confirm("Permanently delete this contact? This cannot be undone."){repository.deleteRecord("contact",id);refresh()}
        }}.setNegativeButton("Cancel",null).show()
    }

    private fun jobsScreen() = open("Jobs") {
        searchableList("Search jobs", repository::jobs) { id -> jobScreen(id) }
            .also { it.addView(Ui.button(this, "+ Add job") { jobForm(null) }, 0) }
    }

    private fun jobScreen(id: Long) = open("Job") {
        val job = repository.job(id)
        Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, job.summary))
            addView(Ui.label(this@MainActivity, "Job number: ${job.jobNumber}", Ui.GOLD))
            if(job.jobSiteAddress.isNotBlank()) {
                addView(Ui.label(this@MainActivity, "Job site address: ${job.jobSiteAddress}"))
                addView(Ui.button(this@MainActivity,"Navigate to job site") { openMapNavigation(job.jobSiteAddress) })
            }
            addView(Ui.label(this@MainActivity, "${job.status} • ${job.billingType}", Ui.GOLD))
            addView(Ui.label(this@MainActivity, job.description.ifBlank { "No description" }))
            addView(Ui.button(this@MainActivity, "Edit job") { jobForm(job) })
            addView(Ui.button(this@MainActivity,"Rename / Copy / Delete job"){recordActions("job",id,"job")})
            addView(Ui.button(this@MainActivity, "Create quote") { confirm("Create quote for this job?") { quoteScreen(repository.createQuote(id)) } })
            addView(Ui.button(this@MainActivity, "Create invoice") { confirm("Create invoice for this job?") { invoiceScreen(repository.createInvoice(id)) } })
            addView(Ui.section(this@MainActivity, "Tasks"))
            repository.tasks(id).forEach { row -> addView(Ui.card(this@MainActivity, row.title, row.subtitle, row.trailing, row.status)) }
            addView(Ui.button(this@MainActivity, "+ Add task") { taskForm(id) })
            addView(Ui.section(this@MainActivity, "Materials and labour"))
            repository.taskItems(id).forEach { row -> addView(Ui.button(this@MainActivity, "${row.title} · ${row.subtitle} · ${row.trailing}  · Edit / Delete") { jobItemActions(id,row.id) }) }
            addView(Ui.button(this@MainActivity, "+ Add material/labour item") { taskItemForm(id) })
            addView(Ui.section(this@MainActivity, "Time entries"))
            val timeRecords=repository.jobTimeEntries(id)
            val totalSeconds=timeRecords.sumOf { entry ->
                java.time.Duration.between(Instant.parse(entry.start),entry.end?.let(Instant::parse) ?: Instant.now()).seconds.coerceAtLeast(0)
            }
            val totalTimeLabel = Ui.label(this@MainActivity,"Total tracked time: ${durationLabel(totalSeconds)}",Ui.GOLD)
            addView(totalTimeLabel)
            val timeButtons = mutableListOf<Pair<JobTimeEntry, TextView>>()
            timeRecords.forEach { entry ->
                val elapsed=java.time.Duration.between(Instant.parse(entry.start),entry.end?.let(Instant::parse) ?: Instant.now()).seconds.coerceAtLeast(0)
                val button = Ui.button(this@MainActivity,"${entry.taskName} • ${durationLabel(elapsed)} • ${if(entry.end==null) "Running" else "Stopped"} • Edit / Stop / Delete") { timeEntryActions(id,entry.id) }
                addView(button)
                timeButtons.add(entry to button)
            }
            resumedTimeJobId = id
            resumedTimeRows = timeButtons
            resumedTimeTotal = totalTimeLabel
            startLiveTimeUpdates(id,timeButtons,totalTimeLabel)
            addView(Ui.button(this@MainActivity, "Start timer") { timerForm(id) })
            addView(Ui.button(this@MainActivity, "+ Add manual time entry") { manualTimeEntry(id) })
        })
    }

    private fun jobForm(existing: JobDraft?) {
        val body = Ui.column(this, 8)
        val customers = repository.customerChoices()
        val customer = spinner(customers.map { it.label }, existing?.customerId?.let { wanted -> customers.indexOfFirst { it.id == wanted }.coerceAtLeast(0) } ?: 0)
        val number = Ui.field(this,"Job number (letters and numbers)",existing?.jobNumber.orEmpty())
        val siteAddress = Ui.field(this,"Job site address (optional)",existing?.jobSiteAddress.orEmpty(),true)
        val summary = Ui.field(this, "Job summary", existing?.summary.orEmpty())
        val description = Ui.field(this, "Description", existing?.description.orEmpty(), true)
        val notes = Ui.field(this, "Internal notes", existing?.notes.orEmpty(), true)
        val billing = spinner(listOf("timeAndMaterial", "fixedPrice", "nonBillable"), listOf("timeAndMaterial", "fixedPrice", "nonBillable").indexOf(existing?.billingType).coerceAtLeast(0))
        val status = spinner(listOf("Prospecting", "In Progress", "On Hold", "Completed", "Rejected"), listOf("Prospecting", "In Progress", "On Hold", "Completed", "Rejected").indexOf(existing?.status).coerceAtLeast(0))
        val rate = Ui.moneyField(this, "Hourly rate", existing?.hourlyRateCents ?: 0)
        listOf(Ui.label(this,"Customer"), customer, number, siteAddress, summary, description, notes, Ui.label(this,"Billing type"), billing, Ui.label(this,"Status"), status, rate).forEach(body::addView)
        formDialog(if (existing == null) "Add job" else "Edit job", body) {
            require(customers.isNotEmpty()) { "Add a customer first" }
            repository.saveJob(JobDraft(existing?.id, customers[customer.selectedItemPosition].id, summary.text.toString(), description.text.toString(), notes.text.toString(), billing.selectedItem.toString(), status.selectedItem.toString(), MoneyMath.parseCents(rate.text.toString()), existing?.bookingFeeCents ?: 0,number.text.toString(),siteAddress.text.toString()))
            refresh()
        }
    }

    private fun taskForm(jobId: Long) {
        val body=Ui.column(this,8); val name=Ui.field(this,"Task name"); val description=Ui.field(this,"Description","",true); val billing=spinner(listOf("timeAndMaterial","fixedPrice","nonBillable"))
        listOf(name,description,Ui.label(this,"Billing type"),billing).forEach(body::addView)
        formDialog("Add task",body){repository.saveTask(jobId,null,name.text.toString(),description.text.toString(),billing.selectedItem.toString(),1);refresh()}
    }

    private fun addMaterialCatalogPicker(body: LinearLayout, description: EditText, price: EditText, quantity: EditText) {
        body.addView(Ui.button(this, "Select material from catalog") {
            val profile = repository.profiles.all().first { it.active }.id.toString()
            val materials = SmartToolsStore(this).use { it.rows("materials",profile) }
            if (materials.isEmpty()) { toast("No materials saved in Smart Project Tools"); return@button }
            AlertDialog.Builder(this).setTitle("Material catalog").setItems(materials.map { "${it["name"]} · ${it["unit"]}" }.toTypedArray()) { _, index ->
                val material = materials[index]
                selectedMaterialForLine=material
                val materialLabel=listOfNotNull(material["name"], material["description"]?.takeIf { it.isNotBlank() }).joinToString(" — ")
                description.setText(getString(R.string.material_description_with_unit,materialLabel,material["unit"].orEmpty()))
                val cents = material["selling_cents"]?.toLongOrNull()?.takeIf { it > 0 } ?: material["cents"]?.toLongOrNull() ?: 0L
                price.setText(MoneyMath.format(cents).replace("$", "").replace(",", ""))
                quantity.setText(material["quantity"]?.takeIf { it.toDoubleOrNull()?.let { q -> q > 0 } == true } ?: "1")
            }.show()
        })
    }

    private fun taskItemForm(jobId: Long) {
        val tasks=repository.taskChoices(jobId); if(tasks.isEmpty()){toast("Add a task first");return}
        val body=Ui.column(this,8);val task=spinner(tasks.map{it.label});val description=Ui.field(this,"Item description");val quantity=Ui.field(this,"Quantity","1");val cost=Ui.moneyField(this,"Unit cost")
        listOf(Ui.label(this,"Task"),task,description,quantity,cost).forEach(body::addView)
        addMaterialCatalogPicker(body,description,cost,quantity)
        formDialog("Add material/labour",body){repository.addTaskItem(tasks[task.selectedItemPosition].id,description.text.toString(),MoneyMath.parseQuantity(quantity.text.toString()),MoneyMath.parseCents(cost.text.toString()),0);refresh()}
    }

    private fun jobItemActions(jobId:Long,itemId:Long) {
        AlertDialog.Builder(this).setTitle("Manage job material / labor").setItems(arrayOf("Edit item","Delete item")) { _,choice ->
            if(choice==0) {
                val current=repository.editableJobItem(jobId,itemId)
                val tasks=repository.taskChoices(jobId)
                val selected=tasks.indexOfFirst { it.id==current.taskId }.coerceAtLeast(0)
                val body=Ui.column(this,8)
                val task=spinner(tasks.map{it.label},selected)
                val description=Ui.field(this,"Item description",current.description)
                val quantity=Ui.field(this,"Quantity",MoneyMath.quantityText(current.quantity))
                val cost=Ui.moneyField(this,"Unit cost",current.unitCents)
                listOf(Ui.label(this,"Task"),task,description,quantity,cost).forEach(body::addView)
                formDialog("Edit material / labor",body) {
                    repository.updateJobItem(jobId,itemId,tasks[task.selectedItemPosition].id,description.text.toString(),MoneyMath.parseQuantity(quantity.text.toString()),MoneyMath.parseCents(cost.text.toString()))
                    jobScreen(jobId)
                }
            } else confirm("Delete this job item? Existing quotes and invoices will retain their saved line items.") {
                repository.deleteJobItem(jobId,itemId);jobScreen(jobId)
            }
        }.show()
    }

    private fun timerForm(jobId: Long) {
        val tasks=repository.taskChoices(jobId)
        if(tasks.isEmpty()){toast("Add a task first");return}
        val body=Ui.column(this,8)
        val task=spinner(tasks.map{it.label})
        val note=Ui.field(this,"Timer note")
        listOf(task,note).forEach(body::addView)
        formDialog("Start timer",body){repository.startTimer(tasks[task.selectedItemPosition].id,note.text.toString());refresh()}
    }

    private fun timeEntryActions(jobId:Long,entryId:Long) {
        val entry=repository.jobTimeEntries(jobId).firstOrNull{it.id==entryId}?:return
        val actions=mutableListOf("Edit time entry")
        if(entry.end==null) actions.add("Stop timer")
        actions.add("Delete time entry")
        AlertDialog.Builder(this).setTitle(entry.taskName).setItems(actions.toTypedArray()){_,which ->
            when(actions[which]) {
                "Stop timer" -> runCatching{repository.stopJobTimer(jobId,entryId);jobScreen(jobId)}.onFailure{toast(it.message?:"Cannot stop timer")}
                "Delete time entry" -> confirm("Delete this recorded time entry?"){repository.deleteJobTimeEntry(jobId,entryId);jobScreen(jobId)}
                else -> editTimeEntry(jobId,entryId)
            }
        }.show()
    }

    private fun durationLabel(seconds:Long):String = "${seconds/3600}h ${(seconds%3600)/60}m ${seconds%60}s"

    private fun localDateTimeLabel(value:Instant):String =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").format(value.atZone(ZoneId.systemDefault()))

    private fun chooseDateTime(initial:Instant,onSelected:(Instant)->Unit) {
        val zone=ZoneId.systemDefault()
        val local=initial.atZone(zone)
        DatePickerDialog(this,{_,year,month,day ->
            TimePickerDialog(this,{_,hour,minute ->
                // Android's calendar picker uses local wall time; resolve in the phone's timezone.
                val chosen=java.time.LocalDateTime.of(year,month+1,day,hour,minute).atZone(zone).toInstant()
                onSelected(chosen)
            },local.hour,local.minute,false).show()
        },local.year,local.monthValue-1,local.dayOfMonth).show()
    }

    private fun manualTimeEntry(jobId:Long) {
        val now=Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MINUTES)
        timeEntryEditor(jobId,null,now.minusSeconds(3600),now,"")
    }

    private fun editTimeEntry(jobId:Long,entryId:Long) {
        val entry=repository.jobTimeEntries(jobId).firstOrNull{it.id==entryId}?:return
        timeEntryEditor(jobId,entryId,Instant.parse(entry.start),entry.end?.let(Instant::parse),entry.notes)
    }

    private fun timeEntryEditor(jobId:Long,entryId:Long?,initialStart:Instant,initialEnd:Instant?,initialNote:String) {
        val tasks=repository.taskChoices(jobId)
        if(tasks.isEmpty()){toast("Add a task first");return}
        val existing=entryId?.let { id -> repository.jobTimeEntries(jobId).firstOrNull{it.id==id} }
        val body=Ui.column(this,8)
        val task=spinner(tasks.map{it.label},tasks.indexOfFirst{it.id==existing?.taskId}.coerceAtLeast(0))
        var startValue=initialStart
        var endValue=initialEnd
        val startButton=Ui.button(this,"Start: ${localDateTimeLabel(startValue)}") { }
        val endButton=Ui.button(this,"End: ${endValue?.let(::localDateTimeLabel) ?: "Running"}") { }
        startButton.setOnClickListener { chooseDateTime(startValue) { chosen -> startValue=chosen;startButton.text="Start: ${localDateTimeLabel(chosen)}" } }
        endButton.setOnClickListener { chooseDateTime(endValue ?: Instant.now()) { chosen -> endValue=chosen;endButton.text="End: ${localDateTimeLabel(chosen)}" } }
        val note=Ui.field(this,"Timer note",initialNote,true)
        listOf(Ui.label(this,"Task"),task,startButton,endButton,note).forEach(body::addView)
        if(entryId!=null && initialEnd==null) {
            body.addView(Ui.label(this,"This timer is running. Use Stop timer to finish it, or select an end time above."))
        }
        val dialog=AlertDialog.Builder(this).setTitle(if(entryId==null)"Add manual time" else "Edit recorded time")
            .setView(body).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                try {
                    val selectedTask=tasks[task.selectedItemPosition].id
                    if(entryId==null) {
                        val end=requireNotNull(endValue){"Select an end time for manual entries"}
                        repository.addManualJobTimeEntry(jobId,selectedTask,startValue.toString(),end.toString(),note.text.toString())
                    } else {
                        repository.editJobTimeEntry(jobId,entryId,selectedTask,startValue.toString(),endValue?.toString(),note.text.toString())
                    }
                    dialog.dismiss();jobScreen(jobId)
                } catch(e:Exception) { toast(e.message ?: "Unable to save time") }
            }
        }
        dialog.show()
    }

    private fun quotesScreen() = open("Quotes") {
        listPage(repository.quotes()) { quoteScreen(it) }
    }

    private fun quoteScreen(id: Long) = open("Quote") {
        val quote=repository.quote(id);val lines=repository.quoteLines(id)
        Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,quote.number));addView(Ui.label(this@MainActivity,"${quote.customer} • ${quote.job}"));repository.documentJobSiteAddress("quote",id).takeIf(String::isNotBlank)?.let { addView(Ui.label(this@MainActivity,"Job site address: $it")) };addView(Ui.label(this@MainActivity,quote.state.uppercase(),Ui.GOLD)); repository.documentCustomerDetails("quote",id).forEach { addView(Ui.label(this@MainActivity,it)) }
            lines.forEach{line->addView(Ui.card(this@MainActivity,line.description,"${MoneyMath.quantityText(line.quantityThousandths)} × ${MoneyMath.format(line.unitCents)}",MoneyMath.format(line.totalCents),onClick={documentLineActions("quote",line)}))}
            addView(Ui.button(this@MainActivity,"Edit / Copy / Delete quote"){recordActions("quote",id,"quote")})
            addView(Ui.button(this@MainActivity,"+ Add line"){documentLineForm(true,id)})
            addView(Ui.button(this@MainActivity,"Create invoice from quote"){confirm("Create an invoice using this quote and its itemized amounts?"){runCatching { invoiceScreen(repository.createInvoiceFromQuote(id)) }.onFailure { toast(it.message ?: "Unable to create invoice") }}})
            addView(Ui.card(this@MainActivity,"Subtotal",trailing=MoneyMath.format(quote.subtotalCents)))
            if(quote.discountCents>0)addView(Ui.card(this@MainActivity,"Discount",trailing="-${MoneyMath.format(quote.discountCents)}"))
            addView(Ui.card(this@MainActivity,"Total",trailing=MoneyMath.format(quote.totalCents)))
            addView(Ui.button(this@MainActivity,"Edit discount, tax and terms"){quoteAdjustments(quote)})
            addView(Ui.button(this@MainActivity,"Change status"){quoteState(id,quote.state)})
            repository.documentSignature("quote",id)?.let { addView(Ui.label(this@MainActivity,"Signed by ${it.signer} • ${it.signedAt}",Ui.GOLD)) }
            addView(Ui.button(this@MainActivity,if(repository.documentSignature("quote",id)==null)"Capture customer signature" else "Replace / remove signature"){signatureActions("quote",id,quote.number)})
            addView(Ui.button(this@MainActivity,"Export/share PDF"){shareQuote(id)})
        })
    }

    private fun quoteAdjustments(q: QuoteSummary){val body=Ui.column(this,8);val discount=Ui.moneyField(this,"Discount",q.discountCents);val tax=Ui.field(this,"Tax percent",(q.taxHundredths/100.0).toString());val terms=Ui.field(this,"Terms",q.terms,true);val valid=Ui.field(this,"Valid until YYYY-MM-DD",q.validUntil.orEmpty());listOf(discount,tax,terms,valid).forEach(body::addView);formDialog("Quote adjustments",body){repository.updateQuoteAdjustments(q.id,MoneyMath.parseCents(discount.text.toString()),((tax.text.toString().toDoubleOrNull()?:0.0)*100).toInt(),terms.text.toString(),valid.text.toString());refresh()}}
    private fun quoteState(id:Long,current:String){val states=arrayOf("reviewing","sent","approved","rejected","withdrawn","invoiced");AlertDialog.Builder(this).setTitle("Quote status").setSingleChoiceItems(states,states.indexOf(current)){d,w->repository.setQuoteState(id,states[w]);d.dismiss();refresh()}.setNegativeButton("Cancel",null).show()}

    private fun invoicesScreen() = open("Invoices & payments") { listPage(repository.invoices()) { invoiceScreen(it) } }

    private fun invoiceScreen(id: Long) = open("Invoice") {
        val invoice=repository.invoice(id);val lines=repository.invoiceLines(id)
        Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,invoice.number));addView(Ui.label(this@MainActivity,"${invoice.customer} • ${invoice.job}"));repository.documentJobSiteAddress("invoice",id).takeIf(String::isNotBlank)?.let { addView(Ui.label(this@MainActivity,"Job site address: $it")) };addView(Ui.label(this@MainActivity,if(invoice.paid)"PAID" else "OPEN • Due ${invoice.dueDate?:"not set"}",Ui.GOLD)); repository.documentCustomerDetails("invoice",id).forEach { addView(Ui.label(this@MainActivity,it)) }
            lines.forEach{line->addView(Ui.card(this@MainActivity,line.description,"${MoneyMath.quantityText(line.quantityThousandths)} × ${MoneyMath.format(line.unitCents)}",MoneyMath.format(line.totalCents),onClick={documentLineActions("invoice",line)}))}
            addView(Ui.button(this@MainActivity,"Edit / Copy / Delete invoice"){recordActions("invoice",id,"invoice")})
            addView(Ui.button(this@MainActivity,"+ Add line"){documentLineForm(false,id)})
            addView(Ui.card(this@MainActivity,"Invoice total",trailing=MoneyMath.format(invoice.totalCents)))
            addView(Ui.card(this@MainActivity,"Paid",trailing=MoneyMath.format(invoice.paidCents)))
            addView(Ui.card(this@MainActivity,"Balance due",trailing=MoneyMath.format(invoice.balanceCents)))
            if(!invoice.paid)addView(Ui.button(this@MainActivity,"Record payment"){paymentForm(id)})
            repository.documentSignature("invoice",id)?.let { addView(Ui.label(this@MainActivity,"Signed by ${it.signer} • ${it.signedAt}",Ui.GOLD)) }
            addView(Ui.button(this@MainActivity,if(repository.documentSignature("invoice",id)==null)"Capture customer signature" else "Replace / remove signature"){signatureActions("invoice",id,invoice.number)})
            addView(Ui.button(this@MainActivity,"Edit invoice terms & conditions"){invoiceTermsEditor(id)})
            addView(Ui.button(this@MainActivity,"Export/share PDF"){shareInvoice(id)})
        })
    }

    private fun invoiceTermsEditor(id:Long) {
        val terms=Ui.field(this,"Terms & conditions (printed at bottom of invoice PDF)",repository.invoiceTerms(id),true)
        formDialog("Invoice terms",Ui.column(this).apply { addView(terms) }) { repository.saveInvoiceTerms(id,terms.text.toString());invoiceScreen(id) }
    }

    private fun documentLineForm(quote:Boolean,id:Long){
        selectedMaterialForLine=null
        val body=Ui.column(this,8);val description=Ui.field(this,"Description");val quantity=Ui.field(this,"Quantity","1");val unit=Ui.moneyField(this,"Unit price")
        listOf(description,quantity,unit).forEach(body::addView)
        addMaterialCatalogPicker(body,description,unit,quantity)
        formDialog("Add line",body){
            val cents=MoneyMath.parseCents(unit.text.toString())
            val count=MoneyMath.parseQuantity(quantity.text.toString())
            if(quote) repository.addQuoteLine(id,description.text.toString(),count,cents)
            else {
                val lineId=repository.addInvoiceLine(id,description.text.toString(),count,cents)
                selectedMaterialForLine?.let { material ->
                    material["id"]?.toLongOrNull()?.let { materialId ->
                        val profile = repository.profiles.all().first { it.active }.id.toString()
                        val supplier = SmartToolsStore(this@MainActivity).use { it.preferredSupplierLink(profile, materialId) }
                        repository.saveInvoiceMaterialReference(
                            lineId, materialId, supplier?.get("supplier_id")?.toLongOrNull(),
                            supplier?.get("product_url").orEmpty(), description.text.toString(),
                            material["unit"].orEmpty(), cents
                        )
                    }
                }
            }
            selectedMaterialForLine=null
            refresh()
        }
    }

    private fun documentLineActions(kind:String,line:DocumentLine) {
        AlertDialog.Builder(this).setTitle("Line item").setItems(arrayOf("Edit","Delete")){_,which->
            if(which==1) confirm("Delete this line item?"){repository.deleteDocumentLine(kind,checkNotNull(line.id));refresh()}
            else {
                val body=Ui.column(this,8);val description=Ui.field(this,"Description",line.description);val quantity=Ui.field(this,"Quantity",MoneyMath.quantityText(line.quantityThousandths));val unit=Ui.moneyField(this,"Unit price",line.unitCents)
                listOf(description,quantity,unit).forEach(body::addView)
                formDialog("Edit line",body){repository.updateDocumentLine(kind,checkNotNull(line.id),description.text.toString(),MoneyMath.parseQuantity(quantity.text.toString()),MoneyMath.parseCents(unit.text.toString()));refresh()}
            }
        }.setNegativeButton("Cancel",null).show()
    }

    private fun signatureActions(kind:String,id:Long,number:String) {
        val existing=repository.documentSignature(kind,id)
        val actions=if(existing==null) arrayOf("Capture signature") else arrayOf("Replace signature","Remove signature")
        AlertDialog.Builder(this).setTitle("Customer signature").setItems(actions){_,which->
            if(existing!=null&&which==1)confirm("Remove the saved signature from this ${kind}?"){repository.removeDocumentSignature(kind,id);refresh()}
            else captureDocumentSignature(kind,id,number)
        }.setNegativeButton("Cancel",null).show()
    }

    private fun captureDocumentSignature(kind:String,id:Long,number:String) {
        val body=Ui.column(this,8);val signer=Ui.field(this,"Signer name (required)");val pad=SignaturePad(this)
        body.addView(Ui.label(this,"Sign inside the white box. The signature will appear on the exported ${kind}."));body.addView(signer);body.addView(pad)
        formDialog("Sign ${kind.replaceFirstChar{it.uppercase()}} $number",body){
            require(pad.hasStroke){"Enter a signature first"};require(signer.text.toString().isNotBlank()){"Signer name is required"}
            val file=File(filesDir,"job-documents/${System.currentTimeMillis()}-$kind-$id-signature.png");file.parentFile?.mkdirs()
            file.outputStream().use{output->check(pad.snapshot().compress(Bitmap.CompressFormat.PNG,100,output))}
            runCatching{repository.saveDocumentSignature(kind,id,signer.text.toString(),file.absolutePath)}.onFailure{file.delete();throw it};refresh()
        }
    }
    private fun paymentForm(id:Long){val body=Ui.column(this,8);val amount=Ui.moneyField(this,"Amount");val method=spinner(listOf("Cash","Card","Bank transfer","Cheque","Other"));val reference=Ui.field(this,"Reference (optional)");listOf(amount,method,reference).forEach(body::addView);formDialog("Record payment",body){repository.recordPayment(id,MoneyMath.parseCents(amount.text.toString()),method.selectedItem.toString(),reference.text.toString());refresh()}}

    private fun todosScreen() = open("Todo") { listPage(repository.todos()) { recordActions("to_do",it,"todo") } .also { it.addView(Ui.button(this,"+ Add todo"){todoForm()},0) } }
    private fun todoForm(){val body=Ui.column(this,8);val title=Ui.field(this,"Title");val note=Ui.field(this,"Notes","",true);val due=Ui.field(this,"Due date YYYY-MM-DD",LocalDate.now().toString());val remind=Ui.field(this,"Optional reminder YYYY-MM-DDTHH:MM");val priority=spinner(listOf("medium","high","low","none"));listOf(title,note,due,remind,priority).forEach(body::addView);formDialog("Add todo",body){val id=repository.saveTodo(null,title.text.toString(),note.text.toString(),due.text.toString(),remind.text.toString(),priority.selectedItem.toString(),"open");if(remind.text.isNotBlank()){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),71);ReminderScheduler.schedule(this,id,title.text.toString(),note.text.toString(),remind.text.toString())};refresh()}}

    private var calendarMode = 3
    private var calendarAnchor: LocalDate = LocalDate.now()
    private val calendarModes = listOf("Day", "Week", "2 weeks", "Month", "Year")

    private fun scheduleScreen() = open("Schedule") {
        val root = Ui.column(this, 8)
        val navigation = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        navigation.addView(Ui.button(this,"‹ Previous") { moveCalendar(-1) }, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        navigation.addView(Ui.button(this,"Today") { calendarAnchor=LocalDate.now();refresh() },LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        navigation.addView(Ui.button(this,"Next ›") { moveCalendar(1) },LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        root.addView(navigation)
        val mode=spinner(calendarModes,calendarMode)
        mode.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) {
                if(calendarMode!=position){calendarMode=position;refresh()}
            }
        }
        root.addView(mode)
        val first=when(calendarMode){0->calendarAnchor;1,2->calendarAnchor.minusDays((calendarAnchor.dayOfWeek.value%7).toLong());3->calendarAnchor.withDayOfMonth(1);else->calendarAnchor.withDayOfYear(1)}
        val last=when(calendarMode){0->first;1->first.plusDays(6);2->first.plusDays(13);3->first.plusMonths(1).minusDays(1);else->first.plusYears(1).minusDays(1)}
        val titleFormat=java.time.format.DateTimeFormatter.ofPattern("MMMM yyyy")
        root.addView(Ui.section(this,if(calendarMode==3)first.format(titleFormat) else "${first} — ${last}"))
        val entries=repository.scheduleBetween(first.toString(),last.plusDays(1).toString())
        val byDay=entries.groupBy { it.start.take(10) }
        if(calendarMode in 1..3) {
            val weekdayRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat").forEach { label ->
                weekdayRow.addView(TextView(this).apply { text=label;gravity=android.view.Gravity.CENTER;textSize=12f;setTypeface(null,Typeface.BOLD);setPadding(1,8,1,8) },LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
            }
            root.addView(weekdayRow)
            val gridStart=first.minusDays((first.dayOfWeek.value%7).toLong())
            val gridEnd=if(calendarMode==3)last.plusDays((6-last.dayOfWeek.value%7).toLong()) else last
            var cursor=gridStart
            while(!cursor.isAfter(gridEnd)) {
                val weekRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;isBaselineAligned=false }
                repeat(7) {
                    val day=cursor
                    val dayItems=byDay[day.toString()].orEmpty()
                    val cell=LinearLayout(this).apply {
                        orientation=LinearLayout.VERTICAL
                        setPadding(3,5,3,5)
                        minimumHeight=if(calendarMode==3)112 else 158
                        val isSelected=day==calendarAnchor
                        val isToday=day==LocalDate.now()
                        setBackgroundColor(if(isSelected)0x335E93C8 else if(isToday)0x2237A878 else if(calendarMode==3 && day.monthValue!=first.monthValue)0x11000000 else 0x0A777777)
                        setOnClickListener { calendarAnchor=day;calendarMode=0;refresh() }
                    }
                    cell.addView(TextView(this).apply {
                        text=day.dayOfMonth.toString();gravity=android.view.Gravity.CENTER
                        textSize=15f;setTypeface(null,if(day==LocalDate.now())Typeface.BOLD else Typeface.NORMAL)
                        alpha=if(calendarMode==3 && day.monthValue!=first.monthValue)0.45f else 1f
                    })
                    dayItems.take(if(calendarMode==3)3 else 5).forEach { appointment ->
                        cell.addView(TextView(this).apply {
                            text=appointment.title;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END
                            textSize=if(calendarMode==3)10f else 12f
                            setPadding(3,3,3,3)
                            setBackgroundColor(0x335E93C8)
                            setOnClickListener { appointmentActions(appointment.id) }
                        })
                    }
                    if(dayItems.size>(if(calendarMode==3)3 else 5))cell.addView(TextView(this).apply { text="+${dayItems.size-(if(calendarMode==3)3 else 5)} more";textSize=10f })
                    weekRow.addView(cell,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f).apply { setMargins(1,1,1,1) })
                    cursor=cursor.plusDays(1)
                }
                root.addView(weekRow)
            }
        }
        root.addView(Ui.button(this,"+ Add appointment") { appointmentForm() })
        val agenda=Ui.column(this,4)
        val agendaDays=if(calendarMode==3)listOf(calendarAnchor) else generateSequence(first){it.plusDays(1)}.takeWhile{!it.isAfter(last)}.toList()
        agendaDays.forEach { day ->
            val items=byDay[day.toString()].orEmpty()
            if(calendarMode==0 || items.isNotEmpty()) {
                agenda.addView(Ui.section(this,"${day.dayOfWeek.toString().lowercase().replaceFirstChar{it.uppercase()}} ${day.monthValue}/${day.dayOfMonth} (${items.size})"))
                items.forEach { appointment ->
                    agenda.addView(Ui.card(this,appointment.title,"${appointment.start.replace('T',' ')} — ${appointment.end.replace('T',' ')}",appointment.notes,appointment.status) { appointmentActions(appointment.id) })
                }
            }
        }
        if(entries.isEmpty())agenda.addView(Ui.label(this,"No appointments in this period."))
        root.addView(Ui.scroll(this,agenda))
        root
    }

    private fun moveCalendar(direction:Long) {
        calendarAnchor=when(calendarMode){0->calendarAnchor.plusDays(direction);1->calendarAnchor.plusWeeks(direction);2->calendarAnchor.plusWeeks(direction*2);3->calendarAnchor.plusMonths(direction);else->calendarAnchor.plusYears(direction)}
        refresh()
    }

    private fun appointmentActions(id:Long) {
        val series=repository.recurrenceFor(id)
        val options=if(series==null) arrayOf("Edit appointment","Delete appointment") else arrayOf("Edit this occurrence","Delete this occurrence","Edit entire series","Delete entire series")
        AlertDialog.Builder(this).setTitle("Appointment").setItems(options){_,which->
            when(which){
                0 -> appointmentForm(id)
                1 -> confirm("Delete ${if(series==null)"this appointment" else "only this occurrence"}?") { repository.deleteAppointmentWithReminders(id).forEach{ReminderScheduler.cancelAppointment(this,it)};refresh() }
                2 -> if(series!=null) appointmentForm(id,series.id)
                3 -> if(series!=null) confirm("Delete the entire recurring series and all its reminders?") { repository.deleteRecurrenceSeries(series.id).forEach{ReminderScheduler.cancelAppointment(this,it)};refresh() }
            }
        }.show()
    }

    private fun appointmentForm(editId:Long?=null,editSeriesId:Long?=null) {
        val jobs=repository.jobChoices()
        if(jobs.isEmpty()){toast("Add a job first");return}
        val seriesEntries=editSeriesId?.let{repository.seriesAppointments(it)}.orEmpty()
        val existing=if(editSeriesId!=null) seriesEntries.firstOrNull() else editId?.let { repository.appointment(it) }
        val body=Ui.column(this,8)
        val selectedJob=jobs.indexOfFirst{it.id==existing?.jobId}.coerceAtLeast(0)
        val job=spinner(jobs.map{it.label},selectedJob)
        val start=Ui.button(this,"Start: ${existing?.start?.replace('T',' ') ?: "Choose date and time"}") {}
        val end=Ui.button(this,"End: ${existing?.end?.replace('T',' ') ?: "Choose date and time"}") {}
        var startValue=runCatching{java.time.LocalDateTime.parse(existing?.start ?: "${calendarAnchor}T09:00:00")}.getOrElse{calendarAnchor.atTime(9,0)}
        var endValue=runCatching{java.time.LocalDateTime.parse(existing?.end ?: "${calendarAnchor}T10:00:00")}.getOrElse{calendarAnchor.atTime(10,0)}
        fun updateLabels(){start.text="Start: ${startValue.toString().replace('T',' ')}";end.text="End: ${endValue.toString().replace('T',' ')}"}
        start.setOnClickListener { chooseDateTime(startValue.atZone(ZoneId.systemDefault()).toInstant()){startValue=java.time.LocalDateTime.ofInstant(it,ZoneId.systemDefault());updateLabels()} }
        end.setOnClickListener { chooseDateTime(endValue.atZone(ZoneId.systemDefault()).toInstant()){endValue=java.time.LocalDateTime.ofInstant(it,ZoneId.systemDefault());updateLabels()} }
        val notes=Ui.field(this,"Notes",existing?.notes.orEmpty(),true)
        val repeatChoices=listOf("Does not repeat","Weekly","Biweekly","Monthly","Quarterly","Semiannually","Annually")
        val currentSeries=editSeriesId?.let{repository.recurrenceFor(seriesEntries.first().id)}
        val repeat=spinner(repeatChoices,repeatChoices.indexOf(currentSeries?.frequency).coerceAtLeast(0))
        var recurrenceEnd=runCatching{java.time.LocalDate.parse(currentSeries?.endDate ?: startValue.toLocalDate().plusYears(5).minusDays(1).toString())}.getOrElse{startValue.toLocalDate().plusYears(5).minusDays(1)}
        val endDateButton=Ui.button(this,"Repeat until: $recurrenceEnd") {}
        endDateButton.setOnClickListener {
            val date=recurrenceEnd
            android.app.DatePickerDialog(this,{_,y,m,d->recurrenceEnd=java.time.LocalDate.of(y,m+1,d);endDateButton.text="Repeat until: $recurrenceEnd"},date.year,date.monthValue-1,date.dayOfMonth).show()
        }
        val previous=editId?.let {repository.appointmentReminders(it)}.orEmpty()
        data class ReminderEditor(val time:java.time.LocalDateTime,val enabled:Boolean)
        val reminders=previous.map { ReminderEditor(java.time.LocalDateTime.parse(it.remindAt),it.enabled) }.toMutableList()
        val reminderList=Ui.column(this,6)
        fun drawReminders() {
            reminderList.removeAllViews()
            reminders.forEachIndexed { index, item ->
                val line=Ui.column(this,4)
                val enabled=CheckBox(this).apply { text="Enabled";isChecked=item.enabled }
                enabled.setOnCheckedChangeListener { _,checked -> reminders[index]=reminders[index].copy(enabled=checked) }
                val dateButton=Ui.button(this,"Reminder ${index+1}: ${item.time.toString().replace('T',' ')}") {
                    chooseDateTime(reminders[index].time.atZone(ZoneId.systemDefault()).toInstant()) { instant ->
                        reminders[index]=reminders[index].copy(time=java.time.LocalDateTime.ofInstant(instant,ZoneId.systemDefault()))
                        drawReminders()
                    }
                }
                line.addView(dateButton)
                line.addView(enabled)
                line.addView(Ui.button(this,"Delete reminder ${index+1}") { reminders.removeAt(index);drawReminders() })
                reminderList.addView(line)
            }
            if(reminders.isEmpty())reminderList.addView(Ui.label(this,"No reminders configured"))
        }
        val addReminder=Ui.button(this,"+ Add reminder") {
            reminders.add(ReminderEditor(startValue.minusHours(1),true))
            drawReminders()
        }
        listOf(Ui.label(this,"Job"),job,start,end,notes).forEach(body::addView)
        if(editId==null || editSeriesId!=null) {
            body.addView(Ui.label(this,"Repeat event (maximum 5 years)"))
            body.addView(repeat)
            body.addView(endDateButton)
        }
        listOf(Ui.label(this,"Reminders (independent date and time)"),reminderList,addReminder).forEach(body::addView)
        drawReminders()
        formDialog(if(editId==null)"Add appointment" else if(editSeriesId!=null)"Edit recurring series" else "Edit appointment",body){
            require(endValue.isAfter(startValue)){"End must be after start"}
            val inputs=reminders.map { com.macleanofduartenterprises.modehandyman.data.ModeRepository.ReminderInput(it.time.toString(),it.enabled) }
            val frequency=if(editId==null || editSeriesId!=null) repeat.selectedItem.toString() else "Does not repeat"
            if(editSeriesId!=null) {
                require(frequency!="Does not repeat") { "Use individual occurrence editing for a non-recurring appointment" }
                val before=seriesEntries.associate { it.id to repository.appointmentReminders(it.id) }
                val (removed,shifted)=repository.updateRecurrenceSeries(editSeriesId,jobs[job.selectedItemPosition].id,startValue,endValue,notes.text.toString(),frequency,recurrenceEnd)
                removed.forEach { id -> before[id].orEmpty().forEach { ReminderScheduler.cancelAppointment(this,it.id) };repository.deleteAppointmentWithReminders(id) }
                shifted.forEach { (id,delta) ->
                    val original=before[id].orEmpty()
                    val newInputs=original.map { item ->
                        val at=java.time.LocalDateTime.parse(item.remindAt).plus(delta)
                        com.macleanofduartenterprises.modehandyman.data.ModeRepository.ReminderInput(at.toString(),item.enabled && at.isAfter(java.time.LocalDateTime.now()))
                    }
                    val (old,new)=repository.replaceAppointmentReminders(id,newInputs)
                    old.forEach { ReminderScheduler.cancelAppointment(this,it) }
                    new.filter { it.enabled }.forEach { ReminderScheduler.scheduleAppointment(this,it.id,it.appointmentId,it.title,it.notes,it.remindAt) }
                }
                refresh();return@formDialog
            }
            if(editId!=null && repository.recurrenceFor(editId)!=null)repository.unlinkRecurrenceOccurrence(editId)
            val savedIds=if(editId==null && frequency!="Does not repeat")
                repository.createRecurringAppointments(jobs[job.selectedItemPosition].id,startValue,endValue,notes.text.toString(),frequency,recurrenceEnd)
                else listOf(repository.saveAppointment(editId,jobs[job.selectedItemPosition].id,startValue.toString(),endValue.toString(),notes.text.toString()))
            var scheduledAny=false
            savedIds.forEach { saved ->
                val shift=java.time.Duration.between(startValue,java.time.LocalDateTime.parse(repository.appointment(saved)!!.start))
                val shiftedInputs=inputs.map { input ->
                    val whenToRemind=java.time.LocalDateTime.parse(input.remindAt).plus(shift)
                    com.macleanofduartenterprises.modehandyman.data.ModeRepository.ReminderInput(whenToRemind.toString(),input.enabled && whenToRemind.isAfter(java.time.LocalDateTime.now()))
                }
                val (removed,created)=repository.replaceAppointmentReminders(saved,shiftedInputs)
                removed.forEach{ReminderScheduler.cancelAppointment(this,it)}
                created.filter{it.enabled}.forEach{ReminderScheduler.scheduleAppointment(this,it.id,it.appointmentId,it.title,it.notes,it.remindAt)}
                scheduledAny=scheduledAny || created.any{it.enabled}
            }
            if(scheduledAny && Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),71)
            refresh()
        }
    }

    private fun simpleScreen(title:String,kind:String)=open(title) {
        val rows=repository.simpleRows(kind)
        Ui.scroll(this,Ui.column(this).apply {
            if(kind=="trips")addView(Ui.label(this@MainActivity,"Driving distances use online OpenStreetMap address lookup and routing. Internet connection required."))
            addView(Ui.button(this@MainActivity,"+ Add ${title.lowercase().removeSuffix("s")}"){simpleForm(kind,title)})
            if(rows.isEmpty())addView(Ui.label(this@MainActivity,"No records for this business profile."))
            rows.forEach { row ->
                addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status) {
                    when(kind) {
                        "receipts" -> receiptActions(row.id)
                        "trips" -> tripActions(row.id)
                        "suppliers","manufacturers" -> directoryActions(if(kind=="suppliers")"supplier" else "manufacturer",row.id,row.title)
                        "tools" -> toolActions(row.id,row.title)
                        else -> recordActions("trip_log",row.id,row.title)
                    }
                })
            }
        })
    }
    private fun simpleForm(kind:String,title:String){
        val body=Ui.column(this,8);val name=Ui.field(this,if(kind=="trips")"Purpose" else "Name");val detail=Ui.field(this,if(kind=="trips")"From address / notes" else "Description or service","",true);val amount=Ui.moneyField(this,if(kind=="trips")if(repository.preferredMetric())"Distance in kilometres" else "Distance in miles" else "Amount / cost")
        body.addView(name);body.addView(detail);body.addView(amount)
        val destination=if(kind=="trips")Ui.field(this,"Destination address (optional)") else null
        var routeSource="manual"
        if(destination!=null) {
            body.addView(destination)
            body.addView(Ui.button(this,"Calculate driving distance online") {
                calculateOnlineRoute(detail.text.toString(),destination.text.toString()) { result ->
                    routeSource="online:${result.mapName}"
                    amount.setText(String.format(Locale.US,"%.2f",result.distanceMetres / if(repository.preferredMetric())1000.0 else 1609.344))
                }
            })
            body.addView(Ui.label(this,"Online routing requires Internet access. Enter complete starting and destination addresses. You may edit the calculated distance before saving."))
        }
        val toolCount=if(kind=="tools")Ui.field(this,"Quantity (whole number)","1") else null
        if(toolCount!=null)body.addView(toolCount)
        val suppliers=if(kind=="receipts")repository.supplierChoices() else emptyList();val supplier=if(suppliers.isNotEmpty())spinner(suppliers.map{it.label}) else null
        if(kind=="receipts"){body.addView(Ui.label(this,"Supplier"));if(supplier!=null)body.addView(supplier) else body.addView(Ui.label(this,"Add a supplier before adding a receipt",Ui.ERROR))}
        formDialog("Add ${title.lowercase().removeSuffix("s")}",body){if(kind=="receipts")require(supplier!=null){"Add a supplier first"};val saved=repository.addSimple(kind,name.text.toString(),detail.text.toString(),if(kind=="trips")BusinessRecordRules.distanceToMetres(amount.text.toString(),repository.preferredMetric()) else MoneyMath.parseCents(amount.text.toString()),supplier?.let{suppliers[it.selectedItemPosition].id},toolCount?.text?.toString()?.toIntOrNull() ?: 1);if(kind=="trips"){repository.saveTripDestination(saved,destination?.text?.toString().orEmpty());repository.updateTripDistance(saved,BusinessRecordRules.distanceToMetres(amount.text.toString(),repository.preferredMetric()),routeSource)};refresh()}
    }

    private fun tripActions(id:Long) {
        val record=repository.recordValues("trip_log",id)
        val start=Ui.field(this,"Starting address",record["from_address"].orEmpty())
        val end=Ui.field(this,"Destination address",repository.tripDestination(id))
        val distance=Ui.moneyField(this,if(repository.preferredMetric())"Distance in kilometres" else "Distance in miles")
        val current=(record["distance_metres"]?.toDoubleOrNull()?:0.0)/if(repository.preferredMetric())1000.0 else 1609.344
        distance.setText(String.format(Locale.US,"%.2f",current))
        var routeSource=record["distance_source"].orEmpty().ifBlank { "manual" }
        val body=Ui.column(this,8).apply {
            addView(start);addView(end);addView(distance)
            addView(Ui.button(this@MainActivity,"Calculate driving distance online") {
                calculateOnlineRoute(start.text.toString(),end.text.toString()) { result ->
                    routeSource="online:${result.mapName}"
                    distance.setText(String.format(Locale.US,"%.2f",result.distanceMetres/if(repository.preferredMetric())1000.0 else 1609.344))
                }
            })
        }
        formDialog("Trip details",body) {
            repository.updateRecord("trip_log",id,mapOf("from_address" to start.text.toString()))
            repository.saveTripDestination(id,end.text.toString())
            repository.updateTripDistance(id,BusinessRecordRules.distanceToMetres(distance.text.toString(),repository.preferredMetric()),routeSource)
            refresh()
        }
    }

    /** Online address geocoding and driving distance; no map files required. */
    private fun calculateOnlineRoute(from:String,to:String,onResult:(OnlineRoutingEngine.RouteResult)->Unit) {
        if(from.isBlank()||to.isBlank()) { toast("Enter both addresses");return }
        toast("Calculating driving distance online…")
        thread { val result=runCatching { onlineRouter.route(from,to) };runOnUiThread { result.onSuccess(onResult).onFailure { toast(it.message?:"Online route calculation failed") } } }
    }

    /** Choose a navigation provider. OsmAnd requires coordinates, not an address in geo:q. */
    private fun openMapNavigation(address:String) {
        if(address.isBlank()) { toast("No job site address saved"); return }
        val options=arrayOf("OsmAnd (online address lookup)","Google Maps","Other map application")
        AlertDialog.Builder(this).setTitle("Navigate to job site")
            .setItems(options) { _, choice ->
                when(choice) {
                    0 -> {
                        toast("Finding destination coordinates…")
                        thread {
                            val result=runCatching { onlineRouter.lookupCoordinates(address) }
                            runOnUiThread {
                                result.onSuccess { point ->
                                    val uri=Uri.parse("google.navigation:q=${point.latitude},${point.longitude}&mode=d")
                                    val packages=listOf("net.osmand.plus","net.osmand")
                                    val launched=packages.any { pkg ->
                                        try { startActivity(Intent(Intent.ACTION_VIEW,uri).setPackage(pkg)); true }
                                        catch (_:android.content.ActivityNotFoundException) { false }
                                        catch (_:SecurityException) { false }
                                    }
                                    if(!launched) toast("OsmAnd is not installed or cannot accept navigation")
                                }.onFailure { toast("Address lookup failed: ${it.message}") }
                            }
                        }
                    }
                    1 -> {
                        val uri=Uri.parse("google.navigation:q=${Uri.encode(address)}&mode=d")
                        try { startActivity(Intent(Intent.ACTION_VIEW,uri).setPackage("com.google.android.apps.maps")) }
                        catch (_:Exception) { openGenericMapNavigation(address) }
                    }
                    else -> openGenericMapNavigation(address)
                }
            }.show()
    }

    private fun openGenericMapNavigation(address:String) {
        val uri=Uri.parse("geo:0,0?q=${Uri.encode(address)}")
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW,uri),"Open job site in maps")) }
        catch(e:Exception) { toast("No compatible map application: ${e.message}") }
    }

    private fun offlineMapsScreen()=open("Offline routing maps") {
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,"Offline regional maps"))
            addView(Ui.label(this@MainActivity,"Download or import a regional OSM XML (.osm/.xml), gzipped OSM XML (.osm.gz), or MODE graph file. Downloading or importing is a one-time setup; address matching and driving routes then work fully offline."))
            addView(Ui.button(this@MainActivity,"Import downloaded regional map"){promptMapImport()})
            addView(Ui.button(this@MainActivity,"Download regional map by HTTPS URL"){promptMapDownload()})
            addView(Ui.label(this@MainActivity,"For a manageable phone-sized map, choose a city, county, or small multi-county OSM XML extract. PBF and BZ2 files are not supported; select OSM XML or gzip format."))
            val maps=offlineRouter.maps()
            addView(Ui.section(this@MainActivity,"Installed maps (${maps.size})"))
            if(maps.isEmpty())addView(Ui.label(this@MainActivity,"No offline routing maps installed."))
            maps.forEach { map ->
                addView(Ui.card(this@MainActivity,map.name,"${map.nodes} road nodes • ${map.edges} directed edges • ${map.addresses} address/name entries","${String.format(Locale.US,"%.1f",map.bytes/1_048_576.0)} MB",if(map.active)"Active" else "Installed") {
                    if(!map.active){offlineRouter.setActive(map.id);toast("${map.name} selected");refresh()}
                })
                if(!map.active)addView(Ui.button(this@MainActivity,"Use ${map.name}"){offlineRouter.setActive(map.id);refresh()})
                addView(Ui.button(this@MainActivity,"Delete ${map.name}"){confirm("Delete the offline routing map ${map.name}?"){offlineRouter.delete(map.id);refresh()}})
            }
        })
    }

    private fun promptMapImport() {
        val name=Ui.field(this,"Region name")
        formDialog("Import offline routing map",Ui.column(this).apply{addView(name);addView(Ui.label(this@MainActivity,"Choose an OSM XML, .osm.gz, or .modegraph file after continuing."))}) {
            pendingMapRegionName=name.text.toString().trim();require(pendingMapRegionName!!.isNotBlank()){"Enter a region name"}
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/xml","text/xml","application/gzip","application/octet-stream","text/plain")) },6220)
        }
    }

    private fun promptMapDownload() {
        val name=Ui.field(this,"Region name")
        val url=Ui.field(this,"Direct HTTPS URL to .osm, .osm.gz, or .modegraph")
        val body=Ui.column(this,8).apply{addView(name);addView(url);addView(Ui.label(this@MainActivity,"The downloaded map is converted and stored privately. It is not contacted again during routing."))}
        formDialog("Download regional routing map",body) {
            val region=name.text.toString().trim();val address=url.text.toString().trim();require(region.isNotBlank()){"Enter a region name"};require(address.startsWith("https://")){"Enter a direct HTTPS download URL"}
            toast("Downloading and indexing $region…")
            thread { val result=runCatching { offlineRouter.downloadMap(address,region) };runOnUiThread { result.onSuccess { toast("${it.name} installed for offline routing");if(pages.lastOrNull()?.title=="Offline routing maps")refresh() }.onFailure { toast(it.message?:"Map download failed") } } }
        }
    }

    private fun toolActions(id:Long,title:String) {
        AlertDialog.Builder(this).setTitle(title).setItems(arrayOf("Edit tool and quantity","Delete tool")){_,which->
            if(which==0){
                val data=repository.recordValues("tool",id)
                val body=Ui.column(this,8)
                val name=Ui.field(this,"Tool name",data["name"].orEmpty())
                val description=Ui.field(this,"Description",data["description"].orEmpty(),true)
                val quantity=Ui.field(this,"Quantity",data["quantity"]?:"1")
                val location=Ui.field(this,"Location",data["location"].orEmpty())
                listOf(name,description,quantity,location).forEach(body::addView)
                formDialog("Edit tool",body){repository.updateTool(id,name.text.toString(),description.text.toString(),quantity.text.toString().toIntOrNull()?:0,location.text.toString());simpleScreen("Tools","tools")}
            } else confirm("Delete tool?"){repository.deleteRecord("tool",id);simpleScreen("Tools","tools")}
        }.show()
    }

    private fun directoryActions(kind:String,id:Long,label:String) {
        val actions=arrayOf("Open website","Edit website URL","Edit record","Delete record")
        AlertDialog.Builder(this).setTitle(label).setItems(actions){_,choice->when(choice){
            0->runCatching {openExternalUrl(repository.directoryUrl(kind,id))}.onFailure{toast(it.message?:"Invalid URL")}
            1->{val url=Ui.field(this,"Website URL",repository.directoryUrl(kind,id));formDialog("Website",Ui.column(this).apply{addView(url)}){repository.setDirectoryUrl(kind,id,url.text.toString());refresh()}}
            2->recordEditor(kind,id,false)
            3->confirm("Delete this $kind?"){repository.deleteRecord(kind,id);refresh()}
        }}.setNegativeButton("Cancel",null).show()
    }
    private fun openExternalUrl(raw:String) {
        val url=raw.trim();val parsed=Uri.parse(url)
        require(BusinessRecordRules.isHttpUrl(url)) {"No valid website URL saved"}
        startActivity(Intent(Intent.ACTION_VIEW,parsed).addCategory(Intent.CATEGORY_BROWSABLE))
    }
    private fun receiptActions(id:Long) {
        AlertDialog.Builder(this).setTitle("Receipt").setItems(arrayOf("View photos","Choose receipt/expense photo","Take receipt/expense photo","Edit receipt","Delete receipt")){_,choice->when(choice){
            0->receiptPhotoGallery(id)
            1->{pendingReceiptPhotoId=id;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6214)}
            2->captureReceiptPhoto(id)
            3->receiptEditor(id)
            4->confirm("Permanently delete this receipt and its photos?"){repository.deleteReceipt(id);refresh()}
        }}.setNegativeButton("Cancel",null).show()
    }
    private fun receiptEditor(id:Long) {
        val record=repository.recordValues("receipt",id);val choices=repository.supplierChoices()
        if(choices.isEmpty()){toast("Add a supplier first");return}
        val date=Ui.field(this,"Receipt date YYYY-MM-DD",record["receipt_date"].orEmpty())
        val amount=Ui.moneyField(this,"Total including tax ($)",record["total_including_tax"]?.toLongOrNull()?:0L)
        val tax=Ui.moneyField(this,"Tax included ($)",record["tax"]?.toLongOrNull()?:0L)
        val supplier=spinner(choices.map{it.label},choices.indexOfFirst{it.id.toString()==record["supplier_id"]}.coerceAtLeast(0))
        val body=Ui.column(this).apply{addView(Ui.label(this@MainActivity,"Supplier"));addView(supplier);addView(date);addView(amount);addView(tax)}
        body.addView(Ui.button(this,"Manage receipt photos"){receiptPhotoGallery(id)})
        formDialog("Edit receipt",body){repository.updateReceipt(id,choices[supplier.selectedItemPosition].id,MoneyMath.parseCents(amount.text.toString()),date.text.toString(),MoneyMath.parseCents(tax.text.toString()));refresh()}
    }
    private fun captureReceiptPhoto(id:Long) {
        pendingCameraReceiptId=id
        runCatching { startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),6215) }
            .onFailure { pendingCameraReceiptId=null;toast("No camera application available") }
    }
    private fun receiptPhotoGallery(id:Long) {
        open("Receipt photos") { Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.button(this@MainActivity,"Take photo with camera"){captureReceiptPhoto(id)})
            addView(Ui.button(this@MainActivity,"+ Add photo"){pendingReceiptPhotoId=id;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},6214)})
            val photos=repository.receiptPhotos(id)
            if(photos.isEmpty())addView(Ui.label(this@MainActivity,"No receipt photos"))
            photos.forEach { (photoId,bytes) ->
                val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                if(bitmap!=null)addView(ImageView(this@MainActivity).apply{setImageBitmap(bitmap);adjustViewBounds=true;maxHeight=700})
                addView(Ui.button(this@MainActivity,"Delete photo"){confirm("Delete this receipt photo?"){repository.deleteReceiptPhoto(id,photoId);receiptPhotoGallery(id)}})
            }
        }) }
    }

    private fun reportsScreen()=open("Reports") { Ui.scroll(this,Ui.column(this).apply {
        addView(Ui.title(this@MainActivity,"Financial reports"))
        addView(Ui.button(this@MainActivity,"Revenue by month"){reportScreen("Revenue","revenue")})
        addView(Ui.button(this@MainActivity,"Aged/open receivables"){reportScreen("Receivables","receivables")})
        addView(Ui.button(this@MainActivity,"Expenses by month"){reportScreen("Expenses","expenses")})
    }) }
    private fun reportScreen(title:String,type:String)=open(title){
        val rows = repository.reportRows(type)
        Ui.scroll(this,Ui.column(this).apply {
            addView(Ui.title(this@MainActivity,title))
            addView(Ui.button(this@MainActivity,"Export branded PDF") {
                try {
                    val businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() }
                    val business=businessDetails["business_name"].orEmpty().ifBlank { "MODE Handyman" }
                    val file=PdfGenerator.createReport(this@MainActivity,title,business,
                        "Generated ${LocalDate.now()}",rows,businessDetails,activeLogoFile().takeIf(File::isFile))
                    shareFile(file,"application/pdf")
                } catch(error:Exception) { toast("Report export failed: ${error.message ?: "Unknown error"}") }
            })
            if(rows.isEmpty()) addView(Ui.label(this@MainActivity,"No records for this business profile."))
            rows.forEach { row -> addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status) {}) }
        })
    }

    private fun settingsScreen()=open("Settings") { val metric=repository.preferredMetric();Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Business & privacy"))
        addView(Ui.button(this@MainActivity,"Business setup"){businessSetup()})
        addView(Ui.button(this@MainActivity,"Business profiles (up to 5)"){profilesScreen()})
        val toggle=CheckBox(this@MainActivity).apply{setText(R.string.metric_measurements);isChecked=metric;setTextColor(Ui.TEXT);setOnCheckedChangeListener{_,checked->repository.setPreferredMetric(checked);toast(if(checked)"Metric units enabled" else "US customary units enabled")}}
        addView(toggle)
        addView(CheckBox(this@MainActivity).apply {
            setText(R.string.calculator_enabled_all_pages)
            setTextColor(Ui.TEXT)
            isChecked = FloatingCalculator.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                FloatingCalculator.setEnabled(this@MainActivity, checked)
                calculatorButton.visibility = if (checked) View.VISIBLE else View.GONE
            }
        })
        addView(Ui.button(this@MainActivity,"Open calculator") { FloatingCalculator.show(this@MainActivity) })
        addView(Ui.button(this@MainActivity,"Create local backup"){createBackup()})
        addView(Ui.button(this@MainActivity,"Restore local backup"){confirm("Restore replaces the active local database after creating a recovery copy. Continue?"){restoreBackup()}})
        addView(Ui.button(this@MainActivity,"Crash diagnostics"){crashesScreen()})
        addView(Ui.button(this@MainActivity,"Privacy & about"){aboutScreen()})
    }) }

    private fun activeLogoFile(): File {
        val profile = repository.profiles.all().first { it.active }.id
        return File(filesDir, "business-logos/profile-$profile.png")
    }

    private fun chooseCustomerExport(ids: List<Long>) {
        if (ids.isEmpty()) { toast("No customers to export"); return }
        AlertDialog.Builder(this).setTitle("Export ${ids.size} customer(s)").setItems(arrayOf("JSON", "CSV")) { _, which ->
            customerExportIds = ids; customerExportCsv = which == 1
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = if (customerExportCsv) "text/csv" else "application/json"
                putExtra(Intent.EXTRA_TITLE, "MODE-customers.${if(customerExportCsv) "csv" else "json"}")
            }, 6210)
        }.show()
    }

    private fun pickCustomerImport() = startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/csv", "text/plain", "application/octet-stream"))
    }, 6211)

    private fun previewCustomerImport(payload: org.json.JSONObject) {
        runCatching {
            require(payload.optString("format") == "mode-customer-contacts" && payload.optInt("version") == 1)
            val profiles = repository.profiles.all()
            AlertDialog.Builder(this).setTitle("Import into business profile").setItems(profiles.map { it.name }.toTypedArray()) { _, index ->
                val target = profiles[index]
                runCatching {
                    val total = payload.getJSONArray("customers").length()
                    val duplicates = repository.customerDuplicateCount(payload, target.id)
                    AlertDialog.Builder(this).setTitle("Review customer import")
                        .setMessage("$total customers; $duplicates potential name duplicates. Destination: ${target.name}. Only contact data will be transferred; jobs and finances are excluded.")
                        .setItems(arrayOf("Skip duplicates", "Update existing contacts", "Create separate customers")) { _, policyIndex ->
                            val policy = listOf("skip", "update", "separate")[policyIndex]
                            AlertDialog.Builder(this).setTitle("Confirm import").setMessage("Import contact information into ${target.name} using '$policy' duplicate handling?")
                                .setNegativeButton("Cancel",null).setPositiveButton("Import") { _, _ ->
                                    runCatching { repository.importCustomerContacts(payload,target.id,policy) }
                                        .onSuccess { toast("Imported ${it.first}; skipped ${it.second}"); refresh() }
                                        .onFailure { toast(it.message ?: "Import failed") }
                                }.show()
                        }.show()
                }.onFailure { toast(it.message ?: "Invalid import") }
            }.show()
        }.onFailure { toast(it.message ?: "Invalid customer file") }
    }

    private fun pickBusinessLogo() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }, logoRequestCode)
    }

    @Deprecated("Uses Android document picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            6220 -> {
                val region=pendingMapRegionName;pendingMapRegionName=null
                if(resultCode==Activity.RESULT_OK && region!=null)data?.data?.let { uri ->
                    toast("Importing and indexing $region…")
                    thread { val result=runCatching { offlineRouter.importMap(uri,region) };runOnUiThread { result.onSuccess { toast("${it.name} installed for offline routing");if(pages.lastOrNull()?.title=="Offline routing maps")refresh() }.onFailure { toast(it.message?:"Map import failed") } } }
                }
            }
            6215 -> {
                val receiptId=pendingCameraReceiptId;pendingCameraReceiptId=null
                if(resultCode==Activity.RESULT_OK && receiptId!=null) runCatching {
                    @Suppress("DEPRECATION")
                    val bitmap=data?.extras?.get("data") as? Bitmap ?: error("Camera did not return an image")
                    val output=ByteArrayOutputStream()
                    require(bitmap.compress(Bitmap.CompressFormat.JPEG,85,output))
                    repository.addReceiptPhoto(receiptId,output.toByteArray())
                }.onSuccess{receiptPhotoGallery(receiptId!!)}.onFailure{toast(it.message?:"Unable to save camera photo")}
            }
            6214 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val receiptId=pendingReceiptPhotoId;pendingReceiptPhotoId=null
                if(receiptId!=null)runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: error("Cannot read photo")
                    require(bytes.size<=8_000_000){"Image is too large"}
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)?:error("Invalid image")
                    val scale=minOf(1f,1400f/maxOf(bitmap.width,bitmap.height))
                    val reduced=if(scale<1f)Bitmap.createScaledBitmap(bitmap,(bitmap.width*scale).toInt().coerceAtLeast(1),(bitmap.height*scale).toInt().coerceAtLeast(1),true) else bitmap
                    val output=ByteArrayOutputStream();require(reduced.compress(Bitmap.CompressFormat.JPEG,80,output))
                    repository.addReceiptPhoto(receiptId,output.toByteArray())
                }.onSuccess{toast("Receipt photo saved");receiptPhotoGallery(receiptId)}.onFailure{toast(it.message?:"Photo failed")}
            }

            6210 -> if (resultCode == Activity.RESULT_OK) data?.data?.let { uri ->
                runCatching {
                    val json = repository.exportCustomerContacts(customerExportIds)
                    val output = if (customerExportCsv) CustomerTransfer.toCsv(json) else json.toString(2)
                    contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(output) } ?: error("Unable to write export")
                }.onSuccess { toast("Customer contacts exported") }.onFailure { toast(it.message ?: "Export failed") }
            }
            6211 -> if (resultCode == Activity.RESULT_OK) data?.data?.let { uri ->
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Unable to read file")
                    require(text.length <= 8_000_000) { "Import file too large" }
                    if (text.trimStart().startsWith("{")) org.json.JSONObject(text) else CustomerTransfer.fromCsv(text)
                }.onSuccess { previewCustomerImport(it) }.onFailure { toast(it.message ?: "Import failed") }
            }
            6213 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val noteId=pendingNotePhotoId;pendingNotePhotoId=null
                if(noteId!=null) runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read image")
                    require(bytes.size<=8_000_000) { "Image exceeds 8 MB" }
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: error("Invalid image")
                    val scaled=if(bitmap.width>1600||bitmap.height>1600){val factor=minOf(1600f/bitmap.width,1600f/bitmap.height);Bitmap.createScaledBitmap(bitmap,(bitmap.width*factor).toInt().coerceAtLeast(1),(bitmap.height*factor).toInt().coerceAtLeast(1),true)} else bitmap
                    val name="note-${noteId}-${java.util.UUID.randomUUID()}.jpg"
                    val dir=File(filesDir,"work-note-photos").apply{mkdirs()}
                    val target=File(dir,name)
                    try {
                        target.outputStream().use { require(scaled.compress(Bitmap.CompressFormat.JPEG,85,it)) { "Unable to save photo" } }
                        val photoId=repository.addNotePhoto(noteId,name)
                        val note=repository.workNote(noteId)
                        val offset=pendingNotePhotoOffset.coerceIn(0,note.body.length)
                        repository.saveWorkNote(noteId,note.customerId,note.title,NotePhotoMarkers.insert(note.body,offset,photoId))
                    } catch(e:Exception) { target.delete();throw e }
                }.onSuccess { pendingNotePhotoOffset=-1;toast("Photo inserted");noteForm(noteId) }.onFailure { toast(it.message?:"Photo import failed") }
            }
            6212 -> if(resultCode==Activity.RESULT_OK) data?.data?.let { uri ->
                val customerId=pendingCustomerPhotoId
                pendingCustomerPhotoId=null
                if(customerId!=null) runCatching {
                    val bytes=contentResolver.openInputStream(uri)?.use { input -> input.readBytes() } ?: error("Unable to read photo")
                    require(bytes.size<=2_000_000) { "Select an image smaller than 2 MB" }
                    require(BitmapFactory.decodeByteArray(bytes,0,bytes.size)!=null) { "Invalid image" }
                    repository.saveCustomerPhoto(customerId,android.util.Base64.encodeToString(bytes,android.util.Base64.NO_WRAP))
                }.onSuccess { toast("Customer photo saved") }.onFailure { toast(it.message?:"Photo import failed") }
            }
            logoRequestCode -> {
                if (resultCode == Activity.RESULT_OK) importBusinessLogo(data)
            }
            90 -> {
                val pending = backupExportPending
                backupExportPending = false
                if (resultCode == Activity.RESULT_OK && pending) {
                    val uri = data?.data ?: return
                    runCatching {
                        contentResolver.openOutputStream(uri, "w")?.use { BackupManager.export(this, it) }
                            ?: error("Unable to open the selected backup destination")
                    }.onSuccess { toast("Local backup exported") }
                        .onFailure { toast(it.message ?: "Backup failed") }
                }
            }
            91 -> {
                val pending = backupRestorePending
                backupRestorePending = false
                if (resultCode == Activity.RESULT_OK && pending) {
                    val uri = data?.data ?: return
                    runCatching {
                        contentResolver.openInputStream(uri)?.use {
                            BackupManager.restore(this, it, (application as ModeApplication).databaseManager)
                        } ?: error("Unable to open the selected backup")
                    }.onSuccess { toast("Backup restored"); recreate() }
                        .onFailure { toast(it.message ?: "Restore failed") }
                }
            }
        }
    }

    private fun importBusinessLogo(data: Intent?) {
        val uri = data?.data ?: return
        runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            require(bounds.outWidth in 1..12000 && bounds.outHeight in 1..12000) { "Invalid image dimensions" }
            var sample = 1
            while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > 1400) sample *= 2
            val bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: error("Unable to read image")
            try {
                val target = activeLogoFile()
                target.parentFile?.mkdirs()
                val temporary = File(target.parentFile, target.name + ".tmp")
                temporary.outputStream().use { require(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
                require(temporary.length() in 1..8_000_000) { "Logo file is too large" }
                if (!temporary.renameTo(target)) { temporary.copyTo(target, overwrite = true); temporary.delete() }
            } finally { bitmap.recycle() }
        }.onSuccess { toast("Business logo saved"); businessSetup() }
            .onFailure { toast("Could not import logo: ${it.message}") }
    }

    private fun businessSetup(): Unit = open("Business setup") {
        val s=repository.system();Ui.scroll(this,Ui.column(this).apply{
            addView(Ui.title(this@MainActivity,"Business details"))
            val logo = activeLogoFile()
            if (logo.isFile) {
                val preview = ImageView(this@MainActivity).apply {
                    setImageURI(Uri.fromFile(logo))
                    adjustViewBounds = true
                    maxHeight = 180
                }
                addView(preview)
            }
            addView(Ui.button(this@MainActivity,"Upload / change business logo") { pickBusinessLogo() })
            if (logo.isFile) addView(Ui.button(this@MainActivity,"Remove business logo") {
                confirm("Remove the logo for this business profile?") { logo.delete(); businessSetup() }
            })
            addView(Ui.label(this@MainActivity,"These details stay on this device and are stored independently for the active profile."))
            val fields=linkedMapOf<String,EditText>()
            listOf("business_name" to "Business name","business_number" to "Business number","firstname" to "First name","surname" to "Surname","address_line_1" to "Address line 1","address_line_2" to "Address line 2","suburb" to "City / suburb","state" to "State / province","postcode" to "Postal code","country_code" to "Country code","email_address" to "Email (optional)","mobile_number" to "Phone (optional)","web_url" to "Website (optional)","payment_options" to "Payment instructions","operating_hours" to "Operating hours").forEach{(key,label)->Ui.field(this@MainActivity,label,s[key]?.toString().orEmpty(),key in setOf("payment_options","operating_hours")).also{fields[key]=it;addView(it)}}
            addView(Ui.button(this@MainActivity,"Save business profile"){repository.updateSystem(fields.mapValues{it.value.text.toString()});toast("Saved locally")})
        })
    }

    private fun profilesScreen()=open("Business profiles") { Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Independent profiles"));addView(Ui.label(this@MainActivity,"Customers, jobs, quotes, invoices, inventory, and financial records are isolated by profile."))
        repository.profiles.all().forEach{p->addView(Ui.card(this@MainActivity,p.name,if(p.active)"Currently active" else "Tap to switch",if(p.active)"✓" else "›",onClick=if(p.active)null else {{repository.profiles.activate(p.id);dashboard(true)}}))}
        if(repository.profiles.all().size<5)addView(Ui.button(this@MainActivity,"+ Add business profile"){profileCreate()})
    }) }
    private fun profileCreate(){val name=Ui.field(this,"Profile name");formDialog("New business profile",name){repository.profiles.create(name.text.toString());dashboard(true)}}

    private fun crashesScreen()=open("Crash diagnostics") { val files=LocalCrashReporter.reports(this);Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"Local crash reports"));addView(Ui.label(this@MainActivity,"Reports never upload automatically. Sensitive patterns are redacted."))
        if(files.isEmpty()) addView(Ui.label(this@MainActivity,"No crash reports stored."))
        files.forEach { file -> addView(Ui.card(this@MainActivity,file.name,"${file.length()} bytes","›") { crashDetail(file) }) }
        if(files.isNotEmpty())addView(Ui.button(this@MainActivity,"Delete all reports"){confirm("Permanently delete all local crash reports?"){files.forEach { LocalCrashReporter.delete(this@MainActivity, it) };refresh()}})
    }) }
    private fun crashDetail(file:File)=open(file.name){Ui.scroll(this,Ui.column(this).apply{addView(Ui.label(this@MainActivity,file.readText().take(30000),Ui.TEXT,12f));addView(Ui.button(this@MainActivity,"Share report manually"){shareFile(file,"application/json")})})}

    private fun openProjectReleases() {
        val url = "https://github.com/Maclean-Of-Duart-Enterprises/MODE-Handyman"
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { toast("No browser available to open project releases") }
    }

    private fun licenseScreen() = open("Open-source license") {
        Ui.scroll(this, Ui.column(this).apply {
            addView(Ui.title(this@MainActivity, "GNU Affero General Public License v3.0"))
            addView(Ui.label(this@MainActivity, "MODE Handyman is distributed under the GNU Affero General Public License, version 3 (AGPL-3.0-only). You may use, study, modify, and redistribute it under the license terms. Modified versions made available over a network must offer corresponding source code to network users, as required by section 13."))
            addView(Ui.label(this@MainActivity, "Copyright (c) Maclean Of Duart Enterprises Corp. This program is provided WITHOUT ANY WARRANTY, to the extent permitted by law."))
            addView(Ui.button(this@MainActivity, "Read complete AGPLv3 license (offline)") {
                open("GNU AGPLv3 — Complete License") {
                    Ui.scroll(this@MainActivity, Ui.column(this@MainActivity).apply {
                        val licenseText = runCatching {
                            assets.open("AGPL-3.0.txt").bufferedReader().use { it.readText() }
                        }.getOrElse { "Unable to read bundled license: ${it.message}" }
                        addView(Ui.label(this@MainActivity, licenseText, Ui.TEXT, 12f))
                    })
                }
            })
            addView(Ui.button(this@MainActivity, "Project source code and releases") { openProjectReleases() })
        })
    }

    private fun aboutScreen()=open("Privacy & about") { Ui.scroll(this,Ui.column(this).apply{
        addView(Ui.title(this@MainActivity,"MODE Handyman"))
        addView(Ui.label(this@MainActivity,"Native Kotlin edition 2.1.16",Ui.GOLD))
        addView(Ui.label(this@MainActivity,"Maclean Of Duart Enterprises Corp — MODE Handyman"))
        addView(Ui.section(this@MainActivity,"License and source"))
        addView(Ui.label(this@MainActivity,"Licensed under GNU Affero General Public License v3.0 (AGPL-3.0-only)."))
        addView(Ui.button(this@MainActivity,"View AGPLv3 license") { licenseScreen() })
        addView(Ui.button(this@MainActivity,"Source code and releases") { openProjectReleases() })
        addView(Ui.section(this@MainActivity,"Privacy"))
        addView(Ui.label(this@MainActivity,"No analytics, advertisements, tracking SDKs, remote synchronization, SMTP, or automatic crash uploads. Trip driving distances use online OpenStreetMap Nominatim geocoding and OSRM routing; when you request a distance, the starting and destination addresses are sent to the geocoding service and coordinates are sent to the routing service. Job-site navigation sends the selected destination to your chosen maps application. Other business data remains local. Other business data remains local. Customer contact details are optional; any supplied phone or email information is included on customer-facing documents. PDF generation, backups, and Android share actions do not require Internet access."))
        addView(Ui.section(this@MainActivity,"Storage"))
        addView(Ui.label(this@MainActivity,"Business data is stored in the private local SQLite database. Files leave the app only after you choose an Android destination or share target."))
    }) }

    private fun recordActions(table:String,id:Long,label:String) {
        val actions=arrayOf("Edit", "Rename", "Copy", "Delete")
        AlertDialog.Builder(this).setTitle(label).setItems(actions){_,which ->
            when(which){
                0 -> when(table){
                    "customer"->customerForm(repository.customer(id))
                    "job"->jobForm(repository.job(id))
                    "quote"->quoteDetailsForm(id)
                    "invoice"->invoiceDetailsForm(id)
                    else->recordEditor(table,id,false)
                }
                1 -> recordEditor(table,id,true)
                2 -> confirm("Copy this $label?"){runCatching { repository.copyRecord(table,id) }.onSuccess { dashboard(true) }.onFailure { toast(it.message ?: "Copy failed") }}
                3 -> confirm("Permanently delete this $label? This cannot be undone."){runCatching { repository.deleteRecord(table,id) }.onSuccess { dashboard(true) }.onFailure { toast(it.message ?: "Delete failed") }}
            }
        }.setNegativeButton("Cancel",null).show()
    }

    private fun recordEditor(table:String,id:Long,renameOnly:Boolean) {
        val data=repository.editableFields(table,id)
        val excluded=emptySet<String>()
        val primary=listOf("name","title","quote_num","invoice_num","summary","job_number","purpose","firstName","description","start_date","note").firstOrNull{it in data}
        val fields=data.keys.filter{it !in excluded && (!renameOnly || it==primary)}
        if(fields.isEmpty()){toast("No editable fields");return}
        val body=Ui.column(this,8)
        val inputs=fields.map { key -> key to Ui.field(this,key.replace('_',' ').replaceFirstChar{it.uppercase()},data[key].orEmpty(),key in setOf("notes","description","terms")) .also(body::addView) }
        formDialog(if(renameOnly)"Rename record" else "Edit record",body){
            repository.updateRecord(table,id,inputs.associate{it.first to it.second.text.toString()});dashboard(true)
        }
    }

    private fun quoteDetailsForm(id:Long) {
        val data=repository.recordValues("quote",id);val jobs=repository.jobChoices();val selected=jobs.indexOfFirst{it.id==data["job_id"]?.toLongOrNull()}.coerceAtLeast(0)
        val body=Ui.column(this,8);val job=spinner(jobs.map{it.label},selected);val number=Ui.field(this,"Quote number",data["quote_num"].orEmpty());val summary=Ui.field(this,"Summary",data["summary"].orEmpty());val description=Ui.field(this,"Description",data["description"].orEmpty(),true);val assumption=Ui.field(this,"Assumptions",data["assumption"].orEmpty(),true)
        listOf(Ui.label(this,"Job"),job,number,summary,description,assumption).forEach(body::addView)
        formDialog("Edit quote",body){require(jobs.isNotEmpty()){"Add a job first"};repository.updateQuoteDetails(id,jobs[job.selectedItemPosition].id,number.text.toString(),summary.text.toString(),description.text.toString(),assumption.text.toString());refresh()}
    }

    private fun invoiceDetailsForm(id:Long) {
        val data=repository.recordValues("invoice",id);val jobs=repository.jobChoices();val customers=repository.customerChoices();val selectedJob=jobs.indexOfFirst{it.id==data["job_id"]?.toLongOrNull()}.coerceAtLeast(0);val selectedCustomer=(customers.indexOfFirst{it.id==data["billing_customer_id"]?.toLongOrNull()}+1).coerceAtLeast(0)
        val body=Ui.column(this,8);val job=spinner(jobs.map{it.label},selectedJob);val billing=spinner(listOf("Use job customer")+customers.map{it.label},selectedCustomer);val number=Ui.field(this,"Invoice number",data["invoice_num"].orEmpty());val due=Ui.field(this,"Due date YYYY-MM-DD",data["due_date"].orEmpty());val note=Ui.field(this,"Void / internal description",data["void_description"].orEmpty(),true)
        listOf(Ui.label(this,"Job"),job,Ui.label(this,"Billing customer"),billing,number,due,note).forEach(body::addView)
        formDialog("Edit invoice",body){require(jobs.isNotEmpty()){"Add a job first"};repository.updateInvoiceDetails(id,jobs[job.selectedItemPosition].id,if(billing.selectedItemPosition==0)null else customers[billing.selectedItemPosition-1].id,number.text.toString(),due.text.toString(),note.text.toString());refresh()}
    }

    private fun searchableList(hint:String,loader:(String)->List<ListRow>,onOpen:(Long)->Unit):LinearLayout{
        val root=Ui.column(this);val search=Ui.field(this,hint);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};fun load(){list.removeAllViews();val rows=loader(search.text.toString());if(rows.isEmpty())list.addView(Ui.label(this,"No matching records."));rows.forEach{row->list.addView(Ui.card(this,row.title,row.subtitle,row.trailing,row.status){onOpen(row.id)})}};search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int)=load();override fun afterTextChanged(s:Editable?) {}});root.addView(search);root.addView(list);load();return root
    }

    private fun listPage(rows:List<ListRow>,onOpen:(Long)->Unit):LinearLayout=Ui.column(this).apply{if(rows.isEmpty())addView(Ui.label(this@MainActivity,"No records for this business profile."));rows.forEach{row->addView(Ui.card(this@MainActivity,row.title,row.subtitle,row.trailing,row.status,if(row.id>0){{onOpen(row.id)}}else null))}}
    private fun spinner(items:List<String>,selection:Int=0)=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);if(items.isNotEmpty())setSelection(selection.coerceIn(0,items.lastIndex));layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)}

    @Suppress("DEPRECATION")
    private fun formDialog(title:String,view:View,onSave:()->Unit){val dialog=AlertDialog.Builder(this).setTitle(title).setView(Ui.scroll(this,view)).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();dialog.setOnShowListener{dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{runCatching(onSave).onSuccess{dialog.dismiss()}.onFailure{toast(it.message?:"Could not save")}}};dialog.show()}
    private fun confirm(message:String,action:()->Unit){AlertDialog.Builder(this).setMessage(message).setNegativeButton("Cancel",null).setPositiveButton("OK"){_,_->runCatching(action).onFailure{toast(it.message?:"Action failed")}}.show()}
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_LONG).show()

    private fun shareQuote(id:Long){val q=repository.quote(id);val lines=repository.quoteLines(id);val tax=(q.totalCents-(q.subtotalCents-q.discountCents).coerceAtLeast(0)).coerceAtLeast(0);val business=repository.system()["business_name"]?.toString().orEmpty().ifBlank{"MODE Handyman"};val profile=repository.profiles.all().first{it.active}.id.toString();val attachments=SmartToolsStore(this).use{it.attachmentsForJobId(profile,repository.jobIdForQuote(id))};val signature=repository.documentSignature("quote",id)?.let{PdfGenerator.ApprovalBlock(it.signer,"Customer signature captured for this quote.",it.signedAt,File(it.file))};shareFile(PdfGenerator.create(this,PdfGenerator.Document(kind="Quote",number=q.number,business=business,customer=q.customer,customerDetails=repository.documentCustomerDetails("quote",id),job=q.job,jobSiteAddress=repository.documentJobSiteAddress("quote",id),dateLabel="Status: ${q.state}",lines=lines,subtotal=q.subtotalCents,discount=q.discountCents,tax=tax,total=q.totalCents,terms=q.terms,businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() },attachments=attachments,approval=signature,logo=activeLogoFile().takeIf(File::isFile))),"application/pdf")}
    private fun shareInvoice(id:Long){val i=repository.invoice(id);val lines=repository.invoiceLines(id);val business=repository.system()["business_name"]?.toString().orEmpty().ifBlank{"MODE Handyman"};val profile=repository.profiles.all().first{it.active}.id.toString();val attachments=SmartToolsStore(this).use{it.attachmentsForJobId(profile,repository.jobIdForInvoice(id))};val signature=repository.documentSignature("invoice",id)?.let{PdfGenerator.ApprovalBlock(it.signer,"Customer signature captured for this invoice.",it.signedAt,File(it.file))};shareFile(PdfGenerator.create(this,PdfGenerator.Document(kind="Invoice",number=i.number,business=business,customer=i.customer,customerDetails=repository.documentCustomerDetails("invoice",id),job=i.job,jobSiteAddress=repository.documentJobSiteAddress("invoice",id),dateLabel=if(i.paid) "PAID" else "Due: ${i.dueDate?:"not set"}",lines=lines,subtotal=i.totalCents,total=i.totalCents,paidAmount=i.paidCents,balanceDue=i.balanceCents,terms=repository.invoiceTerms(id),businessDetails=repository.system().mapValues { it.value?.toString().orEmpty() },attachments=attachments,approval=signature,logo=activeLogoFile().takeIf(File::isFile))),"application/pdf")}
    private fun shareFile(file:File,mime:String){val uri=Uri.parse("content://${packageName}.provider/${if(file.parentFile?.name=="crash-reports")"crash" else "exports"}/${Uri.encode(file.name)}");startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri(file.name,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share using"))}

    private fun createBackup(){backupExportPending=true;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,"MODE-Handyman-backup-${LocalDate.now()}.zip")},90)}
    private fun restoreBackup(){backupRestorePending=true;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip"},91)}
}
