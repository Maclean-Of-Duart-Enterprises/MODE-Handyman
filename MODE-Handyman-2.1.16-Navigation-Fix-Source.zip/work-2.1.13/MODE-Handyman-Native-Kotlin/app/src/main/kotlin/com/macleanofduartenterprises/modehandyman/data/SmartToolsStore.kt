package com.macleanofduartenterprises.modehandyman.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.macleanofduartenterprises.modehandyman.core.EstimateComponent
import com.macleanofduartenterprises.modehandyman.core.JobIdentity
import com.macleanofduartenterprises.modehandyman.core.SmartToolsLogic
import java.io.File

/** Additive private storage for Smart Tools. The legacy handyman tables are never replaced. */
class SmartToolsStore(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, SCHEMA_VERSION) {
    companion object {
        const val DB_NAME = "mode-smart-tools.db"
        const val SCHEMA_VERSION = 6
        private val linkedTables = setOf("estimates", "costs", "job_revenue", "attachments", "approvals")
        private val allTables = linkedTables + setOf("materials", "material_suppliers", "smart_suppliers")
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.rawQuery("PRAGMA busy_timeout=5000", null).use { check(it.moveToFirst()) }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE materials(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,name TEXT NOT NULL,supplier TEXT NOT NULL,unit TEXT NOT NULL,cents INTEGER NOT NULL CHECK(cents>=0),updated INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE estimates(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,title TEXT NOT NULL,category TEXT NOT NULL,quantity REAL NOT NULL CHECK(quantity>0),unit TEXT NOT NULL,materials_cents INTEGER NOT NULL CHECK(materials_cents>=0),labor_cents INTEGER NOT NULL CHECK(labor_cents>=0),markup_percent REAL NOT NULL CHECK(markup_percent>=0),total_cents INTEGER NOT NULL CHECK(total_cents>=0),created INTEGER NOT NULL,job_id INTEGER,quote_id INTEGER,link_status TEXT NOT NULL DEFAULT 'unresolved',link_note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE costs(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,description TEXT NOT NULL,type TEXT NOT NULL,cents INTEGER NOT NULL CHECK(cents>=0),created INTEGER NOT NULL,job_id INTEGER,link_status TEXT NOT NULL DEFAULT 'unresolved',link_note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE job_revenue(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,cents INTEGER NOT NULL CHECK(cents>=0),created INTEGER NOT NULL,job_id INTEGER,link_status TEXT NOT NULL DEFAULT 'unresolved',link_note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE attachments(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,kind TEXT NOT NULL,file TEXT NOT NULL,note TEXT NOT NULL,created INTEGER NOT NULL,job_id INTEGER,link_status TEXT NOT NULL DEFAULT 'unresolved',link_note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE approvals(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,quote_id INTEGER,attachment_id INTEGER,signer TEXT NOT NULL,agreement TEXT NOT NULL,approved_at INTEGER NOT NULL,status TEXT NOT NULL,job_id INTEGER,estimate_id INTEGER,customer_id INTEGER,signature_file TEXT,contract_file TEXT,consent_text TEXT,content_sha256 TEXT,core_approval_id INTEGER,link_status TEXT NOT NULL DEFAULT 'unresolved',link_note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE estimate_components(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,estimate_id INTEGER NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,kind TEXT NOT NULL CHECK(kind IN ('material','labor','markup','other')),description TEXT NOT NULL,quantity_thousandths INTEGER NOT NULL CHECK(quantity_thousandths>=0),unit TEXT NOT NULL,unit_cents INTEGER NOT NULL CHECK(unit_cents>=0),line_total_cents INTEGER NOT NULL CHECK(line_total_cents>=0),position INTEGER NOT NULL)")
        createSupplierSchema(db)
        createExtraLinksSchema(db)
        createIndexes(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // SQLiteOpenHelper already wraps onUpgrade in a transaction.
            if (oldVersion < 2 && !tableExists(db, "approvals")) {
                db.execSQL("CREATE TABLE approvals(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,job TEXT NOT NULL,quote_id INTEGER,attachment_id INTEGER,signer TEXT NOT NULL,agreement TEXT NOT NULL,approved_at INTEGER NOT NULL,status TEXT NOT NULL)")
            }
            if (oldVersion < 3) {
                linkedTables.forEach { addColumn(db, it, "job_id", "INTEGER") }
                addColumn(db, "estimates", "quote_id", "INTEGER")
                addColumn(db, "approvals", "estimate_id", "INTEGER")
            }
            if (oldVersion < 4) {
                linkedTables.forEach { table ->
                    addColumn(db, table, "link_status", "TEXT NOT NULL DEFAULT 'unresolved'")
                    addColumn(db, table, "link_note", "TEXT NOT NULL DEFAULT ''")
                    db.execSQL("UPDATE $table SET job_id=NULL WHERE job_id=0")
                    db.execSQL("UPDATE $table SET link_status='verified',link_note='Previously selected job identifier' WHERE job_id IS NOT NULL")
                }
                addColumn(db, "approvals", "customer_id", "INTEGER")
                addColumn(db, "approvals", "signature_file", "TEXT")
                addColumn(db, "approvals", "contract_file", "TEXT")
                addColumn(db, "approvals", "consent_text", "TEXT")
                addColumn(db, "approvals", "content_sha256", "TEXT")
                addColumn(db, "approvals", "core_approval_id", "INTEGER")
                db.execSQL("CREATE TABLE IF NOT EXISTS estimate_components(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,estimate_id INTEGER NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,kind TEXT NOT NULL CHECK(kind IN ('material','labor','markup','other')),description TEXT NOT NULL,quantity_thousandths INTEGER NOT NULL CHECK(quantity_thousandths>=0),unit TEXT NOT NULL,unit_cents INTEGER NOT NULL CHECK(unit_cents>=0),line_total_cents INTEGER NOT NULL CHECK(line_total_cents>=0),position INTEGER NOT NULL)")
            }
            if (oldVersion < 5) createSupplierSchema(db)
            if (oldVersion < 6) createExtraLinksSchema(db)
            createIndexes(db)
    }

    fun saveEstimate(values: ContentValues, components: List<EstimateComponent>): Long {
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = db.insertOrThrow("estimates", null, values)
            components.forEachIndexed { index, component ->
                db.insertOrThrow("estimate_components", null, ContentValues().apply {
                    put("profile", values.getAsString("profile")); put("estimate_id", id); put("kind", component.kind)
                    put("description", component.description); put("quantity_thousandths", component.quantityThousandths)
                    put("unit", component.unit); put("unit_cents", component.unitCents)
                    put("line_total_cents", component.lineTotalCents); put("position", index)
                })
            }
            db.setTransactionSuccessful(); id
        } finally { db.endTransaction() }
    }

    fun estimate(profile: String, id: Long): Map<String, String> = readableDatabase.query(
        "estimates", null, "profile=? AND id=?", arrayOf(profile, id.toString()), null, null, null
    ).use { cursor -> check(cursor.moveToFirst()) { "Estimate not found" }; cursor.row() }

    fun estimateComponents(profile: String, estimateId: Long): List<EstimateComponent> = readableDatabase.rawQuery(
        "SELECT kind,description,quantity_thousandths,unit,unit_cents,line_total_cents FROM estimate_components WHERE profile=? AND estimate_id=? ORDER BY position,id",
        arrayOf(profile, estimateId.toString())
    ).use { cursor -> buildList { while (cursor.moveToNext()) add(EstimateComponent(cursor.getString(0),cursor.getString(1),cursor.getLong(2),cursor.getString(3),cursor.getLong(4),cursor.getLong(5))) } }

    /** Migrates only exact, unique matches. Ambiguous and missing matches remain untouched and visible. */
    fun reconcileJobIds(profile: String, jobs: List<JobIdentity>): Map<String, Int> {
        val db = writableDatabase
        var verified = 0; var ambiguous = 0; var unresolved = 0
        db.beginTransaction()
        try {
            linkedTables.forEach { table ->
                val textColumn = if (table == "estimates") "title" else "job"
                db.query(table,arrayOf("id",textColumn,"job_id"),"profile=?",arrayOf(profile),null,null,"id").use { cursor ->
                    while (cursor.moveToNext()) {
                        val existingId=if(cursor.isNull(2))null else cursor.getLong(2)
                        val decision=if(existingId!=null&&jobs.any{it.id==existingId})
                            com.macleanofduartenterprises.modehandyman.core.JobLinkDecision(existingId,"verified","Verified existing job identifier")
                        else SmartToolsLogic.resolveJob(cursor.getString(1).orEmpty(), jobs)
                        val values = ContentValues().apply {
                            decision.jobId?.let { put("job_id", it) } ?: putNull("job_id")
                            put("link_status", decision.status); put("link_note", decision.note)
                        }
                        db.update(table, values, "id=? AND profile=?", arrayOf(cursor.getLong(0).toString(), profile))
                        when (decision.status) { "verified" -> verified++; "ambiguous" -> ambiguous++; else -> unresolved++ }
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return mapOf("verified" to verified, "ambiguous" to ambiguous, "unresolved" to unresolved)
    }

    fun unresolvedRows(profile: String): List<Map<String, String>> = buildList {
        linkedTables.forEach { table ->
            val textColumn = if (table == "estimates") "title" else "job"
            readableDatabase.query(table,arrayOf("id",textColumn,"link_status","link_note"),"profile=? AND job_id IS NULL",arrayOf(profile),null,null,"id").use { c ->
                while(c.moveToNext()) add(mapOf("table" to table,"id" to c.getLong(0).toString(),"reference" to c.getString(1).orEmpty(),"status" to c.getString(2),"note" to c.getString(3)))
            }
        }
    }

    fun jobRows(table: String, profile: String, jobId: Long): List<Map<String,String>> {
        require(table in linkedTables)
        return readableDatabase.query(table,null,"profile=? AND job_id=?",arrayOf(profile,jobId.toString()),null,null,"id DESC").use { c -> buildList { while(c.moveToNext()) add(c.row()) } }
    }

    fun linkJob(table: String, profile: String, recordId: Long, jobId: Long): Boolean {
        require(table in linkedTables && jobId > 0)
        return writableDatabase.update(table,ContentValues().apply {
            put("job_id",jobId); put("link_status","verified"); put("link_note","Manually linked to a selected job")
        },"id=? AND profile=?",arrayOf(recordId.toString(),profile)) == 1
    }

    fun linkedQuote(profile: String, estimateId: Long, jobId: Long): Long? = readableDatabase.rawQuery(
        "SELECT quote_id FROM estimates WHERE id=? AND profile=? AND job_id=?",arrayOf(estimateId.toString(),profile,jobId.toString())
    ).use { c -> if(c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null }

    fun setLinkedQuote(profile: String, estimateId: Long, jobId: Long, quoteId: Long): Boolean {
        val changed = writableDatabase.update("estimates",ContentValues().apply { put("quote_id",quoteId) },
            "id=? AND profile=? AND job_id=? AND (quote_id IS NULL OR quote_id=?)",
            arrayOf(estimateId.toString(),profile,jobId.toString(),quoteId.toString()))
        return changed == 1 && linkedQuote(profile,estimateId,jobId) == quoteId
    }

    fun attachmentsForJobId(profile: String, jobId: Long): List<File> = jobRows("attachments",profile,jobId)
        .filter { it["kind"] in setOf("photo", "signature") }
        .mapNotNull { it["file"]?.let(::File)?.takeIf(File::isFile) }

    fun approvalForQuote(profile: String, quoteId: Long): Map<String,String>? = readableDatabase.query(
        "approvals",null,"profile=? AND quote_id=?",arrayOf(profile,quoteId.toString()),null,null,"id DESC","1"
    ).use { if(it.moveToFirst()) it.row() else null }

    fun markApprovalCompleted(profile: String, approvalId: Long, coreId: Long): Boolean = writableDatabase.update(
        "approvals",ContentValues().apply { put("status","approved");put("core_approval_id",coreId) },"id=? AND profile=?",arrayOf(approvalId.toString(),profile)
    ) == 1

    fun add(table: String, values: ContentValues): Long { require(table in allTables); return writableDatabase.insertOrThrow(table,null,values) }
    fun rows(table: String, profile: String): List<Map<String, String>> { require(table in allTables); return readableDatabase.query(table,null,"profile=?",arrayOf(profile),null,null,"id DESC").use { c -> buildList { while(c.moveToNext()) add(c.row()) } } }

    fun remove(table: String, profile: String, id: Long): Int {
        require(table in allTables)
        require(table != "approvals") { "Approved contracts are permanent records and cannot be deleted here" }
        val file = if(table == "attachments") readableDatabase.query(table,arrayOf("file"),"id=? AND profile=?",arrayOf(id.toString(),profile),null,null,null).use { if(it.moveToFirst()) File(it.getString(0)) else null } else null
        val count = writableDatabase.delete(table,"id=? AND profile=?",arrayOf(id.toString(),profile))
        if(count == 1) file?.takeIf(File::isFile)?.delete()
        return count
    }

    fun integrityReport(validJobIds: Set<Long>): List<String> {
        val issues = mutableListOf<String>()
        readableDatabase.rawQuery("PRAGMA integrity_check",null).use { c -> if(!c.moveToFirst() || c.getString(0) != "ok") issues += "Smart Tools database integrity check failed" }
        linkedTables.forEach { table ->
            readableDatabase.rawQuery("SELECT id,job_id FROM $table WHERE job_id IS NOT NULL",null).use { c -> while(c.moveToNext()) if(c.getLong(1) !in validJobIds) issues += "$table #${c.getLong(0)} references a missing job" }
        }
        readableDatabase.rawQuery("SELECT id,file FROM attachments",null).use { c -> while(c.moveToNext()) if(!File(c.getString(1)).isFile) issues += "attachments #${c.getLong(0)} references a missing file" }
        readableDatabase.rawQuery("SELECT id,signature_file,contract_file FROM approvals WHERE status='approved'",null).use { c -> while(c.moveToNext()) {
            if(c.isNull(1)||!File(c.getString(1)).isFile)issues += "approvals #${c.getLong(0)} is missing its signature"
            if(c.isNull(2)||!File(c.getString(2)).isFile)issues += "approvals #${c.getLong(0)} is missing its signed contract"
        } }
        return issues
    }


    private fun createExtraLinksSchema(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS material_extra_links(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,material_id INTEGER NOT NULL REFERENCES materials(id) ON DELETE CASCADE,supplier_label TEXT NOT NULL DEFAULT '',product_url TEXT NOT NULL,UNIQUE(profile,material_id,supplier_label,product_url))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_material_extra_links ON material_extra_links(profile,material_id)")
    }

    fun addExtraProductLink(profile:String,materialId:Long,supplierLabel:String,url:String) {
        validateUrl(url)
        require(url.isNotBlank())
        check(readableDatabase.rawQuery("SELECT 1 FROM materials WHERE id=? AND profile=?",arrayOf(materialId.toString(),profile)).use { it.moveToFirst() })
        writableDatabase.insertWithOnConflict("material_extra_links",null,ContentValues().apply {
            put("profile",profile);put("material_id",materialId);put("supplier_label",supplierLabel.trim());put("product_url",url.trim())
        },SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun extraProductLinks(profile:String,materialId:Long):List<Map<String,String>> = readableDatabase.rawQuery("SELECT id,supplier_label,product_url FROM material_extra_links WHERE profile=? AND material_id=? ORDER BY id",arrayOf(profile,materialId.toString())).use { c -> buildList { while(c.moveToNext()) add(c.row()) } }

    fun deleteExtraProductLink(profile:String,id:Long) {
        writableDatabase.delete("material_extra_links","profile=? AND id=?",arrayOf(profile,id.toString()))
    }

    private fun createSupplierSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS smart_suppliers(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,name TEXT NOT NULL,contact TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL DEFAULT '',email TEXT NOT NULL DEFAULT '',address TEXT NOT NULL DEFAULT '',website TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS material_suppliers(id INTEGER PRIMARY KEY,profile TEXT NOT NULL,material_id INTEGER NOT NULL REFERENCES materials(id) ON DELETE CASCADE,supplier_id INTEGER NOT NULL REFERENCES smart_suppliers(id) ON DELETE CASCADE,product_url TEXT NOT NULL DEFAULT '',purchase_cents INTEGER NOT NULL DEFAULT 0 CHECK(purchase_cents>=0),preferred INTEGER NOT NULL DEFAULT 0 CHECK(preferred IN (0,1)),UNIQUE(profile,material_id,supplier_id))")
        listOf("description" to "TEXT NOT NULL DEFAULT ''", "manufacturer" to "TEXT NOT NULL DEFAULT ''", "sku" to "TEXT NOT NULL DEFAULT ''", "quantity" to "REAL NOT NULL DEFAULT 1", "selling_cents" to "INTEGER NOT NULL DEFAULT 0", "markup_percent" to "REAL NOT NULL DEFAULT 0", "last_purchase_cents" to "INTEGER NOT NULL DEFAULT 0").forEach { (col, type) -> addColumn(db,"materials",col,type) }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_smart_suppliers_profile ON smart_suppliers(profile,name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_material_suppliers_material ON material_suppliers(profile,material_id)")
    }

    fun saveSupplier(profile: String, id: Long?, name: String, contact: String, phone: String, email: String, address: String, website: String, notes: String): Long {
        require(name.isNotBlank())
        validateUrl(website)
        val v=ContentValues().apply { put("profile",profile);put("name",name.trim());put("contact",contact);put("phone",phone);put("email",email);put("address",address);put("website",website);put("notes",notes) }
        if(id==null) return writableDatabase.insertOrThrow("smart_suppliers",null,v)
        check(writableDatabase.update("smart_suppliers",v,"id=? AND profile=?",arrayOf(id.toString(),profile))==1)
        return id
    }

    fun associateSupplier(profile: String, materialId: Long, supplierId: Long, productUrl: String, purchaseCents: Long, preferred: Boolean) {
        validateUrl(productUrl)
        require(purchaseCents>=0)
        val db=writableDatabase
        db.beginTransaction()
        try {
            fun exists(table:String,id:Long)=db.rawQuery("SELECT 1 FROM $table WHERE id=? AND profile=?",arrayOf(id.toString(),profile)).use{it.moveToFirst()}
            require(exists("materials",materialId)&&exists("smart_suppliers",supplierId)) { "Material and supplier must belong to the selected profile" }
            if(preferred) db.execSQL("UPDATE material_suppliers SET preferred=0 WHERE profile=? AND material_id=?",arrayOf<Any?>(profile,materialId))
            val v=ContentValues().apply {put("profile",profile);put("material_id",materialId);put("supplier_id",supplierId);put("product_url",productUrl.trim());put("purchase_cents",purchaseCents);put("preferred",if(preferred)1 else 0)}
            db.insertWithOnConflict("material_suppliers",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun supplierLinks(profile:String,materialId:Long):List<Map<String,String>> = readableDatabase.rawQuery("SELECT ms.id,ms.product_url,ms.purchase_cents,ms.preferred,s.name AS supplier_name FROM material_suppliers ms JOIN smart_suppliers s ON s.id=ms.supplier_id AND s.profile=ms.profile WHERE ms.profile=? AND ms.material_id=? ORDER BY ms.preferred DESC,s.name",arrayOf(profile,materialId.toString())).use{c->buildList{while(c.moveToNext())add(c.row())}}

    /** Snapshot of the preferred supplier association; never modifies catalog pricing. */
    fun preferredSupplierLink(profile:String, materialId:Long):Map<String,String>? = readableDatabase.rawQuery(
        "SELECT ms.supplier_id,ms.product_url,ms.purchase_cents,ms.preferred,s.name AS supplier_name " +
        "FROM material_suppliers ms JOIN smart_suppliers s ON s.id=ms.supplier_id AND s.profile=ms.profile " +
        "JOIN materials m ON m.id=ms.material_id AND m.profile=ms.profile " +
        "WHERE ms.profile=? AND ms.material_id=? ORDER BY ms.preferred DESC,ms.id ASC LIMIT 1",
        arrayOf(profile,materialId.toString())
    ).use { c -> if(c.moveToFirst()) c.row() else null }

    private fun validateUrl(url:String) { if(url.isNotBlank()) require(android.net.Uri.parse(url).let{it.scheme in listOf("https","http") && !it.host.isNullOrBlank()}) { "Use an HTTP or HTTPS URL" } }

    private fun createIndexes(db: SQLiteDatabase) {
        linkedTables.forEach { db.execSQL("CREATE INDEX IF NOT EXISTS idx_${it}_job_id ON $it(profile,job_id)") }
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_estimate_quote ON estimates(profile,quote_id) WHERE quote_id IS NOT NULL")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_estimate_components ON estimate_components(profile,estimate_id,position)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_approval_quote ON approvals(profile,quote_id) WHERE quote_id IS NOT NULL")
    }

    private fun addColumn(db: SQLiteDatabase, table: String, column: String, declaration: String) {
        if (!hasColumn(db, table, column)) db.execSQL("ALTER TABLE $table ADD COLUMN $column $declaration")
    }
    private fun hasColumn(db: SQLiteDatabase, table: String, column: String): Boolean = db.rawQuery("PRAGMA table_info($table)",null).use { c ->
        var found = false; while(c.moveToNext()) if(c.getString(1) == column) found = true; found
    }
    private fun tableExists(db: SQLiteDatabase, table: String): Boolean = db.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",arrayOf(table)).use { it.moveToFirst() }
    private fun Cursor.row(): Map<String,String> = (0 until columnCount).associate { getColumnName(it) to (getString(it) ?: "") }
}
