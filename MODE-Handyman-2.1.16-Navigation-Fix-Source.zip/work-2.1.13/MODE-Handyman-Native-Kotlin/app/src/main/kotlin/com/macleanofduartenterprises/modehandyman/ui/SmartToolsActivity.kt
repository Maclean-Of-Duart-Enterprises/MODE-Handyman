package com.macleanofduartenterprises.modehandyman.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.macleanofduartenterprises.modehandyman.ModeApplication
import com.macleanofduartenterprises.modehandyman.core.ConstructionMath
import com.macleanofduartenterprises.modehandyman.core.JobIdentity
import com.macleanofduartenterprises.modehandyman.core.SmartToolsLogic
import com.macleanofduartenterprises.modehandyman.data.ModeRepository
import com.macleanofduartenterprises.modehandyman.data.SmartToolsStore
import com.macleanofduartenterprises.modehandyman.export.PdfGenerator
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest
import java.time.Instant
import java.util.Locale

/** Offline Smart Tools with verified links into the active MODE business profile. */
@SuppressLint("SetTextI18n")
@Suppress("DEPRECATION")
class SmartToolsActivity : Activity() {
    private lateinit var calculatorButton: Button
    private lateinit var store: SmartToolsStore
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private var profile = ""
    private var selectedJob: JobIdentity? = null
    private var pendingPhotoJob: JobIdentity? = null
    private var pendingPhotoNote = ""

    private fun repository() = ModeRepository(this,(application as ModeApplication).databaseManager.open())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        profile=intent.getStringExtra("profile")?.takeIf(String::isNotBlank) ?: error("Missing business profile")
        store=SmartToolsStore(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),dp(120)) }
        scroll=ScrollView(this).apply { isFillViewport=true;clipToPadding=false;addView(root,ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)) }
        setContentView(scroll)
        calculatorButton = FloatingCalculator.install(this)
        reconcileExistingRecords()
        home()
    }

    override fun onResume() { super.onResume(); calculatorButton.visibility = if (FloatingCalculator.enabled(this)) View.VISIBLE else View.GONE }

    override fun onDestroy() { store.close();super.onDestroy() }

    private fun reconcileExistingRecords() {
        val jobs=repository().allJobIdentities()[profile].orEmpty()
        store.reconcileJobIds(profile,jobs)
    }

    private fun selectJob(onSelected:(JobIdentity)->Unit) {
        val jobs=repository().allJobIdentities()[profile].orEmpty()
        if(jobs.isEmpty()) { toast("Create a job first");return }
        AlertDialog.Builder(this).setTitle("Select existing job")
            .setItems(jobs.map { "#${it.id} · ${it.title}" }.toTypedArray()) { _,index -> onSelected(jobs[index]) }.show()
    }

    private fun field(hint:String,value:String="",multiline:Boolean=false)=EditText(this).apply {
        this.hint=hint;setText(value);setSingleLine(!multiline);if(multiline){minLines=4;maxLines=10}
        // Let the owning ScrollView (page or dialog) manage focus automatically.
        // Requesting focus scrolling on the activity ScrollView for a dialog field
        // crashes with IllegalArgumentException: view is not its descendant.
    }
    private fun button(label:String,action:()->Unit)=Button(this).apply {
        text=label;isAllCaps=false;setOnClickListener { runCatching(action).onFailure { toast(it.message?:"Unable to complete operation") } }
    }
    private fun page(title:String) { root.removeAllViews();root.addView(TextView(this).apply{text=title;textSize=24f;setPadding(dp(16),dp(20),dp(8),dp(16))});root.addView(button("← Smart tools",::home)) }
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_LONG).show()
    private fun money(value:String)=BigDecimal(value.trim()).movePointRight(2).setScale(0,RoundingMode.HALF_UP).longValueExact().also{require(it>=0)}
    private fun dollars(cents:Long)="$%.2f".format(Locale.US,cents/100.0)
    private fun values(vararg pairs:Pair<String,Any?>)=ContentValues().apply {
        put("profile",profile);pairs.forEach { (key,value) -> when(value){null->putNull(key);is Long->put(key,value);is Int->put(key,value);is Double->put(key,value);else->put(key,value.toString())} }
    }

    private fun home() {
        page("MODE Smart Job Tools")
        listOf(
            "Calculator" to { FloatingCalculator.show(this) },
            "Construction calculators" to ::calculators,
            "Smart estimator" to ::estimator,
            "Material price library" to ::materials,
            "Suppliers" to ::suppliers,
            "Job profitability" to ::profitability,
            "Job photos & signatures" to ::documentation,
            "Contract approvals" to ::approvals,
            "Unresolved job links" to ::unresolvedLinks
        ).forEach { (label,action)->root.addView(button(label,action)) }
    }

    private fun calculators() {
        page("Construction calculators")
        val kind=Spinner(this).apply { adapter=ArrayAdapter(this@SmartToolsActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Concrete (yd³)","Gravel (tons)","Area (ft²)","Paint (gallons)","Drywall (4×8 sheets)")) }
        val a=field("Length / area (ft or ft²)");val b=field("Width (ft), or coverage (ft²)","1");val d=field("Depth (in) or coats","4")
        val output=TextView(this).apply{textSize=20f};listOf(kind,a,b,d).forEach(root::addView)
        root.addView(button("Calculate") {
            val x=a.text.toString().toDouble();val y=b.text.toString().toDouble();val z=d.text.toString().toDouble()
            output.text=when(kind.selectedItemPosition){
                0->"%.2f yd³ (10%% allowance)".format(ConstructionMath.concreteYards(x,y,z))
                1->"%.2f tons (assumed 1.4 tons/yd³)".format(ConstructionMath.gravelTons(x,y,z))
                2->"%.2f ft²".format(ConstructionMath.area(x,y))
                3->"${ConstructionMath.paintGallons(x,y,z)} gallons"
                else->"${ConstructionMath.drywallSheets(x)} sheets"
            }
        });root.addView(output);root.addView(TextView(this).apply{text="Planning estimate only. Verify supplier coverage, density, waste, and site conditions."})
    }

    private fun estimator() {
        page("Smart job estimator")
        val title=field("Job / estimate title");val category=field("Category / scope");val quantity=field("Quantity","1");val unit=field("Unit","job")
        val material=field("Material cost ($)","0");val hours=field("Labor hours","0");val rate=field("Hourly rate ($)","50");val markup=field("Markup percent","0")
        val output=TextView(this).apply{textSize=20f};listOf(title,category,quantity,unit,material,hours,rate,markup).forEach(root::addView)
        root.addView(button("Calculate and save estimate") {
            require(title.text.isNotBlank()) { "Estimate title is required" }
            val materialCents=money(material.text.toString());val laborHours=hours.text.toString().toDouble();val hourlyCents=money(rate.text.toString())
            val percent=markup.text.toString().toDouble();val total=ConstructionMath.estimateCents(materialCents,laborHours,hourlyCents,percent)
            val parts=SmartToolsLogic.estimateComponents(title.text.toString(),category.text.toString(),quantity.text.toString().toDouble(),unit.text.toString(),materialCents,laborHours,hourlyCents,total)
            store.saveEstimate(values("created" to System.currentTimeMillis(),"title" to title.text.toString().trim(),"category" to category.text.toString().trim(),
                "quantity" to quantity.text.toString().toDouble(),"unit" to unit.text.toString().trim(),"materials_cents" to materialCents,
                "labor_cents" to parts.filter{it.kind=="labor"}.sumOf{it.lineTotalCents},"markup_percent" to percent,"total_cents" to total),parts)
            output.text="Estimated price: ${dollars(total)}";reconcileExistingRecords()
        });root.addView(output)
        root.addView(button("Link estimate to job and create quote",::chooseEstimateForConversion));showRows("estimates")
    }

    private fun chooseEstimateForConversion() {
        val estimates=store.rows("estimates",profile)
        if(estimates.isEmpty()){toast("Save an estimate first");return}
        AlertDialog.Builder(this).setTitle("Choose estimate").setItems(estimates.map{"#${it["id"]} · ${it["title"]}"}.toTypedArray()){_,index->
            val estimateId=estimates[index].getValue("id").toLong()
            selectJob { job -> runCatching {
                check(store.linkJob("estimates",profile,estimateId,job.id))
                val quoteId=repository().convertSmartEstimate(store,profile,estimateId,job.id)
                toast("Quote #$quoteId created or recovered without duplication");estimator()
            }.onFailure { toast(it.message?:"Conversion failed") } }
        }.show()
    }

    private fun materials() {
        page("Material price library")
        val name=field("Material name");val supplier=field("Supplier");val unit=field("Unit (each, bag, ft, yd³)");val price=field("Purchase cost ($)");val selling=field("Selling price ($)");val manufacturer=field("Manufacturer");val sku=field("SKU / product number");val description=field("Description",multiline=true);val markup=field("Markup (%)","0");val productSupplier1=field("Product link 1 supplier (optional)");val productUrl1=field("Product URL 1 (optional)");val productSupplier2=field("Product link 2 supplier (optional)");val productUrl2=field("Product URL 2 (optional)")
        listOf(name,description,manufacturer,sku,supplier,unit,price,selling,markup,productSupplier1,productUrl1,productSupplier2,productUrl2).forEach(root::addView)
        root.addView(button("Save material") { require(name.text.isNotBlank()&&unit.text.isNotBlank());val materialId=store.add("materials",values("name" to name.text.toString().trim(),"supplier" to supplier.text.toString().trim(),"unit" to unit.text.toString().trim(),"cents" to money(price.text.toString()),"selling_cents" to money(selling.text.toString()),"description" to description.text.toString(),"manufacturer" to manufacturer.text.toString(),"sku" to sku.text.toString(),"markup_percent" to (markup.text.toString().toDoubleOrNull()?:0.0),"updated" to System.currentTimeMillis()));if(productUrl1.text.isNotBlank())store.addExtraProductLink(profile,materialId,productSupplier1.text.toString(),productUrl1.text.toString());if(productUrl2.text.isNotBlank())store.addExtraProductLink(profile,materialId,productSupplier2.text.toString(),productUrl2.text.toString());materials() })
        root.addView(button("Add multiple product links") {
            val mats=store.rows("materials",profile)
            if(mats.isEmpty()){toast("Save a material first");return@button}
            AlertDialog.Builder(this).setTitle("Select material").setItems(mats.map { it["name"].orEmpty() }.toTypedArray()) { _,index ->
                val materialId=mats[index].getValue("id").toLong()
                val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
                val labels=(1..3).map { field("Supplier name $it (optional)") }
                val urls=(1..3).map { field("Product URL $it (optional)") }
                for(i in 0..2) {layout.addView(labels[i]);layout.addView(urls[i])}
                AlertDialog.Builder(this).setTitle("Additional product links").setView(ScrollView(this).apply { addView(layout) })
                    .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ ->
                        runCatching {
                            for(i in 0..2) if(urls[i].text.isNotBlank()) store.addExtraProductLink(profile,materialId,labels[i].text.toString(),urls[i].text.toString())
                            materials()
                        }.onFailure { toast(it.message.orEmpty()) }
                    }.show()
            }.show()
        })
        store.rows("materials",profile).forEach { material ->
            store.extraProductLinks(profile,material.getValue("id").toLong()).forEach { link ->
                root.addView(button("${material["name"]} · ${link["supplier_label"]} · Open / Remove link") {
                    AlertDialog.Builder(this).setItems(arrayOf("Open product link","Remove product link")) { _,choice ->
                        if(choice==0) startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(link["product_url"])).addCategory(Intent.CATEGORY_BROWSABLE))
                        else {store.deleteExtraProductLink(profile,link.getValue("id").toLong());materials()}
                    }.show()
                })
            }
        }
        root.addView(button("Associate supplier and product link") {
            val mats=store.rows("materials",profile);val suppliers=store.rows("smart_suppliers",profile)
            if(mats.isEmpty()||suppliers.isEmpty()){toast("Create a material and supplier first");return@button}
            AlertDialog.Builder(this).setTitle("Select material").setItems(mats.map{it["name"].orEmpty()}.toTypedArray()){_,mi->
                AlertDialog.Builder(this).setTitle("Select supplier").setItems(suppliers.map{it["name"].orEmpty()}.toTypedArray()){_,si->
                    val url=field("Supplier product URL (https://)");val cost=field("Supplier purchase price ($)","0");val preferred=CheckBox(this).apply{text="Preferred supplier"}
                    val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(url);addView(cost);addView(preferred)}
                    AlertDialog.Builder(this).setTitle("Product link").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->runCatching{
                        store.associateSupplier(profile,mats[mi].getValue("id").toLong(),suppliers[si].getValue("id").toLong(),url.text.toString(),money(cost.text.toString()),preferred.isChecked);materials()
                    }.onFailure{toast(it.message.orEmpty())}}.show()
                }.show()
            }.show()
        })
        store.rows("materials",profile).forEach { materialRow ->
            store.supplierLinks(profile,materialRow.getValue("id").toLong()).forEach { link ->
                root.addView(button("${materialRow["name"]} · ${link["supplier_name"]} · Open product") {
                    val url=link["product_url"].orEmpty()
                    if(url.isBlank()) toast("No product URL recorded")
                    else startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
                })
            }
        }
        showRows("materials")
    }

    private fun suppliers() {
        page("Suppliers")
        val name=field("Supplier name");val contact=field("Contact person");val phone=field("Phone");val email=field("Email");val address=field("Address",multiline=true);val website=field("Website URL");val notes=field("Notes",multiline=true)
        listOf(name,contact,phone,email,address,website,notes).forEach(root::addView)
        root.addView(button("Save supplier") {store.saveSupplier(profile,null,name.text.toString(),contact.text.toString(),phone.text.toString(),email.text.toString(),address.text.toString(),website.text.toString(),notes.text.toString());suppliers()})
        store.rows("smart_suppliers",profile).forEach { row ->
            root.addView(button("${row["name"]} · Edit / delete") {
                val fields=listOf("name","contact","phone","email","address","website","notes").map { field(it,row[it].orEmpty()) }
                val layout=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;fields.forEach(::addView)}
                AlertDialog.Builder(this).setTitle("Edit supplier").setView(ScrollView(this).apply{addView(layout)})
                    .setPositiveButton("Save") { _,_ -> runCatching {store.saveSupplier(profile,row.getValue("id").toLong(),fields[0].text.toString(),fields[1].text.toString(),fields[2].text.toString(),fields[3].text.toString(),fields[4].text.toString(),fields[5].text.toString(),fields[6].text.toString());suppliers()}.onFailure{toast(it.message.orEmpty())} }
                    .setNeutralButton("Delete") { _,_ -> AlertDialog.Builder(this).setMessage("Delete this supplier and its product associations?").setNegativeButton("Cancel",null).setPositiveButton("Delete") { _,_ ->store.remove("smart_suppliers",profile,row.getValue("id").toLong());suppliers()}.show() }.setNegativeButton("Cancel",null).show()
            })
        }
    }

    private fun profitability() {
        page("Job profitability")
        val jobLabel=field("Select a verified job").apply{isFocusable=false};val description=field("Expense description")
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@SmartToolsActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Material","Labor","Equipment","Mileage","Other"))}
        val amount=field("Amount ($)");listOf(jobLabel,description,type,amount).forEach(root::addView)
        root.addView(button("Select existing job") { selectJob { selectedJob=it;jobLabel.setText("#${it.id} · ${it.title}") } })
        root.addView(button("Add expense") {
            val job=checkNotNull(selectedJob){"Select an existing job first"};require(description.text.isNotBlank())
            store.add("costs",values("created" to System.currentTimeMillis(),"job" to job.title,"job_id" to job.id,"link_status" to "verified","link_note" to "Selected job", "description" to description.text.toString().trim(),"type" to type.selectedItem.toString(),"cents" to money(amount.text.toString())));profitability()
        })
        root.addView(button("Record job revenue") {
            val job=checkNotNull(selectedJob){"Select an existing job first"};val revenue=field("Revenue ($)")
            AlertDialog.Builder(this).setTitle("Revenue for ${job.title}").setView(revenue).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->runCatching{
                store.add("job_revenue",values("created" to System.currentTimeMillis(),"job" to job.title,"job_id" to job.id,"link_status" to "verified","link_note" to "Selected job","cents" to money(revenue.text.toString())));profitability()
            }.onFailure{toast(it.message?:"Invalid amount")}}.show()
        })
        val jobs=repository().allJobIdentities()[profile].orEmpty()
        jobs.forEach { job ->
            val costs=store.jobRows("costs",profile,job.id).sumOf{it.getValue("cents").toLong()};val revenue=store.jobRows("job_revenue",profile,job.id).sumOf{it.getValue("cents").toLong()}
            if(costs!=0L||revenue!=0L) root.addView(TextView(this).apply{text="#${job.id} ${job.title} | Revenue ${dollars(revenue)} | Costs ${dollars(costs)} | Profit ${dollars(revenue-costs)} | Margin ${if(revenue>0)"%.1f%%".format(100.0*(revenue-costs)/revenue)else"N/A"}"})
        }
        showRows("costs")
    }

    private fun documentation() {
        page("Job photos & signatures")
        val jobLabel=field("Select a verified job").apply{isFocusable=false};val note=field("Photo note / agreement description")
        root.addView(jobLabel);root.addView(note)
        root.addView(button("Select existing job") { selectJob { selectedJob=it;jobLabel.setText("#${it.id} · ${it.title}") } })
        root.addView(button("Attach photo from device") {
            val job=checkNotNull(selectedJob){"Select an existing job first"};pendingPhotoJob=job;pendingPhotoNote=note.text.toString().trim()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},71)
        })
        root.addView(button("Capture standalone customer signature") {
            val job=checkNotNull(selectedJob){"Select an existing job first"};captureSignature("Signature for ${job.title}") { signature ->
                val file=saveSignature(signature,"job-${job.id}")
                store.add("attachments",values("created" to System.currentTimeMillis(),"job" to job.title,"job_id" to job.id,"link_status" to "verified","link_note" to "Selected job","kind" to "signature","file" to file.absolutePath,"note" to note.text.toString().trim()));documentation()
            }
        });showRows("attachments")
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==71&&resultCode==RESULT_OK) runCatching {
            val job=checkNotNull(pendingPhotoJob);val uri=data?.data?:error("No photo selected")
            val file=File(filesDir,"job-documents/${System.currentTimeMillis()}-job-${job.id}-photo")
            file.parentFile?.mkdirs();contentResolver.openInputStream(uri)!!.use{input->file.outputStream().use(input::copyTo)}
            store.add("attachments",values("created" to System.currentTimeMillis(),"job" to job.title,"job_id" to job.id,"link_status" to "verified","link_note" to "Selected job","kind" to "photo","file" to file.absolutePath,"note" to pendingPhotoNote));pendingPhotoJob=null;documentation()
        }.onFailure{toast(it.message?:"Photo import failed")}
    }

    private fun approvals() {
        page("Contract approval")
        val signer=field("Customer / authorized signer's name");val agreement=field("Agreement terms and scope",multiline=true)
        val consent=CheckBox(this).apply{text=CONSENT_TEXT};root.addView(signer);root.addView(agreement);root.addView(consent)
        root.addView(button("Select job, quote, and sign") {
            require(signer.text.isNotBlank()&&agreement.text.isNotBlank()&&consent.isChecked){"Signer, terms, and explicit consent are required"}
            selectJob { job ->
                val repo=repository();val quotes=repo.quotes().filter{repo.quoteBelongsToJob(it.id,job.id)}
                if(quotes.isEmpty()){toast("This job has no quote to approve");return@selectJob}
                AlertDialog.Builder(this).setTitle("Select quote for ${job.title}").setItems(quotes.map{"${it.title} · ${it.trailing}"}.toTypedArray()){_,index->
                    val quoteId=quotes[index].id
                    val existing=store.approvalForQuote(profile,quoteId)
                    if(existing!=null) { recoverOrShareApproval(existing);return@setItems }
                    captureSignature("Sign approval for ${quotes[index].title}") { signature ->
                        createApproval(job,quoteId,signer.text.toString().trim(),agreement.text.toString().trim(),signature)
                    }
                }.show()
            }
        });showRows("approvals")
    }

    private fun createApproval(job:JobIdentity,quoteId:Long,signer:String,agreement:String,signature:SignaturePad) {
        runCatching {
            val repo=repository();val link=repo.contractLink(quoteId,job.id);val quote=repo.quote(quoteId);val signatureFile=saveSignature(signature,"quote-$quoteId")
            val approvedAt=Instant.now();val combinedTerms=listOf(agreement,quote.terms.takeIf(String::isNotBlank)?.let{"Quote terms:\n$it"}).filterNotNull().joinToString("\n\n")
            val business=repo.system()["business_name"]?.toString().orEmpty().ifBlank{"MODE Handyman"}
            val contract=PdfGenerator.create(this,PdfGenerator.Document(
                kind="Signed Contract",number=quote.number,business=business,customer=link.customerName,job=link.jobTitle,
                dateLabel="Approved: $approvedAt",lines=repo.quoteLines(quoteId),subtotal=quote.subtotalCents,discount=quote.discountCents,
                tax=(quote.totalCents-(quote.subtotalCents-quote.discountCents).coerceAtLeast(0)).coerceAtLeast(0),total=quote.totalCents,
                terms=combinedTerms,businessDetails=repo.system().mapValues{it.value?.toString().orEmpty()},
                attachments=store.attachmentsForJobId(profile,job.id).filter{it!=signatureFile},
                approval=PdfGenerator.ApprovalBlock(signer,CONSENT_TEXT,approvedAt.toString(),signatureFile)))
            val digest=sha256(signatureFile,contract,"${link.profileId}|${link.customerId}|${link.jobId}|${link.quoteId}|$signer|$combinedTerms|$CONSENT_TEXT")
            val approvalId=try { store.add("approvals",values("job" to job.title,"job_id" to job.id,"quote_id" to quoteId,"customer_id" to link.customerId,
                "signer" to signer,"agreement" to agreement,"approved_at" to approvedAt.toEpochMilli(),"status" to "pending","signature_file" to signatureFile.absolutePath,
                "contract_file" to contract.absolutePath,"consent_text" to CONSENT_TEXT,"content_sha256" to digest,"link_status" to "verified","link_note" to "Verified customer/job/quote linkage")) }
            catch(error:Throwable){signatureFile.delete();contract.delete();throw error}
            val coreId=repo.approveContract(approvalId,link,signer,agreement,CONSENT_TEXT,approvedAt.toString(),signatureFile.absolutePath,contract.absolutePath,digest)
            check(store.markApprovalCompleted(profile,approvalId,coreId));toast("Signed contract saved and quote approved");shareContract(contract);approvals()
        }.onFailure{toast(it.message?:"Approval failed")}
    }

    private fun recoverOrShareApproval(row:Map<String,String>) {
        runCatching {
            val contract=File(row["contract_file"].orEmpty());require(contract.isFile){"Signed contract file is missing; restore it from backup"}
            if(row["status"]!="approved") {
                val repo=repository();val jobId=row.getValue("job_id").toLong();val quoteId=row.getValue("quote_id").toLong();val link=repo.contractLink(quoteId,jobId)
                val approvedAt=Instant.ofEpochMilli(row.getValue("approved_at").toLong()).toString()
                val coreId=repo.approveContract(row.getValue("id").toLong(),link,row.getValue("signer"),row.getValue("agreement"),row["consent_text"].orEmpty().ifBlank{CONSENT_TEXT},approvedAt,row["signature_file"].orEmpty(),contract.absolutePath,row["content_sha256"].orEmpty())
                check(store.markApprovalCompleted(profile,row.getValue("id").toLong(),coreId))
            }
            shareContract(contract)
        }.onFailure{toast(it.message?:"Unable to recover approval")}
    }

    private fun unresolvedLinks() {
        page("Unresolved job links");reconcileExistingRecords();val rows=store.unresolvedRows(profile)
        if(rows.isEmpty())root.addView(TextView(this).apply{text="All Smart Tools records have verified job identifiers."})
        rows.forEach { row -> root.addView(button("${row["table"]} #${row["id"]}: ${row["reference"]}\n${row["status"]}: ${row["note"]}") {
            selectJob { job -> check(store.linkJob(row.getValue("table"),profile,row.getValue("id").toLong(),job.id));unresolvedLinks() }
        }) }
    }

    private fun showRows(table:String) {
        store.rows(table,profile).forEach { row ->
            val label=when(table){
                "materials"->"${row["name"]} · ${row["supplier"]} · ${dollars(row.getValue("cents").toLong())}/${row["unit"]}"
                "estimates"->"${row["title"]} · ${dollars(row.getValue("total_cents").toLong())} · ${row["link_status"]}"
                "attachments"->"${row["job"]} · ${row["kind"]} · ${row["note"]} · ${row["link_status"]}"
                "approvals"->"${row["job"]} · ${row["signer"]} · ${row["status"]}"
                else->"${row["job"]} · ${row["description"]} · ${dollars(row.getValue("cents").toLong())} · ${row["link_status"]}"
            }
            root.addView(button("$label    ⋮") {
                if(table=="approvals") recoverOrShareApproval(row)
                else AlertDialog.Builder(this).setItems(arrayOf("Delete record")){_,_->AlertDialog.Builder(this).setMessage("Delete this record? This cannot be undone.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->runCatching{store.remove(table,profile,row.getValue("id").toLong());rerender(table)}.onFailure{toast(it.message?:"Delete failed")}}.show()}.show()
            })
        }
    }

    private fun rerender(table:String)=when(table){"materials"->materials();"estimates"->estimator();"costs","job_revenue"->profitability();"approvals"->approvals();else->documentation()}

    private fun captureSignature(title:String,onSave:(SignaturePad)->Unit) {
        val signature=SignaturePad(this);val dialog=AlertDialog.Builder(this).setTitle(title).setMessage("Review the displayed agreement and consent statement before signing. This records a handwritten signature image.")
            .setView(signature).setNegativeButton("Cancel",null).setPositiveButton("Use signature",null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { if(!signature.hasStroke)toast("Enter a signature first") else { dialog.dismiss();onSave(signature) } } }
        dialog.show()
    }
    private fun saveSignature(signature:SignaturePad,prefix:String):File=File(filesDir,"job-documents/${System.currentTimeMillis()}-$prefix-signature.png").also { file ->
        file.parentFile?.mkdirs();file.outputStream().use { output -> check(signature.snapshot().compress(Bitmap.CompressFormat.PNG,100,output)) }
    }
    private fun shareContract(file:File) {
        val uri=Uri.parse("content://${packageName}.provider/exports/${Uri.encode(file.name)}")
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri(file.name,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share signed contract"))
    }
    private fun sha256(first:File,second:File,text:String):String=MessageDigest.getInstance("SHA-256").run {
        first.inputStream().use{input->input.copyTo(digestOutput(this))};second.inputStream().use{input->input.copyTo(digestOutput(this))};update(text.toByteArray());digest().joinToString(""){"%02x".format(it)}
    }
    private fun digestOutput(digest:MessageDigest)=object:java.io.OutputStream(){override fun write(value:Int){digest.update(value.toByte())};override fun write(bytes:ByteArray,offset:Int,length:Int){digest.update(bytes,offset,length)}}
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()

    private class SignaturePad(context:android.content.Context):View(context) {
        private val path=Path();private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.BLACK;style=Paint.Style.STROKE;strokeWidth=5f;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND}
        var hasStroke=false;private set
        init{setBackgroundColor(Color.WHITE);minimumHeight=dp(context,320)}
        override fun onMeasure(widthSpec:Int,heightSpec:Int)=setMeasuredDimension(MeasureSpec.getSize(widthSpec),dp(context,320))
        override fun onDraw(canvas:Canvas){super.onDraw(canvas);canvas.drawPath(path,paint)}
        override fun onTouchEvent(event:MotionEvent):Boolean { when(event.actionMasked){MotionEvent.ACTION_DOWN->{path.moveTo(event.x,event.y);hasStroke=true};MotionEvent.ACTION_MOVE->path.lineTo(event.x,event.y);MotionEvent.ACTION_UP->{path.lineTo(event.x,event.y);performClick()}};invalidate();return true }
        override fun performClick():Boolean { super.performClick();return true }
        fun snapshot():Bitmap=Bitmap.createBitmap(width.coerceAtLeast(1),height.coerceAtLeast(1),Bitmap.Config.ARGB_8888).also{Canvas(it).apply{drawColor(Color.WHITE);drawPath(path,paint)}}
        companion object{fun dp(context:android.content.Context,value:Int)=(value*context.resources.displayMetrics.density).toInt()}
    }

    companion object {
        private const val CONSENT_TEXT="I have reviewed the quote and agreement terms, consent to this electronic signature, and approve this contract."
    }
}
