package com.macleanofduartenterprises.modehandyman.routing

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject

/** Internet-based driving distance: Nominatim geocoding followed by OSRM routing. */
class OnlineRoutingEngine {
    data class RouteResult(val distanceMetres: Double, val mapName: String = "OpenStreetMap/OSRM")
    private data class Point(val latitude: Double, val longitude: Double)

    private fun getJson(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("User-Agent", "MODE-Handyman/2.1.16 (https://github.com/Maclean-Of-Duart-Enterprises/MODE-Handyman)")
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (connection.responseCode !in 200..299) error("Routing service returned HTTP ${connection.responseCode}")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }
    }

    private fun geocode(address: String): Point {
        val q = URLEncoder.encode(address.trim(), "UTF-8")
        val matches = JSONArray(getJson("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=$q"))
        if (matches.length() == 0) error("Address not found: $address")
        val item = matches.getJSONObject(0)
        return Point(item.getString("lat").toDouble(), item.getString("lon").toDouble())
    }

    data class Coordinates(val latitude: Double, val longitude: Double)

    fun lookupCoordinates(address: String): Coordinates {
        require(address.isNotBlank()) { "Destination address is required" }
        val point = geocode(address)
        return Coordinates(point.latitude, point.longitude)
    }

    fun route(from: String, to: String): RouteResult {
        require(from.isNotBlank() && to.isNotBlank()) { "Both addresses are required" }
        val start = geocode(from)
        // Nominatim's public endpoint requires a maximum of one request per second.
        Thread.sleep(1100)
        val end = geocode(to)
        val url = "https://router.project-osrm.org/route/v1/driving/${start.longitude},${start.latitude};${end.longitude},${end.latitude}?overview=false&steps=false"
        val response = JSONObject(getJson(url))
        if (response.optString("code") != "Ok") error("No driving route available for these addresses")
        val routes = response.getJSONArray("routes")
        if (routes.length() == 0) error("No driving route found")
        return RouteResult(routes.getJSONObject(0).getDouble("distance"))
    }
}
