package com.macleanofduartenterprises.modehandyman.core

object RecordRequirements {
    private val identifier = Regex("[A-Za-z0-9][A-Za-z0-9._/-]{0,79}")
    private val email = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")

    fun validateContact(emailAddress: String, phone: String) {
        validateOptionalPhoneAndEmail(phone, emailAddress)
    }

    fun validateOptionalPhoneAndEmail(phone: String, emailAddress: String) {
        require(phone.isBlank() || phone.trim().length >= 5) { "Enter a valid phone number or leave it blank" }
        require(emailAddress.isBlank() || email.matches(emailAddress.trim())) { "Enter a valid email address or leave it blank" }
    }

    fun requireJobNumber(value: String) {
        require(identifier.matches(value.trim())) { "A job number is required (letters and numbers are allowed)" }
    }
}
