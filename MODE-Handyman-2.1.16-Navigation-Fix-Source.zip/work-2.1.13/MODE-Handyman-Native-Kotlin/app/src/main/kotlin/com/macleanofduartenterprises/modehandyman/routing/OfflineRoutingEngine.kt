package com.macleanofduartenterprises.modehandyman.routing

import android.content.Context
import android.net.Uri
import android.util.Xml
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.PriorityQueue
import java.util.zip.GZIPInputStream
import kotlin.math.*

/**
 * Local road-graph importer and A* router. Network access is used only by [downloadMap]
 * to obtain a user-selected regional map. Address matching and routing never contact a server.
 * Supported imports are OSM XML (.osm/.xml), gzipped OSM XML, and MODE graph files.
 */
class OfflineRoutingEngine(private val context: Context) {
    data class MapInfo(val id: String, val name: String, val nodes: Int, val edges: Int, val addresses: Int, val bytes: Long, val active: Boolean)
    data class RouteResult(val distanceMetres: Double, val estimatedSeconds: Double, val visitedNodes: Int, val mapName: String)

    private data class RawNode(val latE6: Int, val lonE6: Int, var label: String = "")
    private data class RawEdge(val from: Long, val to: Long, val distance: Float, val speed: Short)
    private data class Node(val latE6: Int, val lonE6: Int)
    private data class Edge(val to: Int, val distance: Float, val seconds: Float)
    private data class Address(val label: String, val latE6: Int, val lonE6: Int)
    private data class Graph(val name: String, val nodes: List<Node>, val adjacency: Array<MutableList<Edge>>, val addresses: List<Address>, val edgeCount: Int)
    private data class QueueItem(val node: Int, val score: Double) : Comparable<QueueItem> { override fun compareTo(other: QueueItem) = score.compareTo(other.score) }

    private val mapDir = File(context.filesDir, "offline-routing-maps").apply { mkdirs() }
    private val preferences = context.getSharedPreferences("offline-routing", Context.MODE_PRIVATE)

    fun maps(): List<MapInfo> {
        val active = preferences.getString("active", null)
        return mapDir.listFiles { file -> file.extension == EXTENSION }?.mapNotNull { file ->
            runCatching {
                DataInputStream(BufferedInputStream(FileInputStream(file))).use { input ->
                    require(input.readInt() == MAGIC && input.readInt() == FORMAT)
                    val name = input.readUTF(); val nodes = input.readInt(); val edges = input.readInt(); val addresses = input.readInt()
                    MapInfo(file.nameWithoutExtension, name, nodes, edges, addresses, file.length(), file.nameWithoutExtension == active)
                }
            }.getOrNull()
        }?.sortedBy { it.name.lowercase() }.orEmpty()
    }

    fun setActive(id: String) {
        require(File(mapDir, "$id.$EXTENSION").isFile) { "Map is not installed" }
        preferences.edit().putString("active", id).apply()
    }

    fun delete(id: String) {
        require(File(mapDir, "$id.$EXTENSION").delete()) { "Unable to delete map" }
        if (preferences.getString("active", null) == id) preferences.edit().remove("active").apply()
    }

    fun importMap(uri: Uri, regionName: String): MapInfo {
        val input = context.contentResolver.openInputStream(uri) ?: error("Unable to open map file")
        return input.use { importStream(it, regionName) }
    }

    fun downloadMap(url: String, regionName: String, progress: (Long, Long) -> Unit = { _, _ -> }): MapInfo {
        require(url.startsWith("https://")) { "Use an HTTPS map download URL" }
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 20_000; connection.readTimeout = 60_000; connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "MODE-Handyman/2.1.14 offline-map-downloader")
        val temporary = File.createTempFile("route-map-", ".download", context.cacheDir)
        try {
            require(connection.responseCode in 200..299) { "Map server HTTP ${connection.responseCode}" }
            val expected = connection.contentLengthLong
            require(expected <= MAX_DOWNLOAD_BYTES || expected < 0) { "Map exceeds the 750 MB download limit" }
            connection.inputStream.use { source ->
                FileOutputStream(temporary).buffered().use { destination ->
                    val buffer = ByteArray(64 * 1024); var total = 0L
                    while (true) {
                        val count = source.read(buffer); if (count < 0) break
                        total += count; require(total <= MAX_DOWNLOAD_BYTES) { "Map exceeds the 750 MB download limit" }
                        destination.write(buffer, 0, count); progress(total, expected)
                    }
                }
            }
            return FileInputStream(temporary).use { importStream(it, regionName) }
        } finally { connection.disconnect(); temporary.delete() }
    }

    fun route(from: String, to: String): RouteResult {
        require(from.isNotBlank() && to.isNotBlank()) { "Enter both addresses" }
        val file = activeFile(); val graph = readGraph(file)
        val startLocation = resolveLocation(from, graph.addresses)
        val endLocation = resolveLocation(to, graph.addresses)
        val start = nearestNode(startLocation.first, startLocation.second, graph.nodes)
        val goal = nearestNode(endLocation.first, endLocation.second, graph.nodes)
        val count = graph.nodes.size
        val distance = DoubleArray(count) { Double.POSITIVE_INFINITY }
        val travelled = DoubleArray(count) { Double.POSITIVE_INFINITY }
        val queue = PriorityQueue<QueueItem>()
        distance[start] = 0.0; travelled[start] = 0.0
        queue.add(QueueItem(start, heuristicSeconds(graph.nodes[start], graph.nodes[goal])))
        var visited = 0
        while (queue.isNotEmpty()) {
            val current = queue.remove().node
            if (current == goal) return RouteResult(travelled[current], distance[current], visited, graph.name)
            visited++; require(visited <= 2_000_000) { "Route search exceeded the safe processing limit" }
            val currentCost = distance[current]
            graph.adjacency[current].forEach { edge ->
                val candidate = currentCost + edge.seconds
                if (candidate < distance[edge.to]) {
                    distance[edge.to] = candidate
                    travelled[edge.to] = travelled[current] + edge.distance
                    queue.add(QueueItem(edge.to, candidate + heuristicSeconds(graph.nodes[edge.to], graph.nodes[goal])))
                }
            }
        }
        error("No connected driving route was found in ${graph.name}")
    }

    private fun importStream(original: InputStream, regionName: String): MapInfo {
        require(regionName.trim().isNotEmpty()) { "Enter a region name" }
        val buffered = if (original is BufferedInputStream) original else BufferedInputStream(original)
        buffered.mark(16)
        val signature = ByteArray(4); val read = buffered.read(signature); buffered.reset()
        if (read == 4 && bytesToInt(signature) == MAGIC) return installGraph(buffered, regionName)
        val xmlInput = if (read >= 2 && signature[0] == 0x1f.toByte() && signature[1] == 0x8b.toByte()) GZIPInputStream(buffered) else buffered
        return importOsm(xmlInput, regionName)
    }

    private fun importOsm(source: InputStream, regionName: String): MapInfo {
        val nodes = HashMap<Long, RawNode>(100_000)
        val edges = ArrayList<RawEdge>(200_000)
        val roadLabels = ArrayList<Address>()
        val parser = Xml.newPullParser(); parser.setInput(source, "UTF-8")
        var nodeId = 0L; var node: RawNode? = null; var nodeTags = linkedMapOf<String, String>()
        var wayRefs = ArrayList<Long>(); var wayTags = linkedMapOf<String, String>(); var inWay = false
        var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            if (event == org.xmlpull.v1.XmlPullParser.START_TAG) when (parser.name) {
                "node" -> {
                    nodeId = parser.getAttributeValue(null, "id").toLong()
                    node = RawNode((parser.getAttributeValue(null, "lat").toDouble() * 1_000_000).roundToInt(), (parser.getAttributeValue(null, "lon").toDouble() * 1_000_000).roundToInt())
                    nodeTags = linkedMapOf()
                }
                "way" -> { inWay = true; wayRefs = ArrayList(); wayTags = linkedMapOf() }
                "nd" -> if (inWay) wayRefs.add(parser.getAttributeValue(null, "ref").toLong())
                "tag" -> {
                    val key = parser.getAttributeValue(null, "k").orEmpty(); val value = parser.getAttributeValue(null, "v").orEmpty()
                    if (inWay) wayTags[key] = value else if (node != null) nodeTags[key] = value
                }
            } else if (event == org.xmlpull.v1.XmlPullParser.END_TAG) when (parser.name) {
                "node" -> {
                    node?.let { it.label = addressLabel(nodeTags); nodes[nodeId] = it }
                    node = null
                    // No arbitrary OSM-node ceiling: available heap and storage determine practical import size.
                }
                "way" -> {
                    val highway = wayTags["highway"]
                    if (highway != null && highway !in NON_DRIVABLE) {
                        val oneWay = wayTags["oneway"] in setOf("yes", "1", "true") || wayTags["junction"] == "roundabout"
                        val reverse = wayTags["oneway"] == "-1"
                        val speed = speedFor(highway, wayTags["maxspeed"])
                        for (index in 0 until wayRefs.lastIndex) {
                            val aId = wayRefs[index]; val bId = wayRefs[index + 1]
                            val a = nodes[aId] ?: continue; val b = nodes[bId] ?: continue
                            val metres = haversine(a.latE6, a.lonE6, b.latE6, b.lonE6).toFloat()
                            if (reverse) edges.add(RawEdge(bId, aId, metres, speed)) else edges.add(RawEdge(aId, bId, metres, speed))
                            if (!oneWay && !reverse) edges.add(RawEdge(bId, aId, metres, speed))
                        }
                        wayTags["name"]?.takeIf { it.isNotBlank() }?.let { name ->
                            wayRefs.firstNotNullOfOrNull(nodes::get)?.let { roadLabels.add(Address(name, it.latE6, it.lonE6)) }
                        }
                    }
                    inWay = false
                    // No arbitrary edge ceiling; the graph format and device resources set practical limits.
                }
            }
            event = parser.next()
        }
        require(edges.isNotEmpty()) { "No drivable OSM roads were found. Import uncompressed or .gz OSM XML, not PBF" }
        val used = HashSet<Long>(edges.size / 2); edges.forEach { used.add(it.from); used.add(it.to) }
        val ids = used.toList(); val index = HashMap<Long, Int>(ids.size); ids.forEachIndexed { i, id -> index[id] = i }
        val compactNodes = ids.map { id -> nodes[id]!!.let { Node(it.latE6, it.lonE6) } }
        val addresses = ArrayList<Address>()
        nodes.values.forEach { value -> if (value.label.isNotBlank()) addresses.add(Address(value.label, value.latE6, value.lonE6)) }
        addresses.addAll(roadLabels)
        val target = newMapFile(regionName)
        DataOutputStream(BufferedOutputStream(FileOutputStream(target))).use { output ->
            output.writeInt(MAGIC); output.writeInt(FORMAT); output.writeUTF(regionName.trim())
            output.writeInt(compactNodes.size); output.writeInt(edges.size); output.writeInt(addresses.size)
            compactNodes.forEach { output.writeInt(it.latE6); output.writeInt(it.lonE6) }
            edges.forEach { edge -> output.writeInt(index.getValue(edge.from)); output.writeInt(index.getValue(edge.to)); output.writeFloat(edge.distance); output.writeShort(edge.speed.toInt()) }
            addresses.forEach { address -> output.writeUTF(address.label.take(500)); output.writeInt(address.latE6); output.writeInt(address.lonE6) }
        }
        setActive(target.nameWithoutExtension)
        return maps().first { it.id == target.nameWithoutExtension }
    }

    private fun installGraph(source: InputStream, regionName: String): MapInfo {
        val target = newMapFile(regionName)
        FileOutputStream(target).buffered().use { source.copyTo(it) }
        runCatching { readGraph(target) }.getOrElse { target.delete(); throw IllegalArgumentException("Invalid MODE routing map: ${it.message}") }
        setActive(target.nameWithoutExtension)
        return maps().first { it.id == target.nameWithoutExtension }
    }

    private fun readGraph(file: File): Graph = DataInputStream(BufferedInputStream(FileInputStream(file))).use { input ->
        require(input.readInt() == MAGIC && input.readInt() == FORMAT) { "Unsupported offline map format" }
        val name = input.readUTF(); val nodeCount = input.readInt(); val edgeCount = input.readInt(); val addressCount = input.readInt()
        require(nodeCount > 0 && edgeCount >= 0 && addressCount >= 0) { "Invalid map counts" }
        val nodes = List(nodeCount) { Node(input.readInt(), input.readInt()) }
        val adjacency = Array(nodeCount) { mutableListOf<Edge>() }
        repeat(edgeCount) {
            val from = input.readInt(); val to = input.readInt(); val metres = input.readFloat(); val speed = input.readShort().toInt().coerceIn(5, 140)
            require(from in nodes.indices && to in nodes.indices && metres.isFinite() && metres > 0f) { "Invalid road edge" }
            adjacency[from].add(Edge(to, metres, (metres / (speed / 3.6f)).coerceAtLeast(0.1f)))
        }
        val addresses = List(addressCount) { Address(input.readUTF(), input.readInt(), input.readInt()) }
        Graph(name, nodes, adjacency, addresses, edgeCount)
    }

    private fun activeFile(): File {
        val id = preferences.getString("active", null) ?: maps().firstOrNull()?.id ?: error("Install and select an offline regional map first")
        return File(mapDir, "$id.$EXTENSION").also { require(it.isFile) { "The selected offline map is missing" } }
    }

    private fun newMapFile(name: String): File {
        val safe = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(50).ifBlank { "region" }
        return File(mapDir, "$safe-${System.currentTimeMillis()}.$EXTENSION")
    }

    private fun addressLabel(tags: Map<String, String>): String {
        val street = tags["addr:street"].orEmpty(); val number = tags["addr:housenumber"].orEmpty()
        val locality = listOf(tags["addr:city"], tags["addr:state"], tags["addr:postcode"]).filterNotNull().filter { it.isNotBlank() }.joinToString(" ")
        val address = listOf(number, street, locality).filter { it.isNotBlank() }.joinToString(" ")
        return address.ifBlank { tags["name"].orEmpty() }
    }

    private fun resolveLocation(query: String, addresses: List<Address>): Pair<Int, Int> {
        Regex("^\\s*(-?\\d+(?:\\.\\d+)?)\\s*[, ]\\s*(-?\\d+(?:\\.\\d+)?)\\s*$").matchEntire(query)?.let { match ->
            val lat = match.groupValues[1].toDouble(); val lon = match.groupValues[2].toDouble()
            require(lat in -90.0..90.0 && lon in -180.0..180.0) { "Coordinates are outside the valid range" }
            return (lat * 1_000_000).roundToInt() to (lon * 1_000_000).roundToInt()
        }
        val wanted = normalize(query); val tokens = wanted.split(' ').filter { it.length > 1 }
        val best = addresses.asSequence().map { address ->
            val candidate = normalize(address.label)
            val matches = tokens.count { candidate.contains(it) }
            val score = when { candidate == wanted -> 10_000; candidate.contains(wanted) -> 5_000 + wanted.length; matches == tokens.size && tokens.isNotEmpty() -> 1_000 + matches * 20; else -> matches * 10 }
            address to score
        }.filter { it.second > 0 }.maxByOrNull { it.second }?.first
        return best?.let { it.latE6 to it.lonE6 } ?: error("Address not found in the selected map. Try a fuller address or latitude,longitude")
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun nearestNode(latE6: Int, lonE6: Int, nodes: List<Node>): Int {
        var best = -1; var bestDistance = Double.POSITIVE_INFINITY
        nodes.forEachIndexed { index, node ->
            val latDifference = (node.latE6 - latE6).toDouble(); val lonDifference = (node.lonE6 - lonE6).toDouble() * cos(latE6 / 1_000_000.0 * PI / 180.0)
            val square = latDifference * latDifference + lonDifference * lonDifference
            if (square < bestDistance) { bestDistance = square; best = index }
        }
        require(best >= 0) { "Offline map has no road nodes" }; return best
    }

    private fun heuristicSeconds(from: Node, to: Node): Double = haversine(from.latE6, from.lonE6, to.latE6, to.lonE6) / (130.0 / 3.6)

    private fun speedFor(highway: String, maxSpeed: String?): Short {
        val explicit = maxSpeed?.let { Regex("\\d+").find(it)?.value?.toIntOrNull() }
        return (explicit ?: when (highway) { "motorway" -> 105; "trunk" -> 90; "primary" -> 75; "secondary" -> 65; "tertiary" -> 55; "residential", "unclassified" -> 40; "service" -> 25; else -> 30 }).coerceIn(5, 140).toShort()
    }

    private fun haversine(aLatE6: Int, aLonE6: Int, bLatE6: Int, bLonE6: Int): Double {
        val aLat = aLatE6 / 1_000_000.0 * PI / 180.0; val bLat = bLatE6 / 1_000_000.0 * PI / 180.0
        val deltaLat = bLat - aLat; val deltaLon = (bLonE6 - aLonE6) / 1_000_000.0 * PI / 180.0
        val value = sin(deltaLat / 2).pow(2) + cos(aLat) * cos(bLat) * sin(deltaLon / 2).pow(2)
        return 6_371_000.0 * 2 * atan2(sqrt(value), sqrt(1 - value))
    }

    private fun bytesToInt(bytes: ByteArray): Int = ((bytes[0].toInt() and 255) shl 24) or ((bytes[1].toInt() and 255) shl 16) or ((bytes[2].toInt() and 255) shl 8) or (bytes[3].toInt() and 255)

    companion object {
        private const val MAGIC = 0x4d4f4445
        private const val FORMAT = 1
        private const val EXTENSION = "modegraph"
        private const val MAX_DOWNLOAD_BYTES = 750L * 1024 * 1024
        private val NON_DRIVABLE = setOf("footway", "path", "cycleway", "steps", "pedestrian", "bridleway", "corridor", "platform", "construction", "proposed")
    }
}
