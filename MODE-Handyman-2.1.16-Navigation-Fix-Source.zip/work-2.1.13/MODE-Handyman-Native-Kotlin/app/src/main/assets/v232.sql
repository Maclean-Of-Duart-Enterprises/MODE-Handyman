-- Optional job-specific service location shown on quotes and invoices.
ALTER TABLE job ADD COLUMN job_site_address TEXT NOT NULL DEFAULT '';
