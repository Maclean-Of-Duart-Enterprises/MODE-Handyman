-- Dedicated customer/company phone and email fields.
-- The old helper table is created first so direct installs from the bundled
-- legacy template and upgrades from existing native releases use one path.
CREATE TABLE IF NOT EXISTS mode_customer_contact_extra (
  customer_id INTEGER PRIMARY KEY,
  business_name TEXT NOT NULL DEFAULT '',
  billing_address TEXT NOT NULL DEFAULT '',
  service_address TEXT NOT NULL DEFAULT '',
  photo_base64 TEXT NOT NULL DEFAULT ''
);

CREATE TABLE mode_customer_contact_extra_v231 (
  customer_id INTEGER PRIMARY KEY,
  business_name TEXT NOT NULL DEFAULT '',
  billing_address TEXT NOT NULL DEFAULT '',
  service_address TEXT NOT NULL DEFAULT '',
  photo_base64 TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  customer_email TEXT NOT NULL DEFAULT ''
);

INSERT INTO mode_customer_contact_extra_v231(customer_id,business_name,billing_address,service_address,photo_base64)
SELECT customer_id,business_name,billing_address,service_address,photo_base64
FROM mode_customer_contact_extra;

DROP TABLE mode_customer_contact_extra;
ALTER TABLE mode_customer_contact_extra_v231 RENAME TO mode_customer_contact_extra;
