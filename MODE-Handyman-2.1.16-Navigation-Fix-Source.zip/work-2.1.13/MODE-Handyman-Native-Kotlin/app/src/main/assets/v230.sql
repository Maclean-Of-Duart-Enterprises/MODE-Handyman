-- Editable business identifiers, mandatory customer contact references, and
-- direct quote/invoice signature capture.
ALTER TABLE contact ADD COLUMN customer_number TEXT NOT NULL DEFAULT '';
ALTER TABLE job ADD COLUMN job_number TEXT NOT NULL DEFAULT '';

UPDATE contact
SET customer_number = 'C-' || id
WHERE trim(customer_number) = '';

UPDATE job
SET job_number = 'J-' || id
WHERE trim(job_number) = '';

CREATE UNIQUE INDEX job_profile_number_unq
ON job(profile_id, job_number COLLATE NOCASE);

CREATE TABLE mode_document_signature (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profile_id INTEGER NOT NULL REFERENCES business_profile(id) ON DELETE CASCADE,
  document_kind TEXT NOT NULL CHECK(document_kind IN ('quote','invoice')),
  document_id INTEGER NOT NULL,
  signer_name TEXT NOT NULL,
  signed_at TEXT NOT NULL,
  signature_file TEXT NOT NULL,
  UNIQUE(profile_id, document_kind, document_id)
);

CREATE INDEX mode_document_signature_document_idx
ON mode_document_signature(profile_id, document_kind, document_id);
