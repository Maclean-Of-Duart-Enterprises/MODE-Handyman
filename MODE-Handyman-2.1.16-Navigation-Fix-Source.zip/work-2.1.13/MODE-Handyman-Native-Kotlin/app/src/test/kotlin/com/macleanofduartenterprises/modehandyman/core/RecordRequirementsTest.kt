package com.macleanofduartenterprises.modehandyman.core

import org.junit.Assert.assertThrows
import org.junit.Test

class RecordRequirementsTest {
    @Test fun acceptsRequiredContactAndMixedJobIdentifiers() {
        RecordRequirements.validateContact("customer@example.com", "+1 555 0100")
        RecordRequirements.requireJobNumber("JOB-2026/A9")
    }

    @Test fun allowsOptionalContactPhoneAndEmail() {
        RecordRequirements.validateContact("", "")
    }

    @Test fun validatesOptionalCustomerCompanyPhoneAndEmailWhenPresent() {
        RecordRequirements.validateOptionalPhoneAndEmail("","")
        RecordRequirements.validateOptionalPhoneAndEmail("555-0100","office@example.com")
        assertThrows(IllegalArgumentException::class.java) { RecordRequirements.validateOptionalPhoneAndEmail("12","office@example.com") }
        assertThrows(IllegalArgumentException::class.java) { RecordRequirements.validateOptionalPhoneAndEmail("555-0100","not-an-email") }
    }
}
