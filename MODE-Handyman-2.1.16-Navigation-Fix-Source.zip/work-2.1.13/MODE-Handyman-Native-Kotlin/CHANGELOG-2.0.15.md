# MODE Handyman 2.0.15

- Moved the job-site address from **Prepared for** to the right-hand **Job / Project** column directly below the job number on quote and invoice PDFs.
- Added the optional address to the PDF document model separately from customer details.
- Reduced handwritten signatures to a maximum 140 × 50 point area.
- Positioned the compact signature directly beneath the typed signer name in the approval block below the totals.
- Removed the separate **Handwritten signature** heading and oversized signature-only continuation page behavior.
- Advanced the application to version 2.0.15 (version code 21).
- Verified 23 debug and 23 release JVM tests, ten host-side regression suites, Android Lint with zero issues, APK alignment, release metadata, and the v2 signing certificate without an emulator.
