# 2.1.10 Graphical Calendar
- Replaced the schedule's stacked day buttons with a Sunday-first graphical month/week/two-week grid.
- Displays appointment titles inside date cells; tapping an appointment opens its actions.
- Tap a date to switch to the day agenda; highlighted selected date and current date.
- Preserves Day, Week, 2 weeks, Month, Year navigation, appointment editing, recurrence and reminders.
- Month view displays three event labels per day plus overflow count; weekly views show five.
- Corrected the graphical week-row Kotlin property so the updated calendar compiles successfully.
- Built and signed the universal APK; completed host-side unit, regression, archive, metadata, alignment, asset and signature verification without an emulator.
