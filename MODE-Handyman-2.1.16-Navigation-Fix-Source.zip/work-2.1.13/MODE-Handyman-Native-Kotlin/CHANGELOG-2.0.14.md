# MODE Handyman 2.0.14

- Added an optional multiline **Job site address** field immediately beneath **Job number**.
- Displayed a supplied address on the job screen.
- Included the job-specific address on quote and invoice screens and exported PDFs.
- Added database schema 232 migration with an empty default so existing jobs remain unchanged.
- Advanced the application to version 2.0.14 (version code 20).
- Verified 23 debug and 23 release JVM tests, nine host-side regression suites, Android Lint with zero issues, APK alignment, migration packaging, release metadata, and the v2 signing certificate without an emulator.
