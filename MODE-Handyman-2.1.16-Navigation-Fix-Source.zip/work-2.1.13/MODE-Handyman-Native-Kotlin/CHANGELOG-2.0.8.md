# MODE Handyman 2.0.8

- Set versionName to 2.0.8 and versionCode to 14.
- Replaced the previous GPLv3-with-restrictions notice with an AGPL-3.0-only notice.
- Added license and source/release actions to Settings and Privacy & about.
- Corrected the stale version displayed in Privacy & about.
- Added license and source links to README.

Verification: the full AGPLv3 legal text is bundled verbatim for offline viewing. See the release verification report for build and host-side test results.
