# 2.1.12 partial source update

- Correct Privacy & about version to 2.1.12 and Gradle versionCode 34.
- Add persisted invoice terms with PDF footer rendering, accessible on every invoice screen.
- Surface receipt photo management in receipt editor; existing receipt photo gallery/import retained.
- Add trip destination entry and external OpenStreetMap route preview; mileage remains manually entered.

**Not implemented:** offline automatic address geocoding/routing and automatic distance entry; expense-specific photo attachments where expenses are separate from receipts; automatic transfer of quote terms to invoices. This is not a fully completed feature release.
