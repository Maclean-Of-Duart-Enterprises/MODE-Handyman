# Offline Routing Maps

MODE Handyman 2.1.13 performs address matching and driving-route calculation on the phone. Public Nominatim and OSRM routing services are not used.

## Install a regional map

1. Open **Trips**.
2. Select **Offline routing maps**.
3. Choose either:
   - **Import downloaded regional map** to select an existing file; or
   - **Download regional map by HTTPS URL** and enter a direct regional-map URL.
4. Enter a clear region name.
5. Wait while the app converts and indexes the road network.

Supported inputs:

- OpenStreetMap XML: `.osm` or `.xml`
- Gzipped OpenStreetMap XML: `.osm.gz`
- Prebuilt MODE routing graph: `.modegraph`

PBF and BZ2 files are not supported. Choose OSM XML or gzip when obtaining an extract. City, county, or small multi-county extracts are recommended for phone memory and storage limits.

## Calculate a trip

1. Install and select a regional map.
2. Add or edit a trip.
3. Enter the starting and destination addresses.
4. Select **Calculate driving distance offline**.
5. Review the calculated distance and save the trip.

If a location is not present in the map's address index, enter coordinates as `latitude,longitude`. Manual distance entry remains available.

## Privacy

The selected map is stored in the app's private files. Trip addresses are matched locally and the A* route calculation is local. Internet access is used only when the user explicitly downloads a map or opens a source/release link.
