# MODE Handyman 2.1.4

- Calendar schedule views: day, week, two weeks, month, year; period navigation and daily drill-down.
- Native date/time pickers for creating and editing appointments.
- Tool quantity with additive schema 233 migration and edit support.
- No emulator or physical device testing performed.
