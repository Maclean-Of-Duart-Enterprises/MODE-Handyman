# MODE Handyman 2.1.8 — Recurring schedule events

- New appointments can repeat weekly, biweekly, monthly, quarterly, semiannually, or annually.
- Occurrences are generated for five years from the original appointment, up to 300 instances.
- Each occurrence appears in day/week/biweekly/month/year views and is individually editable or deletable.
- Reminder dates and times are shifted by the same interval for each occurrence; past reminders are disabled.
- Existing appointments and reminders remain unchanged. No destructive database migration.

## Known limitations
- Recurrence is materialized for five years, not perpetual; no automatic extension after that period.
- Editing or deleting one occurrence does not change the whole series.
- No exception/series-wide editing or recurring-event end-date control yet.
- Android compilation and device tests are not verified.
