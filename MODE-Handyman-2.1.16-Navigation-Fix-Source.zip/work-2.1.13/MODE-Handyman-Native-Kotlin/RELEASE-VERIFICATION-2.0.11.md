# MODE Handyman 2.0.11 release verification

## Release

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.0.11`
- Version code: `17`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- Database schema: `231`

## Implemented fix

- Added dedicated **Phone number** and **Email address** text boxes immediately below **Customer or company name** in both add and edit customer forms.
- Configured the phone and email keyboard/input types.
- Made both values required and validated the email format before saving.
- Persisted the fields through database upgrades without changing existing customer details or photos.
- Included the fields in customer display, customer copying, JSON/CSV transfer, backups, and customer-facing quote/invoice details.
- Retained compatibility with customer CSV exports from earlier versions.

## Host-side verification

- Debug JVM tests: 23 passed, 0 failed.
- Release JVM tests: 23 passed, 0 failed.
- Android Lint release analysis: 0 issues.
- Six source/database regression suites passed, including schema integrity, foreign keys, legacy-value preservation, field order, required validation, transfer compatibility, and prior 2.0.6–2.0.10 behavior.
- APK package metadata confirms version `2.0.11` / code `17`.
- APK contains migration asset `v231.sql`.
- APK is 4-byte ZIP aligned.
- APK Signature Scheme v2 verification passed with one 4096-bit RSA signer.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK declares only `android.permission.POST_NOTIFICATIONS`; it does not request Internet permission.

No emulator or physical-device UI test was performed, as requested. Verification was limited to compilation, JVM tests, SQLite migration/regression tests, static analysis, and APK inspection.
