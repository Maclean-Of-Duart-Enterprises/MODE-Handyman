# MODE Handyman 2.0.10

- Added required, dedicated contact fields for mobile phone, email address, and customer number, with separate optional landline, office phone, and alternate email fields.
- Added required editable alphanumeric job numbers. New quote and invoice numbers use the job number as their prefix.
- Replaced the broken generic field allow-list with schema-correct editing and dedicated customer, job, quote, and invoice forms.
- Enabled transactional deletion of records and their dependent history instead of returning the financial/dependency restriction message.
- Enabled record copying for customers, contacts, jobs, quotes, invoices, and catalog records; quote and invoice copies include line items.
- Added edit/delete actions for quote and invoice line items.
- Added direct customer signature pads to quote and invoice screens. Saved signatures are shown on the generated PDF and included in backups.
- Advanced the application to version 2.0.10 (version code 16) and database schema 230.

Testing: host-side JVM tests, schema migration/integrity tests, static feature verification, Android lint, release build, APK signature verification, and ZIP alignment. No emulator was used.
