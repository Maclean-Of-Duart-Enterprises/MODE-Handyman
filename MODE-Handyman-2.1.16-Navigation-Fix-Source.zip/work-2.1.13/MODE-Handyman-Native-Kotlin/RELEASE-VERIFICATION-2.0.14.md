# MODE Handyman 2.0.14 release verification

## Release

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.0.14`
- Version code: `20`
- Minimum SDK: `30`
- Target and compile SDK: `36`
- Database schema: `232`

## Implemented update

- Added an optional multiline **Job site address** field immediately below **Job number**.
- Persisted the field in the job record and included it in generic job editing and copying.
- Displayed a supplied address on the job screen.
- Included the job-specific address on quote and invoice screens and exported PDFs.
- Blank job-site addresses are omitted from customer-facing documents.
- Added a schema 232 migration with an empty default, preserving existing jobs unchanged.

## Host-side verification

- Debug JVM tests: 23 passed, 0 failed.
- Release JVM tests: 23 passed, 0 failed.
- Android Lint release analysis: 0 issues.
- Nine source/database regression suites passed.
- Schema 232 migration preserved existing jobs and accepted job-site addresses.
- APK metadata confirms version `2.0.14` / code `20`.
- APK contains the `v232.sql` migration asset.
- APK is 4-byte ZIP aligned.
- APK Signature Scheme v2 verification passed with one 4096-bit RSA signer.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- APK does not request Internet permission.

No emulator or physical-device UI test was performed, as requested. Verification was limited to compilation, JVM tests, SQLite migration/regression tests, static analysis, and APK inspection.
