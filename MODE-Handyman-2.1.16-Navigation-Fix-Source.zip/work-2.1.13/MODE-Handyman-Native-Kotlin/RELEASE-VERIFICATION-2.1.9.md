# MODE Handyman 2.1.9 Release Verification

Date: October 29, 2026

## Release identity

- Package: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.1.9`
- Version code: `31`
- Minimum SDK: 30
- Target/compile SDK: 36

## Build

- Compiled from the supplied 2.1.9 recurring-series source with Kotlin 2.1.20.
- Packaged with Android API 36 and Android Build Tools 36.0.0.
- Universal APK; no ABI-specific native libraries are required.
- Signed with the established Maclean Phone release certificate.
- APK Signature Scheme v3 verified with one 4096-bit RSA signer.
- Signer certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`.
- ZIP alignment verified.

## Non-emulator verification

- Kotlin/JVM unit tests: 23 passed, 0 failed.
- Nine existing host regression suites passed: 2.0.6, 2.0.9, 2.0.10, 2.0.11, 2.0.12, 2.0.13, 2.0.14, database, and Smart Tools.
- Recurrence implementation inspected for occurrence-only edit/delete, series-wide edit/delete, inclusive custom end date, five-year limit, series membership tables, reminder shifting/cancellation, and preservation of occurrence overrides.
- APK manifest, resources, assets and DEX inspected successfully.
- Archive integrity check passed.
- Permissions are limited to `POST_NOTIFICATIONS` and `RECEIVE_BOOT_COMPLETED`; no Internet permission is declared.
- No emulator or physical Android device was used. Installation and interactive UI behavior should be confirmed on the target phone.

## APK checksum

SHA-256: `7e2ea59db1835a0fcb0e596f071f32f46c214d434cf8898f55c59fa54081a64f`
