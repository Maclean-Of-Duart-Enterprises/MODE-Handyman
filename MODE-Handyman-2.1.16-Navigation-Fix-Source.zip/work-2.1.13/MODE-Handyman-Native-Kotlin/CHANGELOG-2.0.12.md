# MODE Handyman 2.0.12

- Made customer/company and contact phone and email fields optional.
- Retained validation for non-empty phone and email values.
- Kept customer numbers mandatory.
- Continued including any supplied customer/company or contact phone and email values in quotes, invoices, and other customer-facing forms.
- Advanced the application to version 2.0.12 (version code 18).
- Verified 23 debug and 23 release JVM tests, seven host-side regression suites, Android Lint with zero issues, APK alignment, release metadata, and the v2 signing certificate without an emulator.
