# MODE Handyman 2.1.14 — Regional OSM import limits

- Removed the hard-coded 1,000,000 OSM-node import rejection.
- Removed the hard-coded 4,000,000 directed-edge rejection.
- Updated graph reader count validation to accept any positive node count and nonnegative edge/address counts representable in the current graph format.
- Updated versionName to 2.1.14, versionCode to 36, and Privacy & about header.

## Capacity warning

This change does NOT guarantee a 5-billion-node import. The in-memory Kotlin collections, Android heap, 32-bit graph indices and file counts, download size cap (750 MiB), and import runtime still impose practical limits. Very large imports may fail with OutOfMemoryError or require an architectural rewrite to a streaming/disk-backed graph builder. No APK build or device test was completed.
