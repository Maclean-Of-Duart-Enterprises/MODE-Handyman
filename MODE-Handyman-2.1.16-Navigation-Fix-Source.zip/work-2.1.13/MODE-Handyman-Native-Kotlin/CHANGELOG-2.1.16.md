# MODE Handyman 2.1.16

- Fix OsmAnd invalid-format error by geocoding the saved job-site address to latitude/longitude before passing the navigation destination.
- Offer explicit OsmAnd, Google Maps, and generic maps choices.
- Preserve job and trip features; update displayed version to 2.1.16 and versionCode 38.
- OsmAnd lookup requires network connectivity.
