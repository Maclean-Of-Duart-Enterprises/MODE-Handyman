# MODE Handyman 2.0.13

- Removed customer numbers from the contact interface and application workflows.
- Removed customer-number requirements from quotes, invoices, and other records.
- Fixed the `near "primary": syntax error` that prevented newly created contacts from being linked to customers.
- Phone and email remain optional and are included on customer-facing documents when supplied.
- Advanced the application to version 2.0.13 (version code 19).
- Verified 23 debug and 23 release JVM tests, eight host-side regression suites, Android Lint with zero issues, APK alignment, release metadata, and the v2 signing certificate without an emulator.
