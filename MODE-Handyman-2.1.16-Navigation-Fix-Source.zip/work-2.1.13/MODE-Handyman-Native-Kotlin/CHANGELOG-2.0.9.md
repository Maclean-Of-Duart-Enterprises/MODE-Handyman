# MODE Handyman 2.0.9

- Quote and invoice detail screens now show customer business name, billing address, site/service address, and associated contact names, phone numbers and email addresses.
- Quote and invoice PDF exports include the same customer information in the Prepared For section, wrapping long fields and paginating when necessary.
- Invoice customer selection respects the invoice billing customer override, falling back to the job customer.
- Customer information is read from the active business profile at export time; no database migration or existing record rewrite is required.
- Internal customer notes and arbitrary custom fields are not exposed on customer-facing documents to avoid inadvertent disclosure.
- Version name 2.0.9; version code 15.

Verification: clean Android build, debug and release unit tests, release lint, database checks, customer-resolution regression tests, and APK signature/alignment checks completed without an emulator. Physical-device testing remains for the installer.
