# MODE Handyman 2.1.3 — Release Verification

Date: October 28, 2026

## Release identity

- Application ID: `com.macleanofduartenterprises.modehandyman`
- Version name: `2.1.3`
- Version code: `25`
- Minimum Android SDK: `30`
- Target and compile Android SDK: `36`
- APK type: universal release APK

## Build correction

The supplied source initially failed both debug and release Kotlin compilation because `MainActivity` referenced the nested `ModeRepository.JobTimeEntry` model without importing it. The missing nested-model import was added, after which the complete clean build succeeded.

## Build and test results

- Clean debug and release Kotlin compilation: passed.
- Debug JVM unit tests: 23 passed; 0 failures; 0 errors; 0 skipped.
- Release JVM unit tests: 23 passed; 0 failures; 0 errors; 0 skipped.
- Android Lint: 0 errors and 8 localization warnings (`SetTextI18n`).
- Release resource shrinking and R8 minification: passed.
- Release signing validation and assembly: passed.
- Ten existing host-side source/database regression suites: passed.
- Live timer checks: passed for the one-second refresh, timestamp-based elapsed-time calculation, lifecycle callback cleanup/restart, manual entries, notes, total-time display, editing/deletion and billed-entry protection.

No emulator or physical-device UI testing was performed, as requested.

## APK verification

- APK Signature Scheme v2: verified.
- Number of signers: 1.
- Signing key: 4096-bit RSA.
- Signing certificate SHA-256: `62ebb3c5d7d722b2e1174a4622f7593926204579084f94e11151ef606b32d136`
- ZIP alignment: verified.
- Package metadata: version `2.1.3`, code `25`.
- Declared permission: `android.permission.POST_NOTIFICATIONS` only.
- APK SHA-256: `53715aed61faec6b2ae26914a3eff0e1cfcbd1c7a58a9f97efd299691f122c17`

## Remaining limitation

Host-side compilation, tests, lint and package verification cannot reproduce touch input, activity timing under device power management, or other phone-specific Android behavior. The live timer should therefore receive final hands-on validation on the intended phone.
