# MODE Handyman 2.1.13 — Trip routing, photo capture, quote terms

- Replaced public Nominatim/OSRM trip routing with an embedded A* driving-route engine. Address matching and routing now run entirely on the device.
- Added offline regional map management: import, download, select, list and delete OSM XML, gzipped OSM XML and MODE graph packages.
- Regional OSM data is converted into a compact private road graph with one-way roads, road-speed weighting, named-road/address indexing and coordinate fallback.
- Saved trip destination addresses in a new auxiliary SQLite table, without altering the legacy trip schema.
- Added trip address/distance editing from Trips.
- Added camera capture for receipt/expense photos alongside the existing local image picker and gallery. Android camera intent returns a thumbnail, not a full-resolution original.
- Added quote terms transfer into converted invoices; invoice terms remain editable and print in invoice PDFs.
- Updated Privacy & about text and ensured the header displays Native Kotlin edition 2.1.13; versionCode remains 35.

## Map format note
Use a city, county or small multi-county OSM XML extract for phone-sized routing. Raw `.osm`, `.xml`, `.osm.gz` and prebuilt `.modegraph` files are supported. PBF and BZ2 files are not accepted by the embedded importer.
