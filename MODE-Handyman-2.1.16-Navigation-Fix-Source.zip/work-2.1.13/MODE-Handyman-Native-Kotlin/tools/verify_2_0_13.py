#!/usr/bin/env python3
"""Host-side source and SQLite verification for contact creation fixes."""
from pathlib import Path
import shutil
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
MODELS = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/core/Models.kt").read_text()
assert "Customer number" not in UI and "customerNumber" not in MODELS
assert "customer_number" not in REPO
assert 'put("primary"' not in REPO
assert "INSERT OR IGNORE INTO customer_contact(customer_id,contact_id,createdDate,modifiedDate,`primary`)" in REPO
assert 'add("Phone",contact.phone)' in REPO and 'add("Email",contact.email)' in REPO
assert "db.beginTransaction()" in REPO and "db.setTransactionSuccessful()" in REPO

with tempfile.TemporaryDirectory() as directory:
    database = Path(directory) / "handyman.db"
    shutil.copy2(ASSETS / "handyman-template.db", database)
    db = sqlite3.connect(database)
    db.execute(
        "INSERT INTO customer_contact(customer_id,contact_id,createdDate,modifiedDate,`primary`) VALUES(?,?,?,?,?)",
        (1, 2, "2026-10-25", "2026-10-25", 1),
    )
    assert db.execute("SELECT customer_id,contact_id,`primary` FROM customer_contact").fetchone() == (1, 2, 1)

print("PASS: 2.0.13 customer-number removal, optional contact details, quoted primary-column linking, and atomic contact save")
