#!/usr/bin/env python3
"""Host-side verification for 2.0.9 quote/invoice customer detail resolution."""
import pathlib
import shutil
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        target = pathlib.Path(directory) / "handyman.db"
        shutil.copy2(ASSETS / "handyman-template.db", target)
        db = sqlite3.connect(target)
        db.executescript((ASSETS / "v228.sql").read_text())
        db.executescript((ASSETS / "v229.sql").read_text())
        db.executescript((ASSETS / "v230.sql").read_text())
        db.executescript((ASSETS / "v231.sql").read_text())
        db.executescript(
            """
            INSERT INTO business_profile(id,display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date)
              VALUES(1,'MODE','{}','{}','{}',1,'2026-10-25','2026-10-25'),
                    (2,'Other','{}','{}','{}',0,'2026-10-25','2026-10-25');
            INSERT INTO customer(id,name,description,mode_fields,createdDate,modifiedDate,profile_id)
              VALUES(101,'Job Customer','INTERNAL CUSTOMER NOTE','secret custom value','2026-10-25','2026-10-25',1),
                    (102,'Billing Customer','INTERNAL BILLING NOTE','another secret','2026-10-25','2026-10-25',1),
                    (201,'Other Profile Customer','','','2026-10-25','2026-10-25',2);
            INSERT INTO mode_customer_contact_extra(customer_id,business_name,billing_address,service_address)
              VALUES(101,'Job Customer LLC','10 Billing Rd','20 Jobsite Ave'),
                    (102,'Billing Customer Inc','30 Accounts Way','40 Service St'),
                    (201,'Other Profile Inc','Hidden','Hidden');
            INSERT INTO contact(id,firstName,surname,mobileNumber,emailAddress,alternateEmail,createdDate,modifiedDate,profile_id)
              VALUES(301,'Jane','Job','555-0101','jane@example.test','jane.alt@example.test','2026-10-25','2026-10-25',1),
                    (302,'Bill','Payer','555-0102','bill@example.test','','2026-10-25','2026-10-25',1);
            INSERT INTO customer_contact(customer_id,contact_id,createdDate,modifiedDate,`primary`)
              VALUES(101,301,'2026-10-25','2026-10-25',1),(102,302,'2026-10-25','2026-10-25',1);
            INSERT INTO job(id,customer_id,summary,description,billing_type,created_date,modified_date,profile_id)
              VALUES(401,101,'Kitchen repair','Scope','timeAndMaterial','2026-10-25','2026-10-25',1);
            INSERT INTO quote(id,job_id,total_amount,quote_num,state,created_date,modified_date,profile_id)
              VALUES(501,401,10000,'Q-501','reviewing','2026-10-25','2026-10-25',1);
            INSERT INTO invoice(id,job_id,total_amount,invoice_num,paid,created_date,modified_date,billing_customer_id,profile_id)
              VALUES(601,401,10000,'I-601',0,'2026-10-25','2026-10-25',102,1);
            """
        )

        def document_customer(kind: str, document_id: int, profile_id: int) -> int | None:
            if kind == "quote":
                sql = "SELECT j.customer_id FROM quote d JOIN job j ON j.id=d.job_id WHERE d.id=? AND d.profile_id=? AND j.profile_id=?"
                args = (document_id, profile_id, profile_id)
            else:
                sql = "SELECT COALESCE(d.billing_customer_id,j.customer_id) FROM invoice d LEFT JOIN job j ON j.id=d.job_id WHERE d.id=? AND d.profile_id=?"
                args = (document_id, profile_id)
            row = db.execute(sql, args).fetchone()
            return None if row is None or row[0] is None else row[0]

        def customer_lines(customer_id: int, profile_id: int) -> list[str]:
            customer = db.execute(
                "SELECT name,description,mode_fields FROM customer WHERE id=? AND profile_id=?",
                (customer_id, profile_id),
            ).fetchone()
            assert customer is not None
            extra = db.execute(
                "SELECT business_name,billing_address,service_address FROM mode_customer_contact_extra WHERE customer_id=?",
                (customer_id,),
            ).fetchone()
            lines = [customer[0]]
            for label, value in zip(("Business", "Billing address", "Site / service address"), extra):
                if value:
                    lines.append(f"{label}: {value}")
            for contact in db.execute(
                "SELECT c.firstName,c.surname,c.mobileNumber,c.emailAddress,c.alternateEmail FROM contact c JOIN customer_contact cc ON cc.contact_id=c.id WHERE cc.customer_id=? AND c.profile_id=? ORDER BY cc.`primary` DESC,c.surname,c.firstName",
                (customer_id, profile_id),
            ):
                values = ("Contact", " ".join(x for x in contact[:2] if x), "Phone", contact[2], "Email", contact[3], "Alternate email", contact[4])
                for index in range(0, len(values), 2):
                    if values[index + 1]:
                        lines.append(f"{values[index]}: {values[index + 1]}")
            joined = "\n".join(lines)
            assert customer[1] not in joined and customer[2] not in joined
            return lines

        quote_customer = document_customer("quote", 501, 1)
        invoice_customer = document_customer("invoice", 601, 1)
        assert quote_customer == 101
        assert invoice_customer == 102
        assert document_customer("quote", 501, 2) is None
        assert customer_lines(quote_customer, 1) == [
            "Job Customer", "Business: Job Customer LLC", "Billing address: 10 Billing Rd",
            "Site / service address: 20 Jobsite Ave", "Contact: Jane Job", "Phone: 555-0101",
            "Email: jane@example.test", "Alternate email: jane.alt@example.test",
        ]
        assert customer_lines(invoice_customer, 1) == [
            "Billing Customer", "Business: Billing Customer Inc", "Billing address: 30 Accounts Way",
            "Site / service address: 40 Service St", "Contact: Bill Payer", "Phone: 555-0102",
            "Email: bill@example.test",
        ]
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"

        pdf_source = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/export/PdfGenerator.kt").read_text()
        assert "customerDetails: List<String>" in pdf_source
        assert "customers.flatMap { wrap(it,body,235f) }" in pdf_source
        print("PASS: 2.0.9 quote customer, invoice billing override, profile isolation, address/contact disclosure, internal-field exclusion, and PDF wrapping")


if __name__ == "__main__":
    main()
