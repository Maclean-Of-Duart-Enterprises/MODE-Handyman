#!/usr/bin/env python3
"""Host-side source verification for optional phone/email document handling."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RULES = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/core/RecordRequirements.kt").read_text()
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
assert 'phone.isBlank() || phone.trim().length >= 5' in RULES
assert 'emailAddress.isBlank() || email.matches(emailAddress.trim())' in RULES
assert 'Mobile phone (optional)' in UI and 'Email address (optional)' in UI
assert 'validateOptionalPhoneAndEmail(phone.text.toString(),email.text.toString())' in UI
assert 'requirePhoneAndEmail' not in REPO
assert 'add("Customer phone",extra.optString("customer_phone"))' in REPO
assert 'add("Customer email",extra.optString("customer_email"))' in REPO
assert 'add("Phone",contact.phone)' in REPO
assert 'add("Email",contact.email)' in REPO
print("PASS: 2.0.12 optional phone/email validation and conditional document inclusion")
