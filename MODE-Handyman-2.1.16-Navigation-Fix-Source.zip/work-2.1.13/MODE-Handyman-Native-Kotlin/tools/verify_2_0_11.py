#!/usr/bin/env python3
"""Host-side verification for 2.0.11 customer/company phone and email."""
from pathlib import Path
import shutil
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
TRANSFER = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/CustomerTransfer.kt").read_text()


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        database = Path(directory) / "handyman.db"
        shutil.copy2(ASSETS / "handyman-template.db", database)
        db = sqlite3.connect(database)
        for version in (228, 229, 230):
            db.executescript((ASSETS / f"v{version}.sql").read_text())

        # Confirm an upgrade preserves all legacy helper-table data and adds
        # empty values for the two new fields.
        db.execute(
            "CREATE TABLE mode_customer_contact_extra(customer_id INTEGER PRIMARY KEY,business_name TEXT NOT NULL DEFAULT '',billing_address TEXT NOT NULL DEFAULT '',service_address TEXT NOT NULL DEFAULT '',photo_base64 TEXT NOT NULL DEFAULT '')"
        )
        db.execute(
            "INSERT INTO mode_customer_contact_extra(customer_id,business_name,billing_address,service_address,photo_base64) VALUES(?,?,?,?,?)",
            (77, "Acme Ltd", "1 Billing Road", "2 Service Road", "image-data"),
        )
        db.executescript((ASSETS / "v231.sql").read_text())
        db.execute("PRAGMA user_version=231")
        columns = {row[1] for row in db.execute("PRAGMA table_info(mode_customer_contact_extra)")}
        assert {"customer_phone", "customer_email"} <= columns
        assert db.execute(
            "SELECT business_name,billing_address,service_address,photo_base64,customer_phone,customer_email FROM mode_customer_contact_extra WHERE customer_id=77"
        ).fetchone() == ("Acme Ltd", "1 Billing Road", "2 Service Road", "image-data", "", "")
        assert db.execute("PRAGMA user_version").fetchone()[0] == 231
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"

    name = UI.index('Ui.field(this, "Customer or company name"')
    phone = UI.index('Ui.field(this,"Phone number"')
    email = UI.index('Ui.field(this,"Email address"')
    description = UI.index('Ui.field(this, "Description"')
    assert name < phone < email < description
    assert "TYPE_CLASS_PHONE" in UI and "TYPE_TEXT_VARIATION_EMAIL_ADDRESS" in UI
    assert 'put("customer_phone",phone.trim())' in REPO
    assert 'put("customer_email",email.trim())' in REPO
    assert 'add("Customer phone",extra.optString("customer_phone"))' in REPO
    assert 'add("Customer email",extra.optString("customer_email"))' in REPO
    assert 'legacyHeaders + listOf("customer_phone", "customer_email")' in TRANSFER
    assert 'rows.first() in listOf(headers,legacyHeaders)' in TRANSFER
    print("PASS: 2.0.11 field order, keyboard types, schema migration, legacy preservation, document details, and transfer compatibility")


if __name__ == "__main__":
    main()
