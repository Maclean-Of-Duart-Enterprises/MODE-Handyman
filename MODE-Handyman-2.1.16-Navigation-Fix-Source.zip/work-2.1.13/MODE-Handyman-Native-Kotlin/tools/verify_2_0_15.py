#!/usr/bin/env python3
"""Host-side source verification for quote/invoice PDF layout changes."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PDF = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/export/PdfGenerator.kt").read_text()
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
BUILD = (ROOT / "app/build.gradle").read_text()

assert 'versionCode = 35' in BUILD and 'versionName = "2.1.13"' in BUILD
assert 'val jobSiteAddress: String = ""' in PDF
assert 'wrap("Job site address: ${document.jobSiteAddress.trim()}",body,235f)' in PDF
assert 'jobs.getOrNull(index)?.let { write(it,312f,y) }' in PDF
assert '140f/bitmap.width' in PDF and '50f/bitmap.height' in PDF
assert 'drawImage(approval.signature,"HANDWRITTEN SIGNATURE")' not in PDF
signed_index = PDF.index('paragraph("Signed by: ${approval.signer}",paint=bold)')
signature_index = PDF.index('drawSignature(approval.signature)')
approved_index = PDF.index('paragraph("Approved: ${approval.approvedAt}",paint=small)')
assert signed_index < signature_index < approved_index
assert 'ensure(125f)' in PDF
assert 'fun documentJobSiteAddress' in REPO
assert 'add("Job site address"' not in REPO
assert 'jobSiteAddress=repository.documentJobSiteAddress("quote",id)' in UI
assert 'jobSiteAddress=repository.documentJobSiteAddress("invoice",id)' in UI
print("PASS: 2.0.15 right-column job-site address and compact inline signature layout for quote/invoice PDFs")
