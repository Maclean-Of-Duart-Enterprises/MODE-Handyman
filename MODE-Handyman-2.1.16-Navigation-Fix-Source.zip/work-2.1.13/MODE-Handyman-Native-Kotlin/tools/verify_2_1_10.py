#!/usr/bin/env python3
"""Host-side verification for the 2.1.10 graphical calendar release."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()

assert 'versionCode = 35' in BUILD and 'versionName = "2.1.13"' in BUILD
assert 'private val calendarModes = listOf("Day", "Week", "2 weeks", "Month", "Year")' in UI
assert 'listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat").forEach' in UI
assert 'val weekRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;isBaselineAligned=false }' in UI
assert 'dayItems.take(if(calendarMode==3)3 else 5)' in UI
assert 'text="+${dayItems.size-(if(calendarMode==3)3 else 5)} more"' in UI
assert 'setOnClickListener { appointmentActions(appointment.id) }' in UI
assert 'setOnClickListener { calendarAnchor=day;calendarMode=0;refresh() }' in UI
assert 'baselineAligned=false' not in UI
print("PASS: 2.1.10 graphical day/week/two-week/month/year calendar, event actions, overflow display, and corrected week-row layout")
