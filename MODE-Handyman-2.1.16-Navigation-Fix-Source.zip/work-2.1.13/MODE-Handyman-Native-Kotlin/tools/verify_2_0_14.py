#!/usr/bin/env python3
"""Host-side schema and source verification for optional job-site addresses."""
from pathlib import Path
import shutil
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
MODELS = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/core/Models.kt").read_text()
assert "val jobSiteAddress: String = \"\"" in MODELS
number_index = UI.index('Ui.field(this,"Job number (letters and numbers)"')
address_index = UI.index('Ui.field(this,"Job site address (optional)"')
summary_index = UI.index('Ui.field(this, "Job summary"')
assert number_index < address_index < summary_index
assert 'put("job_site_address", draft.jobSiteAddress.trim())' in REPO
assert "documentJobSiteAddress" in REPO
assert "COALESCE(j.job_site_address,'') FROM quote" in REPO
assert "COALESCE(j.job_site_address,'') FROM invoice" in REPO

with tempfile.TemporaryDirectory() as directory:
    database = Path(directory) / "handyman.db"
    shutil.copy2(ASSETS / "handyman-template.db", database)
    db = sqlite3.connect(database)
    for version in (228, 229, 230, 231):
        db.executescript((ASSETS / f"v{version}.sql").read_text())
    db.execute("INSERT INTO business_profile(id,display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date) VALUES(1,'MODE','{}','{}','{}',1,'2026-10-25','2026-10-25')")
    job_id = db.execute(
        "INSERT INTO job(summary,description,billing_type,created_date,modified_date,profile_id,job_number) VALUES(?,?,?,?,?,?,?)",
        ("Existing job", "", "timeAndMaterial", "2026-10-25", "2026-10-25", 1, "J-EXISTING"),
    ).lastrowid
    db.executescript((ASSETS / "v232.sql").read_text())
    columns = {row[1] for row in db.execute("PRAGMA table_info(job)")}
    assert "job_site_address" in columns
    assert db.execute("SELECT job_site_address FROM job WHERE id=?", (job_id,)).fetchone()[0] == ""
    db.execute("UPDATE job SET job_site_address=? WHERE id=?", ("123 Job Site Road", job_id))
    assert db.execute("SELECT job_site_address FROM job WHERE id=?", (job_id,)).fetchone()[0] == "123 Job Site Road"
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"

print("PASS: 2.0.14 field order, optional storage, migration preservation, job display, and quote/invoice document inclusion")
