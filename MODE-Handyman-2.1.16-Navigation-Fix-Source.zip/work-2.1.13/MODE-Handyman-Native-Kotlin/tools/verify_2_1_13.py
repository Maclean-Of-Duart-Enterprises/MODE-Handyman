#!/usr/bin/env python3
"""Host-side verification for 2.1.13 offline routing and release identity."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = (ROOT / "app/build.gradle").read_text()
MANIFEST = (ROOT / "app/src/main/AndroidManifest.xml").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
ENGINE = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/routing/OfflineRoutingEngine.kt").read_text()

assert 'versionCode = 35' in BUILD and 'versionName = "2.1.13"' in BUILD
assert 'Native Kotlin edition 2.1.13' in UI
assert 'android.permission.INTERNET' in MANIFEST
assert 'Offline routing maps' in UI and 'Calculate driving distance offline' in UI
assert 'offlineRouter.route(from,to)' in UI
assert 'importMap(uri: Uri' in ENGINE and 'downloadMap(url: String' in ENGINE
assert 'PriorityQueue<QueueItem>' in ENGINE and 'heuristicSeconds' in ENGINE
assert 'org.xmlpull.v1.XmlPullParser' in ENGINE and 'GZIPInputStream' in ENGINE
assert 'oneway' in ENGINE and 'maxspeed' in ENGINE and 'addr:street' in ENGINE
assert 'No connected driving route was found' in ENGINE
for obsolete in ('nominatim.openstreetmap.org', 'router.project-osrm.org', 'fossgis_osrm_car'):
    assert obsolete not in UI and obsolete not in ENGINE
assert 'trip addresses are never sent to a geocoding or routing server' in UI
print('PASS: 2.1.13 embedded offline A* routing, OSM regional-map import/download/management, no public routing endpoints, and About version identity')
