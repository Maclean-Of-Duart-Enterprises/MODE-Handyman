#!/usr/bin/env python3
"""Host-side schema/migration/CRUD verification; requires no Android emulator."""
import datetime
import pathlib
import shutil
import sqlite3
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        database = pathlib.Path(directory) / "handyman.db"
        shutil.copy2(ASSETS / "handyman-template.db", database)
        db = sqlite3.connect(database)
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        db.execute(
            "INSERT INTO business_profile(display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",
            ("MODE Handyman", "{}", "{}", "{}", 1, now, now),
        )
        db.commit()
        db.executescript((ASSETS / "v228.sql").read_text())
        db.executescript((ASSETS / "v229.sql").read_text())
        db.executescript((ASSETS / "v230.sql").read_text())
        db.executescript((ASSETS / "v231.sql").read_text())
        db.executescript((ASSETS / "v232.sql").read_text())
        db.execute("PRAGMA user_version=232")
        db.execute("PRAGMA foreign_keys=ON")

        customer = db.execute(
            "INSERT INTO customer(name,primaryFirstName,secondaryFirstName,createdDate,modifiedDate,disbarred,customerType,exclude_from_mailings,description,mode_groups,mode_fields,default_hourly_rate,profile_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            ("Migration Test", "", "", now, now, 0, "residential", 0, "", "", "", 5000, 1),
        ).lastrowid
        job = db.execute(
            "INSERT INTO job(customer_id,summary,description,hourly_rate,booking_fee,last_active,billing_type,booking_fee_invoiced,created_date,modified_date,assumption,status_id,internal_notes,billing_party,is_stock,estimate_margin,profile_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (customer, "Test job", "", 5000, 0, 1, "timeAndMaterial", 0, now, now, "", "Prospecting", "", "customer", 0, 0, 1),
        ).lastrowid
        task = db.execute(
            "INSERT INTO task(job_id,name,description,task_status_id,createdDate,modifiedDate,billing_type,assumption,internal_notes,estimate_complete,effort_unit,effort_notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (job, "Test task", "", 1, now, now, "timeAndMaterial", "", "", 0, "", ""),
        ).lastrowid
        db.execute(
            "INSERT INTO task_item(task_id,description,item_type_id,estimated_price_mode,estimated_quantity,estimated_unit_cost,margin,total_line_charge,charge_mode,completed,billed,labour_entry_mode,is_return,created_date,modified_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (task, "Material", 1, "items", 1000, 1000, 0, 1000, "calculated", 0, 0, "hours", 0, now, now),
        )
        quote = db.execute(
            "INSERT INTO quote(job_id,total_amount,created_date,modified_date,quote_num,state,assumption,summary,description,quote_margin,mode_discount_cents,mode_tax_hundredths,mode_terms,profile_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (job, 1100, now, now, "Q-TEST", "reviewing", "", "", "", 0, 0, 1000, "", 1),
        ).lastrowid
        db.execute(
            "INSERT INTO quote_line(quote_id,description,quantity,unit_charge,line_total,created_date,modified_date,line_chargeable_status) VALUES(?,?,?,?,?,?,?,?)",
            (quote, "Work", 1000, 1000, 1000, now, now, "normal"),
        )
        db.execute(
            "INSERT INTO mode_smart_estimate_conversion(profile_id,estimate_id,job_id,quote_id,state,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",
            (1, 44, job, quote, "completed", now, now),
        )
        db.execute(
            "INSERT INTO mode_contract_approval(profile_id,customer_id,job_id,quote_id,smart_approval_id,signer_name,agreement_text,consent_text,approved_at,signature_file,contract_file,content_sha256,created_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (1, customer, job, quote, 9, "Customer", "Scope", "Consent", now, "/private/signature.png", "/private/contract.pdf", "a" * 64, now),
        )
        invoice = db.execute(
            "INSERT INTO invoice(job_id,total_amount,created_date,modified_date,invoice_num,due_date,sent,paid,external_sync_status,payment_source,profile_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (job, 1000, now, now, "I-TEST", "2026-11-01", 0, 0, 0, 0, 1),
        ).lastrowid
        db.execute(
            "INSERT INTO invoice_line(invoice_id,description,quantity,unit_price,line_total,created_date,modified_date,status,from_booking_fee,tax_amount) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (invoice, "Work", 1000, 1000, 1000, now, now, "active", 0, 0),
        )
        payment = db.execute(
            "INSERT INTO debtor_payment(customer_id,payment_date,amount,payment_method,reference,notes,created_date,modified_date) VALUES(?,?,?,?,?,?,?,?)",
            (customer, "2026-10-24", 1000, "Cash", "", "", now, now),
        ).lastrowid
        db.execute(
            "INSERT INTO debtor_payment_allocation(payment_id,invoice_id,amount,allocated_date,created_date,modified_date) VALUES(?,?,?,?,?,?)",
            (payment, invoice, 1000, "2026-10-24", now, now),
        )
        db.execute(
            "INSERT INTO to_do(title,note,due_date,priority,status,created_date,modified_date,profile_id) VALUES(?,?,?,?,?,?,?,?)",
            ("Call client", "", "2026-10-25", "medium", "open", now, now, 1),
        )
        db.execute(
            "INSERT INTO job_activity(job_id,start_date,end_date,notes,status,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",
            (job, "2026-10-25T09:00:00", "2026-10-25T10:00:00", "", "scheduled", now, now),
        )
        db.commit()
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        assert db.execute("PRAGMA user_version").fetchone()[0] == 232
        assert db.execute("SELECT COUNT(*) FROM customer WHERE profile_id=1").fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM quote_line WHERE quote_id=?", (quote,)).fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM debtor_payment_allocation WHERE invoice_id=?", (invoice,)).fetchone()[0] == 1
        invoice_total, paid_total = db.execute(
            "SELECT i.total_amount,COALESCE(SUM(a.amount),0) FROM invoice i LEFT JOIN debtor_payment_allocation a ON a.invoice_id=i.id WHERE i.id=? GROUP BY i.id",
            (invoice,),
        ).fetchone()
        assert invoice_total == 1000
        assert paid_total == 1000
        assert max(invoice_total - paid_total, 0) == 0
        assert db.execute("SELECT quote_id FROM mode_smart_estimate_conversion WHERE estimate_id=44").fetchone()[0] == quote
        assert db.execute("SELECT customer_id,job_id,quote_id FROM mode_contract_approval WHERE smart_approval_id=9").fetchone() == (customer, job, quote)
        try:
            db.execute(
                "INSERT INTO mode_smart_estimate_conversion(profile_id,estimate_id,job_id,quote_id,state,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",
                (1, 44, job, quote, "completed", now, now),
            )
        except sqlite3.IntegrityError:
            pass
        else:
            raise AssertionError("duplicate estimate conversion was accepted")
        print("PASS: schema 232, integrity, foreign keys, zero paid-invoice balance, conversion uniqueness, contract linkage, and representative CRUD")


if __name__ == "__main__":
    main()
