#!/usr/bin/env python3
"""Host-side verification of the 2.0.10 contacts, numbering, CRUD and signature work."""
from pathlib import Path
import shutil
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets"
REPO = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/data/ModeRepository.kt").read_text()
UI = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/ui/MainActivity.kt").read_text()
PDF = (ROOT / "app/src/main/kotlin/com/macleanofduartenterprises/modehandyman/export/PdfGenerator.kt").read_text()
BUILD = (ROOT / "app/build.gradle").read_text()

with tempfile.TemporaryDirectory() as directory:
    database = Path(directory) / "handyman.db"
    shutil.copy2(ASSETS / "handyman-template.db", database)
    db = sqlite3.connect(database)
    db.execute("PRAGMA foreign_keys=ON")
    now = "2026-10-25T00:00:00Z"
    db.execute("INSERT INTO business_profile(display_name,configuration_json,preferences_json,trip_settings_json,active,created_date,modified_date) VALUES(?,?,?,?,?,?,?)",("Test","{}","{}","{}",1,now,now))
    for version in (228, 229, 230, 231, 232):
        db.executescript((ASSETS / f"v{version}.sql").read_text())
    db.execute("PRAGMA user_version=232")

    contact_columns = {row[1] for row in db.execute("PRAGMA table_info(contact)")}
    job_columns = {row[1] for row in db.execute("PRAGMA table_info(job)")}
    assert {"mobileNumber", "emailAddress", "alternateEmail", "landLine", "officeNumber", "customer_number"} <= contact_columns
    assert "job_number" in job_columns
    assert db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='mode_document_signature'").fetchone()
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert not list(db.execute("PRAGMA foreign_key_check"))

assert "RecordRequirements.validateContact" in REPO
assert "RecordRequirements.requireJobNumber" in REPO
assert 'put("quote_num", "$jobNumber-Q-$next")' in REPO
assert 'put("invoice_num", "$jobNumber-I-$next")' in REPO
assert "cascadeDelete(table,id,mutableSetOf())" in REPO
assert "Deletion is restricted for records" not in REPO
assert "updateDocumentLine" in REPO and "deleteDocumentLine" in REPO
assert "saveDocumentSignature" in REPO and "removeDocumentSignature" in REPO
assert "SignaturePad(this)" in UI and "Capture customer signature" in UI
assert 'approval=signature' in UI
assert "drawSignature" in PDF
print("PASS: 2.0.10 schema compatibility, contact validation, editable job numbering, CRUD/cascade paths, line editing, signature capture and PDF embedding")
