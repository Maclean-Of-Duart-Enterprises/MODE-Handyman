# MODE Handyman 2.1.3

- Live job timer: refreshes running entry durations and total tracked time every second while the job screen remains visible.
- The live display uses current time and persisted start/end timestamps; it does not accumulate ticks, so delayed callbacks do not distort elapsed time.
- Stops UI callbacks when navigating away, pausing or destroying the activity; reattaches when resuming the job screen.
- Keeps manual entries, notes, editing, stopping and billed-entry protections from 2.1.2.
- Fixed the missing nested `JobTimeEntry` model import that previously prevented debug and release Kotlin compilation.
- Version code 25.

Verification: clean debug/release compilation, JVM unit tests, Android lint, release shrinking, signing, source regression checks and APK verification completed. No emulator or physical-device UI testing was performed.
