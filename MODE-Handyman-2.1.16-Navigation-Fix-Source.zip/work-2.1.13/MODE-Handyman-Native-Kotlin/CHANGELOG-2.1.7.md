# MODE Handyman 2.1.7 — Unlimited appointment reminders

- Removed the unique appointment/kind database constraint while preserving existing reminder IDs and records.
- Added independent, repeatable reminder rows with Android graphical date/time picker, enable/disable, and delete controls.
- Each enabled reminder is scheduled as an independent local alarm; editing an appointment cancels and recreates its alarms.
- Boot recovery schedules enabled future reminders only.
- Source-only update; Android compilation and device testing not performed.
